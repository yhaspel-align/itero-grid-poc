import * as i0 from "@angular/core";
export declare class IuiCheckboxGroupComponent {
    label: string;
    showLabel: boolean;
    orientation: 'vertical' | 'horizontal';
    required: boolean;
    levels: '1' | '2';
    readonly _labelId: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiCheckboxGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiCheckboxGroupComponent, "iui-checkbox-group", never, { "label": { "alias": "label"; "required": false; }; "showLabel": { "alias": "showLabel"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "required": { "alias": "required"; "required": false; }; "levels": { "alias": "levels"; "required": false; }; }, {}, never, ["*"], true, never>;
}
