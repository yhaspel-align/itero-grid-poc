import { IuiTooltipAlignment, IuiTooltipPlacement } from './iui-tooltip.component';
import * as i0 from "@angular/core";
export declare class IuiTooltipIconTriggerComponent {
    text: string;
    placement: IuiTooltipPlacement;
    alignment: IuiTooltipAlignment;
    protected _visible: boolean;
    protected _show(): void;
    protected _hide(): void;
    protected get _tooltipStyle(): Record<string, string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiTooltipIconTriggerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiTooltipIconTriggerComponent, "iui-tooltip-icon-trigger", never, { "text": { "alias": "text"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; }, {}, never, never, true, never>;
}
export declare function _getTooltipStyle(placement: IuiTooltipPlacement, alignment: IuiTooltipAlignment): Record<string, string>;
