import * as i0 from "@angular/core";
export type IuiTooltipPlacement = 'top' | 'bottom' | 'left' | 'right';
export type IuiTooltipAlignment = 'start' | 'middle' | 'end';
export declare class IuiTooltipComponent {
    placement: IuiTooltipPlacement;
    alignment: IuiTooltipAlignment;
    showCaret: boolean;
    text: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiTooltipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiTooltipComponent, "iui-tooltip", never, { "placement": { "alias": "placement"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; "showCaret": { "alias": "showCaret"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, ["*"], true, never>;
}
