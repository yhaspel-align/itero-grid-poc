import { ApplicationRef, ElementRef, EnvironmentInjector, OnDestroy } from '@angular/core';
import { IuiTooltipAlignment, IuiTooltipPlacement } from './iui-tooltip.component';
import * as i0 from "@angular/core";
export declare class IuiTooltipDirective implements OnDestroy {
    private _el;
    private _appRef;
    private _injector;
    tooltipText: string;
    iuiTooltipPlacement: IuiTooltipPlacement;
    iuiTooltipAlignment: IuiTooltipAlignment;
    iuiTooltipShowCaret: boolean;
    iuiTooltipDelay: number;
    private _tooltipRef;
    private _showTimeout;
    private _hideTimeout;
    private _tooltipId;
    constructor(_el: ElementRef<HTMLElement>, _appRef: ApplicationRef, _injector: EnvironmentInjector);
    show(): void;
    hide(): void;
    onEscape(): void;
    private _createTooltip;
    private _positionTooltip;
    private _destroyTooltip;
    private _clearShowTimeout;
    private _clearHideTimeout;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiTooltipDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IuiTooltipDirective, "[iuiTooltip]", never, { "tooltipText": { "alias": "iuiTooltip"; "required": false; }; "iuiTooltipPlacement": { "alias": "iuiTooltipPlacement"; "required": false; }; "iuiTooltipAlignment": { "alias": "iuiTooltipAlignment"; "required": false; }; "iuiTooltipShowCaret": { "alias": "iuiTooltipShowCaret"; "required": false; }; "iuiTooltipDelay": { "alias": "iuiTooltipDelay"; "required": false; }; }, {}, never, never, true, never>;
}
