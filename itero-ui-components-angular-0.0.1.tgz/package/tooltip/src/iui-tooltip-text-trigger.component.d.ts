import { IuiTooltipAlignment } from './iui-tooltip.component';
import * as i0 from "@angular/core";
export type IuiTooltipTextTriggerPosition = 'top' | 'bottom';
export declare class IuiTooltipTextTriggerComponent {
    text: string;
    triggerText: string;
    position: IuiTooltipTextTriggerPosition;
    alignment: IuiTooltipAlignment;
    protected _visible: boolean;
    protected _show(): void;
    protected _hide(): void;
    protected get _tooltipStyle(): Record<string, string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiTooltipTextTriggerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiTooltipTextTriggerComponent, "iui-tooltip-text-trigger", never, { "text": { "alias": "text"; "required": false; }; "triggerText": { "alias": "triggerText"; "required": false; }; "position": { "alias": "position"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; }, {}, never, never, true, never>;
}
