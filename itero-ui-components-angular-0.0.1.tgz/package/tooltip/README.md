﻿# iui-tooltip

A tooltip component for displaying brief contextual information on hover or focus.

## Components

| Component | Tag | Description |
|-----------|-----|------------|
| `IuiTooltipComponent` | `<iui-tooltip>` | Tooltip container with caret |
| `IuiTooltipDirective` | `[iuiTooltip]` | Directive for any element |
| `IuiTooltipIconTriggerComponent` | `<iui-tooltip-icon-trigger>` | Icon trigger with tooltip |
| `IuiTooltipTextTriggerComponent` | `<iui-tooltip-text-trigger>` | Text with dashed underline |

## Import

```typescript
import { IuiTooltipComponent, IuiTooltipDirective, IuiTooltipIconTriggerComponent, IuiTooltipTextTriggerComponent } from '@itero/ui-components-angular/tooltip';
```

## Usage

### Directive (arbitrary element)

```html
<button iuiTooltip="Tooltip text">Hover me</button>
```

### Icon trigger

```html
<iui-tooltip-icon-trigger
  text="Additional information"
  placement="bottom"
  alignment="middle">
</iui-tooltip-icon-trigger>
```

### Text trigger

```html
<iui-tooltip-text-trigger
  triggerText="Term"
  text="Definition of the term"
  position="bottom"
  alignment="middle">
</iui-tooltip-text-trigger>
```

### Standalone component

```html
<iui-tooltip
  text="Tooltip text"
  placement="bottom"
  alignment="start"
  [showCaret]="true">
</iui-tooltip>
```

## `iui-tooltip` Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|------------|
| `text` | `string` | `''` | Tooltip text |
| `placement` | `'top' \| 'bottom' \| 'left' \| 'right'` | `'bottom'` | Position relative to trigger |
| `alignment` | `'start' \| 'middle' \| 'end'` | `'start'` | Alignment along the trigger axis |
| `showCaret` | `boolean` | `true` | Show directional caret |

## `[iuiTooltip]` Directive Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|------------|
| `iuiTooltip` | `string` | `''` | Tooltip text |
| `iuiTooltipPlacement` | `IuiTooltipPlacement` | `'top'` | Position |
| `iuiTooltipAlignment` | `IuiTooltipAlignment` | `'middle'` | Alignment |
| `iuiTooltipShowCaret` | `boolean` | `true` | Show caret |
| `iuiTooltipDelay` | `number` | `300` | Appearance delay (ms) |
