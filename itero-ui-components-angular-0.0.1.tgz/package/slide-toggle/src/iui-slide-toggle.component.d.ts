import { EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
export interface IuiSlideToggleEvent {
    event: Event;
    checked: boolean;
}
export declare class IuiSlideToggleComponent implements ControlValueAccessor {
    /** The unique id of the element */
    id: string;
    get _inputId(): string;
    get _labelId(): string;
    /**
     * input where you can pass desirable state of slide-toggle "true" or "false".
     * Can be helpful when you don't use formControl, otherwise you can patchValue of formControl
     * */
    set checked(value: boolean);
    get checked(): boolean;
    /** Position of the label rendered with slide-toggle can be 'left' or right'. Default is left */
    labelPosition: 'left' | 'right';
    /** Whether to show the skeleton loading state */
    skeleton: boolean;
    /** Whether to show the value/label text. Default: true */
    showValue: boolean;
    get disabled(): boolean;
    get effectivelyDisabled(): boolean;
    private _touched;
    private _checked;
    private isDisabledDirective;
    changeEvent: EventEmitter<IuiSlideToggleEvent>;
    _blurHandler(): void;
    private _markAsTouched;
    private _propagateChange;
    private _propagateTouched;
    _changeHandler(event: Event): void;
    writeValue(val: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiSlideToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiSlideToggleComponent, "iui-slide-toggle", never, { "id": { "alias": "id"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "skeleton": { "alias": "skeleton"; "required": false; }; "showValue": { "alias": "showValue"; "required": false; }; }, { "changeEvent": "changeEvent"; }, never, ["*"], true, [{ directive: typeof i1.NgControlDirective; inputs: {}; outputs: {}; }, { directive: typeof i1.IuiIsDisabledDirective; inputs: { "isDisabled": "isDisabled"; }; outputs: { "disableChangeEvent": "disableChangeEvent"; }; }]>;
}
