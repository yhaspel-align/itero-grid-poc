# Link

Secondary entry point of `@itero/ui-components-angular`. It can be used by importing the following:

```
import { IuiLinkComponent } from '@itero/ui-components-angular/link';
```
