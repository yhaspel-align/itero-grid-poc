import * as i0 from "@angular/core";
export type IuiLinkType = 'primary' | 'secondary' | 'inversed' | 'on-color';
export type IuiLinkSize = 'm' | 's';
export declare class IuiLinkComponent {
    /** Color variant */
    type: IuiLinkType;
    /** Link size */
    size: IuiLinkSize;
    /** Disabled state */
    disabled: boolean;
    /** Adds external-link arrow icon after text */
    external: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiLinkComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiLinkComponent, "a[iuiLink]", never, { "type": { "alias": "type"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "external": { "alias": "external"; "required": false; }; }, {}, never, ["*"], true, never>;
}
