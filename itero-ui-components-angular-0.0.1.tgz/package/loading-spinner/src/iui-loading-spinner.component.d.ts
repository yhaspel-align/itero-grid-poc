import * as i0 from "@angular/core";
export type IuiSpinnerSize = 'large' | 'small';
export declare class IuiLoadingSpinnerComponent {
    size: IuiSpinnerSize | number | string;
    onColor: boolean;
    overlay: boolean;
    get resolvedSize(): IuiSpinnerSize;
    get diameter(): number;
    get strokeWidth(): number;
    get viewBox(): string;
    get center(): number;
    get radius(): number;
    get strokeDasharray(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiLoadingSpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiLoadingSpinnerComponent, "iui-loading-spinner", never, { "size": { "alias": "size"; "required": false; }; "onColor": { "alias": "onColor"; "required": false; }; "overlay": { "alias": "overlay"; "required": false; }; }, {}, never, never, true, never>;
}
