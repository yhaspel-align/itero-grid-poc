import { EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
export interface IuiCheckboxEvent {
    event: Event;
    checked: boolean;
}
type IuiCheckboxPropagateChangeType = (_: boolean) => void;
type IuiCheckboxPropagateTouchedType = () => void;
export declare class IuiCheckboxComponent implements ControlValueAccessor {
    /** The unique id of the element */
    id: string;
    showValue: boolean;
    skeleton: boolean;
    /**
     * @prop
     * @ignore
     */
    get _markId(): string;
    /**
     * @prop
     * @ignore
     */
    get _labelId(): string;
    /**
     * input where you can pass desirable state of checkbox "true" or "false".
     * Can be helpful when you don't use formControl, otherwise you can patchValue of formControl
     * */
    set checked(value: boolean);
    get checked(): boolean;
    set indeterminate(value: boolean);
    get indeterminate(): boolean;
    get disabled(): boolean;
    /**
     * @prop
     * @ignore
     */
    private _touched;
    /**
     * @prop
     * @ignore
     */
    private _checked;
    /**
     * @prop
     * @ignore
     */
    private _indeterminate;
    /**
     * @prop
     * @ignore
     */
    private isDisabledDirective;
    changeEvent: EventEmitter<IuiCheckboxEvent>;
    indeterminateChanged: EventEmitter<boolean>;
    /**
     * @method
     * @ignore
     */
    _blurHandler(): void;
    /**
     * @method
     * @ignore
     */
    private setIndeterminateInternal;
    /**
     * @method
     * @ignore
     */
    private markAsTouched;
    /**
     * @prop
     * @ignore
     */
    private propagateChange;
    /**
     * @prop
     * @ignore
     */
    private propagateTouched;
    /**
     * @method
     * @ignore
     */
    _changeHandler(event: Event): void;
    writeValue(val: boolean): void;
    registerOnChange(fn: IuiCheckboxPropagateChangeType): void;
    registerOnTouched(fn: IuiCheckboxPropagateTouchedType): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiCheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiCheckboxComponent, "iui-checkbox", never, { "id": { "alias": "id"; "required": false; }; "showValue": { "alias": "showValue"; "required": false; }; "skeleton": { "alias": "skeleton"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "indeterminate": { "alias": "indeterminate"; "required": false; }; }, { "changeEvent": "changeEvent"; "indeterminateChanged": "indeterminateChanged"; }, never, ["*", "[description]"], true, [{ directive: typeof i1.NgControlDirective; inputs: {}; outputs: {}; }, { directive: typeof i1.IuiIsDisabledDirective; inputs: { "isDisabled": "isDisabled"; }; outputs: { "disableChangeEvent": "disableChangeEvent"; }; }]>;
}
export {};
