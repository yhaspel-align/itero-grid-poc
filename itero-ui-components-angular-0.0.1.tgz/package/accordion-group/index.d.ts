export * from './src/iui-accordion-group.component';
