import { CdkAccordion } from '@angular/cdk/accordion';
import { IuiAccordionStyle } from '@itero/ui-components-angular/accordion';
import * as i0 from "@angular/core";
export declare class IuiAccordionGroupComponent extends CdkAccordion {
    style: IuiAccordionStyle;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiAccordionGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiAccordionGroupComponent, "iui-accordion-group", never, { "style": { "alias": "style"; "required": false; }; }, {}, never, ["*"], true, never>;
}
