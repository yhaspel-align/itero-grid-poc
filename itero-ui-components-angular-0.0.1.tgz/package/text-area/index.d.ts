export * from './src/iui-text-area.component';
