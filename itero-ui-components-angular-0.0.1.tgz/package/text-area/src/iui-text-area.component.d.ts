import { ChangeDetectorRef, ElementRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
export type TextAreaLayerSet = 'set-01' | 'set-02';
type ValueType = string | null;
export declare class IuiTextAreaComponent implements ControlValueAccessor {
    protected _changeDetectorRef: ChangeDetectorRef;
    protected ngControlDirective: NgControlDirective<ValueType>;
    protected errorStateMatcherDirective: IuiErrorStateMatcherDirective;
    protected isDisabledDirective: IuiIsDisabledDirective;
    /** The ref to the native textarea element. */
    textareaElement: ElementRef<HTMLTextAreaElement> | undefined;
    /** Unique id of the element. */
    set id(value: string);
    get id(): string;
    /** Label text. Leave empty to hide the label. */
    label: string;
    /** Placeholder text passed to the native textarea. */
    placeholder: string;
    /** Name attribute passed to the native textarea. */
    name: string;
    /** Autocomplete attribute. */
    autocomplete: string | null;
    /** Layer set background variant: set-01 (white, default) or set-02 (gray). */
    layerSet: TextAreaLayerSet;
    /** Whether to show the character counter in the label row. */
    showCounter: boolean;
    /** Maximum character length. Shown in counter as current/max. */
    maxLength: number | null;
    /** Whether to show the skeleton loading state. */
    skeleton: boolean;
    /** Whether to show a clear icon when the field has a value and is not disabled. */
    cancelable: boolean;
    /** When non-empty, renders an info icon next to the label wired to an iui-tooltip. */
    explainerText: string;
    /** Minimum number of visible rows. Also acts as the lower bound for auto-grow. */
    rows: number;
    /** When true, the textarea height grows to fit content (capped by maxRows). */
    get autoGrow(): boolean;
    set autoGrow(value: boolean | string);
    /** Upper bound (in rows) for auto-grow. null means unlimited. */
    maxRows: number | null;
    /** Whether the component is required. Derived from Validators.required or explicit Input. */
    get required(): boolean;
    set required(value: string | boolean | null | undefined);
    get _labelId(): string;
    get _textareaId(): string;
    get disabled(): boolean;
    get _errorState(): boolean;
    get empty(): boolean;
    get _counterText(): string;
    get _focused(): boolean;
    /** Whether the auto-grow height has been capped at maxRows. */
    get _maxRowsReached(): boolean;
    constructor(_changeDetectorRef: ChangeDetectorRef, ngControlDirective: NgControlDirective<ValueType>, errorStateMatcherDirective: IuiErrorStateMatcherDirective, isDisabledDirective: IuiIsDisabledDirective);
    private __value;
    private _required;
    private __focused;
    private __maxRowsReached;
    private _autoGrow;
    _id: string;
    /** View → model callback called when value changes. */
    _onChange: (value: ValueType) => void;
    /** View → model callback called when the control has been touched. */
    _onTouched: () => void;
    get _value(): ValueType;
    set _value(newValue: ValueType);
    _onFocus(): void;
    _onBlur(): void;
    _focusTextarea(el: HTMLTextAreaElement | undefined): void;
    _clearValue(event: MouseEvent): void;
    modelChangeHandler(value: ValueType): void;
    writeValue(value: ValueType): void;
    registerOnChange(fn: (value: ValueType) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    private _assignValue;
    /**
     * Adjusts the textarea height to fit its content when autoGrow is enabled.
     * Clamps height to maxRows if set. When the cap is reached, sets the
     * _maxRowsReached flag so that overflow-y: auto kicks in via CSS.
     */
    private _adjustHeight;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiTextAreaComponent, [null, { self: true; }, { self: true; }, { self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiTextAreaComponent, "iui-text-area", never, { "id": { "alias": "id"; "required": false; }; "label": { "alias": "label"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "name": { "alias": "name"; "required": false; }; "autocomplete": { "alias": "autocomplete"; "required": false; }; "layerSet": { "alias": "layerSet"; "required": false; }; "showCounter": { "alias": "showCounter"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "skeleton": { "alias": "skeleton"; "required": false; }; "cancelable": { "alias": "cancelable"; "required": false; }; "explainerText": { "alias": "explainerText"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "autoGrow": { "alias": "autoGrow"; "required": false; }; "maxRows": { "alias": "maxRows"; "required": false; }; "required": { "alias": "required"; "required": false; }; }, {}, never, ["[iui-error]", "[iui-hint]"], true, [{ directive: typeof i1.NgControlDirective; inputs: {}; outputs: {}; }, { directive: typeof i1.IuiErrorStateMatcherDirective; inputs: { "errorStateMatcher": "errorStateMatcher"; }; outputs: {}; }, { directive: typeof i1.IuiIsDisabledDirective; inputs: { "isDisabled": "isDisabled"; }; outputs: { "disableChangeEvent": "disableChangeEvent"; }; }]>;
}
export {};
