import { AfterViewInit, ElementRef, OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
export type IuiButtonType = 'brand' | 'danger' | 'success';
export type IuiButtonEmphasis = 'primary' | 'secondary' | 'ghost';
export type IuiButtonSize = 'l' | 'm' | 's';
export declare class IuiButtonComponent implements AfterViewInit, OnDestroy {
    /** Color type axis */
    type: IuiButtonType;
    /** Visual weight axis */
    emphasis: IuiButtonEmphasis;
    /** Button size */
    size: IuiButtonSize;
    /** Disabled state */
    disabled: boolean;
    /** Shows spinner and prevents interaction */
    loading: boolean;
    /** Adds a chevron dropdown icon after the label */
    menu: boolean;
    innerSpan: ElementRef<HTMLElement> | undefined;
    private elRef;
    private renderer;
    private subscription;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private checkTextContent;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiButtonComponent, "button[iuiButton]", never, { "type": { "alias": "type"; "required": false; }; "emphasis": { "alias": "emphasis"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "menu": { "alias": "menu"; "required": false; }; }, {}, never, ["*"], true, never>;
}
