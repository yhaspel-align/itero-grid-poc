export * from './src/iui-button.component';
