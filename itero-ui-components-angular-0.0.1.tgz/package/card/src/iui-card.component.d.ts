import * as i0 from "@angular/core";
export declare class IuiCardComponent {
    set padding(value: number);
    _padding?: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiCardComponent, "iui-card", never, { "padding": { "alias": "padding"; "required": false; }; }, {}, never, ["*"], true, never>;
}
