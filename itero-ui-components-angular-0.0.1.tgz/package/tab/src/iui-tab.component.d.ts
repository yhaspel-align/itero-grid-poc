import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class IuiTabComponent {
    label: string;
    disabled: boolean;
    showBadge: boolean;
    content: TemplateRef<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiTabComponent, "iui-tab", never, { "label": { "alias": "label"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "showBadge": { "alias": "showBadge"; "required": false; }; }, {}, never, ["*"], true, never>;
}
