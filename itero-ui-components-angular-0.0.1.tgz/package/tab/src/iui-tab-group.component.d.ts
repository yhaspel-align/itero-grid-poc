import { AfterContentInit, ElementRef, EventEmitter, OnChanges, OnDestroy, QueryList, SimpleChanges } from '@angular/core';
import { IuiTabComponent } from './iui-tab.component';
import { IuiTabChangeEvent } from './iui-tab.types';
import * as i0 from "@angular/core";
export declare class IuiTabGroupComponent implements AfterContentInit, OnChanges, OnDestroy {
    private el;
    tabs: QueryList<IuiTabComponent>;
    selectedIndex: number;
    scrollable: boolean;
    selectedIndexChange: EventEmitter<number>;
    tabChange: EventEmitter<IuiTabChangeEvent>;
    /** Tracks the DOM-focused tab index for keyboard navigation (may differ from selected). */
    focusedIndex: number;
    private tabsSubscription?;
    constructor(el: ElementRef<HTMLElement>);
    ngAfterContentInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    selectTab(index: number): void;
    onKeyDown(event: KeyboardEvent, currentIndex: number): void;
    private focusDomTab;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiTabGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiTabGroupComponent, "iui-tab-group", never, { "selectedIndex": { "alias": "selectedIndex"; "required": false; }; "scrollable": { "alias": "scrollable"; "required": false; }; }, { "selectedIndexChange": "selectedIndexChange"; "tabChange": "tabChange"; }, ["tabs"], never, true, never>;
}
