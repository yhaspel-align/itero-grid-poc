export type IuiTabState = 'enabled' | 'hovered' | 'focused' | 'selected' | 'disabled';
export interface IuiTabChangeEvent {
    previousIndex: number;
    index: number;
}
