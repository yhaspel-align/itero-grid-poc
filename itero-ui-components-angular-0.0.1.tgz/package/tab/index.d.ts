export * from './src/iui-tab.component';
export * from './src/iui-tab-group.component';
export * from './src/iui-tab.types';
