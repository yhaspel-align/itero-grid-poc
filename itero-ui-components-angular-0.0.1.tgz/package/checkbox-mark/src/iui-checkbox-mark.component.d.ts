import { ElementRef, EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
export interface IuiCheckboxMarkEvent {
    event: Event;
    checked: boolean;
}
export type IuiCheckboxMarkPropagateChangeType = (_: boolean) => void;
export type IuiCheckboxMarkPropagateTouchedType = () => void;
export declare class IuiCheckboxMarkComponent implements ControlValueAccessor {
    checkboxInput?: ElementRef<HTMLInputElement>;
    /** The unique id of the element */
    id: string;
    skeleton: boolean;
    blurEvent: EventEmitter<Event>;
    /**
     * @prop
     * @ignore
     */
    get _inputId(): string;
    /**
     * input where you can pass desirable state of checkbox "true" or "false".
     * Can be helpful when you don't use formControl, otherwise you can patchValue of formControl
     * */
    set checked(value: boolean);
    get checked(): boolean;
    set indeterminate(value: boolean);
    get indeterminate(): boolean;
    get disabled(): boolean;
    /**
     * @prop
     * @ignore
     */
    private _touched;
    /**
     * @prop
     * @ignore
     */
    private _checked;
    /**
     * @prop
     * @ignore
     */
    private _indeterminate;
    /**
     * @prop
     * @ignore
     */
    private isDisabledDirective;
    changeEvent: EventEmitter<IuiCheckboxMarkEvent>;
    indeterminateChanged: EventEmitter<boolean>;
    /**
     * @method
     * @ignore
     */
    _blurHandler(event: Event): void;
    /**
     * @method
     * @ignore
     */
    private setIndeterminateInternal;
    /**
     * @method
     * @ignore
     */
    private markAsTouched;
    /**
     * @prop
     * @ignore
     */
    private propagateChange;
    /**
     * @prop
     * @ignore
     */
    private propagateTouched;
    /**
     * @method
     * @ignore
     */
    _changeHandler(event: Event): void;
    writeValue(val: boolean): void;
    registerOnChange(fn: IuiCheckboxMarkPropagateChangeType): void;
    registerOnTouched(fn: IuiCheckboxMarkPropagateTouchedType): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiCheckboxMarkComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiCheckboxMarkComponent, "iui-checkbox-mark", never, { "id": { "alias": "id"; "required": false; }; "skeleton": { "alias": "skeleton"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "indeterminate": { "alias": "indeterminate"; "required": false; }; }, { "blurEvent": "blurEvent"; "changeEvent": "changeEvent"; "indeterminateChanged": "indeterminateChanged"; }, never, never, true, [{ directive: typeof i1.NgControlDirective; inputs: {}; outputs: {}; }, { directive: typeof i1.IuiIsDisabledDirective; inputs: { "isDisabled": "isDisabled"; }; outputs: { "disableChangeEvent": "disableChangeEvent"; }; }]>;
}
