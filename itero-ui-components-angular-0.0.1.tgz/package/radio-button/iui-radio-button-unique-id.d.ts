import * as i0 from "@angular/core";
export declare class IuiRadioButtonUniqueIdService {
    private nextUniqueId;
    getRadioButtonGroupId(): number;
    getRadioButtonId(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiRadioButtonUniqueIdService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IuiRadioButtonUniqueIdService>;
}
