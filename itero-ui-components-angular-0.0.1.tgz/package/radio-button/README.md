# @itero/ui-components-angular/radio-button

Secondary entry point of `@itero/ui-components-angular`. It can be used by importing from `@itero/ui-components-angular/radio-button`.
