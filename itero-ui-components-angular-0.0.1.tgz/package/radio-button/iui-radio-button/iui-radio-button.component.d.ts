import { UniqueSelectionDispatcher } from '@angular/cdk/collections';
import { ChangeDetectorRef, EventEmitter, OnInit } from '@angular/core';
import { IuiRadioGroupComponent } from '../iui-radio-group/iui-radio-group.component';
import { IuiRadioButtonUniqueIdService } from '../iui-radio-button-unique-id';
import * as i0 from "@angular/core";
export declare class IuiRadioButtonComponent implements OnInit {
    private radioGroup;
    private changeDetector;
    private nextUniqueId;
    private radioDispatcher;
    id: string;
    value: any;
    label: string;
    description: string;
    name: string;
    arialabel: string;
    arialabelledby: string;
    showValue: boolean;
    skeleton: boolean;
    private _required;
    private _checked;
    private _disabled;
    set disabled(value: boolean);
    get disabled(): boolean;
    _change: EventEmitter<any>;
    get change(): EventEmitter<any>;
    get checked(): boolean;
    set checked(state: boolean);
    get required(): boolean;
    set required(value: boolean);
    constructor(radioGroup: IuiRadioGroupComponent, changeDetector: ChangeDetectorRef, nextUniqueId: IuiRadioButtonUniqueIdService, radioDispatcher: UniqueSelectionDispatcher);
    ngOnInit(): void;
    onChange(event: Event): void;
    /** Marks the component for change detection */
    markForCheck(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiRadioButtonComponent, [{ optional: true; }, null, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiRadioButtonComponent, "iui-radio-button", never, { "id": { "alias": "id"; "required": false; }; "value": { "alias": "value"; "required": false; }; "label": { "alias": "label"; "required": false; }; "description": { "alias": "description"; "required": false; }; "name": { "alias": "name"; "required": false; }; "arialabel": { "alias": "arialabel"; "required": false; }; "arialabelledby": { "alias": "arialabelledby"; "required": false; }; "showValue": { "alias": "showValue"; "required": false; }; "skeleton": { "alias": "skeleton"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "required": { "alias": "required"; "required": false; }; }, { "_change": "_change"; }, never, never, true, never>;
}
