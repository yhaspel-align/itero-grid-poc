import { CdkListbox } from '@angular/cdk/listbox';
import { BooleanInput } from '@angular/cdk/coercion';
import { AfterContentInit, OnChanges, SimpleChanges } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { IuiListboxOptionComponent, IuiListboxOptionSize } from './option/iui-listbox-option.component';
import * as i0 from "@angular/core";
export type IuiListOptionTogglePosition = 'before' | 'after';
export declare class IuiListboxComponent extends CdkListbox<IuiListboxOptionComponent> implements OnChanges, AfterContentInit, ControlValueAccessor {
    size: IuiListboxOptionSize;
    get multipleSelection(): boolean;
    set multipleSelection(value: BooleanInput);
    hideSelectionIndicator: boolean;
    togglePosition: IuiListOptionTogglePosition;
    private _changeDetectorRef;
    /**
     * @method
     * @ignore
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * @method
     * @ignore
     */
    ngAfterContentInit(): void;
    /**
     * @method
     * @ignore
     */
    private updateChildren;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiListboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiListboxComponent, "iui-listbox", never, { "size": { "alias": "size"; "required": false; }; "multipleSelection": { "alias": "multiple"; "required": false; }; "hideSelectionIndicator": { "alias": "hideSelectionIndicator"; "required": false; }; "togglePosition": { "alias": "togglePosition"; "required": false; }; }, {}, never, ["iui-listbox-option"], true, never>;
}
