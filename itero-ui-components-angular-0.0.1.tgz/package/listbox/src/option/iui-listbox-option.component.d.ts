import { IuiListOptionTogglePosition } from '../iui-listbox.component';
import { CdkOption } from '@angular/cdk/listbox';
import * as i0 from "@angular/core";
export type IuiListboxOptionSize = 'l' | 'm' | 's';
export declare class IuiListboxOptionComponent<T = unknown> extends CdkOption {
    size: IuiListboxOptionSize;
    /** Indeterminate value option of checkbox. */
    indeterminate: boolean;
    value: T;
    get disabled(): boolean;
    set disabled(val: boolean);
    get _radioId(): string;
    get _radioName(): string;
    get _radioValue(): string;
    /**
     * @method
     * @ignore
     */
    _clickHandler(event: MouseEvent): void;
    /** Whether a checkbox is shown at the given position. */
    _hasCheckboxAt(position: IuiListOptionTogglePosition): boolean;
    /** Whether a radio indicator is shown at the given position. */
    _hasRadioAt(position: IuiListOptionTogglePosition): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiListboxOptionComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiListboxOptionComponent<any>, "iui-listbox-option", never, { "size": { "alias": "size"; "required": false; }; "indeterminate": { "alias": "indeterminate"; "required": false; }; "value": { "alias": "value"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, ["[left]", "[optionTitle]", "[optionSubtitle]", "*", "[right]"], true, never>;
}
