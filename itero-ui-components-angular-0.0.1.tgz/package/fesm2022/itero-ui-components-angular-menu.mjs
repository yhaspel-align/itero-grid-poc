import * as i0 from '@angular/core';
import { TemplateRef, ViewChild, Input, Component, EventEmitter, Output, Directive } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IuiSlideToggleComponent } from '@itero/ui-components-angular/slide-toggle';
import * as i1 from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';

class IuiMenuComponent {
    constructor() {
        /** Size of the menu items inside this panel — drives CSS custom property for item height */
        this.size = 'l';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiMenuComponent, isStandalone: true, selector: "iui-menu", inputs: { size: "size" }, viewQueries: [{ propertyName: "templateRef", first: true, predicate: TemplateRef, descendants: true, static: true }], ngImport: i0, template: "<ng-template>\r\n\t<div\r\n\t\tclass=\"iui-menu\"\r\n\t\t[class.iui-menu_size_l]=\"size === 'l'\"\r\n\t\t[class.iui-menu_size_m]=\"size === 'm'\"\r\n\t\t[class.iui-menu_size_s]=\"size === 's'\"\r\n\t\trole=\"menu\"\r\n\t>\r\n\t\t<ng-content></ng-content>\r\n\t</div>\r\n</ng-template>\r\n", styles: [".iui-menu{display:flex;flex-direction:column;background:var(--iui-menu-bg);border:1px solid var(--iui-menu-border);border-radius:var(--iui-border-radius);box-shadow:var(--iui-menu-shadow);padding:4px 0;min-width:120px;max-height:320px;overflow-y:auto;outline:none}.iui-menu.iui-menu_size_l{--iui-menu-item-height: 44px;--iui-menu-item-padding-x: 12px}.iui-menu.iui-menu_size_m{--iui-menu-item-height: 36px;--iui-menu-item-padding-x: 12px}.iui-menu.iui-menu_size_s{--iui-menu-item-height: 28px;--iui-menu-item-padding-x: 8px}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-menu', standalone: true, template: "<ng-template>\r\n\t<div\r\n\t\tclass=\"iui-menu\"\r\n\t\t[class.iui-menu_size_l]=\"size === 'l'\"\r\n\t\t[class.iui-menu_size_m]=\"size === 'm'\"\r\n\t\t[class.iui-menu_size_s]=\"size === 's'\"\r\n\t\trole=\"menu\"\r\n\t>\r\n\t\t<ng-content></ng-content>\r\n\t</div>\r\n</ng-template>\r\n", styles: [".iui-menu{display:flex;flex-direction:column;background:var(--iui-menu-bg);border:1px solid var(--iui-menu-border);border-radius:var(--iui-border-radius);box-shadow:var(--iui-menu-shadow);padding:4px 0;min-width:120px;max-height:320px;overflow-y:auto;outline:none}.iui-menu.iui-menu_size_l{--iui-menu-item-height: 44px;--iui-menu-item-padding-x: 12px}.iui-menu.iui-menu_size_m{--iui-menu-item-height: 36px;--iui-menu-item-padding-x: 12px}.iui-menu.iui-menu_size_s{--iui-menu-item-height: 28px;--iui-menu-item-padding-x: 8px}\n"] }]
        }], propDecorators: { size: [{
                type: Input
            }], templateRef: [{
                type: ViewChild,
                args: [TemplateRef, { static: true }]
            }] } });

class IuiMenuItemComponent {
    constructor() {
        /** Visual type: neutral (default) or destructive (red) */
        this.type = 'neutral';
        /** Whether the item is disabled — removes pointer-events and dims text */
        this.disabled = false;
        /** Whether the item shows a checkmark selection indicator */
        this.selected = false;
        /** Text label shown when trailing === 'keyboard-shortcut' */
        this.shortcutLabel = '';
        /** Checked state for the toggle when trailing === 'toggle' */
        this.toggleValue = false;
        /** Emits the new boolean value when the trailing toggle changes */
        this.toggleChange = new EventEmitter();
    }
    _onToggleChange(event) {
        this.toggleChange.emit(event.checked);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiMenuItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.12", type: IuiMenuItemComponent, isStandalone: true, selector: "iui-menu-item", inputs: { type: "type", disabled: "disabled", selected: "selected", trailing: "trailing", shortcutLabel: "shortcutLabel", toggleValue: "toggleValue" }, outputs: { toggleChange: "toggleChange" }, host: { attributes: { "role": "menuitem", "tabindex": "-1" }, properties: { "class.iui-menu-item": "true", "class.iui-menu-item_type_destructive": "type === \"destructive\"", "class.iui-menu-item_disabled": "disabled", "class.iui-menu-item_selected": "selected", "attr.aria-disabled": "disabled ? \"true\" : null", "attr.aria-checked": "selected ? \"true\" : null" } }, ngImport: i0, template: "<span class=\"iui-menu-item__selection\" aria-hidden=\"true\">\r\n\t@if (selected) {\r\n\t\t<svg class=\"iui-menu-item__checkmark\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n\t\t\t<path d=\"M4 10L8 14L16 6\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n\t\t</svg>\r\n\t}\r\n</span>\r\n\r\n<span class=\"iui-menu-item__icon\">\r\n\t<ng-content select=\"[iuiMenuItemIcon]\"></ng-content>\r\n</span>\r\n\r\n<span class=\"iui-menu-item__label\">\r\n\t<ng-content></ng-content>\r\n</span>\r\n\r\n@if (trailing) {\r\n\t<span class=\"iui-menu-item__trailing\">\r\n\t\t@if (trailing === 'keyboard-shortcut') {\r\n\t\t\t<span class=\"iui-menu-item__shortcut\">{{ shortcutLabel }}</span>\r\n\t\t}\r\n\t\t@if (trailing === 'toggle') {\r\n\t\t\t<iui-slide-toggle\r\n\t\t\t\t[checked]=\"toggleValue\"\r\n\t\t\t\t[showValue]=\"false\"\r\n\t\t\t\t[isDisabled]=\"disabled\"\r\n\t\t\t\t(changeEvent)=\"_onToggleChange($event)\"\r\n\t\t\t></iui-slide-toggle>\r\n\t\t}\r\n\t\t@if (trailing === 'submenu') {\r\n\t\t\t<svg class=\"iui-menu-item__submenu-chevron\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\">\r\n\t\t\t\t<path d=\"M7.5 5L12.5 10L7.5 15\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n\t\t\t</svg>\r\n\t\t}\r\n\t</span>\r\n}\r\n", styles: [":host{display:flex;align-items:center;gap:8px;height:var(--iui-menu-item-height, 44px);padding:0 var(--iui-menu-item-padding-x, 12px);cursor:pointer;color:var(--iui-menu-item-text);background:transparent;outline:none;border:none;width:100%;box-sizing:border-box;-webkit-user-select:none;user-select:none}:host:hover:not(.iui-menu-item_disabled){background:var(--iui-menu-item-hover-bg)}:host:focus-visible{outline:2px solid var(--iui-menu-item-focus-border);outline-offset:-2px}:host.iui-menu-item_type_destructive{color:var(--iui-menu-item-text-destructive)}:host.iui-menu-item_type_destructive .iui-menu-item__icon{color:var(--iui-menu-item-icon-destructive)}:host.iui-menu-item_type_destructive:hover:not(.iui-menu-item_disabled){background:var(--iui-menu-item-destructive-hover-bg)}:host.iui-menu-item_selected{background:var(--iui-menu-item-selected-bg)}:host.iui-menu-item_selected:hover:not(.iui-menu-item_disabled){background:var(--iui-menu-item-selected-hover-bg)}:host.iui-menu-item_disabled{color:var(--iui-menu-item-text-disabled);pointer-events:none;cursor:default}:host.iui-menu-item_disabled .iui-menu-item__icon{color:var(--iui-menu-item-icon-disabled)}:host.iui-menu-item_disabled .iui-menu-item__checkmark,:host.iui-menu-item_disabled .iui-menu-item__submenu-chevron{color:var(--iui-menu-item-icon-disabled)}.iui-menu-item__selection{flex-shrink:0;width:20px;height:20px;display:flex;align-items:center;justify-content:center;color:var(--iui-menu-item-icon)}.iui-menu-item__checkmark{width:20px;height:20px}.iui-menu-item__icon{flex-shrink:0;width:20px;height:20px;display:flex;align-items:center;justify-content:center;color:var(--iui-menu-item-icon)}.iui-menu-item__icon:empty{display:none}.iui-menu-item__label{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font:var(--iui-tp-body-01-font)}.iui-menu-item__trailing{flex-shrink:0;display:flex;align-items:center}.iui-menu-item__shortcut{color:var(--iui-menu-shortcut-text);font:var(--iui-tp-label-01-font);white-space:nowrap}.iui-menu-item__submenu-chevron{width:20px;height:20px;color:var(--iui-menu-item-icon-secondary)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: IuiSlideToggleComponent, selector: "iui-slide-toggle", inputs: ["id", "checked", "labelPosition", "skeleton", "showValue"], outputs: ["changeEvent"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiMenuItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-menu-item', standalone: true, imports: [CommonModule, IuiSlideToggleComponent], host: {
                        role: 'menuitem',
                        tabindex: '-1',
                        '[class.iui-menu-item]': 'true',
                        '[class.iui-menu-item_type_destructive]': 'type === "destructive"',
                        '[class.iui-menu-item_disabled]': 'disabled',
                        '[class.iui-menu-item_selected]': 'selected',
                        '[attr.aria-disabled]': 'disabled ? "true" : null',
                        '[attr.aria-checked]': 'selected ? "true" : null',
                    }, template: "<span class=\"iui-menu-item__selection\" aria-hidden=\"true\">\r\n\t@if (selected) {\r\n\t\t<svg class=\"iui-menu-item__checkmark\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n\t\t\t<path d=\"M4 10L8 14L16 6\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n\t\t</svg>\r\n\t}\r\n</span>\r\n\r\n<span class=\"iui-menu-item__icon\">\r\n\t<ng-content select=\"[iuiMenuItemIcon]\"></ng-content>\r\n</span>\r\n\r\n<span class=\"iui-menu-item__label\">\r\n\t<ng-content></ng-content>\r\n</span>\r\n\r\n@if (trailing) {\r\n\t<span class=\"iui-menu-item__trailing\">\r\n\t\t@if (trailing === 'keyboard-shortcut') {\r\n\t\t\t<span class=\"iui-menu-item__shortcut\">{{ shortcutLabel }}</span>\r\n\t\t}\r\n\t\t@if (trailing === 'toggle') {\r\n\t\t\t<iui-slide-toggle\r\n\t\t\t\t[checked]=\"toggleValue\"\r\n\t\t\t\t[showValue]=\"false\"\r\n\t\t\t\t[isDisabled]=\"disabled\"\r\n\t\t\t\t(changeEvent)=\"_onToggleChange($event)\"\r\n\t\t\t></iui-slide-toggle>\r\n\t\t}\r\n\t\t@if (trailing === 'submenu') {\r\n\t\t\t<svg class=\"iui-menu-item__submenu-chevron\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\">\r\n\t\t\t\t<path d=\"M7.5 5L12.5 10L7.5 15\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n\t\t\t</svg>\r\n\t\t}\r\n\t</span>\r\n}\r\n", styles: [":host{display:flex;align-items:center;gap:8px;height:var(--iui-menu-item-height, 44px);padding:0 var(--iui-menu-item-padding-x, 12px);cursor:pointer;color:var(--iui-menu-item-text);background:transparent;outline:none;border:none;width:100%;box-sizing:border-box;-webkit-user-select:none;user-select:none}:host:hover:not(.iui-menu-item_disabled){background:var(--iui-menu-item-hover-bg)}:host:focus-visible{outline:2px solid var(--iui-menu-item-focus-border);outline-offset:-2px}:host.iui-menu-item_type_destructive{color:var(--iui-menu-item-text-destructive)}:host.iui-menu-item_type_destructive .iui-menu-item__icon{color:var(--iui-menu-item-icon-destructive)}:host.iui-menu-item_type_destructive:hover:not(.iui-menu-item_disabled){background:var(--iui-menu-item-destructive-hover-bg)}:host.iui-menu-item_selected{background:var(--iui-menu-item-selected-bg)}:host.iui-menu-item_selected:hover:not(.iui-menu-item_disabled){background:var(--iui-menu-item-selected-hover-bg)}:host.iui-menu-item_disabled{color:var(--iui-menu-item-text-disabled);pointer-events:none;cursor:default}:host.iui-menu-item_disabled .iui-menu-item__icon{color:var(--iui-menu-item-icon-disabled)}:host.iui-menu-item_disabled .iui-menu-item__checkmark,:host.iui-menu-item_disabled .iui-menu-item__submenu-chevron{color:var(--iui-menu-item-icon-disabled)}.iui-menu-item__selection{flex-shrink:0;width:20px;height:20px;display:flex;align-items:center;justify-content:center;color:var(--iui-menu-item-icon)}.iui-menu-item__checkmark{width:20px;height:20px}.iui-menu-item__icon{flex-shrink:0;width:20px;height:20px;display:flex;align-items:center;justify-content:center;color:var(--iui-menu-item-icon)}.iui-menu-item__icon:empty{display:none}.iui-menu-item__label{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font:var(--iui-tp-body-01-font)}.iui-menu-item__trailing{flex-shrink:0;display:flex;align-items:center}.iui-menu-item__shortcut{color:var(--iui-menu-shortcut-text);font:var(--iui-tp-label-01-font);white-space:nowrap}.iui-menu-item__submenu-chevron{width:20px;height:20px;color:var(--iui-menu-item-icon-secondary)}\n"] }]
        }], propDecorators: { type: [{
                type: Input
            }], disabled: [{
                type: Input
            }], selected: [{
                type: Input
            }], trailing: [{
                type: Input
            }], shortcutLabel: [{
                type: Input
            }], toggleValue: [{
                type: Input
            }], toggleChange: [{
                type: Output
            }] } });

class IuiMenuDividerComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiMenuDividerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiMenuDividerComponent, isStandalone: true, selector: "iui-menu-divider", host: { attributes: { "role": "separator" } }, ngImport: i0, template: '', isInline: true, styles: [":host{display:block;height:1px;background:var(--iui-menu-divider);margin:4px 0}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiMenuDividerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-menu-divider', standalone: true, template: '', host: { role: 'separator' }, styles: [":host{display:block;height:1px;background:var(--iui-menu-divider);margin:4px 0}\n"] }]
        }] });

class IuiMenuSubheadComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiMenuSubheadComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiMenuSubheadComponent, isStandalone: true, selector: "iui-menu-subhead", ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:flex;align-items:center;padding:0 12px;height:28px;color:var(--iui-menu-subhead-text);font:var(--iui-tp-label-01-font);pointer-events:none;-webkit-user-select:none;user-select:none}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiMenuSubheadComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-menu-subhead', standalone: true, template: '<ng-content></ng-content>', styles: [":host{display:flex;align-items:center;padding:0 12px;height:28px;color:var(--iui-menu-subhead-text);font:var(--iui-tp-label-01-font);pointer-events:none;-webkit-user-select:none;user-select:none}\n"] }]
        }] });

class IuiMenuTriggerDirective {
    constructor(_el, _overlay, _viewContainerRef) {
        this._el = _el;
        this._overlay = _overlay;
        this._viewContainerRef = _viewContainerRef;
        /** Whether the panel opens above or below the trigger */
        this.menuPlacement = 'bottom';
        /** Whether the panel aligns to the start or end of the trigger */
        this.menuAlignment = 'start';
        /** Whether the menu overlay is currently open */
        this.isOpen = false;
        this._overlayRef = null;
        this._closeSub = Subscription.EMPTY;
        this._detachSub = Subscription.EMPTY;
        this._keydownSub = Subscription.EMPTY;
    }
    toggle() {
        this.isOpen ? this.close() : this.open();
    }
    open() {
        if (this.isOpen || !this.menuRef?.templateRef)
            return;
        const overlayRef = this._getOrCreateOverlay();
        const portal = new TemplatePortal(this.menuRef.templateRef, this._viewContainerRef);
        overlayRef.attach(portal);
        this.isOpen = true;
        this._closeSub = overlayRef.backdropClick().subscribe(() => this.close());
        this._detachSub = overlayRef.detachments().pipe(take(1)).subscribe(() => {
            if (this.isOpen) {
                this.isOpen = false;
            }
        });
        this._keydownSub = overlayRef.keydownEvents().subscribe(e => this._handleKeydown(e));
        // Focus first enabled item after overlay renders
        Promise.resolve().then(() => this._focusFirstItem());
    }
    close() {
        if (!this.isOpen)
            return;
        this._overlayRef?.detach();
        this._closeSub.unsubscribe();
        this._detachSub.unsubscribe();
        this._keydownSub.unsubscribe();
        this.isOpen = false;
        this._el.nativeElement.focus();
    }
    _getOrCreateOverlay() {
        if (!this._overlayRef) {
            const positionStrategy = this._overlay
                .position()
                .flexibleConnectedTo(this._el)
                .withPositions(this._buildPositions())
                .withFlexibleDimensions(false)
                .withPush(false);
            this._overlayRef = this._overlay.create({
                positionStrategy,
                scrollStrategy: this._overlay.scrollStrategies.reposition(),
                hasBackdrop: true,
                backdropClass: 'cdk-overlay-transparent-backdrop',
            });
        }
        return this._overlayRef;
    }
    _buildPositions() {
        const originYPrimary = this.menuPlacement === 'bottom' ? 'bottom' : 'top';
        const originYFallback = this.menuPlacement === 'bottom' ? 'top' : 'bottom';
        const overlayYPrimary = this.menuPlacement === 'bottom' ? 'top' : 'bottom';
        const overlayYFallback = this.menuPlacement === 'bottom' ? 'bottom' : 'top';
        const originX = this.menuAlignment === 'start' ? 'start' : 'end';
        const overlayX = this.menuAlignment === 'start' ? 'start' : 'end';
        const offsetY = 4;
        return [
            { originX, originY: originYPrimary, overlayX, overlayY: overlayYPrimary, offsetY },
            { originX, originY: originYFallback, overlayX, overlayY: overlayYFallback, offsetY: -offsetY },
        ];
    }
    _handleKeydown(event) {
        switch (event.key) {
            case 'Escape':
                event.preventDefault();
                this.close();
                break;
            case 'Tab':
                this.close();
                break;
            case 'ArrowDown':
                event.preventDefault();
                this._moveFocus(1);
                break;
            case 'ArrowUp':
                event.preventDefault();
                this._moveFocus(-1);
                break;
            case 'Home':
                event.preventDefault();
                this._focusFirstItem();
                break;
            case 'End':
                event.preventDefault();
                this._focusLastItem();
                break;
        }
    }
    _getMenuItems() {
        if (!this._overlayRef)
            return [];
        return Array.from(this._overlayRef.overlayElement.querySelectorAll('iui-menu-item:not(.iui-menu-item_disabled)'));
    }
    _focusFirstItem() {
        this._getMenuItems()[0]?.focus();
    }
    _focusLastItem() {
        const items = this._getMenuItems();
        items[items.length - 1]?.focus();
    }
    _moveFocus(direction) {
        const items = this._getMenuItems();
        if (!items.length)
            return;
        const focused = document.activeElement;
        const currentIndex = items.indexOf(focused);
        const nextIndex = currentIndex < 0
            ? direction === 1 ? 0 : items.length - 1
            : (currentIndex + direction + items.length) % items.length;
        items[nextIndex]?.focus();
    }
    ngOnDestroy() {
        this._overlayRef?.dispose();
        this._overlayRef = null;
        this._closeSub.unsubscribe();
        this._detachSub.unsubscribe();
        this._keydownSub.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiMenuTriggerDirective, deps: [{ token: i0.ElementRef }, { token: i1.Overlay }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: IuiMenuTriggerDirective, isStandalone: true, selector: "[iuiMenuTrigger]", inputs: { menuRef: ["iuiMenuTrigger", "menuRef"], menuPlacement: "menuPlacement", menuAlignment: "menuAlignment" }, host: { listeners: { "click": "toggle()" }, properties: { "attr.aria-expanded": "isOpen ? \"true\" : \"false\"", "attr.aria-haspopup": "\"menu\"" } }, exportAs: ["iuiMenuTrigger"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiMenuTriggerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[iuiMenuTrigger]',
                    standalone: true,
                    exportAs: 'iuiMenuTrigger',
                    host: {
                        '(click)': 'toggle()',
                        '[attr.aria-expanded]': 'isOpen ? "true" : "false"',
                        '[attr.aria-haspopup]': '"menu"',
                    },
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.Overlay }, { type: i0.ViewContainerRef }], propDecorators: { menuRef: [{
                type: Input,
                args: ['iuiMenuTrigger']
            }], menuPlacement: [{
                type: Input
            }], menuAlignment: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiMenuComponent, IuiMenuDividerComponent, IuiMenuItemComponent, IuiMenuSubheadComponent, IuiMenuTriggerDirective };
//# sourceMappingURL=itero-ui-components-angular-menu.mjs.map
