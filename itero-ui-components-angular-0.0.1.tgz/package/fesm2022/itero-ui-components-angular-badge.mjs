import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Input, ChangeDetectionStrategy, Component } from '@angular/core';

class IuiBadgeComponent {
    constructor() {
        /** Semantic status determining badge colors */
        this.status = 'netral';
        /** Layout context — 'default' for standard use, 'on-image' for overlaying photos */
        this.layout = 'default';
        /** Show loading skeleton state */
        this.loading = false;
        /** Show leading icon */
        this.showIcon = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiBadgeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiBadgeComponent, isStandalone: true, selector: "span[iui-badge]", inputs: { status: "status", layout: "layout", loading: "loading", showIcon: "showIcon" }, host: { properties: { "class.iui-badge": "true", "class.iui-badge_status_netral": "status === \"netral\"", "class.iui-badge_status_info": "status === \"info\"", "class.iui-badge_status_success": "status === \"success\"", "class.iui-badge_status_warning": "status === \"warning\"", "class.iui-badge_status_destructive": "status === \"destructive\"", "class.iui-badge_layout_default": "layout === \"default\"", "class.iui-badge_layout_on-image": "layout === \"on-image\"", "class.iui-badge_loading": "loading" } }, ngImport: i0, template: "<ng-container *ngIf=\"!loading; else loadingTpl\">\n\t<svg *ngIf=\"showIcon\"\n\t\t class=\"iui-badge__icon\"\n\t\t width=\"20\" height=\"20\" viewBox=\"0 0 20 20\"\n\t\t fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"\n\t\t aria-hidden=\"true\">\n\t\t<path d=\"M10 3.5C6.41 3.5 3.5 6.41 3.5 10C3.5 13.59 6.41 16.5 10 16.5C13.59 16.5 16.5 13.59 16.5 10C16.5 6.41 13.59 3.5 10 3.5ZM10.75 13.75H9.25V12.25H10.75V13.75ZM10.75 10.75H9.25V6.25H10.75V10.75Z\"\n\t\t\t  fill=\"currentColor\"/>\n\t</svg>\n\t<span class=\"iui-badge__content\">\n\t\t<ng-content></ng-content>\n\t</span>\n</ng-container>\n<ng-template #loadingTpl>\n\t<span class=\"iui-badge__skeleton\" aria-hidden=\"true\"></span>\n</ng-template>\n", styles: [":host{display:inline-flex;align-items:center;justify-content:center;gap:var(--iui-main-unit);min-width:24px;padding:var(--iui-main-unit) calc(2 * var(--iui-main-unit));border-radius:var(--iui-border-radius);border:1px solid transparent;font:var(--iui-tp-body-01-font);white-space:nowrap;width:fit-content;position:relative}:host .iui-badge__content{display:flex;align-items:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:1px}:host .iui-badge__icon{flex-shrink:0;color:currentColor}:host.iui-badge_layout_default.iui-badge_status_netral{background-color:var(--iui-badge-netral-bg);border-color:var(--iui-badge-netral-border);color:var(--iui-badge-netral-color)}:host.iui-badge_layout_default.iui-badge_status_info{background-color:var(--iui-badge-info-bg);border-color:var(--iui-badge-info-border);color:var(--iui-badge-info-color)}:host.iui-badge_layout_default.iui-badge_status_success{background-color:var(--iui-badge-success-bg);border-color:var(--iui-badge-success-border);color:var(--iui-badge-success-color)}:host.iui-badge_layout_default.iui-badge_status_warning{background-color:var(--iui-badge-warning-bg);border-color:var(--iui-badge-warning-border);color:var(--iui-badge-warning-color)}:host.iui-badge_layout_default.iui-badge_status_destructive{background-color:var(--iui-badge-destructive-bg);border-color:var(--iui-badge-destructive-border);color:var(--iui-badge-destructive-color)}:host.iui-badge_layout_on-image{background-color:var(--iui-badge-on-image-bg);border-color:transparent}:host.iui-badge_layout_on-image.iui-badge_status_netral{color:var(--iui-badge-on-image-netral-color)}:host.iui-badge_layout_on-image.iui-badge_status_info{color:var(--iui-badge-on-image-info-color)}:host.iui-badge_layout_on-image.iui-badge_status_success{color:var(--iui-badge-on-image-success-color)}:host.iui-badge_layout_on-image.iui-badge_status_warning{color:var(--iui-badge-on-image-warning-color)}:host.iui-badge_layout_on-image.iui-badge_status_destructive{color:var(--iui-badge-on-image-destructive-color)}:host.iui-badge_loading{width:56px;height:28px;padding:0;background-color:var(--iui-badge-loading-bg);border-color:transparent;overflow:hidden}:host.iui-badge_loading .iui-badge__skeleton{display:block;width:100%;height:100%;border-radius:var(--iui-border-radius)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiBadgeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'span[iui-badge]', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        '[class.iui-badge]': 'true',
                        '[class.iui-badge_status_netral]': 'status === "netral"',
                        '[class.iui-badge_status_info]': 'status === "info"',
                        '[class.iui-badge_status_success]': 'status === "success"',
                        '[class.iui-badge_status_warning]': 'status === "warning"',
                        '[class.iui-badge_status_destructive]': 'status === "destructive"',
                        '[class.iui-badge_layout_default]': 'layout === "default"',
                        '[class.iui-badge_layout_on-image]': 'layout === "on-image"',
                        '[class.iui-badge_loading]': 'loading',
                    }, template: "<ng-container *ngIf=\"!loading; else loadingTpl\">\n\t<svg *ngIf=\"showIcon\"\n\t\t class=\"iui-badge__icon\"\n\t\t width=\"20\" height=\"20\" viewBox=\"0 0 20 20\"\n\t\t fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"\n\t\t aria-hidden=\"true\">\n\t\t<path d=\"M10 3.5C6.41 3.5 3.5 6.41 3.5 10C3.5 13.59 6.41 16.5 10 16.5C13.59 16.5 16.5 13.59 16.5 10C16.5 6.41 13.59 3.5 10 3.5ZM10.75 13.75H9.25V12.25H10.75V13.75ZM10.75 10.75H9.25V6.25H10.75V10.75Z\"\n\t\t\t  fill=\"currentColor\"/>\n\t</svg>\n\t<span class=\"iui-badge__content\">\n\t\t<ng-content></ng-content>\n\t</span>\n</ng-container>\n<ng-template #loadingTpl>\n\t<span class=\"iui-badge__skeleton\" aria-hidden=\"true\"></span>\n</ng-template>\n", styles: [":host{display:inline-flex;align-items:center;justify-content:center;gap:var(--iui-main-unit);min-width:24px;padding:var(--iui-main-unit) calc(2 * var(--iui-main-unit));border-radius:var(--iui-border-radius);border:1px solid transparent;font:var(--iui-tp-body-01-font);white-space:nowrap;width:fit-content;position:relative}:host .iui-badge__content{display:flex;align-items:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:1px}:host .iui-badge__icon{flex-shrink:0;color:currentColor}:host.iui-badge_layout_default.iui-badge_status_netral{background-color:var(--iui-badge-netral-bg);border-color:var(--iui-badge-netral-border);color:var(--iui-badge-netral-color)}:host.iui-badge_layout_default.iui-badge_status_info{background-color:var(--iui-badge-info-bg);border-color:var(--iui-badge-info-border);color:var(--iui-badge-info-color)}:host.iui-badge_layout_default.iui-badge_status_success{background-color:var(--iui-badge-success-bg);border-color:var(--iui-badge-success-border);color:var(--iui-badge-success-color)}:host.iui-badge_layout_default.iui-badge_status_warning{background-color:var(--iui-badge-warning-bg);border-color:var(--iui-badge-warning-border);color:var(--iui-badge-warning-color)}:host.iui-badge_layout_default.iui-badge_status_destructive{background-color:var(--iui-badge-destructive-bg);border-color:var(--iui-badge-destructive-border);color:var(--iui-badge-destructive-color)}:host.iui-badge_layout_on-image{background-color:var(--iui-badge-on-image-bg);border-color:transparent}:host.iui-badge_layout_on-image.iui-badge_status_netral{color:var(--iui-badge-on-image-netral-color)}:host.iui-badge_layout_on-image.iui-badge_status_info{color:var(--iui-badge-on-image-info-color)}:host.iui-badge_layout_on-image.iui-badge_status_success{color:var(--iui-badge-on-image-success-color)}:host.iui-badge_layout_on-image.iui-badge_status_warning{color:var(--iui-badge-on-image-warning-color)}:host.iui-badge_layout_on-image.iui-badge_status_destructive{color:var(--iui-badge-on-image-destructive-color)}:host.iui-badge_loading{width:56px;height:28px;padding:0;background-color:var(--iui-badge-loading-bg);border-color:transparent;overflow:hidden}:host.iui-badge_loading .iui-badge__skeleton{display:block;width:100%;height:100%;border-radius:var(--iui-border-radius)}\n"] }]
        }], propDecorators: { status: [{
                type: Input
            }], layout: [{
                type: Input
            }], loading: [{
                type: Input
            }], showIcon: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiBadgeComponent };
//# sourceMappingURL=itero-ui-components-angular-badge.mjs.map
