import * as i2 from '@angular/cdk/collections';
import { NgIf, NgClass } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, EventEmitter, Input, Output, ContentChildren, forwardRef, Component, Optional, Inject } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

class IuiRadioButtonUniqueIdService {
    constructor() {
        this.nextUniqueId = 0;
    }
    getRadioButtonGroupId() {
        return this.nextUniqueId++;
    }
    getRadioButtonId() {
        return ++this.nextUniqueId;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioButtonUniqueIdService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioButtonUniqueIdService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioButtonUniqueIdService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class IuiRadioGroupComponent {
    get selected() {
        return this._selected;
    }
    set selected(selected) {
        this._selected = selected;
        this.value = selected ? selected.value : null;
        this.checkSelectedRadioButton();
    }
    get required() {
        return this._required;
    }
    set required(value) {
        this._required = value;
        this._markRadiosForCheck();
    }
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = value;
        this._markRadiosForCheck();
    }
    constructor(_changeDetectorRef, nextUniqueId) {
        this._changeDetectorRef = _changeDetectorRef;
        this.nextUniqueId = nextUniqueId;
        this.orientation = 'vertical';
        this.label = '';
        this.showLabel = true;
        this.value = null;
        this._selected = null;
        this.radioButtonChangeSubscription = null;
        this._required = false;
        this._disabled = false;
        this._change = new EventEmitter();
        this._onChange = () => { };
        this._onTouched = () => { };
    }
    ngOnInit() {
        const uniqueId = this.nextUniqueId.getRadioButtonGroupId();
        if (!this.name) {
            this.name = `iui-radio-group-${uniqueId}`;
        }
    }
    ngAfterContentInit() {
        this.updateRadioButtonNames();
        this._subscribeToRadioButtonChanges();
    }
    ngOnDestroy() {
        this.radioButtonChangeSubscription?.unsubscribe();
    }
    writeValue(value) {
        this.value = value;
        this.updateSelectedRadioFromValue();
        this._changeDetectorRef.markForCheck();
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    updateRadioButtonNames() {
        this._radios.forEach(radioButton => {
            radioButton.name = this.name;
            radioButton.disabled = this.disabled;
        });
    }
    _subscribeToRadioButtonChanges() {
        this.radioButtonChangeSubscription = this._radios.changes.subscribe(() => {
            this.updateRadioButtonNames();
        });
        this._radios.forEach(radioButton => {
            radioButton.change.subscribe(() => {
                this.selectRadio(radioButton);
            });
        });
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        this._markRadiosForCheck();
    }
    updateSelectedRadioFromValue() {
        if (this._radios) {
            this._radios.forEach(radioButton => {
                radioButton.checked = this.value === radioButton.value;
            });
        }
    }
    selectRadio(selectedRadioButton) {
        this.value = selectedRadioButton.value;
        this._selected = selectedRadioButton;
        this.updateSelectedRadioFromValue();
        this._onChange(this.value);
        this._onTouched(this.value);
        this._change.emit(this.value);
    }
    _markRadiosForCheck() {
        if (this._radios) {
            this._radios.forEach(radioButton => radioButton.markForCheck());
        }
    }
    checkSelectedRadioButton() {
        if (this._selected && !this._selected.checked) {
            this._selected.checked = true;
        }
    }
    getGroupName() {
        return this.name ? this.name : null;
    }
    getCheckedValue() {
        return this.value !== null && this.value !== undefined ? this.value : null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioGroupComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: IuiRadioButtonUniqueIdService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiRadioGroupComponent, isStandalone: true, selector: "iui-radio-group", inputs: { orientation: "orientation", label: "label", showLabel: "showLabel", name: "name", selected: "selected", required: "required", disabled: "disabled" }, outputs: { _change: "_change" }, host: { classAttribute: "iui-radio-group" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: IuiRadioGroupComponent,
                multi: true
            }
        ], queries: [{ propertyName: "_radios", predicate: i0.forwardRef(() => IuiRadioButtonComponent), descendants: true }], ngImport: i0, template: "<div class=\"iui-radio-group-label\" *ngIf=\"showLabel && label\">\n\t<span class=\"iui-radio-group-label-text\">{{ label }}</span>\n\t<span class=\"iui-radio-group-required\" *ngIf=\"required\">*</span>\n</div>\n<div\n\tclass=\"iui-radio-group-items\"\n\t[class.iui-radio-group-items--horizontal]=\"orientation === 'horizontal'\"\n>\n\t<ng-content></ng-content>\n</div>\n", styles: [":host{display:flex;flex-direction:column;align-items:flex-start}.iui-radio-group-label{display:flex;gap:4px;align-items:flex-start;padding-bottom:8px}.iui-radio-group-label .iui-radio-group-label-text{font:var(--iui-tp-label-01-font);color:var(--iui-radio-group-label-color)}.iui-radio-group-label .iui-radio-group-required{font:var(--iui-tp-label-01-font);color:var(--iui-radio-group-required-color)}.iui-radio-group-items{display:flex;flex-direction:column;gap:8px;align-items:flex-start}.iui-radio-group-items--horizontal{flex-direction:row;gap:16px}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-radio-group', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: IuiRadioGroupComponent,
                            multi: true
                        }
                    ], standalone: true, imports: [NgIf], host: {
                        class: 'iui-radio-group'
                    }, template: "<div class=\"iui-radio-group-label\" *ngIf=\"showLabel && label\">\n\t<span class=\"iui-radio-group-label-text\">{{ label }}</span>\n\t<span class=\"iui-radio-group-required\" *ngIf=\"required\">*</span>\n</div>\n<div\n\tclass=\"iui-radio-group-items\"\n\t[class.iui-radio-group-items--horizontal]=\"orientation === 'horizontal'\"\n>\n\t<ng-content></ng-content>\n</div>\n", styles: [":host{display:flex;flex-direction:column;align-items:flex-start}.iui-radio-group-label{display:flex;gap:4px;align-items:flex-start;padding-bottom:8px}.iui-radio-group-label .iui-radio-group-label-text{font:var(--iui-tp-label-01-font);color:var(--iui-radio-group-label-color)}.iui-radio-group-label .iui-radio-group-required{font:var(--iui-tp-label-01-font);color:var(--iui-radio-group-required-color)}.iui-radio-group-items{display:flex;flex-direction:column;gap:8px;align-items:flex-start}.iui-radio-group-items--horizontal{flex-direction:row;gap:16px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: IuiRadioButtonUniqueIdService }], propDecorators: { _radios: [{
                type: ContentChildren,
                args: [forwardRef(() => IuiRadioButtonComponent), { descendants: true }]
            }], orientation: [{
                type: Input
            }], label: [{
                type: Input
            }], showLabel: [{
                type: Input
            }], _change: [{
                type: Output
            }], name: [{
                type: Input
            }], selected: [{
                type: Input
            }], required: [{
                type: Input
            }], disabled: [{
                type: Input
            }] } });

class IuiRadioButtonComponent {
    set disabled(value) {
        this._disabled = value;
        this.markForCheck();
    }
    get disabled() {
        return this._disabled || this.skeleton || (this.radioGroup && this.radioGroup.disabled);
    }
    get change() {
        return this._change;
    }
    get checked() {
        return this._checked;
    }
    set checked(state) {
        if (this._checked !== state) {
            this._checked = state;
            if (state && this.radioGroup && this.radioGroup.value !== this.value) {
                this.radioGroup.selected = this;
            }
            else if (!state && this.radioGroup && this.radioGroup.value === this.value) {
                this.radioGroup.selected = null;
            }
            if (state) {
                this.radioDispatcher.notify(this.id, this.name);
            }
            this.changeDetector.markForCheck();
        }
    }
    get required() {
        return this._required || (this.radioGroup && this.radioGroup.required);
    }
    set required(value) {
        this._required = value;
    }
    constructor(radioGroup, changeDetector, nextUniqueId, radioDispatcher) {
        this.radioGroup = radioGroup;
        this.changeDetector = changeDetector;
        this.nextUniqueId = nextUniqueId;
        this.radioDispatcher = radioDispatcher;
        this.showValue = true;
        this.skeleton = false;
        this._required = false;
        this._checked = false;
        this._disabled = false;
        this._change = new EventEmitter(); // Event emitter for change
    }
    ngOnInit() {
        const uniqueId = this.nextUniqueId.getRadioButtonId();
        // Set unique ID if not provided
        if (!this.id) {
            this.id = `iui-radio-${uniqueId}`;
        }
        // If part of a radio group, inherit the group’s name and disabled state
        if (this.radioGroup) {
            this.name = this.radioGroup.name;
            this.disabled = this.radioGroup.disabled;
            this.checked = this.radioGroup.value === this.value;
        }
    }
    onChange(event) {
        const inputElement = event.target;
        this.checked = inputElement.checked;
        this._change.emit(this.value);
        // Notify the group of the change if part of a group
        if (this.radioGroup) {
            this.radioGroup.selectRadio(this);
        }
    }
    /** Marks the component for change detection */
    markForCheck() {
        this.changeDetector.markForCheck();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioButtonComponent, deps: [{ token: forwardRef(() => IuiRadioGroupComponent), optional: true }, { token: i0.ChangeDetectorRef }, { token: IuiRadioButtonUniqueIdService }, { token: i2.UniqueSelectionDispatcher }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiRadioButtonComponent, isStandalone: true, selector: "iui-radio-button", inputs: { id: "id", value: "value", label: "label", description: "description", name: "name", arialabel: "arialabel", arialabelledby: "arialabelledby", showValue: "showValue", skeleton: "skeleton", disabled: "disabled", checked: "checked", required: "required" }, outputs: { _change: "_change" }, ngImport: i0, template: "<label class=\"iui-radio-button-container\" [ngClass]=\"{ disabled: disabled, skeleton: skeleton }\">\n\t<input\n\t\ttype=\"radio\"\n\t\t[attr.aria-label]=\"arialabel\"\n\t\t[attr.aria-labelledby]=\"arialabelledby\"\n\t\t[id]=\"id\"\n\t\t[name]=\"name\"\n\t\t[disabled]=\"disabled\"\n\t\t[checked]=\"checked\"\n\t\t[value]=\"value\"\n\t\t(change)=\"onChange($event)\"\n\t/>\n\t<div class=\"label-container\" *ngIf=\"showValue && !skeleton\">\n\t\t<p class=\"label-text\">{{ label }}</p>\n\t\t<p *ngIf=\"description\" class=\"label-description\">{{ description }}</p>\n\t</div>\n\t<div class=\"skeleton-value-box\" *ngIf=\"skeleton\"></div>\n</label>\n", styles: ["@charset \"UTF-8\";input[type=radio]{--radio-border-color: var(--iui-radio-border);--radio-checked-color: var(--iui-radio-checked);--radio-disabled-bg-color: var(--iui-radio-disabled-bg);--radio-focused-color: var(--iui-radio-focus);cursor:pointer;box-sizing:border-box;width:20px;height:20px;margin:0;padding:0;border:1px solid var(--radio-border-color);border-radius:50%;appearance:none;background-color:transparent;outline:none;flex-shrink:0}input[type=radio]:not(:disabled):checked{border-color:var(--radio-checked-color);background-color:var(--radio-checked-color);background-clip:content-box;padding:5.2px;background-image:radial-gradient(circle,var(--radio-checked-color) 0%,var(--radio-checked-color) 50%,transparent 60%,transparent 100%)}input[type=radio]:disabled{background-color:var(--radio-disabled-bg-color);border:1px solid var(--iui-radio-disabled-border);cursor:default}input[type=radio]:disabled:checked{border-color:var(--iui-radio-disabled-checked);background-clip:content-box;padding:5.2px;background-image:radial-gradient(circle,var(--iui-radio-disabled-checked) 0%,var(--iui-radio-disabled-checked) 50%,transparent 50%,transparent 100%)}input[type=radio]:focus-visible{outline:2px solid var(--radio-focused-color);outline-offset:1px}.iui-radio-button-container{display:flex;align-items:flex-start;gap:8px;padding:0}.iui-radio-button-container.skeleton{align-items:center}.iui-radio-button-container.disabled{color:var(--iui-radio-disabled-color)}.iui-radio-button-container input[type=radio].disabled{cursor:default}.iui-radio-button-container .label-container{display:flex;flex-direction:column;gap:4px}.iui-radio-button-container .label-container .label-text{margin:0;font:var(--iui-tp-body-01-font);color:var(--iui-radio-color);max-width:320px;white-space:nowrap}.iui-radio-button-container .label-container .label-description{margin:0;font:var(--iui-tp-label-01-font);color:var(--iui-radio-color);box-sizing:border-box;white-space:normal;word-wrap:break-word}.iui-radio-button-container .skeleton-value-box{width:40px;height:8px;background-color:var(--iui-radio-skeleton-bg);flex-shrink:0}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-radio-button', standalone: true, imports: [NgIf, NgClass], template: "<label class=\"iui-radio-button-container\" [ngClass]=\"{ disabled: disabled, skeleton: skeleton }\">\n\t<input\n\t\ttype=\"radio\"\n\t\t[attr.aria-label]=\"arialabel\"\n\t\t[attr.aria-labelledby]=\"arialabelledby\"\n\t\t[id]=\"id\"\n\t\t[name]=\"name\"\n\t\t[disabled]=\"disabled\"\n\t\t[checked]=\"checked\"\n\t\t[value]=\"value\"\n\t\t(change)=\"onChange($event)\"\n\t/>\n\t<div class=\"label-container\" *ngIf=\"showValue && !skeleton\">\n\t\t<p class=\"label-text\">{{ label }}</p>\n\t\t<p *ngIf=\"description\" class=\"label-description\">{{ description }}</p>\n\t</div>\n\t<div class=\"skeleton-value-box\" *ngIf=\"skeleton\"></div>\n</label>\n", styles: ["@charset \"UTF-8\";input[type=radio]{--radio-border-color: var(--iui-radio-border);--radio-checked-color: var(--iui-radio-checked);--radio-disabled-bg-color: var(--iui-radio-disabled-bg);--radio-focused-color: var(--iui-radio-focus);cursor:pointer;box-sizing:border-box;width:20px;height:20px;margin:0;padding:0;border:1px solid var(--radio-border-color);border-radius:50%;appearance:none;background-color:transparent;outline:none;flex-shrink:0}input[type=radio]:not(:disabled):checked{border-color:var(--radio-checked-color);background-color:var(--radio-checked-color);background-clip:content-box;padding:5.2px;background-image:radial-gradient(circle,var(--radio-checked-color) 0%,var(--radio-checked-color) 50%,transparent 60%,transparent 100%)}input[type=radio]:disabled{background-color:var(--radio-disabled-bg-color);border:1px solid var(--iui-radio-disabled-border);cursor:default}input[type=radio]:disabled:checked{border-color:var(--iui-radio-disabled-checked);background-clip:content-box;padding:5.2px;background-image:radial-gradient(circle,var(--iui-radio-disabled-checked) 0%,var(--iui-radio-disabled-checked) 50%,transparent 50%,transparent 100%)}input[type=radio]:focus-visible{outline:2px solid var(--radio-focused-color);outline-offset:1px}.iui-radio-button-container{display:flex;align-items:flex-start;gap:8px;padding:0}.iui-radio-button-container.skeleton{align-items:center}.iui-radio-button-container.disabled{color:var(--iui-radio-disabled-color)}.iui-radio-button-container input[type=radio].disabled{cursor:default}.iui-radio-button-container .label-container{display:flex;flex-direction:column;gap:4px}.iui-radio-button-container .label-container .label-text{margin:0;font:var(--iui-tp-body-01-font);color:var(--iui-radio-color);max-width:320px;white-space:nowrap}.iui-radio-button-container .label-container .label-description{margin:0;font:var(--iui-tp-label-01-font);color:var(--iui-radio-color);box-sizing:border-box;white-space:normal;word-wrap:break-word}.iui-radio-button-container .skeleton-value-box{width:40px;height:8px;background-color:var(--iui-radio-skeleton-bg);flex-shrink:0}\n"] }]
        }], ctorParameters: () => [{ type: IuiRadioGroupComponent, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [forwardRef(() => IuiRadioGroupComponent)]
                }] }, { type: i0.ChangeDetectorRef }, { type: IuiRadioButtonUniqueIdService }, { type: i2.UniqueSelectionDispatcher }], propDecorators: { id: [{
                type: Input
            }], value: [{
                type: Input
            }], label: [{
                type: Input
            }], description: [{
                type: Input
            }], name: [{
                type: Input
            }], arialabel: [{
                type: Input
            }], arialabelledby: [{
                type: Input
            }], showValue: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], disabled: [{
                type: Input
            }], _change: [{
                type: Output
            }], checked: [{
                type: Input
            }], required: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiRadioButtonComponent, IuiRadioGroupComponent, IuiRadioGroupComponent as IuiRadioGroupDirective };
//# sourceMappingURL=itero-ui-components-angular-radio-button.mjs.map
