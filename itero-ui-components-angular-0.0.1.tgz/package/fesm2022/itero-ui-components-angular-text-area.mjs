import * as i0 from '@angular/core';
import { forwardRef, Input, ViewChild, Self, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i3 from '@angular/forms';
import { Validators, FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i1 from '@itero/ui-components-angular/core';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import { CloseEmptyIconComponent, InformationIconComponent } from '@itero/ui-components-angular/icons';
import { IuiTooltipDirective } from '@itero/ui-components-angular/tooltip';

let nextUniqueId = 0;
/** Line height in px used for auto-grow height calculations (matches --iui-tp-body-01). */
const LINE_HEIGHT_PX = 20;
/** Vertical padding of the field container (12px top + 12px bottom). */
const FIELD_VERTICAL_PADDING_PX = 24;
class IuiTextAreaComponent {
    /** Unique id of the element. */
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    /** When true, the textarea height grows to fit content (capped by maxRows). */
    get autoGrow() {
        return this._autoGrow;
    }
    set autoGrow(value) {
        this._autoGrow = coerceBooleanProperty(value);
    }
    /** Whether the component is required. Derived from Validators.required or explicit Input. */
    get required() {
        return this._required ?? this.ngControlDirective.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    get _labelId() {
        return this.id + '-label';
    }
    get _textareaId() {
        return this.id + '-textarea';
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get empty() {
        return this._value == null || this._value === '';
    }
    get _counterText() {
        const len = this._value?.length ?? 0;
        return this.maxLength ? `${len}/${this.maxLength}` : `${len}`;
    }
    get _focused() {
        return this.__focused;
    }
    /** Whether the auto-grow height has been capped at maxRows. */
    get _maxRowsReached() {
        return this.__maxRowsReached;
    }
    constructor(_changeDetectorRef, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._changeDetectorRef = _changeDetectorRef;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        /** Label text. Leave empty to hide the label. */
        this.label = '';
        /** Placeholder text passed to the native textarea. */
        this.placeholder = '';
        /** Name attribute passed to the native textarea. */
        this.name = '';
        /** Autocomplete attribute. */
        this.autocomplete = null;
        /** Layer set background variant: set-01 (white, default) or set-02 (gray). */
        this.layerSet = 'set-01';
        /** Whether to show the character counter in the label row. */
        this.showCounter = false;
        /** Maximum character length. Shown in counter as current/max. */
        this.maxLength = null;
        /** Whether to show the skeleton loading state. */
        this.skeleton = false;
        /** Whether to show a clear icon when the field has a value and is not disabled. */
        this.cancelable = false;
        /** When non-empty, renders an info icon next to the label wired to an iui-tooltip. */
        this.explainerText = '';
        /** Minimum number of visible rows. Also acts as the lower bound for auto-grow. */
        this.rows = 4;
        /** Upper bound (in rows) for auto-grow. null means unlimited. */
        this.maxRows = null;
        this.__focused = false;
        this.__maxRowsReached = false;
        this._autoGrow = false;
        this._id = `iui-text-area-${nextUniqueId++}`;
        /** View → model callback called when value changes. */
        this._onChange = () => { };
        /** View → model callback called when the control has been touched. */
        this._onTouched = () => { };
    }
    get _value() {
        return this.__value;
    }
    set _value(newValue) {
        const hasAssigned = this._assignValue(newValue);
        if (hasAssigned) {
            this._onChange(newValue);
        }
    }
    _onFocus() {
        if (!this.disabled) {
            this.__focused = true;
            this._changeDetectorRef.markForCheck();
        }
    }
    _onBlur() {
        this.__focused = false;
        if (!this.disabled) {
            this._onTouched();
            this._changeDetectorRef.markForCheck();
        }
    }
    _focusTextarea(el) {
        if (!this.disabled && el) {
            el.focus();
        }
    }
    _clearValue(event) {
        event.stopPropagation();
        if (!this.disabled) {
            this._value = '';
            this._adjustHeight();
        }
    }
    modelChangeHandler(value) {
        this._assignValue(value);
        this._onChange(value);
        this._adjustHeight();
    }
    // ── ControlValueAccessor ──────────────────────────────────────────────────
    writeValue(value) {
        this._assignValue(value);
        // Run after view is initialized (avoids ExpressionChangedAfterItHasBeenChecked)
        Promise.resolve().then(() => this._adjustHeight());
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._changeDetectorRef.markForCheck();
    }
    // ── Private helpers ───────────────────────────────────────────────────────
    _assignValue(newValue) {
        if (newValue !== this.__value) {
            this.__value = newValue;
            this._changeDetectorRef.markForCheck();
            return true;
        }
        return false;
    }
    /**
     * Adjusts the textarea height to fit its content when autoGrow is enabled.
     * Clamps height to maxRows if set. When the cap is reached, sets the
     * _maxRowsReached flag so that overflow-y: auto kicks in via CSS.
     */
    _adjustHeight() {
        if (!this.autoGrow || !this.textareaElement)
            return;
        const el = this.textareaElement.nativeElement;
        // Reset to auto to get the correct scrollHeight
        el.style.height = 'auto';
        const scrollHeight = el.scrollHeight;
        if (this.maxRows != null) {
            const maxHeightPx = this.maxRows * LINE_HEIGHT_PX + FIELD_VERTICAL_PADDING_PX;
            if (scrollHeight > maxHeightPx) {
                el.style.height = `${maxHeightPx}px`;
                this.__maxRowsReached = true;
            }
            else {
                el.style.height = `${scrollHeight}px`;
                this.__maxRowsReached = false;
            }
        }
        else {
            el.style.height = `${scrollHeight}px`;
            this.__maxRowsReached = false;
        }
        this._changeDetectorRef.markForCheck();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTextAreaComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.NgControlDirective, self: true }, { token: i1.IuiErrorStateMatcherDirective, self: true }, { token: i1.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiTextAreaComponent, isStandalone: true, selector: "iui-text-area", inputs: { id: "id", label: "label", placeholder: "placeholder", name: "name", autocomplete: "autocomplete", layerSet: "layerSet", showCounter: "showCounter", maxLength: "maxLength", skeleton: "skeleton", cancelable: "cancelable", explainerText: "explainerText", rows: "rows", autoGrow: "autoGrow", maxRows: "maxRows", required: "required" }, host: { properties: { "class.iui-text-area_layer-set-02": "layerSet === \"set-02\"", "class.iui-text-area_required": "required", "class.iui-text-area_disabled": "disabled", "class.iui-text-area_invalid": "_errorState", "class.iui-text-area_focused": "_focused", "class.iui-text-area_filled": "!empty", "class.iui-text-area_skeleton": "skeleton", "class.iui-text-area_auto-grow": "autoGrow", "class.iui-text-area_max-rows-reached": "_maxRowsReached", "attr.id": "id", "attr.data-testid": "id" }, classAttribute: "iui-text-area" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiTextAreaComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "textareaElement", first: true, predicate: ["textareaElement"], descendants: true }], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\r\n\t<div class=\"iui-text-area__skeleton-label\"></div>\r\n\t<div class=\"iui-text-area__skeleton-field\"></div>\r\n</ng-container>\r\n\r\n<ng-template #normalTemplate>\r\n\t<!-- Label row: label + optional explainer tooltip + optional counter -->\r\n\t<div class=\"iui-text-area__label-row\" *ngIf=\"label || showCounter\">\r\n\t\t<label\r\n\t\t\t*ngIf=\"label\"\r\n\t\t\tclass=\"iui-text-area__label\"\r\n\t\t\t[attr.for]=\"_textareaId\"\r\n\t\t\t[id]=\"_labelId\"\r\n\t\t>{{ label }}<span class=\"iui-text-area__required\" *ngIf=\"required\">*</span></label>\r\n\r\n\t\t<span\r\n\t\t\t*ngIf=\"explainerText\"\r\n\t\t\tclass=\"iui-text-area__explainer\"\r\n\t\t\t[iuiTooltip]=\"explainerText\"\r\n\t\t\t[iuiTooltipPlacement]=\"'top'\"\r\n\t\t>\r\n\t\t\t<iui-information-icon\r\n\t\t\t\tclass=\"iui-icon iui-icon_size_s\"\r\n\t\t\t\t[attr.aria-label]=\"explainerText\"\r\n\t\t\t></iui-information-icon>\r\n\t\t</span>\r\n\r\n\t\t<span class=\"iui-text-area__counter\" *ngIf=\"showCounter\">{{ _counterText }}</span>\r\n\t</div>\r\n\r\n\t<!-- Field container -->\r\n\t<div class=\"iui-text-area__field\" (click)=\"_focusTextarea(textareaElement)\">\r\n\t\t<textarea\r\n\t\t\t#textareaElement\r\n\t\t\tclass=\"iui-text-area__textarea\"\r\n\t\t\t[required]=\"required\"\r\n\t\t\t[disabled]=\"disabled\"\r\n\t\t\t[attr.aria-invalid]=\"_errorState\"\r\n\t\t\t[attr.aria-disabled]=\"disabled.toString()\"\r\n\t\t\t[attr.aria-labelledby]=\"label ? _labelId : null\"\r\n\t\t\t[attr.maxlength]=\"maxLength\"\r\n\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t[name]=\"name\"\r\n\t\t\t[attr.name]=\"name\"\r\n\t\t\t[rows]=\"rows\"\r\n\t\t\t[attr.autocomplete]=\"autocomplete\"\r\n\t\t\t[id]=\"_textareaId\"\r\n\t\t\t[value]=\"_value ?? ''\"\r\n\t\t\t[ngModel]=\"_value\"\r\n\t\t\t(ngModelChange)=\"modelChangeHandler($event)\"\r\n\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t(blur)=\"_onBlur()\"\r\n\t\t></textarea>\r\n\r\n\t\t<!-- Clear icon: shown when cancelable, field has a value, and not disabled -->\r\n\t\t<iui-close-empty-icon\r\n\t\t\t*ngIf=\"cancelable && !empty && !disabled\"\r\n\t\t\t(click)=\"_clearValue($event)\"\r\n\t\t\tclass=\"iui-text-area__clear-icon iui-icon iui-icon_size_s\"\r\n\t\t\t[attr.aria-label]=\"'Clear'\"\r\n\t\t></iui-close-empty-icon>\r\n\r\n\t\t<!-- Resize handle: decorative SVG grip, hidden when disabled or autoGrow is on -->\r\n\t\t<span\r\n\t\t\t*ngIf=\"!disabled && !autoGrow\"\r\n\t\t\tclass=\"iui-text-area__resize-handle\"\r\n\t\t\taria-hidden=\"true\"\r\n\t\t>\r\n\t\t\t<svg width=\"8\" height=\"8\" viewBox=\"0 0 8 8\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n\t\t\t\t<path d=\"M7.5 1.5L1.5 7.5\" stroke=\"currentColor\" stroke-width=\"1\" stroke-linecap=\"round\"/>\r\n\t\t\t\t<path d=\"M7.5 4L4 7.5\" stroke=\"currentColor\" stroke-width=\"1\" stroke-linecap=\"round\"/>\r\n\t\t\t\t<path d=\"M7.5 7L7 7.5\" stroke=\"currentColor\" stroke-width=\"1\" stroke-linecap=\"round\"/>\r\n\t\t\t</svg>\r\n\t\t</span>\r\n\t</div>\r\n\r\n\t<!-- Helper / Error row -->\r\n\t<div class=\"iui-text-area__helper-row\">\r\n\t\t<span *ngIf=\"_errorState\" class=\"iui-text-area__error\">\r\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t</span>\r\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-text-area__helper\">\r\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t</span>\r\n\t</div>\r\n</ng-template>\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{--iui-text-area-label-color: var(--iui-text-secondary);--iui-text-area-label-disabled-color: var(--iui-text-disabled);--iui-text-area-bg: var(--iui-background-layer-01);--iui-text-area-bg-layer-02: var(--iui-background-layer-02);--iui-text-area-color: var(--iui-text-primary);--iui-text-area-placeholder-color: var(--iui-text-tertiary);--iui-text-area-disabled-color: var(--iui-text-disabled);--iui-text-area-error-border: var(--iui-border-error);--iui-text-area-error-color: var(--iui-text-error);--iui-text-area-focus-border: var(--iui-border-focus);--iui-text-area-helper-color: var(--iui-text-secondary);--iui-text-area-subtle-border: var(--iui-border-subtle);--iui-text-area-skeleton-bg: var(--iui-background-highlight-gray);display:flex;flex-direction:column;min-width:206px;max-width:100%}.iui-text-area__label-row{display:flex;align-items:flex-start;justify-content:space-between;padding-bottom:8px}.iui-text-area__label{font:var(--iui-tp-label-01-font);color:var(--iui-text-area-label-color);flex:1;min-width:1px}:host.iui-text-area_disabled .iui-text-area__label{color:var(--iui-text-area-label-disabled-color)}.iui-text-area__required{color:var(--iui-text-area-error-color);margin-left:4px}.iui-text-area__counter{font:var(--iui-tp-label-01-font);color:var(--iui-text-area-label-color);padding-left:8px;flex-shrink:0;white-space:nowrap}:host.iui-text-area_disabled .iui-text-area__counter{color:var(--iui-text-area-label-disabled-color)}.iui-text-area__explainer{display:inline-flex;align-items:center;margin-left:4px;color:var(--iui-text-area-label-color);cursor:help;flex-shrink:0}.iui-text-area__field{position:relative;display:flex;align-items:flex-start;gap:8px;overflow:hidden;background:var(--iui-text-area-bg);border:1px solid transparent;border-radius:8px;transition:border-color .2s ease-out;cursor:text;padding:12px 16px}:host.iui-text-area_layer-set-02 .iui-text-area__field{background:var(--iui-text-area-bg-layer-02)}:host.iui-text-area_focused .iui-text-area__field{border-color:var(--iui-text-area-focus-border)}:host.iui-text-area_invalid .iui-text-area__field{border-color:var(--iui-text-area-error-border)}:host.iui-text-area_disabled .iui-text-area__field{cursor:default;pointer-events:none}.iui-text-area__textarea{flex:1;min-width:0;font:var(--iui-tp-body-01-font);color:var(--iui-text-area-color);background:transparent;border:none;outline:none;padding:0;margin:0;resize:vertical;min-height:72px;overflow-y:auto;line-height:20px;scrollbar-width:thin;scrollbar-color:var(--iui-text-area-subtle-border) transparent}.iui-text-area__textarea::placeholder{color:var(--iui-text-area-placeholder-color)}.iui-text-area__textarea:disabled{color:var(--iui-text-area-disabled-color);resize:none}.iui-text-area__textarea:disabled::placeholder{color:var(--iui-text-area-disabled-color)}.iui-text-area__textarea::-webkit-resizer{display:none}.iui-text-area__textarea::-webkit-scrollbar{width:4px}.iui-text-area__textarea::-webkit-scrollbar-track{background:transparent}.iui-text-area__textarea::-webkit-scrollbar-thumb{background:var(--iui-text-area-subtle-border);border-radius:4px}:host.iui-text-area_auto-grow .iui-text-area__textarea{resize:none;overflow-y:hidden}:host.iui-text-area_auto-grow.iui-text-area_max-rows-reached .iui-text-area__textarea{overflow-y:auto}.iui-text-area__clear-icon{position:absolute;top:10px;right:10px;flex-shrink:0;cursor:pointer;color:inherit;pointer-events:auto}:host.iui-text-area_invalid .iui-text-area__clear-icon{color:var(--iui-text-area-error-color)}.iui-text-area__resize-handle{position:absolute;bottom:4px;right:4px;width:8px;height:8px;pointer-events:none;color:var(--iui-text-area-subtle-border)}.iui-text-area__helper-row{padding-top:8px}.iui-text-area__helper{font:var(--iui-tp-label-01-font);color:var(--iui-text-area-helper-color)}.iui-text-area__error{font:var(--iui-tp-label-01-font);color:var(--iui-text-area-error-color)}:host.iui-text-area_disabled .iui-text-area__helper{color:var(--iui-text-area-label-disabled-color)}.iui-text-area__skeleton-label{width:40px;height:8px;background:var(--iui-text-area-skeleton-bg);border-radius:4px;margin-bottom:8px}.iui-text-area__skeleton-field{width:100%;height:96px;background:var(--iui-text-area-skeleton-bg);border-radius:8px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: CloseEmptyIconComponent, selector: "iui-close-empty-icon" }, { kind: "component", type: InformationIconComponent, selector: "iui-information-icon" }, { kind: "directive", type: IuiTooltipDirective, selector: "[iuiTooltip]", inputs: ["iuiTooltip", "iuiTooltipPlacement", "iuiTooltipAlignment", "iuiTooltipShowCaret", "iuiTooltipDelay"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTextAreaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-text-area', standalone: true, imports: [CommonModule, FormsModule, CloseEmptyIconComponent, InformationIconComponent, IuiTooltipDirective], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiTextAreaComponent),
                            multi: true
                        }
                    ], host: {
                        class: 'iui-text-area',
                        '[class.iui-text-area_layer-set-02]': 'layerSet === "set-02"',
                        '[class.iui-text-area_required]': 'required',
                        '[class.iui-text-area_disabled]': 'disabled',
                        '[class.iui-text-area_invalid]': '_errorState',
                        '[class.iui-text-area_focused]': '_focused',
                        '[class.iui-text-area_filled]': '!empty',
                        '[class.iui-text-area_skeleton]': 'skeleton',
                        '[class.iui-text-area_auto-grow]': 'autoGrow',
                        '[class.iui-text-area_max-rows-reached]': '_maxRowsReached',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\r\n\t<div class=\"iui-text-area__skeleton-label\"></div>\r\n\t<div class=\"iui-text-area__skeleton-field\"></div>\r\n</ng-container>\r\n\r\n<ng-template #normalTemplate>\r\n\t<!-- Label row: label + optional explainer tooltip + optional counter -->\r\n\t<div class=\"iui-text-area__label-row\" *ngIf=\"label || showCounter\">\r\n\t\t<label\r\n\t\t\t*ngIf=\"label\"\r\n\t\t\tclass=\"iui-text-area__label\"\r\n\t\t\t[attr.for]=\"_textareaId\"\r\n\t\t\t[id]=\"_labelId\"\r\n\t\t>{{ label }}<span class=\"iui-text-area__required\" *ngIf=\"required\">*</span></label>\r\n\r\n\t\t<span\r\n\t\t\t*ngIf=\"explainerText\"\r\n\t\t\tclass=\"iui-text-area__explainer\"\r\n\t\t\t[iuiTooltip]=\"explainerText\"\r\n\t\t\t[iuiTooltipPlacement]=\"'top'\"\r\n\t\t>\r\n\t\t\t<iui-information-icon\r\n\t\t\t\tclass=\"iui-icon iui-icon_size_s\"\r\n\t\t\t\t[attr.aria-label]=\"explainerText\"\r\n\t\t\t></iui-information-icon>\r\n\t\t</span>\r\n\r\n\t\t<span class=\"iui-text-area__counter\" *ngIf=\"showCounter\">{{ _counterText }}</span>\r\n\t</div>\r\n\r\n\t<!-- Field container -->\r\n\t<div class=\"iui-text-area__field\" (click)=\"_focusTextarea(textareaElement)\">\r\n\t\t<textarea\r\n\t\t\t#textareaElement\r\n\t\t\tclass=\"iui-text-area__textarea\"\r\n\t\t\t[required]=\"required\"\r\n\t\t\t[disabled]=\"disabled\"\r\n\t\t\t[attr.aria-invalid]=\"_errorState\"\r\n\t\t\t[attr.aria-disabled]=\"disabled.toString()\"\r\n\t\t\t[attr.aria-labelledby]=\"label ? _labelId : null\"\r\n\t\t\t[attr.maxlength]=\"maxLength\"\r\n\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t[name]=\"name\"\r\n\t\t\t[attr.name]=\"name\"\r\n\t\t\t[rows]=\"rows\"\r\n\t\t\t[attr.autocomplete]=\"autocomplete\"\r\n\t\t\t[id]=\"_textareaId\"\r\n\t\t\t[value]=\"_value ?? ''\"\r\n\t\t\t[ngModel]=\"_value\"\r\n\t\t\t(ngModelChange)=\"modelChangeHandler($event)\"\r\n\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t(blur)=\"_onBlur()\"\r\n\t\t></textarea>\r\n\r\n\t\t<!-- Clear icon: shown when cancelable, field has a value, and not disabled -->\r\n\t\t<iui-close-empty-icon\r\n\t\t\t*ngIf=\"cancelable && !empty && !disabled\"\r\n\t\t\t(click)=\"_clearValue($event)\"\r\n\t\t\tclass=\"iui-text-area__clear-icon iui-icon iui-icon_size_s\"\r\n\t\t\t[attr.aria-label]=\"'Clear'\"\r\n\t\t></iui-close-empty-icon>\r\n\r\n\t\t<!-- Resize handle: decorative SVG grip, hidden when disabled or autoGrow is on -->\r\n\t\t<span\r\n\t\t\t*ngIf=\"!disabled && !autoGrow\"\r\n\t\t\tclass=\"iui-text-area__resize-handle\"\r\n\t\t\taria-hidden=\"true\"\r\n\t\t>\r\n\t\t\t<svg width=\"8\" height=\"8\" viewBox=\"0 0 8 8\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n\t\t\t\t<path d=\"M7.5 1.5L1.5 7.5\" stroke=\"currentColor\" stroke-width=\"1\" stroke-linecap=\"round\"/>\r\n\t\t\t\t<path d=\"M7.5 4L4 7.5\" stroke=\"currentColor\" stroke-width=\"1\" stroke-linecap=\"round\"/>\r\n\t\t\t\t<path d=\"M7.5 7L7 7.5\" stroke=\"currentColor\" stroke-width=\"1\" stroke-linecap=\"round\"/>\r\n\t\t\t</svg>\r\n\t\t</span>\r\n\t</div>\r\n\r\n\t<!-- Helper / Error row -->\r\n\t<div class=\"iui-text-area__helper-row\">\r\n\t\t<span *ngIf=\"_errorState\" class=\"iui-text-area__error\">\r\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t</span>\r\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-text-area__helper\">\r\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t</span>\r\n\t</div>\r\n</ng-template>\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{--iui-text-area-label-color: var(--iui-text-secondary);--iui-text-area-label-disabled-color: var(--iui-text-disabled);--iui-text-area-bg: var(--iui-background-layer-01);--iui-text-area-bg-layer-02: var(--iui-background-layer-02);--iui-text-area-color: var(--iui-text-primary);--iui-text-area-placeholder-color: var(--iui-text-tertiary);--iui-text-area-disabled-color: var(--iui-text-disabled);--iui-text-area-error-border: var(--iui-border-error);--iui-text-area-error-color: var(--iui-text-error);--iui-text-area-focus-border: var(--iui-border-focus);--iui-text-area-helper-color: var(--iui-text-secondary);--iui-text-area-subtle-border: var(--iui-border-subtle);--iui-text-area-skeleton-bg: var(--iui-background-highlight-gray);display:flex;flex-direction:column;min-width:206px;max-width:100%}.iui-text-area__label-row{display:flex;align-items:flex-start;justify-content:space-between;padding-bottom:8px}.iui-text-area__label{font:var(--iui-tp-label-01-font);color:var(--iui-text-area-label-color);flex:1;min-width:1px}:host.iui-text-area_disabled .iui-text-area__label{color:var(--iui-text-area-label-disabled-color)}.iui-text-area__required{color:var(--iui-text-area-error-color);margin-left:4px}.iui-text-area__counter{font:var(--iui-tp-label-01-font);color:var(--iui-text-area-label-color);padding-left:8px;flex-shrink:0;white-space:nowrap}:host.iui-text-area_disabled .iui-text-area__counter{color:var(--iui-text-area-label-disabled-color)}.iui-text-area__explainer{display:inline-flex;align-items:center;margin-left:4px;color:var(--iui-text-area-label-color);cursor:help;flex-shrink:0}.iui-text-area__field{position:relative;display:flex;align-items:flex-start;gap:8px;overflow:hidden;background:var(--iui-text-area-bg);border:1px solid transparent;border-radius:8px;transition:border-color .2s ease-out;cursor:text;padding:12px 16px}:host.iui-text-area_layer-set-02 .iui-text-area__field{background:var(--iui-text-area-bg-layer-02)}:host.iui-text-area_focused .iui-text-area__field{border-color:var(--iui-text-area-focus-border)}:host.iui-text-area_invalid .iui-text-area__field{border-color:var(--iui-text-area-error-border)}:host.iui-text-area_disabled .iui-text-area__field{cursor:default;pointer-events:none}.iui-text-area__textarea{flex:1;min-width:0;font:var(--iui-tp-body-01-font);color:var(--iui-text-area-color);background:transparent;border:none;outline:none;padding:0;margin:0;resize:vertical;min-height:72px;overflow-y:auto;line-height:20px;scrollbar-width:thin;scrollbar-color:var(--iui-text-area-subtle-border) transparent}.iui-text-area__textarea::placeholder{color:var(--iui-text-area-placeholder-color)}.iui-text-area__textarea:disabled{color:var(--iui-text-area-disabled-color);resize:none}.iui-text-area__textarea:disabled::placeholder{color:var(--iui-text-area-disabled-color)}.iui-text-area__textarea::-webkit-resizer{display:none}.iui-text-area__textarea::-webkit-scrollbar{width:4px}.iui-text-area__textarea::-webkit-scrollbar-track{background:transparent}.iui-text-area__textarea::-webkit-scrollbar-thumb{background:var(--iui-text-area-subtle-border);border-radius:4px}:host.iui-text-area_auto-grow .iui-text-area__textarea{resize:none;overflow-y:hidden}:host.iui-text-area_auto-grow.iui-text-area_max-rows-reached .iui-text-area__textarea{overflow-y:auto}.iui-text-area__clear-icon{position:absolute;top:10px;right:10px;flex-shrink:0;cursor:pointer;color:inherit;pointer-events:auto}:host.iui-text-area_invalid .iui-text-area__clear-icon{color:var(--iui-text-area-error-color)}.iui-text-area__resize-handle{position:absolute;bottom:4px;right:4px;width:8px;height:8px;pointer-events:none;color:var(--iui-text-area-subtle-border)}.iui-text-area__helper-row{padding-top:8px}.iui-text-area__helper{font:var(--iui-tp-label-01-font);color:var(--iui-text-area-helper-color)}.iui-text-area__error{font:var(--iui-tp-label-01-font);color:var(--iui-text-area-error-color)}:host.iui-text-area_disabled .iui-text-area__helper{color:var(--iui-text-area-label-disabled-color)}.iui-text-area__skeleton-label{width:40px;height:8px;background:var(--iui-text-area-skeleton-bg);border-radius:4px;margin-bottom:8px}.iui-text-area__skeleton-field{width:100%;height:96px;background:var(--iui-text-area-skeleton-bg);border-radius:8px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { textareaElement: [{
                type: ViewChild,
                args: ['textareaElement']
            }], id: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], name: [{
                type: Input
            }], autocomplete: [{
                type: Input
            }], layerSet: [{
                type: Input
            }], showCounter: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], cancelable: [{
                type: Input
            }], explainerText: [{
                type: Input
            }], rows: [{
                type: Input
            }], autoGrow: [{
                type: Input
            }], maxRows: [{
                type: Input
            }], required: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiTextAreaComponent };
//# sourceMappingURL=itero-ui-components-angular-text-area.mjs.map
