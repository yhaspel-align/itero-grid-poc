import * as i0 from '@angular/core';
import { forwardRef, Input, ViewChildren, Self, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i1 from '@itero/ui-components-angular/core';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import * as i3 from '@angular/forms';
import { Validators, FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { CloseEmptyIconComponent } from '@itero/ui-components-angular/icons';

let nextUniqueId = 0;
class IuiTextInputComponent {
    /** Unique id of the element */
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    /** Whether the component is required. */
    get required() {
        return this._required ?? this.ngControlDirective.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    get _labelId() {
        return this.id + '-label';
    }
    get _inputId() {
        return this.id + '-input';
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get empty() {
        return this._value == null || this._value == '';
    }
    get _counterText() {
        const len = this._value?.length ?? 0;
        return this.maxLength ? `${len}/${this.maxLength}` : `${len}`;
    }
    constructor(_changeDetectorRef, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._changeDetectorRef = _changeDetectorRef;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        /** Label of component, default is '', strongly recommended to be filled */
        this.label = '';
        /** Placeholder of component, rendered in the place of the value when no selections/input */
        this.placeholder = '';
        /** Whether the input contains "X" icon to clear the field */
        this.cancelable = false;
        /** Name assigned to input element inside */
        this.name = '';
        this.autocomplete = null;
        /** Type of input element, supported: text, password, email */
        this.type = 'text';
        /** Size of the input field: large (default), medium, small */
        this.size = 'l';
        /** Layer set: set-01 (white bg, default) or set-02 (gray bg) */
        this.layerSet = 'set-01';
        /** Whether to show character counter in the label row */
        this.showCounter = false;
        /** Max character length; displayed in counter as current/max */
        this.maxLength = null;
        /** Whether to show the skeleton loading state */
        this.skeleton = false;
        this.__focused = false;
        this._id = `iui-text-input-${nextUniqueId++}`;
        /** `View -> model callback called when value changes` */
        this._onChange = () => { };
        /** `View -> model callback called when select has been touched` */
        this._onTouched = () => { };
    }
    /** Value of the select control. */
    get _value() {
        return this.__value;
    }
    set _value(newValue) {
        const hasAssigned = this._assignValue(newValue);
        if (hasAssigned) {
            this._onChange(newValue);
        }
    }
    /** Whether the select is focused. */
    get _focused() {
        return this.__focused;
    }
    _onFocus() {
        if (!this.disabled) {
            this.__focused = true;
        }
    }
    _onBlur() {
        this.__focused = false;
        if (!this.disabled) {
            this._onTouched();
            this._changeDetectorRef.markForCheck();
        }
    }
    _focusInput(input) {
        if (!this.disabled) {
            input.focus();
        }
    }
    _cancelSelection(event) {
        event.stopPropagation();
        if (!this.disabled) {
            this._value = '';
        }
    }
    writeValue(value) {
        this._assignValue(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._changeDetectorRef.markForCheck();
    }
    modelChangeHandler(value) {
        this._assignValue(value);
        this._onChange(value);
    }
    _assignValue(newValue) {
        if (newValue !== this.__value) {
            this.__value = newValue;
            this._changeDetectorRef.markForCheck();
            return true;
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTextInputComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.NgControlDirective, self: true }, { token: i1.IuiErrorStateMatcherDirective, self: true }, { token: i1.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiTextInputComponent, isStandalone: true, selector: "iui-text-input", inputs: { id: "id", label: "label", placeholder: "placeholder", cancelable: "cancelable", name: "name", autocomplete: "autocomplete", type: "type", size: "size", layerSet: "layerSet", showCounter: "showCounter", maxLength: "maxLength", skeleton: "skeleton", required: "required" }, host: { properties: { "class.iui-text-input_size_l": "size === \"l\"", "class.iui-text-input_size_m": "size === \"m\"", "class.iui-text-input_size_s": "size === \"s\"", "class.iui-text-input_layer-set-02": "layerSet === \"set-02\"", "class.iui-text-input_required": "required", "class.iui-text-input_disabled": "disabled", "class.iui-text-input_invalid": "_errorState", "class.iui-text-input_focused": "_focused", "class.iui-text-input_filled": "!empty", "class.iui-text-input_skeleton": "skeleton", "attr.id": "id", "attr.data-testid": "id" }, classAttribute: "iui-text-input" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiTextInputComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "inputElement", predicate: ["inputElement"], descendants: true }], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\n\t<div class=\"iui-text-input__skeleton-field\"></div>\n\t<div class=\"iui-text-input__skeleton-helper\"></div>\n</ng-container>\n\n<ng-template #normalTemplate>\n\t<div class=\"iui-text-input__label-row\" *ngIf=\"label || showCounter\">\n\t\t<label *ngIf=\"label\" class=\"iui-text-input__label\" [attr.for]=\"_inputId\" [id]=\"_labelId\">\n\t\t\t{{ label }}<span class=\"iui-text-input__required\" *ngIf=\"required\">*</span>\n\t\t</label>\n\t\t<span class=\"iui-text-input__counter\" *ngIf=\"showCounter\">{{ _counterText }}</span>\n\t</div>\n\n\t<div class=\"iui-text-input__field\" (click)=\"_focusInput(inputElement)\">\n\t\t<span class=\"iui-text-input__prefix\">\n\t\t\t<ng-content select=\"[iui-prefix]\"></ng-content>\n\t\t</span>\n\n\t\t<input\n\t\t\t#inputElement\n\t\t\tclass=\"iui-text-input__input\"\n\t\t\t[required]=\"required\"\n\t\t\t[disabled]=\"disabled\"\n\t\t\t[attr.aria-invalid]=\"_errorState\"\n\t\t\t[attr.aria-disabled]=\"disabled.toString()\"\n\t\t\t[attr.aria-labelledby]=\"label ? _labelId : null\"\n\t\t\t[attr.autocomplete]=\"autocomplete\"\n\t\t\t[attr.maxlength]=\"maxLength\"\n\t\t\t[placeholder]=\"placeholder\"\n\t\t\t[name]=\"name\"\n\t\t\t[attr.name]=\"name\"\n\t\t\t[type]=\"type\"\n\t\t\t[id]=\"_inputId\"\n\t\t\t[value]=\"_value\"\n\t\t\t[ngModel]=\"_value\"\n\t\t\t(ngModelChange)=\"modelChangeHandler($event)\"\n\t\t\t(focus)=\"_onFocus()\"\n\t\t\t(blur)=\"_onBlur()\"\n\t\t/>\n\n\t\t<iui-close-empty-icon\n\t\t\t*ngIf=\"cancelable && !empty && !disabled\"\n\t\t\t(click)=\"_cancelSelection($event)\"\n\t\t\tclass=\"iui-text-input__clear-icon iui-icon iui-icon_size_s\"\n\t\t\t[attr.aria-label]=\"'Clear'\"\n\t\t></iui-close-empty-icon>\n\n\t\t<span class=\"iui-text-input__suffix\">\n\t\t\t<ng-content select=\"[iui-suffix]\"></ng-content>\n\t\t</span>\n\t</div>\n\n\t<div class=\"iui-text-input__helper-row\">\n\t\t<span *ngIf=\"_errorState\" class=\"iui-text-input__error\">\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\n\t\t</span>\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-text-input__helper\">\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\n\t\t</span>\n\t</div>\n</ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;min-width:206px;max-width:100%}.iui-text-input__label-row{display:flex;align-items:flex-start;justify-content:space-between;padding-bottom:8px}.iui-text-input__label{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-label-color);flex:1;min-width:1px}.iui-text-input__required{color:var(--iui-text-input-error-color);margin-left:4px}.iui-text-input__counter{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-label-color);padding-left:8px;flex-shrink:0;white-space:nowrap}.iui-text-input__field{display:flex;align-items:center;gap:8px;overflow:hidden;background:var(--iui-text-input-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:text}:host.iui-text-input_size_l .iui-text-input__field{padding:12px 16px;border-radius:var(--iui-border-radius-medium)}:host.iui-text-input_size_m .iui-text-input__field{padding:8px 12px;border-radius:var(--iui-border-radius-medium)}:host.iui-text-input_size_s .iui-text-input__field{padding:4px 8px;border-radius:var(--iui-border-radius)}.iui-text-input__input{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-text-input-color);background:transparent;border:none;outline:none;padding:0;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.iui-text-input__input::placeholder{color:var(--iui-text-input-placeholder-color)}.iui-text-input__input:disabled{color:var(--iui-text-input-disabled-color)}.iui-text-input__input:disabled::placeholder{color:var(--iui-text-input-disabled-color)}.iui-text-input__prefix,.iui-text-input__suffix{display:inline-flex;align-items:center;flex-shrink:0}.iui-text-input__prefix:empty,.iui-text-input__suffix:empty{display:none}.iui-text-input__clear-icon{flex-shrink:0;cursor:pointer;color:inherit;pointer-events:auto}:host.iui-text-input_invalid .iui-text-input__clear-icon{color:var(--iui-text-input-error-color)}.iui-text-input__helper-row{padding-top:8px}.iui-text-input__helper{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-helper-color)}.iui-text-input__error{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-error-color)}:host.iui-text-input_focused .iui-text-input__field{border-color:var(--iui-text-input-focus-border)}:host.iui-text-input_invalid .iui-text-input__field{border-color:var(--iui-text-input-error-border)}:host.iui-text-input_disabled .iui-text-input__field{cursor:default;pointer-events:none}:host.iui-text-input_disabled .iui-text-input__label,:host.iui-text-input_disabled .iui-text-input__counter{color:var(--iui-text-input-disabled-color)}:host.iui-text-input_disabled .iui-text-input__helper{color:var(--iui-text-input-disabled-color)}:host.iui-text-input_layer-set-02 .iui-text-input__field{background:var(--iui-text-input-bg-layer-02)}.iui-text-input__skeleton-field{height:44px;border-radius:var(--iui-border-radius-medium);background:var(--iui-text-input-skeleton-bg)}.iui-text-input__skeleton-helper{margin-top:8px;width:40px;height:8px;background:var(--iui-text-input-skeleton-bg)}:host.iui-text-input_size_m .iui-text-input__skeleton-field{height:36px}:host.iui-text-input_size_s .iui-text-input__skeleton-field{height:28px;border-radius:var(--iui-border-radius)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: CloseEmptyIconComponent, selector: "iui-close-empty-icon" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTextInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-text-input', standalone: true, imports: [CommonModule, FormsModule, CloseEmptyIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiTextInputComponent),
                            multi: true
                        }
                    ], host: {
                        class: 'iui-text-input',
                        '[class.iui-text-input_size_l]': 'size === "l"',
                        '[class.iui-text-input_size_m]': 'size === "m"',
                        '[class.iui-text-input_size_s]': 'size === "s"',
                        '[class.iui-text-input_layer-set-02]': 'layerSet === "set-02"',
                        '[class.iui-text-input_required]': 'required',
                        '[class.iui-text-input_disabled]': 'disabled',
                        '[class.iui-text-input_invalid]': '_errorState',
                        '[class.iui-text-input_focused]': '_focused',
                        '[class.iui-text-input_filled]': '!empty',
                        '[class.iui-text-input_skeleton]': 'skeleton',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\n\t<div class=\"iui-text-input__skeleton-field\"></div>\n\t<div class=\"iui-text-input__skeleton-helper\"></div>\n</ng-container>\n\n<ng-template #normalTemplate>\n\t<div class=\"iui-text-input__label-row\" *ngIf=\"label || showCounter\">\n\t\t<label *ngIf=\"label\" class=\"iui-text-input__label\" [attr.for]=\"_inputId\" [id]=\"_labelId\">\n\t\t\t{{ label }}<span class=\"iui-text-input__required\" *ngIf=\"required\">*</span>\n\t\t</label>\n\t\t<span class=\"iui-text-input__counter\" *ngIf=\"showCounter\">{{ _counterText }}</span>\n\t</div>\n\n\t<div class=\"iui-text-input__field\" (click)=\"_focusInput(inputElement)\">\n\t\t<span class=\"iui-text-input__prefix\">\n\t\t\t<ng-content select=\"[iui-prefix]\"></ng-content>\n\t\t</span>\n\n\t\t<input\n\t\t\t#inputElement\n\t\t\tclass=\"iui-text-input__input\"\n\t\t\t[required]=\"required\"\n\t\t\t[disabled]=\"disabled\"\n\t\t\t[attr.aria-invalid]=\"_errorState\"\n\t\t\t[attr.aria-disabled]=\"disabled.toString()\"\n\t\t\t[attr.aria-labelledby]=\"label ? _labelId : null\"\n\t\t\t[attr.autocomplete]=\"autocomplete\"\n\t\t\t[attr.maxlength]=\"maxLength\"\n\t\t\t[placeholder]=\"placeholder\"\n\t\t\t[name]=\"name\"\n\t\t\t[attr.name]=\"name\"\n\t\t\t[type]=\"type\"\n\t\t\t[id]=\"_inputId\"\n\t\t\t[value]=\"_value\"\n\t\t\t[ngModel]=\"_value\"\n\t\t\t(ngModelChange)=\"modelChangeHandler($event)\"\n\t\t\t(focus)=\"_onFocus()\"\n\t\t\t(blur)=\"_onBlur()\"\n\t\t/>\n\n\t\t<iui-close-empty-icon\n\t\t\t*ngIf=\"cancelable && !empty && !disabled\"\n\t\t\t(click)=\"_cancelSelection($event)\"\n\t\t\tclass=\"iui-text-input__clear-icon iui-icon iui-icon_size_s\"\n\t\t\t[attr.aria-label]=\"'Clear'\"\n\t\t></iui-close-empty-icon>\n\n\t\t<span class=\"iui-text-input__suffix\">\n\t\t\t<ng-content select=\"[iui-suffix]\"></ng-content>\n\t\t</span>\n\t</div>\n\n\t<div class=\"iui-text-input__helper-row\">\n\t\t<span *ngIf=\"_errorState\" class=\"iui-text-input__error\">\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\n\t\t</span>\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-text-input__helper\">\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\n\t\t</span>\n\t</div>\n</ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;min-width:206px;max-width:100%}.iui-text-input__label-row{display:flex;align-items:flex-start;justify-content:space-between;padding-bottom:8px}.iui-text-input__label{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-label-color);flex:1;min-width:1px}.iui-text-input__required{color:var(--iui-text-input-error-color);margin-left:4px}.iui-text-input__counter{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-label-color);padding-left:8px;flex-shrink:0;white-space:nowrap}.iui-text-input__field{display:flex;align-items:center;gap:8px;overflow:hidden;background:var(--iui-text-input-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:text}:host.iui-text-input_size_l .iui-text-input__field{padding:12px 16px;border-radius:var(--iui-border-radius-medium)}:host.iui-text-input_size_m .iui-text-input__field{padding:8px 12px;border-radius:var(--iui-border-radius-medium)}:host.iui-text-input_size_s .iui-text-input__field{padding:4px 8px;border-radius:var(--iui-border-radius)}.iui-text-input__input{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-text-input-color);background:transparent;border:none;outline:none;padding:0;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.iui-text-input__input::placeholder{color:var(--iui-text-input-placeholder-color)}.iui-text-input__input:disabled{color:var(--iui-text-input-disabled-color)}.iui-text-input__input:disabled::placeholder{color:var(--iui-text-input-disabled-color)}.iui-text-input__prefix,.iui-text-input__suffix{display:inline-flex;align-items:center;flex-shrink:0}.iui-text-input__prefix:empty,.iui-text-input__suffix:empty{display:none}.iui-text-input__clear-icon{flex-shrink:0;cursor:pointer;color:inherit;pointer-events:auto}:host.iui-text-input_invalid .iui-text-input__clear-icon{color:var(--iui-text-input-error-color)}.iui-text-input__helper-row{padding-top:8px}.iui-text-input__helper{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-helper-color)}.iui-text-input__error{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-error-color)}:host.iui-text-input_focused .iui-text-input__field{border-color:var(--iui-text-input-focus-border)}:host.iui-text-input_invalid .iui-text-input__field{border-color:var(--iui-text-input-error-border)}:host.iui-text-input_disabled .iui-text-input__field{cursor:default;pointer-events:none}:host.iui-text-input_disabled .iui-text-input__label,:host.iui-text-input_disabled .iui-text-input__counter{color:var(--iui-text-input-disabled-color)}:host.iui-text-input_disabled .iui-text-input__helper{color:var(--iui-text-input-disabled-color)}:host.iui-text-input_layer-set-02 .iui-text-input__field{background:var(--iui-text-input-bg-layer-02)}.iui-text-input__skeleton-field{height:44px;border-radius:var(--iui-border-radius-medium);background:var(--iui-text-input-skeleton-bg)}.iui-text-input__skeleton-helper{margin-top:8px;width:40px;height:8px;background:var(--iui-text-input-skeleton-bg)}:host.iui-text-input_size_m .iui-text-input__skeleton-field{height:36px}:host.iui-text-input_size_s .iui-text-input__skeleton-field{height:28px;border-radius:var(--iui-border-radius)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { inputElement: [{
                type: ViewChildren,
                args: ['inputElement']
            }], id: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], cancelable: [{
                type: Input
            }], name: [{
                type: Input
            }], autocomplete: [{
                type: Input
            }], type: [{
                type: Input
            }], size: [{
                type: Input
            }], layerSet: [{
                type: Input
            }], showCounter: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], required: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiTextInputComponent };
//# sourceMappingURL=itero-ui-components-angular-text-input.mjs.map
