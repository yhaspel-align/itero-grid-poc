import * as i0 from '@angular/core';
import { EventEmitter, inject, forwardRef, Output, Input, ViewChild, Component } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { CommonModule } from '@angular/common';
import * as i1 from '@itero/ui-components-angular/core';
import { IuiIsDisabledDirective, NgControlDirective } from '@itero/ui-components-angular/core';

let nextUniqueId = 0;
class IuiCheckboxMarkComponent {
    constructor() {
        /** The unique id of the element */
        this.id = `iui-checkbox-mark-${nextUniqueId++}`;
        this.skeleton = false;
        this.blurEvent = new EventEmitter();
        /**
         * @prop
         * @ignore
         */
        this._touched = false;
        /**
         * @prop
         * @ignore
         */
        this._checked = false;
        /**
         * @prop
         * @ignore
         */
        this._indeterminate = false;
        /**
         * @prop
         * @ignore
         */
        this.isDisabledDirective = inject(IuiIsDisabledDirective, { self: true });
        this.changeEvent = new EventEmitter();
        this.indeterminateChanged = new EventEmitter();
        /**
         * @prop
         * @ignore
         */
        this.propagateChange = () => undefined;
        /**
         * @prop
         * @ignore
         */
        this.propagateTouched = () => undefined;
    }
    /**
     * @prop
     * @ignore
     */
    get _inputId() {
        return this.id + '-input';
    }
    /**
     * input where you can pass desirable state of checkbox "true" or "false".
     * Can be helpful when you don't use formControl, otherwise you can patchValue of formControl
     * */
    set checked(value) {
        this._checked = value;
        this.indeterminate = false;
    }
    get checked() {
        return this._checked;
    }
    set indeterminate(value) {
        const updateCheckedState = (newIndeterminateState) => {
            if (newIndeterminateState) {
                this._checked = false;
            }
        };
        this.setIndeterminateInternal(value, updateCheckedState);
    }
    get indeterminate() {
        return this._indeterminate;
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled || this.skeleton;
    }
    /**
     * @method
     * @ignore
     */
    _blurHandler(event) {
        if (this.disabled) {
            return;
        }
        this.markAsTouched();
        this.blurEvent.emit(event);
    }
    /**
     * @method
     * @ignore
     */
    setIndeterminateInternal(value, cb) {
        const changed = value !== this._indeterminate;
        this._indeterminate = value;
        if (changed) {
            if (cb) {
                cb(this._indeterminate);
            }
            this.indeterminateChanged.emit(this._indeterminate);
        }
    }
    /**
     * @method
     * @ignore
     */
    markAsTouched() {
        if (!this._touched) {
            this.propagateTouched();
            this._touched = true;
        }
    }
    /**
     * @method
     * @ignore
     */
    _changeHandler(event) {
        if (this.disabled) {
            return;
        }
        this._checked = !this.checked;
        this.setIndeterminateInternal(false);
        this.markAsTouched();
        this.propagateChange(this._checked);
        this.changeEvent.emit({
            event,
            checked: this._checked
        });
    }
    writeValue(val) {
        this._checked = val;
        this.setIndeterminateInternal(false);
    }
    registerOnChange(fn) {
        this.propagateChange = fn;
    }
    registerOnTouched(fn) {
        this.propagateTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCheckboxMarkComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiCheckboxMarkComponent, isStandalone: true, selector: "iui-checkbox-mark", inputs: { id: "id", skeleton: "skeleton", checked: "checked", indeterminate: "indeterminate" }, outputs: { blurEvent: "blurEvent", changeEvent: "changeEvent", indeterminateChanged: "indeterminateChanged" }, host: { properties: { "class.iui-checkbox-mark_checked": "checked", "class.iui-checkbox-mark_indeterminate": "indeterminate", "class.iui-checkbox-mark_disabled": "disabled", "class.iui-checkbox-mark_skeleton": "skeleton", "attr.id": "id", "attr.data-testid": "id" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiCheckboxMarkComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "checkboxInput", first: true, predicate: ["checkboxInput"], descendants: true }], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<div\n\tclass=\"iui-checkbox-mark\"\n\t[attr.id]=\"id\"\n\t[attr.data-testid]=\"id\"\n\t[attr.aria-checked]=\"indeterminate ? 'mixed' : checked\"\n>\n\t<input\n\t\t#checkboxInput\n\t\t[attr.id]=\"_inputId\"\n\t\t[attr.data-testid]=\"_inputId\"\n\t\tclass=\"iui-checkbox-mark__input_native\"\n\t\t[disabled]=\"disabled\"\n\t\t(change)=\"_changeHandler($event)\"\n\t\t(blur)=\"_blurHandler($event)\"\n\t\t[checked]=\"checked\"\n\t\t[indeterminate]=\"indeterminate\"\n\t\ttype=\"checkbox\"\n\t/>\n\t<div class=\"iui-checkbox-mark__tickbox\"></div>\n\t<div class=\"iui-checkbox-mark__tick\"></div>\n</div>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:block;--checkbox-full-height: 20px}.iui-checkbox-mark__input_native{-webkit-appearance:none!important;-moz-appearance:none!important;appearance:none!important;border:0;overflow:hidden;outline:0;margin:0;padding:0;opacity:0;cursor:inherit;position:absolute;z-index:10;left:0;top:0;width:100%;height:100%}.iui-checkbox-mark{position:relative;padding:0;height:var(--checkbox-full-height);width:20px;display:flex;align-items:center;outline:none;border:none;background:transparent;cursor:pointer}:host.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark{cursor:default}.iui-checkbox-mark__tickbox{height:20px;width:20px;overflow:hidden;position:relative;flex-shrink:0;border-radius:var(--iui-main-unit);border:1px solid var(--iui-checkbox-border);background:var(--iui-checkbox-bg);transition:background-color .1s ease-in,border-color .1s ease-in}:host.iui-checkbox-mark_checked ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-checked-bg);border-color:var(--iui-checkbox-checked-bg)}:host.iui-checkbox-mark_indeterminate ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-checked-bg);border-color:var(--iui-checkbox-checked-bg)}:host.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-bg);border-color:var(--iui-checkbox-disabled-border)}:host.iui-checkbox-mark_checked.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-disabled-bg);border-color:var(--iui-checkbox-disabled-bg)}:host.iui-checkbox-mark_indeterminate.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-disabled-bg);border-color:var(--iui-checkbox-disabled-bg)}.iui-checkbox-mark__tickbox:before{content:\"\";position:absolute;inset:-4px;border:2px solid transparent;border-radius:calc(var(--iui-main-unit) * 2);transition:border-color .1s ease-in}.iui-checkbox-mark__input_native:focus-visible~.iui-checkbox-mark__tickbox:before{border-color:var(--iui-checkbox-focus-ring)}.iui-checkbox-mark__tick{position:absolute;z-index:1;display:inline-block;right:6.5px;top:calc((var(--checkbox-full-height) - 15px) * .5 - 2.4748737341px);transform:rotate(45deg);width:7px;height:15px;border-bottom:3px solid transparent;border-right:3px solid transparent}:host.iui-checkbox-mark_checked ::ng-deep .iui-checkbox-mark__tick{border-color:var(--iui-checkbox-checked-mark)}:host.iui-checkbox-mark_indeterminate ::ng-deep .iui-checkbox-mark__tick{transition:none;transform:none;border-right:none;border-bottom:4px solid var(--iui-checkbox-checked-mark);height:4px;width:8px;right:6px;top:calc((var(--checkbox-full-height) - 4px) * .5)}:host.iui-checkbox-mark_checked.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tick{border-color:var(--iui-checkbox-disabled-mark)}:host.iui-checkbox-mark_indeterminate.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tick{border-color:var(--iui-checkbox-disabled-mark)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCheckboxMarkComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-checkbox-mark', standalone: true, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiCheckboxMarkComponent),
                            multi: true
                        }
                    ], imports: [CommonModule], hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiIsDisabledDirective,
                            // eslint-disable-next-line @angular-eslint/no-inputs-metadata-property
                            inputs: ['isDisabled'],
                            // eslint-disable-next-line @angular-eslint/no-outputs-metadata-property
                            outputs: ['disableChangeEvent']
                        }
                    ], host: {
                        '[class.iui-checkbox-mark_checked]': 'checked',
                        '[class.iui-checkbox-mark_indeterminate]': 'indeterminate',
                        '[class.iui-checkbox-mark_disabled]': 'disabled',
                        '[class.iui-checkbox-mark_skeleton]': 'skeleton',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<div\n\tclass=\"iui-checkbox-mark\"\n\t[attr.id]=\"id\"\n\t[attr.data-testid]=\"id\"\n\t[attr.aria-checked]=\"indeterminate ? 'mixed' : checked\"\n>\n\t<input\n\t\t#checkboxInput\n\t\t[attr.id]=\"_inputId\"\n\t\t[attr.data-testid]=\"_inputId\"\n\t\tclass=\"iui-checkbox-mark__input_native\"\n\t\t[disabled]=\"disabled\"\n\t\t(change)=\"_changeHandler($event)\"\n\t\t(blur)=\"_blurHandler($event)\"\n\t\t[checked]=\"checked\"\n\t\t[indeterminate]=\"indeterminate\"\n\t\ttype=\"checkbox\"\n\t/>\n\t<div class=\"iui-checkbox-mark__tickbox\"></div>\n\t<div class=\"iui-checkbox-mark__tick\"></div>\n</div>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:block;--checkbox-full-height: 20px}.iui-checkbox-mark__input_native{-webkit-appearance:none!important;-moz-appearance:none!important;appearance:none!important;border:0;overflow:hidden;outline:0;margin:0;padding:0;opacity:0;cursor:inherit;position:absolute;z-index:10;left:0;top:0;width:100%;height:100%}.iui-checkbox-mark{position:relative;padding:0;height:var(--checkbox-full-height);width:20px;display:flex;align-items:center;outline:none;border:none;background:transparent;cursor:pointer}:host.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark{cursor:default}.iui-checkbox-mark__tickbox{height:20px;width:20px;overflow:hidden;position:relative;flex-shrink:0;border-radius:var(--iui-main-unit);border:1px solid var(--iui-checkbox-border);background:var(--iui-checkbox-bg);transition:background-color .1s ease-in,border-color .1s ease-in}:host.iui-checkbox-mark_checked ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-checked-bg);border-color:var(--iui-checkbox-checked-bg)}:host.iui-checkbox-mark_indeterminate ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-checked-bg);border-color:var(--iui-checkbox-checked-bg)}:host.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-bg);border-color:var(--iui-checkbox-disabled-border)}:host.iui-checkbox-mark_checked.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-disabled-bg);border-color:var(--iui-checkbox-disabled-bg)}:host.iui-checkbox-mark_indeterminate.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-disabled-bg);border-color:var(--iui-checkbox-disabled-bg)}.iui-checkbox-mark__tickbox:before{content:\"\";position:absolute;inset:-4px;border:2px solid transparent;border-radius:calc(var(--iui-main-unit) * 2);transition:border-color .1s ease-in}.iui-checkbox-mark__input_native:focus-visible~.iui-checkbox-mark__tickbox:before{border-color:var(--iui-checkbox-focus-ring)}.iui-checkbox-mark__tick{position:absolute;z-index:1;display:inline-block;right:6.5px;top:calc((var(--checkbox-full-height) - 15px) * .5 - 2.4748737341px);transform:rotate(45deg);width:7px;height:15px;border-bottom:3px solid transparent;border-right:3px solid transparent}:host.iui-checkbox-mark_checked ::ng-deep .iui-checkbox-mark__tick{border-color:var(--iui-checkbox-checked-mark)}:host.iui-checkbox-mark_indeterminate ::ng-deep .iui-checkbox-mark__tick{transition:none;transform:none;border-right:none;border-bottom:4px solid var(--iui-checkbox-checked-mark);height:4px;width:8px;right:6px;top:calc((var(--checkbox-full-height) - 4px) * .5)}:host.iui-checkbox-mark_checked.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tick{border-color:var(--iui-checkbox-disabled-mark)}:host.iui-checkbox-mark_indeterminate.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tick{border-color:var(--iui-checkbox-disabled-mark)}\n"] }]
        }], propDecorators: { checkboxInput: [{
                type: ViewChild,
                args: ['checkboxInput']
            }], id: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], blurEvent: [{
                type: Output
            }], checked: [{
                type: Input
            }], indeterminate: [{
                type: Input
            }], changeEvent: [{
                type: Output
            }], indeterminateChanged: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiCheckboxMarkComponent };
//# sourceMappingURL=itero-ui-components-angular-checkbox-mark.mjs.map
