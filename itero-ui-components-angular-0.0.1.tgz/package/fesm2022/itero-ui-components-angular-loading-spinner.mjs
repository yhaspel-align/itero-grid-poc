import * as i0 from '@angular/core';
import { Input, ChangeDetectionStrategy, Component } from '@angular/core';

class IuiLoadingSpinnerComponent {
    constructor() {
        this.size = 'large';
        this.onColor = false;
        this.overlay = false;
    }
    get resolvedSize() {
        if (this.size === 'large' || this.size === 'small')
            return this.size;
        const num = Number(this.size);
        return num && num < 32 ? 'small' : 'large';
    }
    get diameter() {
        return this.resolvedSize === 'large' ? 96 : 20;
    }
    get strokeWidth() {
        return this.resolvedSize === 'large' ? 12 : 2.5;
    }
    get viewBox() {
        return `0 0 ${this.diameter} ${this.diameter}`;
    }
    get center() {
        return this.diameter / 2;
    }
    get radius() {
        return (this.diameter - this.strokeWidth) / 2;
    }
    get strokeDasharray() {
        const circumference = 2 * Math.PI * this.radius;
        return `${circumference * 0.75} ${circumference * 0.25}`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiLoadingSpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiLoadingSpinnerComponent, isStandalone: true, selector: "iui-loading-spinner", inputs: { size: "size", onColor: "onColor", overlay: "overlay" }, host: { attributes: { "role": "progressbar", "tabIndex": "-1" }, properties: { "attr.aria-label": "\"Loading...\"", "class.iui-spinner_size_large": "resolvedSize === \"large\"", "class.iui-spinner_size_small": "resolvedSize === \"small\"", "class.iui-spinner_on-color": "onColor", "class.iui-spinner_overlay": "overlay" }, classAttribute: "iui-spinner" }, ngImport: i0, template: "<svg class=\"iui-spinner__svg\"\n     [attr.viewBox]=\"viewBox\"\n     xmlns=\"http://www.w3.org/2000/svg\">\n  <circle class=\"iui-spinner__track\"\n          [attr.cx]=\"center\"\n          [attr.cy]=\"center\"\n          [attr.r]=\"radius\"\n          [attr.stroke-width]=\"strokeWidth\"\n          fill=\"none\" />\n  <circle class=\"iui-spinner__arc\"\n          [attr.cx]=\"center\"\n          [attr.cy]=\"center\"\n          [attr.r]=\"radius\"\n          [attr.stroke-width]=\"strokeWidth\"\n          [attr.stroke-dasharray]=\"strokeDasharray\"\n          fill=\"none\"\n          stroke-linecap=\"round\" />\n</svg>\n", styles: [":host.iui-spinner{position:relative;display:flex;align-items:center;justify-content:center;width:100%;height:100%}:host.iui-spinner_overlay{background-color:var(--iui-spinner-overlay-bg);z-index:1100}:host.iui-spinner_size_large .iui-spinner__svg{width:96px;height:96px}:host.iui-spinner_size_small .iui-spinner__svg{width:20px;height:20px}.iui-spinner__svg{animation:iui-spinner-rotate 1.2s linear infinite}.iui-spinner__track{stroke:var(--iui-spinner-track)}.iui-spinner__arc{stroke:var(--iui-spinner-active)}:host.iui-spinner_on-color .iui-spinner__track{stroke:var(--iui-spinner-track-on-color)}:host.iui-spinner_on-color .iui-spinner__arc{stroke:var(--iui-spinner-active-on-color)}@keyframes iui-spinner-rotate{0%{transform:rotate(0)}to{transform:rotate(360deg)}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiLoadingSpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-loading-spinner', changeDetection: ChangeDetectionStrategy.OnPush, standalone: true, host: {
                        class: 'iui-spinner',
                        role: 'progressbar',
                        tabIndex: '-1',
                        '[attr.aria-label]': '"Loading..."',
                        '[class.iui-spinner_size_large]': 'resolvedSize === "large"',
                        '[class.iui-spinner_size_small]': 'resolvedSize === "small"',
                        '[class.iui-spinner_on-color]': 'onColor',
                        '[class.iui-spinner_overlay]': 'overlay'
                    }, template: "<svg class=\"iui-spinner__svg\"\n     [attr.viewBox]=\"viewBox\"\n     xmlns=\"http://www.w3.org/2000/svg\">\n  <circle class=\"iui-spinner__track\"\n          [attr.cx]=\"center\"\n          [attr.cy]=\"center\"\n          [attr.r]=\"radius\"\n          [attr.stroke-width]=\"strokeWidth\"\n          fill=\"none\" />\n  <circle class=\"iui-spinner__arc\"\n          [attr.cx]=\"center\"\n          [attr.cy]=\"center\"\n          [attr.r]=\"radius\"\n          [attr.stroke-width]=\"strokeWidth\"\n          [attr.stroke-dasharray]=\"strokeDasharray\"\n          fill=\"none\"\n          stroke-linecap=\"round\" />\n</svg>\n", styles: [":host.iui-spinner{position:relative;display:flex;align-items:center;justify-content:center;width:100%;height:100%}:host.iui-spinner_overlay{background-color:var(--iui-spinner-overlay-bg);z-index:1100}:host.iui-spinner_size_large .iui-spinner__svg{width:96px;height:96px}:host.iui-spinner_size_small .iui-spinner__svg{width:20px;height:20px}.iui-spinner__svg{animation:iui-spinner-rotate 1.2s linear infinite}.iui-spinner__track{stroke:var(--iui-spinner-track)}.iui-spinner__arc{stroke:var(--iui-spinner-active)}:host.iui-spinner_on-color .iui-spinner__track{stroke:var(--iui-spinner-track-on-color)}:host.iui-spinner_on-color .iui-spinner__arc{stroke:var(--iui-spinner-active-on-color)}@keyframes iui-spinner-rotate{0%{transform:rotate(0)}to{transform:rotate(360deg)}}\n"] }]
        }], propDecorators: { size: [{
                type: Input
            }], onColor: [{
                type: Input
            }], overlay: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiLoadingSpinnerComponent };
//# sourceMappingURL=itero-ui-components-angular-loading-spinner.mjs.map
