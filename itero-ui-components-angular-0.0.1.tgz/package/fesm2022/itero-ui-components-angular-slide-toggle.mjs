import * as i0 from '@angular/core';
import { inject, EventEmitter, forwardRef, Output, Input, Component } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i1 from '@itero/ui-components-angular/core';
import { IuiIsDisabledDirective, NgControlDirective } from '@itero/ui-components-angular/core';

let nextUniqueId = 0;
class IuiSlideToggleComponent {
    constructor() {
        /** The unique id of the element */
        this.id = `iui-slide-toggle-${nextUniqueId++}`;
        /** Position of the label rendered with slide-toggle can be 'left' or right'. Default is left */
        this.labelPosition = 'left';
        /** Whether to show the skeleton loading state */
        this.skeleton = false;
        /** Whether to show the value/label text. Default: true */
        this.showValue = true;
        this._touched = false;
        this._checked = false;
        this.isDisabledDirective = inject(IuiIsDisabledDirective, { self: true });
        this.changeEvent = new EventEmitter();
        this._propagateChange = (_) => { };
        this._propagateTouched = () => { };
    }
    get _inputId() {
        return this.id + '-input';
    }
    get _labelId() {
        return this.id + '-label';
    }
    /**
     * input where you can pass desirable state of slide-toggle "true" or "false".
     * Can be helpful when you don't use formControl, otherwise you can patchValue of formControl
     * */
    set checked(value) {
        this._checked = value;
    }
    get checked() {
        return this._checked;
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get effectivelyDisabled() {
        return this.disabled || this.skeleton;
    }
    _blurHandler() {
        if (this.effectivelyDisabled) {
            return;
        }
        this._markAsTouched();
    }
    _markAsTouched() {
        if (!this._touched) {
            this._propagateTouched();
            this._touched = true;
        }
    }
    _changeHandler(event) {
        if (this.effectivelyDisabled) {
            return;
        }
        this._checked = !this.checked;
        this._markAsTouched();
        this._propagateChange(this._checked);
        this.changeEvent.emit({
            event,
            checked: this._checked
        });
    }
    writeValue(val) {
        this._checked = val;
    }
    registerOnChange(fn) {
        this._propagateChange = fn;
    }
    registerOnTouched(fn) {
        this._propagateTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiSlideToggleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.12", type: IuiSlideToggleComponent, isStandalone: true, selector: "iui-slide-toggle", inputs: { id: "id", checked: "checked", labelPosition: "labelPosition", skeleton: "skeleton", showValue: "showValue" }, outputs: { changeEvent: "changeEvent" }, host: { properties: { "class.iui-slide-toggle_checked": "checked", "class.iui-slide-toggle_disabled": "disabled", "class.iui-slide-toggle_skeleton": "skeleton", "attr.id": "id", "attr.data-testid": "id" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiSlideToggleComponent),
                multi: true
            }
        ], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<label [for]=\"_inputId\" [attr.data-testid]=\"_labelId\" [attr.id]=\"_labelId\">\n\t@if (labelPosition === 'left' && showValue && !skeleton) {\n\t\t<span class=\"iui-slide-toggle__label-text\"><ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container></span>\n\t}\n\n\t<input\n\t\t[attr.id]=\"_inputId\"\n\t\t[attr.data-testid]=\"_inputId\"\n\t\tclass=\"iui-slide-toggle__input_hidden\"\n\t\t[disabled]=\"effectivelyDisabled\"\n\t\t(change)=\"_changeHandler($event)\"\n\t\t(blur)=\"_blurHandler()\"\n\t\t[checked]=\"checked\"\n\t\trole=\"switch\"\n\t\ttype=\"checkbox\"\n\t/>\n\t<div class=\"iui-slide-toggle__trigger\">\n\t\t<div class=\"iui-slide-toggle__handle\"></div>\n\t</div>\n\n\t@if (labelPosition === 'right' && showValue && !skeleton) {\n\t\t<span class=\"iui-slide-toggle__label-text\"><ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container></span>\n\t}\n\n\t@if (skeleton) {\n\t\t<span class=\"iui-slide-toggle__skeleton-placeholder\"></span>\n\t}\n</label>\n\n<ng-template #contentTpl><ng-content></ng-content></ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:inline-block}label{display:inline-flex;align-items:center;gap:8px;cursor:pointer}:host(.iui-slide-toggle_disabled) label,:host(.iui-slide-toggle_skeleton) label{cursor:default}.iui-slide-toggle__label-text{font:var(--iui-tp-body-01-font, 400 14px/20px var(--iui-font-family));color:var(--iui-slide-toggle-label-color);white-space:nowrap;-webkit-user-select:none;user-select:none;cursor:pointer}:host.iui-slide-toggle_disabled ::ng-deep .iui-slide-toggle__label-text{color:var(--iui-slide-toggle-label-disabled-color);cursor:default}.iui-slide-toggle__input_hidden{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.iui-slide-toggle__trigger{position:relative;width:32px;height:20px;flex-shrink:0;border-radius:10000px;background-color:var(--iui-slide-toggle-track-off);cursor:pointer;transition:background-color .1s ease-in;outline:none;border:none;padding:0}.iui-slide-toggle__trigger:hover{background-color:var(--iui-slide-toggle-track-off-hover)}.iui-slide-toggle__trigger:active{background-color:var(--iui-slide-toggle-track-off-active)}.iui-slide-toggle__trigger:before{content:\"\";position:absolute;inset:-2px;border:2px solid transparent;border-radius:10000px;pointer-events:none;transition:border-color .1s ease-in}.iui-slide-toggle__input_hidden:focus-visible~.iui-slide-toggle__trigger:before{border-color:var(--iui-slide-toggle-focus-border)}.iui-slide-toggle__handle{position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background-color:var(--iui-slide-toggle-handle);transition:transform 75ms cubic-bezier(.4,0,.2,1)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__trigger{background-color:var(--iui-slide-toggle-track-on)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__trigger:hover{background-color:var(--iui-slide-toggle-track-on-hover)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__trigger:active{background-color:var(--iui-slide-toggle-track-on-active)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__handle{transform:translate(12px)}:host(.iui-slide-toggle_disabled){pointer-events:none;cursor:default}:host(.iui-slide-toggle_disabled) .iui-slide-toggle__trigger{background-color:var(--iui-slide-toggle-track-disabled)}:host(.iui-slide-toggle_disabled) .iui-slide-toggle__trigger:hover,:host(.iui-slide-toggle_disabled) .iui-slide-toggle__trigger:active{background-color:var(--iui-slide-toggle-track-disabled)}:host(.iui-slide-toggle_skeleton){pointer-events:none}:host(.iui-slide-toggle_skeleton) .iui-slide-toggle__trigger{background-color:var(--iui-slide-toggle-track-disabled)}.iui-slide-toggle__skeleton-placeholder{width:40px;height:8px;border-radius:4px;background-color:var(--iui-slide-toggle-skeleton-bg)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiSlideToggleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-slide-toggle', standalone: true, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiSlideToggleComponent),
                            multi: true
                        }
                    ], imports: [CommonModule], hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], host: {
                        '[class.iui-slide-toggle_checked]': 'checked',
                        '[class.iui-slide-toggle_disabled]': 'disabled',
                        '[class.iui-slide-toggle_skeleton]': 'skeleton',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<label [for]=\"_inputId\" [attr.data-testid]=\"_labelId\" [attr.id]=\"_labelId\">\n\t@if (labelPosition === 'left' && showValue && !skeleton) {\n\t\t<span class=\"iui-slide-toggle__label-text\"><ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container></span>\n\t}\n\n\t<input\n\t\t[attr.id]=\"_inputId\"\n\t\t[attr.data-testid]=\"_inputId\"\n\t\tclass=\"iui-slide-toggle__input_hidden\"\n\t\t[disabled]=\"effectivelyDisabled\"\n\t\t(change)=\"_changeHandler($event)\"\n\t\t(blur)=\"_blurHandler()\"\n\t\t[checked]=\"checked\"\n\t\trole=\"switch\"\n\t\ttype=\"checkbox\"\n\t/>\n\t<div class=\"iui-slide-toggle__trigger\">\n\t\t<div class=\"iui-slide-toggle__handle\"></div>\n\t</div>\n\n\t@if (labelPosition === 'right' && showValue && !skeleton) {\n\t\t<span class=\"iui-slide-toggle__label-text\"><ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container></span>\n\t}\n\n\t@if (skeleton) {\n\t\t<span class=\"iui-slide-toggle__skeleton-placeholder\"></span>\n\t}\n</label>\n\n<ng-template #contentTpl><ng-content></ng-content></ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:inline-block}label{display:inline-flex;align-items:center;gap:8px;cursor:pointer}:host(.iui-slide-toggle_disabled) label,:host(.iui-slide-toggle_skeleton) label{cursor:default}.iui-slide-toggle__label-text{font:var(--iui-tp-body-01-font, 400 14px/20px var(--iui-font-family));color:var(--iui-slide-toggle-label-color);white-space:nowrap;-webkit-user-select:none;user-select:none;cursor:pointer}:host.iui-slide-toggle_disabled ::ng-deep .iui-slide-toggle__label-text{color:var(--iui-slide-toggle-label-disabled-color);cursor:default}.iui-slide-toggle__input_hidden{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.iui-slide-toggle__trigger{position:relative;width:32px;height:20px;flex-shrink:0;border-radius:10000px;background-color:var(--iui-slide-toggle-track-off);cursor:pointer;transition:background-color .1s ease-in;outline:none;border:none;padding:0}.iui-slide-toggle__trigger:hover{background-color:var(--iui-slide-toggle-track-off-hover)}.iui-slide-toggle__trigger:active{background-color:var(--iui-slide-toggle-track-off-active)}.iui-slide-toggle__trigger:before{content:\"\";position:absolute;inset:-2px;border:2px solid transparent;border-radius:10000px;pointer-events:none;transition:border-color .1s ease-in}.iui-slide-toggle__input_hidden:focus-visible~.iui-slide-toggle__trigger:before{border-color:var(--iui-slide-toggle-focus-border)}.iui-slide-toggle__handle{position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background-color:var(--iui-slide-toggle-handle);transition:transform 75ms cubic-bezier(.4,0,.2,1)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__trigger{background-color:var(--iui-slide-toggle-track-on)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__trigger:hover{background-color:var(--iui-slide-toggle-track-on-hover)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__trigger:active{background-color:var(--iui-slide-toggle-track-on-active)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__handle{transform:translate(12px)}:host(.iui-slide-toggle_disabled){pointer-events:none;cursor:default}:host(.iui-slide-toggle_disabled) .iui-slide-toggle__trigger{background-color:var(--iui-slide-toggle-track-disabled)}:host(.iui-slide-toggle_disabled) .iui-slide-toggle__trigger:hover,:host(.iui-slide-toggle_disabled) .iui-slide-toggle__trigger:active{background-color:var(--iui-slide-toggle-track-disabled)}:host(.iui-slide-toggle_skeleton){pointer-events:none}:host(.iui-slide-toggle_skeleton) .iui-slide-toggle__trigger{background-color:var(--iui-slide-toggle-track-disabled)}.iui-slide-toggle__skeleton-placeholder{width:40px;height:8px;border-radius:4px;background-color:var(--iui-slide-toggle-skeleton-bg)}\n"] }]
        }], propDecorators: { id: [{
                type: Input
            }], checked: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], showValue: [{
                type: Input
            }], changeEvent: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiSlideToggleComponent };
//# sourceMappingURL=itero-ui-components-angular-slide-toggle.mjs.map
