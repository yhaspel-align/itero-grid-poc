import * as i0 from '@angular/core';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';

class AccountIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AccountIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AccountIconComponent, isStandalone: true, selector: "iui-account-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 8a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm0 8a3 3 0 1 1 0-5.999A3 3 0 0 1 16 16z" fill="currentColor"></path><path d="M16 2a14 14 0 1 0 14 14A14.016 14.016 0 0 0 16 2zm-6 24.377V25a3.003 3.003 0 0 1 3-3h6a3.004 3.004 0 0 1 3 3v1.377a11.899 11.899 0 0 1-12 0zm13.992-1.451A5.002 5.002 0 0 0 19 20h-6a5.001 5.001 0 0 0-4.992 4.926 12 12 0 1 1 15.985 0z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AccountIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-account-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 8a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm0 8a3 3 0 1 1 0-5.999A3 3 0 0 1 16 16z" fill="currentColor"></path><path d="M16 2a14 14 0 1 0 14 14A14.016 14.016 0 0 0 16 2zm-6 24.377V25a3.003 3.003 0 0 1 3-3h6a3.004 3.004 0 0 1 3 3v1.377a11.899 11.899 0 0 1-12 0zm13.992-1.451A5.002 5.002 0 0 0 19 20h-6a5.001 5.001 0 0 0-4.992 4.926 12 12 0 1 1 15.985 0z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AddCommentIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AddCommentIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AddCommentIconComponent, isStandalone: true, selector: "iui-add-comment-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17.74 30 16 29l4-7h6a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h9v2H6a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v12a4 4 0 0 1-4 4h-4.84l-3.42 6z" fill="currentColor"></path><path d="M17 9h-2v4h-4v2h4v4h2v-4h4v-2h-4V9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AddCommentIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-add-comment-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17.74 30 16 29l4-7h6a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h9v2H6a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v12a4 4 0 0 1-4 4h-4.84l-3.42 6z" fill="currentColor"></path><path d="M17 9h-2v4h-4v2h4v4h2v-4h4v-2h-4V9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AddEmptyIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AddEmptyIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AddEmptyIconComponent, isStandalone: true, selector: "iui-add-empty-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17 15V8h-2v7H8v2h7v7h2v-7h7v-2h-7z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AddEmptyIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-add-empty-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17 15V8h-2v7H8v2h7v7h2v-7h7v-2h-7z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AddFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AddFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AddFillIconComponent, isStandalone: true, selector: "iui-add-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2C8.4 2 2 8.4 2 16s6.4 14 14 14 14-6.4 14-14S23.6 2 16 2zm8 15h-7v7h-2v-7H8v-2h7V8h2v7h7v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AddFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-add-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2C8.4 2 2 8.4 2 16s6.4 14 14 14 14-6.4 14-14S23.6 2 16 2zm8 15h-7v7h-2v-7H8v-2h7V8h2v7h7v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlarmAddIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlarmAddIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlarmAddIconComponent, isStandalone: true, selector: "iui-alarm-add-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 28a11 11 0 1 1 0-22 11 11 0 0 1 0 22zm0-20a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM7.582 4.003 4 7.592l1.416 1.413 3.581-3.59-1.415-1.412zM24.415 3.994 23 5.407l3.58 3.589 1.417-1.413-3.582-3.589z" fill="currentColor"></path><path d="M21 16h-4v-4h-2v4h-4v2h4v4h2v-4h4v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlarmAddIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-alarm-add-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 28a11 11 0 1 1 0-22 11 11 0 0 1 0 22zm0-20a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM7.582 4.003 4 7.592l1.416 1.413 3.581-3.59-1.415-1.412zM24.415 3.994 23 5.407l3.58 3.589 1.417-1.413-3.582-3.589z" fill="currentColor"></path><path d="M21 16h-4v-4h-2v4h-4v2h4v4h2v-4h4v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlarmIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlarmIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlarmIconComponent, isStandalone: true, selector: "iui-alarm-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 28a11 11 0 1 1 0-22 11 11 0 0 1 0 22zm0-20a9 9 0 1 0 0 18 9 9 0 0 0 0-18z" fill="currentColor"></path><path d="M18.59 21 15 17.41V11h2v5.58l3 3.01L18.59 21zM7.582 4.003 4 7.592l1.416 1.413 3.581-3.59-1.415-1.412zM24.415 3.994 23 5.407l3.58 3.589 1.417-1.413-3.582-3.589z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlarmIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-alarm-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 28a11 11 0 1 1 0-22 11 11 0 0 1 0 22zm0-20a9 9 0 1 0 0 18 9 9 0 0 0 0-18z" fill="currentColor"></path><path d="M18.59 21 15 17.41V11h2v5.58l3 3.01L18.59 21zM7.582 4.003 4 7.592l1.416 1.413 3.581-3.59-1.415-1.412zM24.415 3.994 23 5.407l3.58 3.589 1.417-1.413-3.582-3.589z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlarmSubtractIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlarmSubtractIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlarmSubtractIconComponent, isStandalone: true, selector: "iui-alarm-subtract-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 28a11 11 0 1 1 0-22 11 11 0 0 1 0 22zm0-20a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM7.582 4.003 4 7.592l1.416 1.413 3.581-3.59-1.415-1.412zM24.415 3.994 23 5.407l3.58 3.589 1.417-1.413-3.582-3.589z" fill="currentColor"></path><path d="M21 16H11v2h10v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlarmSubtractIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-alarm-subtract-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 28a11 11 0 1 1 0-22 11 11 0 0 1 0 22zm0-20a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM7.582 4.003 4 7.592l1.416 1.413 3.581-3.59-1.415-1.412zM24.415 3.994 23 5.407l3.58 3.589 1.417-1.413-3.582-3.589z" fill="currentColor"></path><path d="M21 16H11v2h10v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignBoxBottomCenterIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxBottomCenterIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignBoxBottomCenterIconComponent, isStandalone: true, selector: "iui-align-box-bottom-center-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M10 20h12v-2H10v2zM12 25h8v-2h-8v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxBottomCenterIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-box-bottom-center-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M10 20h12v-2H10v2zM12 25h8v-2h-8v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignBoxBottomLeftIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxBottomLeftIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignBoxBottomLeftIconComponent, isStandalone: true, selector: "iui-align-box-bottom-left-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M20 18H9v2h11v-2zM16 23H9v2h7v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxBottomLeftIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-box-bottom-left-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M20 18H9v2h11v-2zM16 23H9v2h7v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignBoxBottomRightIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxBottomRightIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignBoxBottomRightIconComponent, isStandalone: true, selector: "iui-align-box-bottom-right-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M12 20h11v-2H12v2zM16 25h7v-2h-7v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxBottomRightIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-box-bottom-right-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M12 20h11v-2H12v2zM16 25h7v-2h-7v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignBoxMiddleCenterIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxMiddleCenterIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignBoxMiddleCenterIconComponent, isStandalone: true, selector: "iui-align-box-middle-center-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M10 15h12v-2H10v2zM12 20h8v-2h-8v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxMiddleCenterIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-box-middle-center-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M10 15h12v-2H10v2zM12 20h8v-2h-8v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignBoxMiddleLeftIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxMiddleLeftIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignBoxMiddleLeftIconComponent, isStandalone: true, selector: "iui-align-box-middle-left-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M20 13H9v2h11v-2zM16 18H9v2h7v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxMiddleLeftIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-box-middle-left-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M20 13H9v2h11v-2zM16 18H9v2h7v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignBoxMiddleRightIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxMiddleRightIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignBoxMiddleRightIconComponent, isStandalone: true, selector: "iui-align-box-middle-right-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M12 15h11v-2H12v2zM16 20h7v-2h-7v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxMiddleRightIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-box-middle-right-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M12 15h11v-2H12v2zM16 20h7v-2h-7v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignBoxTopCenterIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxTopCenterIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignBoxTopCenterIconComponent, isStandalone: true, selector: "iui-align-box-top-center-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M10 9h12V7H10v2zM12 14h8v-2h-8v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxTopCenterIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-box-top-center-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M10 9h12V7H10v2zM12 14h8v-2h-8v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignBoxTopLeftIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxTopLeftIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignBoxTopLeftIconComponent, isStandalone: true, selector: "iui-align-box-top-left-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M20 7H9v2h11V7zM16 12H9v2h7v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxTopLeftIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-box-top-left-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M20 7H9v2h11V7zM16 12H9v2h7v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignBoxTopRightIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxTopRightIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignBoxTopRightIconComponent, isStandalone: true, selector: "iui-align-box-top-right-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M12 9h11V7H12v2zM16 14h7v-2h-7v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignBoxTopRightIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-box-top-right-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM6 4v24h20V4H6z" fill="currentColor"></path><path d="M12 9h11V7H12v2zM16 14h7v-2h-7v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignHorizontalCenterIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignHorizontalCenterIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignHorizontalCenterIconComponent, isStandalone: true, selector: "iui-align-horizontal-center-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 18h-7v-4h3a2.003 2.003 0 0 0 2-2V8a2.003 2.003 0 0 0-2-2h-3V2h-2v4h-3a2.003 2.003 0 0 0-2 2v4a2.003 2.003 0 0 0 2 2h3v4H8a2.003 2.003 0 0 0-2 2v4a2.003 2.003 0 0 0 2 2h7v4h2v-4h7a2.003 2.003 0 0 0 2-2v-4a2.003 2.003 0 0 0-2-2zM12 8h8v4h-8V8zm12 16H8v-4h16v4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignHorizontalCenterIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-horizontal-center-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 18h-7v-4h3a2.003 2.003 0 0 0 2-2V8a2.003 2.003 0 0 0-2-2h-3V2h-2v4h-3a2.003 2.003 0 0 0-2 2v4a2.003 2.003 0 0 0 2 2h3v4H8a2.003 2.003 0 0 0-2 2v4a2.003 2.003 0 0 0 2 2h7v4h2v-4h7a2.003 2.003 0 0 0 2-2v-4a2.003 2.003 0 0 0-2-2zM12 8h8v4h-8V8zm12 16H8v-4h16v4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignHorizontalLeftIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignHorizontalLeftIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignHorizontalLeftIconComponent, isStandalone: true, selector: "iui-align-horizontal-left-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 26H11a2.002 2.002 0 0 1-2-2v-4a2.002 2.002 0 0 1 2-2h15a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zm0-6.001L11 20v4h15v-4.001zM18 14h-7a2.002 2.002 0 0 1-2-2V8a2.002 2.002 0 0 1 2-2h7a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zm0-6.001L11 8v4h7V7.999zM6 2H4v28h2V2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignHorizontalLeftIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-horizontal-left-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 26H11a2.002 2.002 0 0 1-2-2v-4a2.002 2.002 0 0 1 2-2h15a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zm0-6.001L11 20v4h15v-4.001zM18 14h-7a2.002 2.002 0 0 1-2-2V8a2.002 2.002 0 0 1 2-2h7a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zm0-6.001L11 8v4h7V7.999zM6 2H4v28h2V2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignHorizontalRightIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignHorizontalRightIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignHorizontalRightIconComponent, isStandalone: true, selector: "iui-align-horizontal-right-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 24v-4a2.002 2.002 0 0 1 2-2h15a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2H6a2.002 2.002 0 0 1-2-2zm2 0h15v-4l-15-.001V24zM12 12V8a2.002 2.002 0 0 1 2-2h7a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2h-7a2.002 2.002 0 0 1-2-2zm2 0h7V8l-7-.001V12zM26 30h2V2h-2v28z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignHorizontalRightIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-horizontal-right-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 24v-4a2.002 2.002 0 0 1 2-2h15a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2H6a2.002 2.002 0 0 1-2-2zm2 0h15v-4l-15-.001V24zM12 12V8a2.002 2.002 0 0 1 2-2h7a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2h-7a2.002 2.002 0 0 1-2-2zm2 0h7V8l-7-.001V12zM26 30h2V2h-2v28z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignVerticalBottomIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignVerticalBottomIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignVerticalBottomIconComponent, isStandalone: true, selector: "iui-align-vertical-bottom-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 26H2v2h28v-2zM24 23h-4a2.002 2.002 0 0 1-2-2v-7a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v7a2.002 2.002 0 0 1-2 2zm-4-9v7h4.001L24 14h-4zM12 23H8a2.002 2.002 0 0 1-2-2V6a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v15a2.002 2.002 0 0 1-2 2zM8 6v15h4.001L12 6H8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignVerticalBottomIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-vertical-bottom-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 26H2v2h28v-2zM24 23h-4a2.002 2.002 0 0 1-2-2v-7a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v7a2.002 2.002 0 0 1-2 2zm-4-9v7h4.001L24 14h-4zM12 23H8a2.002 2.002 0 0 1-2-2V6a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v15a2.002 2.002 0 0 1-2 2zM8 6v15h4.001L12 6H8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignVerticalCenterIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignVerticalCenterIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignVerticalCenterIconComponent, isStandalone: true, selector: "iui-align-vertical-center-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 15h-4v-3a2.003 2.003 0 0 0-2-2h-4a2.003 2.003 0 0 0-2 2v3h-4V8a2.003 2.003 0 0 0-2-2H8a2.002 2.002 0 0 0-2 2v7H2v2h4v7a2.003 2.003 0 0 0 2 2h4a2.003 2.003 0 0 0 2-2v-7h4v3a2.003 2.003 0 0 0 2 2h4a2.003 2.003 0 0 0 2-2v-3h4v-2zM8 24V8h4l.001 16H8zm12-4v-8h4l.001 8H20z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignVerticalCenterIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-vertical-center-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 15h-4v-3a2.003 2.003 0 0 0-2-2h-4a2.003 2.003 0 0 0-2 2v3h-4V8a2.003 2.003 0 0 0-2-2H8a2.002 2.002 0 0 0-2 2v7H2v2h4v7a2.003 2.003 0 0 0 2 2h4a2.003 2.003 0 0 0 2-2v-7h4v3a2.003 2.003 0 0 0 2 2h4a2.003 2.003 0 0 0 2-2v-3h4v-2zM8 24V8h4l.001 16H8zm12-4v-8h4l.001 8H20z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AlignVerticalTopIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignVerticalTopIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AlignVerticalTopIconComponent, isStandalone: true, selector: "iui-align-vertical-top-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 20h-4a2.002 2.002 0 0 1-2-2v-7a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v7a2.002 2.002 0 0 1-2 2zm-4-9v7h4.001L24 11h-4zM12 28H8a2.002 2.002 0 0 1-2-2V11a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v15a2.002 2.002 0 0 1-2 2zM8 11v15h4.001L12 11H8zM30 4H2v2h28V4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AlignVerticalTopIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-align-vertical-top-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 20h-4a2.002 2.002 0 0 1-2-2v-7a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v7a2.002 2.002 0 0 1-2 2zm-4-9v7h4.001L24 11h-4zM12 28H8a2.002 2.002 0 0 1-2-2V11a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v15a2.002 2.002 0 0 1-2 2zM8 11v15h4.001L12 11H8zM30 4H2v2h28V4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ArchiveIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArchiveIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ArchiveIconComponent, isStandalone: true, selector: "iui-archive-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M20 21h-8a2 2 0 0 1-2-2v-2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2zm-8-4v2h8v-2h-8z" fill="currentColor"></path><path d="M28 4H4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2v16a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2V12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm-2 24H6V12h20v16zm2-18H4V6h24v4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArchiveIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-archive-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M20 21h-8a2 2 0 0 1-2-2v-2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2zm-8-4v2h8v-2h-8z" fill="currentColor"></path><path d="M28 4H4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2v16a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2V12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm-2 24H6V12h20v16zm2-18H4V6h24v4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ArrowDownIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowDownIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ArrowDownIconComponent, isStandalone: true, selector: "iui-arrow-down-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24.59 16.59 17 24.17V4h-2v20.17l-7.59-7.58L6 18l10 10 10-10-1.41-1.41z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowDownIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-arrow-down-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24.59 16.59 17 24.17V4h-2v20.17l-7.59-7.58L6 18l10 10 10-10-1.41-1.41z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ArrowDownLeftIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowDownLeftIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ArrowDownLeftIconComponent, isStandalone: true, selector: "iui-arrow-down-left-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 26v-2H9.41L26 7.41 24.59 6 8 22.59V10H6v16h16z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowDownLeftIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-arrow-down-left-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 26v-2H9.41L26 7.41 24.59 6 8 22.59V10H6v16h16z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ArrowDownRightIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowDownRightIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ArrowDownRightIconComponent, isStandalone: true, selector: "iui-arrow-down-right-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 26v-2h12.59L6 7.41 7.41 6 24 22.59V10h2v16H10z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowDownRightIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-arrow-down-right-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 26v-2h12.59L6 7.41 7.41 6 24 22.59V10h2v16H10z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ArrowLeftIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowLeftIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ArrowLeftIconComponent, isStandalone: true, selector: "iui-arrow-left-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m14 26 1.41-1.41L7.83 17H28v-2H7.83l7.58-7.59L14 6 4 16l10 10z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowLeftIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-arrow-left-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m14 26 1.41-1.41L7.83 17H28v-2H7.83l7.58-7.59L14 6 4 16l10 10z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ArrowRightIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowRightIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ArrowRightIconComponent, isStandalone: true, selector: "iui-arrow-right-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m18 6-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10L18 6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowRightIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-arrow-right-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m18 6-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10L18 6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ArrowUpIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowUpIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ArrowUpIconComponent, isStandalone: true, selector: "iui-arrow-up-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 4 6 14l1.41 1.41L15 7.83V28h2V7.83l7.59 7.58L26 14 16 4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowUpIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-arrow-up-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 4 6 14l1.41 1.41L15 7.83V28h2V7.83l7.59 7.58L26 14 16 4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ArrowUpLeftIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowUpLeftIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ArrowUpLeftIconComponent, isStandalone: true, selector: "iui-arrow-up-left-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 6v2H9.41L26 24.59 24.59 26 8 9.41V22H6V6h16z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowUpLeftIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-arrow-up-left-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 6v2H9.41L26 24.59 24.59 26 8 9.41V22H6V6h16z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ArrowUpRightIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowUpRightIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ArrowUpRightIconComponent, isStandalone: true, selector: "iui-arrow-up-right-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 6v2h12.59L6 24.59 7.41 26 24 9.41V22h2V6H10z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ArrowUpRightIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-arrow-up-right-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 6v2h12.59L6 24.59 7.41 26 24 9.41V22h2V6H10z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AttachmentIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AttachmentIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AttachmentIconComponent, isStandalone: true, selector: "iui-attachment-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m28.1 18.9-15-15c-2.5-2.6-6.6-2.6-9.2-.1-2.6 2.5-2.6 6.7 0 9.2l.1.1L6.8 16l1.4-1.4-2.9-2.9c-1.7-1.7-1.7-4.6 0-6.3 1.7-1.7 4.6-1.8 6.3-.1l.1.1 14.9 14.9c1.8 1.7 1.8 4.6.1 6.3-1.7 1.8-4.6 1.8-6.3.1l-.1-.1-7.4-7.4c-1-1-.9-2.6 0-3.5 1-.9 2.5-.9 3.5 0l4.1 4.1 1.4-1.4-4.2-4.2c-1.8-1.7-4.6-1.6-6.3.2-1.6 1.7-1.6 4.4 0 6.2l7.5 7.5c2.5 2.6 6.6 2.6 9.2.1 2.6-2.5 2.6-6.7 0-9.3 0 .1 0 0 0 0z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AttachmentIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-attachment-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m28.1 18.9-15-15c-2.5-2.6-6.6-2.6-9.2-.1-2.6 2.5-2.6 6.7 0 9.2l.1.1L6.8 16l1.4-1.4-2.9-2.9c-1.7-1.7-1.7-4.6 0-6.3 1.7-1.7 4.6-1.8 6.3-.1l.1.1 14.9 14.9c1.8 1.7 1.8 4.6.1 6.3-1.7 1.8-4.6 1.8-6.3.1l-.1-.1-7.4-7.4c-1-1-.9-2.6 0-3.5 1-.9 2.5-.9 3.5 0l4.1 4.1 1.4-1.4-4.2-4.2c-1.8-1.7-4.6-1.6-6.3.2-1.6 1.7-1.6 4.4 0 6.2l7.5 7.5c2.5 2.6 6.6 2.6 9.2.1 2.6-2.5 2.6-6.7 0-9.3 0 .1 0 0 0 0z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class BadgeIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BadgeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: BadgeIconComponent, isStandalone: true, selector: "iui-badge-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m23 2.005 1.593 3L28 5.419 25.5 7.67l.5 3.333-3-1.875-3 1.875.5-3.333L18 5.42l3.5-.414 1.5-3z" fill="currentColor"></path><path d="m22.717 13.252-1.938-.498a6.992 6.992 0 0 1-9.808 4.542 6.993 6.993 0 0 1 4.78-13.071l.499-1.936A8.992 8.992 0 0 0 5.137 12.553 8.988 8.988 0 0 0 8 17.691V30l6-4 6 4V17.71a8.96 8.96 0 0 0 2.717-4.458zM18 26.263l-4-2.666-4 2.666v-7.211a8.925 8.925 0 0 0 8 .006v7.205z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BadgeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-badge-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m23 2.005 1.593 3L28 5.419 25.5 7.67l.5 3.333-3-1.875-3 1.875.5-3.333L18 5.42l3.5-.414 1.5-3z" fill="currentColor"></path><path d="m22.717 13.252-1.938-.498a6.992 6.992 0 0 1-9.808 4.542 6.993 6.993 0 0 1 4.78-13.071l.499-1.936A8.992 8.992 0 0 0 5.137 12.553 8.988 8.988 0 0 0 8 17.691V30l6-4 6 4V17.71a8.96 8.96 0 0 0 2.717-4.458zM18 26.263l-4-2.666-4 2.666v-7.211a8.925 8.925 0 0 0 8 .006v7.205z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class BarcodeIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BarcodeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: BarcodeIconComponent, isStandalone: true, selector: "iui-barcode-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 6H2v22h2V6zM14 6h-2v20h2V6zM10 6H6v20h4V6zM20 6h-4v20h4V6zM26 6h-4v20h4V6zM30 6h-2v22h2V6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BarcodeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-barcode-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 6H2v22h2V6zM14 6h-2v20h2V6zM10 6H6v20h4V6zM20 6h-4v20h4V6zM26 6h-4v20h4V6zM30 6h-2v22h2V6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class BatteryChargingIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BatteryChargingIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: BatteryChargingIconComponent, isStandalone: true, selector: "iui-battery-charging-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27 11h-1v-1a2 2 0 0 0-2-2h-4v2h4v3h3v6h-3v3h-5v2h5a2 2 0 0 0 2-2v-1h1a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2zM11 22H6V10h6V8H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h5v-2z" fill="currentColor"></path><path d="m14.81 23.58-1.62-1.16L17.06 17H9.37l6.85-8.62 1.56 1.24L13.51 15h7.43l-6.13 8.58z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BatteryChargingIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-battery-charging-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27 11h-1v-1a2 2 0 0 0-2-2h-4v2h4v3h3v6h-3v3h-5v2h5a2 2 0 0 0 2-2v-1h1a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2zM11 22H6V10h6V8H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h5v-2z" fill="currentColor"></path><path d="m14.81 23.58-1.62-1.16L17.06 17H9.37l6.85-8.62 1.56 1.24L13.51 15h7.43l-6.13 8.58z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class BatteryEmptyIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BatteryEmptyIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: BatteryEmptyIconComponent, isStandalone: true, selector: "iui-battery-empty-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 24H6a2.002 2.002 0 0 1-2-2V10a2.002 2.002 0 0 1 2-2h18a2.002 2.002 0 0 1 2 2v1h1a2.002 2.002 0 0 1 2 2v6a2.003 2.003 0 0 1-2 2h-1v1a2.003 2.003 0 0 1-2 2zM6 10v12h18v-3h3v-6h-3v-3H6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BatteryEmptyIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-battery-empty-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 24H6a2.002 2.002 0 0 1-2-2V10a2.002 2.002 0 0 1 2-2h18a2.002 2.002 0 0 1 2 2v1h1a2.002 2.002 0 0 1 2 2v6a2.003 2.003 0 0 1-2 2h-1v1a2.003 2.003 0 0 1-2 2zM6 10v12h18v-3h3v-6h-3v-3H6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class BatteryFullIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BatteryFullIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: BatteryFullIconComponent, isStandalone: true, selector: "iui-battery-full-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 24H6a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2h18a2 2 0 0 1 2 2v1h1a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2h-1v1a2 2 0 0 1-2 2zM6 10v12h18v-3h3v-6h-3v-3H6z" fill="currentColor"></path><path d="M22 20v-8H8v8h14z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BatteryFullIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-battery-full-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 24H6a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2h18a2 2 0 0 1 2 2v1h1a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2h-1v1a2 2 0 0 1-2 2zM6 10v12h18v-3h3v-6h-3v-3H6z" fill="currentColor"></path><path d="M22 20v-8H8v8h14z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class BatteryHalfIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BatteryHalfIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: BatteryHalfIconComponent, isStandalone: true, selector: "iui-battery-half-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 24H6a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2h18a2 2 0 0 1 2 2v1h1a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2h-1v1a2 2 0 0 1-2 2zM6 10v12h18v-3h3v-6h-3v-3H6z" fill="currentColor"></path><path d="M16 20v-8H8v8h8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BatteryHalfIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-battery-half-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 24H6a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2h18a2 2 0 0 1 2 2v1h1a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2h-1v1a2 2 0 0 1-2 2zM6 10v12h18v-3h3v-6h-3v-3H6z" fill="currentColor"></path><path d="M16 20v-8H8v8h8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class BatteryLowIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BatteryLowIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: BatteryLowIconComponent, isStandalone: true, selector: "iui-battery-low-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 24H6a2.002 2.002 0 0 1-2-2V10a2.002 2.002 0 0 1 2-2h18a2.002 2.002 0 0 1 2 2v1h1a2.002 2.002 0 0 1 2 2v6a2.003 2.003 0 0 1-2 2h-1v1a2.003 2.003 0 0 1-2 2zM6 10v12h18v-3h3v-6h-3v-3H6z" fill="currentColor"></path><path d="M10 20v-8H8v8h2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BatteryLowIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-battery-low-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 24H6a2.002 2.002 0 0 1-2-2V10a2.002 2.002 0 0 1 2-2h18a2.002 2.002 0 0 1 2 2v1h1a2.002 2.002 0 0 1 2 2v6a2.003 2.003 0 0 1-2 2h-1v1a2.003 2.003 0 0 1-2 2zM6 10v12h18v-3h3v-6h-3v-3H6z" fill="currentColor"></path><path d="M10 20v-8H8v8h2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class BatteryQuarterIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BatteryQuarterIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: BatteryQuarterIconComponent, isStandalone: true, selector: "iui-battery-quarter-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 24H6a2.002 2.002 0 0 1-2-2V10a2.002 2.002 0 0 1 2-2h18a2.002 2.002 0 0 1 2 2v1h1a2.002 2.002 0 0 1 2 2v6a2.003 2.003 0 0 1-2 2h-1v1a2.003 2.003 0 0 1-2 2zM6 10v12h18v-3h3v-6h-3v-3H6z" fill="currentColor"></path><path d="M12 20v-8H8v8h4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BatteryQuarterIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-battery-quarter-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 24H6a2.002 2.002 0 0 1-2-2V10a2.002 2.002 0 0 1 2-2h18a2.002 2.002 0 0 1 2 2v1h1a2.002 2.002 0 0 1 2 2v6a2.003 2.003 0 0 1-2 2h-1v1a2.003 2.003 0 0 1-2 2zM6 10v12h18v-3h3v-6h-3v-3H6z" fill="currentColor"></path><path d="M12 20v-8H8v8h4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class BookIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BookIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: BookIconComponent, isStandalone: true, selector: "iui-book-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 10h-7v2h7v-2zM26 15h-7v2h7v-2zM26 20h-7v2h7v-2zM13 10H6v2h7v-2zM13 15H6v2h7v-2zM13 20H6v2h7v-2z" fill="currentColor"></path><path d="M28 5H4a2.002 2.002 0 0 0-2 2v18a2.002 2.002 0 0 0 2 2h24a2.002 2.002 0 0 0 2-2V7a2.002 2.002 0 0 0-2-2zM4 7h11v18H4V7zm13 18V7h11v18H17z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BookIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-book-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 10h-7v2h7v-2zM26 15h-7v2h7v-2zM26 20h-7v2h7v-2zM13 10H6v2h7v-2zM13 15H6v2h7v-2zM13 20H6v2h7v-2z" fill="currentColor"></path><path d="M28 5H4a2.002 2.002 0 0 0-2 2v18a2.002 2.002 0 0 0 2 2h24a2.002 2.002 0 0 0 2-2V7a2.002 2.002 0 0 0-2-2zM4 7h11v18H4V7zm13 18V7h11v18H17z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class BookmarkAddIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BookmarkAddIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: BookmarkAddIconComponent, isStandalone: true, selector: "iui-bookmark-add-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 16v10.752l-8-4.047-8 4.043V4h10V2H8a2 2 0 0 0-2 2v26l10-5.054L26 30V16h-2z" fill="currentColor"></path><path d="M26 6V2h-2v4h-4v2h4v4h2V8h4V6h-4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BookmarkAddIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-bookmark-add-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 16v10.752l-8-4.047-8 4.043V4h10V2H8a2 2 0 0 0-2 2v26l10-5.054L26 30V16h-2z" fill="currentColor"></path><path d="M26 6V2h-2v4h-4v2h4v4h2V8h4V6h-4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class BookmarkFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BookmarkFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: BookmarkFillIconComponent, isStandalone: true, selector: "iui-bookmark-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 2H8a2 2 0 0 0-2 2v26l10-5.054L26 30V4a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BookmarkFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-bookmark-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 2H8a2 2 0 0 0-2 2v26l10-5.054L26 30V4a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class BookmarkOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BookmarkOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: BookmarkOutlineIconComponent, isStandalone: true, selector: "iui-bookmark-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 4v22.75l-7.1-3.59-.9-.45-.9.45L8 26.75V4h16zm0-2H8a2 2 0 0 0-2 2v26l10-5 10 5V4a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: BookmarkOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-bookmark-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 4v22.75l-7.1-3.59-.9-.45-.9.45L8 26.75V4h16zm0-2H8a2 2 0 0 0-2 2v26l10-5 10 5V4a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CalendarAddIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CalendarAddIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CalendarAddIconComponent, isStandalone: true, selector: "iui-calendar-add-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 22h-6v-6h-2v6h-6v2h6v6h2v-6h6v-2z" fill="currentColor"></path><path d="M28 6c0-1.1-.9-2-2-2h-4V2h-2v2h-8V2h-2v2H6c-1.1 0-2 .9-2 2v20c0 1.1.9 2 2 2h8v-2H6V6h4v2h2V6h8v2h2V6h4v8h2V6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CalendarAddIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-calendar-add-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 22h-6v-6h-2v6h-6v2h6v6h2v-6h6v-2z" fill="currentColor"></path><path d="M28 6c0-1.1-.9-2-2-2h-4V2h-2v2h-8V2h-2v2H6c-1.1 0-2 .9-2 2v20c0 1.1.9 2 2 2h8v-2H6V6h4v2h2V6h8v2h2V6h4v8h2V6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CalendarIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CalendarIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CalendarIconComponent, isStandalone: true, selector: "iui-calendar-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 4h-4V2h-2v2h-8V2h-2v2H6c-1.1 0-2 .9-2 2v20c0 1.1.9 2 2 2h20c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 22H6V12h20v14zm0-16H6V6h4v2h2V6h8v2h2V6h4v4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CalendarIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-calendar-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 4h-4V2h-2v2h-8V2h-2v2H6c-1.1 0-2 .9-2 2v20c0 1.1.9 2 2 2h20c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 22H6V12h20v14zm0-16H6V6h4v2h2V6h8v2h2V6h4v4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CalendarRemindIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CalendarRemindIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CalendarRemindIconComponent, isStandalone: true, selector: "iui-calendar-remind-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m30 23.382-2-1V20a6.005 6.005 0 0 0-5-5.91V12h-2v2.09A6.004 6.004 0 0 0 16 20v2.382l-2 1V28h6v2h4v-2h6v-4.618zM28 26H16v-1.382l2-1V20a4 4 0 1 1 8 0v3.618l2 1V26z" fill="currentColor"></path><path d="M28 6a2 2 0 0 0-2-2h-4V2h-2v2h-8V2h-2v2H6a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h4v-2H6V6h4v2h2V6h8v2h2V6h4v6h2V6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CalendarRemindIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-calendar-remind-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m30 23.382-2-1V20a6.005 6.005 0 0 0-5-5.91V12h-2v2.09A6.004 6.004 0 0 0 16 20v2.382l-2 1V28h6v2h4v-2h6v-4.618zM28 26H16v-1.382l2-1V20a4 4 0 1 1 8 0v3.618l2 1V26z" fill="currentColor"></path><path d="M28 6a2 2 0 0 0-2-2h-4V2h-2v2h-8V2h-2v2H6a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h4v-2H6V6h4v2h2V6h8v2h2V6h4v6h2V6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CameraIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CameraIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CameraIconComponent, isStandalone: true, selector: "iui-camera-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29 26H3a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h6.46l1.71-2.55A1 1 0 0 1 12 4h8a1 1 0 0 1 .83.45L22.54 7H29a1 1 0 0 1 1 1v17a1 1 0 0 1-1 1zM4 24h24V9h-6a1 1 0 0 1-.83-.45L19.46 6h-6.92l-1.71 2.55A1 1 0 0 1 10 9H4v15z" fill="currentColor"></path><path d="M16 22a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm0-10a4 4 0 1 0 0 8 4 4 0 0 0 0-8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CameraIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-camera-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29 26H3a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h6.46l1.71-2.55A1 1 0 0 1 12 4h8a1 1 0 0 1 .83.45L22.54 7H29a1 1 0 0 1 1 1v17a1 1 0 0 1-1 1zM4 24h24V9h-6a1 1 0 0 1-.83-.45L19.46 6h-6.92l-1.71 2.55A1 1 0 0 1 10 9H4v15z" fill="currentColor"></path><path d="M16 22a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm0-10a4 4 0 1 0 0 8 4 4 0 0 0 0-8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CaretBottomRightIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CaretBottomRightIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CaretBottomRightIconComponent, isStandalone: true, selector: "iui-caret-bottom-right-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M31 19v12H19l12-12z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CaretBottomRightIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-caret-bottom-right-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M31 19v12H19l12-12z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CaretDownIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CaretDownIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CaretDownIconComponent, isStandalone: true, selector: "iui-caret-down-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m24 12-8 10-8-10h16z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CaretDownIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-caret-down-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m24 12-8 10-8-10h16z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CaretLeftIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CaretLeftIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CaretLeftIconComponent, isStandalone: true, selector: "iui-caret-left-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m20 24-10-8 10-8v16z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CaretLeftIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-caret-left-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m20 24-10-8 10-8v16z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CaretRightIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CaretRightIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CaretRightIconComponent, isStandalone: true, selector: "iui-caret-right-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m12 8 10 8-10 8V8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CaretRightIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-caret-right-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m12 8 10 8-10 8V8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CaretUpIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CaretUpIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CaretUpIconComponent, isStandalone: true, selector: "iui-caret-up-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m8 20 8-10 8 10H8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CaretUpIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-caret-up-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m8 20 8-10 8 10H8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CatalogIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CatalogIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CatalogIconComponent, isStandalone: true, selector: "iui-catalog-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 2H8a2 2 0 0 0-2 2v4H4v2h2v5H4v2h2v5H4v2h2v4a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zm0 26H8v-4h2v-2H8v-5h2v-2H8v-5h2V8H8V4h18v24z" fill="currentColor"></path><path d="M22 8h-8v2h8V8zM22 15h-8v2h8v-2zM22 22h-8v2h8v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CatalogIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-catalog-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 2H8a2 2 0 0 0-2 2v4H4v2h2v5H4v2h2v5H4v2h2v4a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zm0 26H8v-4h2v-2H8v-5h2v-2H8v-5h2V8H8V4h18v24z" fill="currentColor"></path><path d="M22 8h-8v2h8V8zM22 15h-8v2h8v-2zM22 22h-8v2h8v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CategoriesIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CategoriesIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CategoriesIconComponent, isStandalone: true, selector: "iui-categories-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m6.76 6 .45.89L7.76 8H12v5H4V6h2.76zm.62-2H3a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V7a1 1 0 0 0-1-1H9l-.72-1.45a1 1 0 0 0-.9-.55zM22.76 6l.45.89.55 1.11H28v5h-8V6h2.76zm.62-2H19a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V7a1 1 0 0 0-1-1h-4l-.72-1.45a1 1 0 0 0-.9-.55zM6.76 19l.45.89.55 1.11H12v5H4v-7h2.76zm.62-2H3a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-7a1 1 0 0 0-1-1H9l-.72-1.45a1 1 0 0 0-.9-.55zM22.76 19l.45.89.55 1.11H28v5h-8v-7h2.76zm.62-2H19a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-7a1 1 0 0 0-1-1h-4l-.72-1.45a1 1 0 0 0-.9-.55z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CategoriesIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-categories-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m6.76 6 .45.89L7.76 8H12v5H4V6h2.76zm.62-2H3a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V7a1 1 0 0 0-1-1H9l-.72-1.45a1 1 0 0 0-.9-.55zM22.76 6l.45.89.55 1.11H28v5h-8V6h2.76zm.62-2H19a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V7a1 1 0 0 0-1-1h-4l-.72-1.45a1 1 0 0 0-.9-.55zM6.76 19l.45.89.55 1.11H12v5H4v-7h2.76zm.62-2H3a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-7a1 1 0 0 0-1-1H9l-.72-1.45a1 1 0 0 0-.9-.55zM22.76 19l.45.89.55 1.11H28v5h-8v-7h2.76zm.62-2H19a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-7a1 1 0 0 0-1-1h-4l-.72-1.45a1 1 0 0 0-.9-.55z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CdaIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CdaIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CdaIconComponent, isStandalone: true, selector: "iui-cda-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 9h-4a2.002 2.002 0 0 0-2 2v12h2v-5h4v5h2V11a2.002 2.002 0 0 0-2-2zm-4 7v-5h4v5h-4zM16 23h-4V9h4a4.004 4.004 0 0 1 4 4v6a4.004 4.004 0 0 1-4 4zm-2-2h2a2.003 2.003 0 0 0 2-2v-6a2.002 2.002 0 0 0-2-2h-2v10zM10 23H4a2.002 2.002 0 0 1-2-2V11a2.002 2.002 0 0 1 2-2h6v2H4v10h6v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CdaIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-cda-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 9h-4a2.002 2.002 0 0 0-2 2v12h2v-5h4v5h2V11a2.002 2.002 0 0 0-2-2zm-4 7v-5h4v5h-4zM16 23h-4V9h4a4.004 4.004 0 0 1 4 4v6a4.004 4.004 0 0 1-4 4zm-2-2h2a2.003 2.003 0 0 0 2-2v-6a2.002 2.002 0 0 0-2-2h-2v10zM10 23H4a2.002 2.002 0 0 1-2-2V11a2.002 2.002 0 0 1 2-2h6v2H4v10h6v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CenterToFitIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CenterToFitIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CenterToFitIconComponent, isStandalone: true, selector: "iui-center-to-fit-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M8 2H2v6h2V4h4V2zM24 2h6v6h-2V4h-4V2zM8 30H2v-6h2v4h4v2zM24 30h6v-6h-2v4h-4v2zM24 24H8a2.002 2.002 0 0 1-2-2V10a2.002 2.002 0 0 1 2-2h16a2.002 2.002 0 0 1 2 2v12a2.002 2.002 0 0 1-2 2zM8 10v12h16V10H8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CenterToFitIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-center-to-fit-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M8 2H2v6h2V4h4V2zM24 2h6v6h-2V4h-4V2zM8 30H2v-6h2v4h4v2zM24 30h6v-6h-2v4h-4v2zM24 24H8a2.002 2.002 0 0 1-2-2V10a2.002 2.002 0 0 1 2-2h16a2.002 2.002 0 0 1 2 2v12a2.002 2.002 0 0 1-2 2zM8 10v12h16V10H8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CertificateCheckIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CertificateCheckIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CertificateCheckIconComponent, isStandalone: true, selector: "iui-certificate-check-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 16H6v2h6v-2zM16 12H6v2h10v-2zM16 8H6v2h10V8z" fill="currentColor"></path><path d="M14 26H4V6h24v10h2V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h10v-2z" fill="currentColor"></path><path d="M22 25.59 19.41 23 18 24.41l4 4 8-8L28.59 19 22 25.59z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CertificateCheckIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-certificate-check-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 16H6v2h6v-2zM16 12H6v2h10v-2zM16 8H6v2h10V8z" fill="currentColor"></path><path d="M14 26H4V6h24v10h2V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h10v-2z" fill="currentColor"></path><path d="M22 25.59 19.41 23 18 24.41l4 4 8-8L28.59 19 22 25.59z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CertificateIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CertificateIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CertificateIconComponent, isStandalone: true, selector: "iui-certificate-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m24 17 1.912 3.703 4.088.594L27 24l.771 4L24 25.75 20.229 28 21 24l-3-2.703 4.2-.594L24 17zM12 16H6v2h6v-2zM16 12H6v2h10v-2zM16 8H6v2h10V8z" fill="currentColor"></path><path d="M16 26H4V6h24v10h2V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h12v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CertificateIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-certificate-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m24 17 1.912 3.703 4.088.594L27 24l.771 4L24 25.75 20.229 28 21 24l-3-2.703 4.2-.594L24 17zM12 16H6v2h6v-2zM16 12H6v2h10v-2zM16 8H6v2h10V8z" fill="currentColor"></path><path d="M16 26H4V6h24v10h2V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h12v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ChatIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ChatIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ChatIconComponent, isStandalone: true, selector: "iui-chat-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17.74 30 16 29l4-7h6a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h9v2H6a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v12a4 4 0 0 1-4 4h-4.84l-3.42 6z" fill="currentColor"></path><path d="M24 10H8v2h16v-2zM18 16H8v2h10v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ChatIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-chat-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17.74 30 16 29l4-7h6a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h9v2H6a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v12a4 4 0 0 1-4 4h-4.84l-3.42 6z" fill="currentColor"></path><path d="M24 10H8v2h16v-2zM18 16H8v2h10v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ChatLaunchIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ChatLaunchIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ChatLaunchIconComponent, isStandalone: true, selector: "iui-chat-launch-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 4v2h4.586L20 12.586 21.414 14 28 7.414V12h2V4h-8zM28 16v4a1.996 1.996 0 0 1-2 2h-6l-4 7 1.736 1 3.429-6H26a4 4 0 0 0 4-4v-4h-2zM4 20V8a1.997 1.997 0 0 1 2-2h12V4H6a3.999 3.999 0 0 0-4 4v12a4 4 0 0 0 4 4h9v-2H6a1.997 1.997 0 0 1-2-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ChatLaunchIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-chat-launch-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 4v2h4.586L20 12.586 21.414 14 28 7.414V12h2V4h-8zM28 16v4a1.996 1.996 0 0 1-2 2h-6l-4 7 1.736 1 3.429-6H26a4 4 0 0 0 4-4v-4h-2zM4 20V8a1.997 1.997 0 0 1 2-2h12V4H6a3.999 3.999 0 0 0-4 4v12a4 4 0 0 0 4 4h9v-2H6a1.997 1.997 0 0 1-2-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CheckmarkEmptyIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CheckmarkEmptyIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CheckmarkEmptyIconComponent, isStandalone: true, selector: "iui-checkmark-empty-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m13 24-9-9 1.414-1.414L13 21.171 26.586 7.586 28 9 13 24z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CheckmarkEmptyIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-checkmark-empty-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m13 24-9-9 1.414-1.414L13 21.171 26.586 7.586 28 9 13 24z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CheckmarkFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CheckmarkFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CheckmarkFillIconComponent, isStandalone: true, selector: "iui-checkmark-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm-2 19.59-5-5L10.59 15 14 18.41 21.41 11l1.596 1.586L14 21.59z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CheckmarkFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-checkmark-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm-2 19.59-5-5L10.59 15 14 18.41 21.41 11l1.596 1.586L14 21.59z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CheckmarkOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CheckmarkOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CheckmarkOutlineIconComponent, isStandalone: true, selector: "iui-checkmark-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m14 21.414-5-5.001L10.413 15 14 18.586 21.585 11 23 12.415l-9 8.999z" fill="currentColor"></path><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CheckmarkOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-checkmark-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m14 21.414-5-5.001L10.413 15 14 18.586 21.585 11 23 12.415l-9 8.999z" fill="currentColor"></path><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ChevronDownIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ChevronDownIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ChevronDownIconComponent, isStandalone: true, selector: "iui-chevron-down-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 22 6 12l1.4-1.4 8.6 8.6 8.6-8.6L26 12 16 22z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ChevronDownIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-chevron-down-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 22 6 12l1.4-1.4 8.6 8.6 8.6-8.6L26 12 16 22z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ChevronLeftIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ChevronLeftIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ChevronLeftIconComponent, isStandalone: true, selector: "iui-chevron-left-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 16 20 6l1.4 1.4-8.6 8.6 8.6 8.6L20 26 10 16z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ChevronLeftIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-chevron-left-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 16 20 6l1.4 1.4-8.6 8.6 8.6 8.6L20 26 10 16z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ChevronRightIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ChevronRightIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ChevronRightIconComponent, isStandalone: true, selector: "iui-chevron-right-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 16 12 26l-1.4-1.4 8.6-8.6-8.6-8.6L12 6l10 10z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ChevronRightIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-chevron-right-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 16 12 26l-1.4-1.4 8.6-8.6-8.6-8.6L12 6l10 10z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ChevronUpIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ChevronUpIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ChevronUpIconComponent, isStandalone: true, selector: "iui-chevron-up-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m16 10 10 10-1.4 1.4-8.6-8.6-8.6 8.6L6 20l10-10z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ChevronUpIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-chevron-up-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m16 10 10 10-1.4 1.4-8.6-8.6-8.6 8.6L6 20l10-10z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CircleDashedIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CircleDashedIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CircleDashedIconComponent, isStandalone: true, selector: "iui-circle-dashed-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M7.7 4.7a14.7 14.7 0 0 0-3 3.1L6.3 9a13.26 13.26 0 0 1 2.6-2.7L7.7 4.7zM4.6 12.3l-1.9-.6A12.51 12.51 0 0 0 2 16h2a11.48 11.48 0 0 1 .6-3.7zM2.7 20.4a14.4 14.4 0 0 0 2 3.9l1.6-1.2a12.89 12.89 0 0 1-1.7-3.3l-1.9.6zM7.8 27.3a14.4 14.4 0 0 0 3.9 2l.6-1.9A12.893 12.893 0 0 1 9 25.7l-1.2 1.6zM11.7 2.7l.6 1.9A11.481 11.481 0 0 1 16 4V2a12.51 12.51 0 0 0-4.3.7zM24.2 27.3a15.178 15.178 0 0 0 3.1-3.1L25.7 23a11.527 11.527 0 0 1-2.7 2.7l1.2 1.6zM27.4 19.7l1.9.6c.435-1.393.67-2.84.7-4.3h-2a11.477 11.477 0 0 1-.6 3.7zM29.2 11.6a14.398 14.398 0 0 0-2-3.9l-1.6 1.2a12.885 12.885 0 0 1 1.7 3.3l1.9-.6zM24.1 4.6a14.399 14.399 0 0 0-3.9-2l-.6 1.9a12.89 12.89 0 0 1 3.3 1.7l1.2-1.6zM20.3 29.3l-.6-1.9a11.477 11.477 0 0 1-3.7.6v2a21.419 21.419 0 0 0 4.3-.7z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CircleDashedIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-circle-dashed-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M7.7 4.7a14.7 14.7 0 0 0-3 3.1L6.3 9a13.26 13.26 0 0 1 2.6-2.7L7.7 4.7zM4.6 12.3l-1.9-.6A12.51 12.51 0 0 0 2 16h2a11.48 11.48 0 0 1 .6-3.7zM2.7 20.4a14.4 14.4 0 0 0 2 3.9l1.6-1.2a12.89 12.89 0 0 1-1.7-3.3l-1.9.6zM7.8 27.3a14.4 14.4 0 0 0 3.9 2l.6-1.9A12.893 12.893 0 0 1 9 25.7l-1.2 1.6zM11.7 2.7l.6 1.9A11.481 11.481 0 0 1 16 4V2a12.51 12.51 0 0 0-4.3.7zM24.2 27.3a15.178 15.178 0 0 0 3.1-3.1L25.7 23a11.527 11.527 0 0 1-2.7 2.7l1.2 1.6zM27.4 19.7l1.9.6c.435-1.393.67-2.84.7-4.3h-2a11.477 11.477 0 0 1-.6 3.7zM29.2 11.6a14.398 14.398 0 0 0-2-3.9l-1.6 1.2a12.885 12.885 0 0 1 1.7 3.3l1.9-.6zM24.1 4.6a14.399 14.399 0 0 0-3.9-2l-.6 1.9a12.89 12.89 0 0 1 3.3 1.7l1.2-1.6zM20.3 29.3l-.6-1.9a11.477 11.477 0 0 1-3.7.6v2a21.419 21.419 0 0 0 4.3-.7z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CloseEmptyIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CloseEmptyIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CloseEmptyIconComponent, isStandalone: true, selector: "iui-close-empty-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 9.4 22.6 8 16 14.6 9.4 8 8 9.4l6.6 6.6L8 22.6 9.4 24l6.6-6.6 6.6 6.6 1.4-1.4-6.6-6.6L24 9.4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CloseEmptyIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-close-empty-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 9.4 22.6 8 16 14.6 9.4 8 8 9.4l6.6 6.6L8 22.6 9.4 24l6.6-6.6 6.6 6.6 1.4-1.4-6.6-6.6L24 9.4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CloseFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CloseFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CloseFillIconComponent, isStandalone: true, selector: "iui-close-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2C8.2 2 2 8.2 2 16s6.2 14 14 14 14-6.2 14-14S23.8 2 16 2zm5.4 21L16 17.6 10.6 23 9 21.4l5.4-5.4L9 10.6 10.6 9l5.4 5.4L21.4 9l1.6 1.6-5.4 5.4 5.4 5.4-1.6 1.6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CloseFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-close-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2C8.2 2 2 8.2 2 16s6.2 14 14 14 14-6.2 14-14S23.8 2 16 2zm5.4 21L16 17.6 10.6 23 9 21.4l5.4-5.4L9 10.6 10.6 9l5.4 5.4L21.4 9l1.6 1.6-5.4 5.4 5.4 5.4-1.6 1.6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CloudDownloadIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CloudDownloadIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CloudDownloadIconComponent, isStandalone: true, selector: "iui-cloud-download-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23.5 22H23v-2h.5a4.504 4.504 0 0 0 .36-9H23l-.1-.82a7 7 0 0 0-13.88 0L9 11h-.86a4.503 4.503 0 1 0 .36 9H9v2h-.5A6.5 6.5 0 0 1 7.2 9.14a9 9 0 0 1 17.6 0A6.5 6.5 0 0 1 23.5 22z" fill="currentColor"></path><path d="M17 26.17V14h-2v12.17l-2.59-2.58L11 25l5 5 5-5-1.41-1.41L17 26.17z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CloudDownloadIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-cloud-download-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23.5 22H23v-2h.5a4.504 4.504 0 0 0 .36-9H23l-.1-.82a7 7 0 0 0-13.88 0L9 11h-.86a4.503 4.503 0 1 0 .36 9H9v2h-.5A6.5 6.5 0 0 1 7.2 9.14a9 9 0 0 1 17.6 0A6.5 6.5 0 0 1 23.5 22z" fill="currentColor"></path><path d="M17 26.17V14h-2v12.17l-2.59-2.58L11 25l5 5 5-5-1.41-1.41L17 26.17z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CloudOfflineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CloudOfflineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CloudOfflineIconComponent, isStandalone: true, selector: "iui-cloud-offline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24.8 12.136a8.87 8.87 0 0 0-.979-2.543L30 3.414 28.587 2 2 28.587 3.414 30l5-5H23.5a6.497 6.497 0 0 0 1.3-12.864zM23.5 23H10.414l11.928-11.928c.307.655.51 1.354.6 2.071l.099.812.815.064A4.497 4.497 0 0 1 23.5 23zM4.296 23.449l1.432-1.431a4.478 4.478 0 0 1 2.416-7.999l.816-.064.099-.812a6.987 6.987 0 0 1 10.63-5.086l1.443-1.443A8.986 8.986 0 0 0 7.2 12.136 6.49 6.49 0 0 0 4.296 23.45z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CloudOfflineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-cloud-offline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24.8 12.136a8.87 8.87 0 0 0-.979-2.543L30 3.414 28.587 2 2 28.587 3.414 30l5-5H23.5a6.497 6.497 0 0 0 1.3-12.864zM23.5 23H10.414l11.928-11.928c.307.655.51 1.354.6 2.071l.099.812.815.064A4.497 4.497 0 0 1 23.5 23zM4.296 23.449l1.432-1.431a4.478 4.478 0 0 1 2.416-7.999l.816-.064.099-.812a6.987 6.987 0 0 1 10.63-5.086l1.443-1.443A8.986 8.986 0 0 0 7.2 12.136 6.49 6.49 0 0 0 4.296 23.45z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CloudUploadIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CloudUploadIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CloudUploadIconComponent, isStandalone: true, selector: "iui-cloud-upload-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m11 18 1.41 1.41L15 16.83V29h2V16.83l2.59 2.58L21 18l-5-5-5 5z" fill="currentColor"></path><path d="M23.5 22H23v-2h.5a4.504 4.504 0 0 0 .36-9H23l-.1-.82a7 7 0 0 0-13.88 0L9 11h-.86a4.503 4.503 0 1 0 .36 9H9v2h-.5A6.5 6.5 0 0 1 7.2 9.14a9 9 0 0 1 17.6 0A6.5 6.5 0 0 1 23.5 22z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CloudUploadIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-cloud-upload-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m11 18 1.41 1.41L15 16.83V29h2V16.83l2.59 2.58L21 18l-5-5-5 5z" fill="currentColor"></path><path d="M23.5 22H23v-2h.5a4.504 4.504 0 0 0 .36-9H23l-.1-.82a7 7 0 0 0-13.88 0L9 11h-.86a4.503 4.503 0 1 0 .36 9H9v2h-.5A6.5 6.5 0 0 1 7.2 9.14a9 9 0 0 1 17.6 0A6.5 6.5 0 0 1 23.5 22z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CollaborateIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CollaborateIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CollaborateIconComponent, isStandalone: true, selector: "iui-collaborate-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M6 21v-1H4v1a7 7 0 0 0 7 7h3v-2h-3a5 5 0 0 1-5-5zM24 11v1h2v-1a7 7 0 0 0-7-7h-3v2h3a5 5 0 0 1 5 5zM11 11H5a3 3 0 0 0-3 3v2h2v-2a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2h2v-2a3 3 0 0 0-3-3zM8 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0-6a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM27 25h-6a3 3 0 0 0-3 3v2h2v-2a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2h2v-2a3 3 0 0 0-3-3zM20 20a4 4 0 1 0 8 0 4 4 0 0 0-8 0zm6 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CollaborateIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-collaborate-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M6 21v-1H4v1a7 7 0 0 0 7 7h3v-2h-3a5 5 0 0 1-5-5zM24 11v1h2v-1a7 7 0 0 0-7-7h-3v2h3a5 5 0 0 1 5 5zM11 11H5a3 3 0 0 0-3 3v2h2v-2a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2h2v-2a3 3 0 0 0-3-3zM8 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0-6a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM27 25h-6a3 3 0 0 0-3 3v2h2v-2a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2h2v-2a3 3 0 0 0-3-3zM20 20a4 4 0 1 0 8 0 4 4 0 0 0-8 0zm6 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CommunityIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CommunityIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CommunityIconComponent, isStandalone: true, selector: "iui-community-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 14h-2v2h2a3.004 3.004 0 0 1 3 3v4h2v-4a5.005 5.005 0 0 0-5-5zM24 4a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm0-2a5 5 0 1 0 0 10 5 5 0 0 0 0-10zM23 30h-2v-2a3.004 3.004 0 0 0-3-3h-4a3.004 3.004 0 0 0-3 3v2H9v-2a5.006 5.006 0 0 1 5-5h4a5.006 5.006 0 0 1 5 5v2zM16 13a3 3 0 1 1 0 5.999A3 3 0 0 1 16 13zm0-2a5 5 0 1 0 0 10 5 5 0 0 0 0-10zM8 14H6a5.006 5.006 0 0 0-5 5v4h2v-4a3.003 3.003 0 0 1 3-3h2v-2zM8 4a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm0-2a5 5 0 1 0 0 10A5 5 0 0 0 8 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CommunityIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-community-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 14h-2v2h2a3.004 3.004 0 0 1 3 3v4h2v-4a5.005 5.005 0 0 0-5-5zM24 4a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm0-2a5 5 0 1 0 0 10 5 5 0 0 0 0-10zM23 30h-2v-2a3.004 3.004 0 0 0-3-3h-4a3.004 3.004 0 0 0-3 3v2H9v-2a5.006 5.006 0 0 1 5-5h4a5.006 5.006 0 0 1 5 5v2zM16 13a3 3 0 1 1 0 5.999A3 3 0 0 1 16 13zm0-2a5 5 0 1 0 0 10 5 5 0 0 0 0-10zM8 14H6a5.006 5.006 0 0 0-5 5v4h2v-4a3.003 3.003 0 0 1 3-3h2v-2zM8 4a3 3 0 1 1 0 6 3 3 0 0 1 0-6zm0-2a5 5 0 1 0 0 10A5 5 0 0 0 8 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CompareIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CompareIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CompareIconComponent, isStandalone: true, selector: "iui-compare-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M14 2h2v28h-2v-2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h10V2zM28 4H17v2h11v20H17v2h11a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CompareIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-compare-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M14 2h2v28h-2v-2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h10V2zM28 4H17v2h11v20H17v2h11a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CopyDocumentIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CopyDocumentIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CopyDocumentIconComponent, isStandalone: true, selector: "iui-copy-document-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m27.4 14.7-6.1-6.1C21 8.2 20.5 8 20 8h-8c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V16.1c0-.5-.2-1-.6-1.4zM20 10l5.9 6H20v-6zm-8 18V10h6v6c0 1.1.9 2 2 2h6v10H12z" fill="currentColor"></path><path d="M6 18H4V4c0-1.1.9-2 2-2h14v2H6v14z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CopyDocumentIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-copy-document-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m27.4 14.7-6.1-6.1C21 8.2 20.5 8 20 8h-8c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V16.1c0-.5-.2-1-.6-1.4zM20 10l5.9 6H20v-6zm-8 18V10h6v6c0 1.1.9 2 2 2h6v10H12z" fill="currentColor"></path><path d="M6 18H4V4c0-1.1.9-2 2-2h14v2H6v14z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CopyIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CopyIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CopyIconComponent, isStandalone: true, selector: "iui-copy-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 10v18H10V10h18zm0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2z" fill="currentColor"></path><path d="M4 18H2V4a2 2 0 0 1 2-2h14v2H4v14z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CopyIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-copy-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 10v18H10V10h18zm0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2z" fill="currentColor"></path><path d="M4 18H2V4a2 2 0 0 1 2-2h14v2H4v14z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CopyImageIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CopyImageIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CopyImageIconComponent, isStandalone: true, selector: "iui-copy-image-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 22H2V4a2.002 2.002 0 0 1 2-2h18v2H4v18zM21 17a3 3 0 1 0 0-5.999A3 3 0 0 0 21 17zm0-4a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" fill="currentColor"></path><path d="M28 7H9a2.002 2.002 0 0 0-2 2v19a2.003 2.003 0 0 0 2 2h19a2.003 2.003 0 0 0 2-2V9a2.003 2.003 0 0 0-2-2zm0 21H9v-6l4-3.997 5.586 5.586a2 2 0 0 0 2.828 0L23 22.003 28 27v1zm0-3.828-3.586-3.586a2 2 0 0 0-2.828 0L20 22.172l-5.586-5.586a2 2 0 0 0-2.828 0L9 19.172V9h19v15.172z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CopyImageIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-copy-image-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 22H2V4a2.002 2.002 0 0 1 2-2h18v2H4v18zM21 17a3 3 0 1 0 0-5.999A3 3 0 0 0 21 17zm0-4a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" fill="currentColor"></path><path d="M28 7H9a2.002 2.002 0 0 0-2 2v19a2.003 2.003 0 0 0 2 2h19a2.003 2.003 0 0 0 2-2V9a2.003 2.003 0 0 0-2-2zm0 21H9v-6l4-3.997 5.586 5.586a2 2 0 0 0 2.828 0L23 22.003 28 27v1zm0-3.828-3.586-3.586a2 2 0 0 0-2.828 0L20 22.172l-5.586-5.586a2 2 0 0 0-2.828 0L9 19.172V9h19v15.172z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CopyLinkIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CopyLinkIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CopyLinkIconComponent, isStandalone: true, selector: "iui-copy-link-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M11.947 19a4.947 4.947 0 0 1-3.499-8.447l5.106-5.104a4.948 4.948 0 1 1 6.998 6.998l-.553.552-1.415-1.413.557-.557a2.95 2.95 0 0 0-.004-4.166 3.02 3.02 0 0 0-4.17 0l-5.104 5.104a2.947 2.947 0 0 0 0 4.17 3.02 3.02 0 0 0 4.17 0l1.414 1.414a4.919 4.919 0 0 1-3.5 1.449z" fill="currentColor"></path><path d="M19.947 17a4.947 4.947 0 0 1-3.499-8.447l.553-.552 1.414 1.415-.552.552a2.948 2.948 0 0 0 0 4.169 3.02 3.02 0 0 0 4.17 0l5.105-5.105a2.951 2.951 0 0 0 0-4.168 3.02 3.02 0 0 0-4.17 0l-1.414-1.415a4.948 4.948 0 0 1 6.998 6.998l-5.104 5.103a4.92 4.92 0 0 1-3.5 1.45z" fill="currentColor"></path><path d="M24 30H4a2.002 2.002 0 0 1-2-2V8a2.002 2.002 0 0 1 2-2h4v2H4v20h20V18h2v10a2.002 2.002 0 0 1-2 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CopyLinkIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-copy-link-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M11.947 19a4.947 4.947 0 0 1-3.499-8.447l5.106-5.104a4.948 4.948 0 1 1 6.998 6.998l-.553.552-1.415-1.413.557-.557a2.95 2.95 0 0 0-.004-4.166 3.02 3.02 0 0 0-4.17 0l-5.104 5.104a2.947 2.947 0 0 0 0 4.17 3.02 3.02 0 0 0 4.17 0l1.414 1.414a4.919 4.919 0 0 1-3.5 1.449z" fill="currentColor"></path><path d="M19.947 17a4.947 4.947 0 0 1-3.499-8.447l.553-.552 1.414 1.415-.552.552a2.948 2.948 0 0 0 0 4.169 3.02 3.02 0 0 0 4.17 0l5.105-5.105a2.951 2.951 0 0 0 0-4.168 3.02 3.02 0 0 0-4.17 0l-1.414-1.415a4.948 4.948 0 0 1 6.998 6.998l-5.104 5.103a4.92 4.92 0 0 1-3.5 1.45z" fill="currentColor"></path><path d="M24 30H4a2.002 2.002 0 0 1-2-2V8a2.002 2.002 0 0 1 2-2h4v2H4v20h20V18h2v10a2.002 2.002 0 0 1-2 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CredentialsIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CredentialsIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CredentialsIconComponent, isStandalone: true, selector: "iui-credentials-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 22a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0-6a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM18 6h-4v2h4V6z" fill="currentColor"></path><path d="M24 2H8a2.002 2.002 0 0 0-2 2v24a2.002 2.002 0 0 0 2 2h16a2.003 2.003 0 0 0 2-2V4a2.002 2.002 0 0 0-2-2zm-4 26h-8v-2a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2zm2 0v-2a3 3 0 0 0-3-3h-6a3 3 0 0 0-3 3v2H8V4h16v24h-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CredentialsIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-credentials-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 22a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0-6a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM18 6h-4v2h4V6z" fill="currentColor"></path><path d="M24 2H8a2.002 2.002 0 0 0-2 2v24a2.002 2.002 0 0 0 2 2h16a2.003 2.003 0 0 0 2-2V4a2.002 2.002 0 0 0-2-2zm-4 26h-8v-2a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2zm2 0v-2a3 3 0 0 0-3-3h-6a3 3 0 0 0-3 3v2H8V4h16v24h-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CropIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CropIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CropIconComponent, isStandalone: true, selector: "iui-crop-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M25 20h-2V9H12V7h11a2 2 0 0 1 2 2v11z" fill="currentColor"></path><path d="M9 23V2H7v5H2v2h5v14a2 2 0 0 0 2 2h14v5h2v-5h5v-2H9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CropIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-crop-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M25 20h-2V9H12V7h11a2 2 0 0 1 2 2v11z" fill="currentColor"></path><path d="M9 23V2H7v5H2v2h5v14a2 2 0 0 0 2 2h14v5h2v-5h5v-2H9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CsvIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CsvIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CsvIconComponent, isStandalone: true, selector: "iui-csv-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m28 9-2 13-2-13h-2l2.516 14h2.968L30 9h-2zM18 23h-6v-2h6v-4h-4a2.002 2.002 0 0 1-2-2v-4a2.002 2.002 0 0 1 2-2h6v2h-6v4h4a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zM10 23H4a2.002 2.002 0 0 1-2-2V11a2.002 2.002 0 0 1 2-2h6v2H4v10h6v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CsvIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-csv-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m28 9-2 13-2-13h-2l2.516 14h2.968L30 9h-2zM18 23h-6v-2h6v-4h-4a2.002 2.002 0 0 1-2-2v-4a2.002 2.002 0 0 1 2-2h6v2h-6v4h4a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zM10 23H4a2.002 2.002 0 0 1-2-2V11a2.002 2.002 0 0 1 2-2h6v2H4v10h6v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class CutIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CutIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CutIconComponent, isStandalone: true, selector: "iui-cut-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26.5 19.63 20.24 16l6.26-3.63a5 5 0 0 0-1.21-9.2A5.19 5.19 0 0 0 24 3a5 5 0 0 0-4.33 7.53 5 5 0 0 0 2.39 2.1l-3.82 2.21L4 6.6 3 8.34 16.24 16 3 23.68l1 1.74 14.24-8.26 3.82 2.21a5 5 0 0 0-2.39 2.1A5 5 0 0 0 24 29c.435-.002.869-.06 1.29-.17a5 5 0 0 0 1.21-9.2zm-5.1-10.1a3.002 3.002 0 0 1 3.38-4.416A3 3 0 0 1 26.6 6.52a3 3 0 0 1-1.1 4.11 3 3 0 0 1-4.1-1.1zm5.2 16a3 3 0 0 1-4.1 1.11 2.999 2.999 0 0 1-1.1-4.12 2.997 2.997 0 0 1 4.1-1.1 3 3 0 0 1 1.1 4.06v.05z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CutIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-cut-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26.5 19.63 20.24 16l6.26-3.63a5 5 0 0 0-1.21-9.2A5.19 5.19 0 0 0 24 3a5 5 0 0 0-4.33 7.53 5 5 0 0 0 2.39 2.1l-3.82 2.21L4 6.6 3 8.34 16.24 16 3 23.68l1 1.74 14.24-8.26 3.82 2.21a5 5 0 0 0-2.39 2.1A5 5 0 0 0 24 29c.435-.002.869-.06 1.29-.17a5 5 0 0 0 1.21-9.2zm-5.1-10.1a3.002 3.002 0 0 1 3.38-4.416A3 3 0 0 1 26.6 6.52a3 3 0 0 1-1.1 4.11 3 3 0 0 1-4.1-1.1zm5.2 16a3 3 0 0 1-4.1 1.11 2.999 2.999 0 0 1-1.1-4.12 2.997 2.997 0 0 1 4.1-1.1 3 3 0 0 1 1.1 4.06v.05z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DashboardIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DashboardIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DashboardIconComponent, isStandalone: true, selector: "iui-dashboard-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 21h-2v5h2v-5zM22 16h-2v10h2V16zM11 26a5.006 5.006 0 0 1-5-5h2a3 3 0 1 0 3-3v-2a5 5 0 1 1 0 10z" fill="currentColor"></path><path d="M28 2H4a2.002 2.002 0 0 0-2 2v24a2.002 2.002 0 0 0 2 2h24a2.003 2.003 0 0 0 2-2V4a2.002 2.002 0 0 0-2-2zm0 9H14V4h14v7zM12 4v7H4V4h8zM4 28V13h24l.002 15H4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DashboardIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-dashboard-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 21h-2v5h2v-5zM22 16h-2v10h2V16zM11 26a5.006 5.006 0 0 1-5-5h2a3 3 0 1 0 3-3v-2a5 5 0 1 1 0 10z" fill="currentColor"></path><path d="M28 2H4a2.002 2.002 0 0 0-2 2v24a2.002 2.002 0 0 0 2 2h24a2.003 2.003 0 0 0 2-2V4a2.002 2.002 0 0 0-2-2zm0 9H14V4h14v7zM12 4v7H4V4h8zM4 28V13h24l.002 15H4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DeleteIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DeleteIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DeleteIconComponent, isStandalone: true, selector: "iui-delete-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M14 12h-2v12h2V12zM20 12h-2v12h2V12z" fill="currentColor"></path><path d="M4 6v2h2v20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8h2V6H4zm4 22V8h16v20H8zM20 2h-8v2h8V2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DeleteIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-delete-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M14 12h-2v12h2V12zM20 12h-2v12h2V12z" fill="currentColor"></path><path d="M4 6v2h2v20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8h2V6H4zm4 22V8h16v20H8zM20 2h-8v2h8V2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DeliveryAddIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DeliveryAddIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DeliveryAddIconComponent, isStandalone: true, selector: "iui-delivery-add-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 6H8V2H6v4H2v2h4v4h2V8h4V6z" fill="currentColor"></path><path d="m29.919 16.606-3-7A.999.999 0 0 0 26 9h-3V7a1 1 0 0 0-1-1h-7v2h6v12.556A3.992 3.992 0 0 0 19.142 23h-6.284a3.98 3.98 0 0 0-7.716 0H4v-9H2v10a1 1 0 0 0 1 1h2.142a3.98 3.98 0 0 0 7.716 0h6.284a3.98 3.98 0 0 0 7.716 0H29a1 1 0 0 0 1-1v-7a.996.996 0 0 0-.081-.394zM9 26a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm14-15h2.34l2.144 5H23v-5zm0 15a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm5-3h-1.142A3.995 3.995 0 0 0 23 20v-2h5v5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DeliveryAddIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-delivery-add-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 6H8V2H6v4H2v2h4v4h2V8h4V6z" fill="currentColor"></path><path d="m29.919 16.606-3-7A.999.999 0 0 0 26 9h-3V7a1 1 0 0 0-1-1h-7v2h6v12.556A3.992 3.992 0 0 0 19.142 23h-6.284a3.98 3.98 0 0 0-7.716 0H4v-9H2v10a1 1 0 0 0 1 1h2.142a3.98 3.98 0 0 0 7.716 0h6.284a3.98 3.98 0 0 0 7.716 0H29a1 1 0 0 0 1-1v-7a.996.996 0 0 0-.081-.394zM9 26a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm14-15h2.34l2.144 5H23v-5zm0 15a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm5-3h-1.142A3.995 3.995 0 0 0 23 20v-2h5v5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DeliveryIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DeliveryIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DeliveryIconComponent, isStandalone: true, selector: "iui-delivery-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 16H4v2h12v-2zM12 11H2v2h10v-2z" fill="currentColor"></path><path d="m29.919 16.606-3-7A.999.999 0 0 0 26 9h-3V7a1 1 0 0 0-1-1H6v2h15v12.556A3.992 3.992 0 0 0 19.142 23h-6.284a4 4 0 1 0 0 2h6.284a3.98 3.98 0 0 0 7.716 0H29a1 1 0 0 0 1-1v-7a.996.996 0 0 0-.081-.394zM9 26a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm14-15h2.34l2.144 5H23v-5zm0 15a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm5-3h-1.142A3.995 3.995 0 0 0 23 20v-2h5v5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DeliveryIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-delivery-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 16H4v2h12v-2zM12 11H2v2h10v-2z" fill="currentColor"></path><path d="m29.919 16.606-3-7A.999.999 0 0 0 26 9h-3V7a1 1 0 0 0-1-1H6v2h15v12.556A3.992 3.992 0 0 0 19.142 23h-6.284a4 4 0 1 0 0 2h6.284a3.98 3.98 0 0 0 7.716 0H29a1 1 0 0 0 1-1v-7a.996.996 0 0 0-.081-.394zM9 26a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm14-15h2.34l2.144 5H23v-5zm0 15a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm5-3h-1.142A3.995 3.995 0 0 0 23 20v-2h5v5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DeliveryParcelIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DeliveryParcelIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DeliveryParcelIconComponent, isStandalone: true, selector: "iui-delivery-parcel-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m29.482 8.624-10-5.5a1 1 0 0 0-.964 0l-10 5.5a1 1 0 0 0 0 1.752L18 15.591V26.31l-3.036-1.67L14 26.391l4.518 2.485a.999.999 0 0 0 .964 0l10-5.5A1 1 0 0 0 30 22.5v-13a.999.999 0 0 0-.518-.876zM19 5.142 26.925 9.5 19 13.858 11.075 9.5 19 5.142zm9 16.767-8 4.4V15.59l8-4.4V21.91z" fill="currentColor"></path><path d="M2 16h8v-2H2v2zM4 24h8v-2H4v2zM6 20h8v-2H6v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DeliveryParcelIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-delivery-parcel-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m29.482 8.624-10-5.5a1 1 0 0 0-.964 0l-10 5.5a1 1 0 0 0 0 1.752L18 15.591V26.31l-3.036-1.67L14 26.391l4.518 2.485a.999.999 0 0 0 .964 0l10-5.5A1 1 0 0 0 30 22.5v-13a.999.999 0 0 0-.518-.876zM19 5.142 26.925 9.5 19 13.858 11.075 9.5 19 5.142zm9 16.767-8 4.4V15.59l8-4.4V21.91z" fill="currentColor"></path><path d="M2 16h8v-2H2v2zM4 24h8v-2H4v2zM6 20h8v-2H6v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DesktopIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DesktopIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DesktopIconComponent, isStandalone: true, selector: "iui-desktop-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h8v4H8v2h16v-2h-4v-4h8a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM18 28h-4v-4h4v4zm10-6H4V6h24v16z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DesktopIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-desktop-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h8v4H8v2h16v-2h-4v-4h8a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM18 28h-4v-4h4v4zm10-6H4V6h24v16z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DevicesIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DevicesIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DevicesIconComponent, isStandalone: true, selector: "iui-devices-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30H4a2 2 0 0 1-2-2V16a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2zM4 16v12h6V16H4z" fill="currentColor"></path><path d="M28 4H6a2 2 0 0 0-2 2v6h2V6h22v14H14v2h2v4h-2v2h9v-2h-5v-4h10a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DevicesIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-devices-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30H4a2 2 0 0 1-2-2V16a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2zM4 16v12h6V16H4z" fill="currentColor"></path><path d="M28 4H6a2 2 0 0 0-2 2v6h2V6h22v14H14v2h2v4h-2v2h9v-2h-5v-4h10a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DiscordIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DiscordIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DiscordIconComponent, isStandalone: true, selector: "iui-discord-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M13.647 14.907a1.448 1.448 0 1 0 1.326 1.443 1.384 1.384 0 0 0-1.326-1.443zm4.745 0a1.448 1.448 0 1 0 1.326 1.443 1.384 1.384 0 0 0-1.326-1.443z" fill="currentColor"></path><path d="M24.71 4H7.29a2.672 2.672 0 0 0-2.665 2.678v17.576a2.671 2.671 0 0 0 2.665 2.678h14.742l-.689-2.405 1.664 1.547 1.573 1.456L27.375 30V6.678A2.672 2.672 0 0 0 24.71 4zm-5.018 16.978s-.468-.559-.858-1.053a4.102 4.102 0 0 0 2.353-1.547c-.468.311-.97.569-1.495.767a8.56 8.56 0 0 1-1.885.559 9.106 9.106 0 0 1-3.367-.013 10.91 10.91 0 0 1-1.911-.559 7.62 7.62 0 0 1-.949-.442c-.039-.026-.078-.039-.117-.065a.18.18 0 0 1-.052-.039c-.234-.13-.364-.221-.364-.221a4.043 4.043 0 0 0 2.275 1.534c-.39.494-.871 1.079-.871 1.079a4.714 4.714 0 0 1-3.965-1.976 17.409 17.409 0 0 1 1.872-7.579 6.429 6.429 0 0 1 3.653-1.365l.13.156a8.77 8.77 0 0 0-3.419 1.703s.286-.156.767-.377a9.76 9.76 0 0 1 2.951-.819c.073-.015.147-.024.221-.026a10.597 10.597 0 0 1 6.539 1.222 8.652 8.652 0 0 0-3.237-1.651l.182-.208a6.428 6.428 0 0 1 3.653 1.365 17.409 17.409 0 0 1 1.872 7.579 4.752 4.752 0 0 1-3.978 1.976z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DiscordIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-discord-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M13.647 14.907a1.448 1.448 0 1 0 1.326 1.443 1.384 1.384 0 0 0-1.326-1.443zm4.745 0a1.448 1.448 0 1 0 1.326 1.443 1.384 1.384 0 0 0-1.326-1.443z" fill="currentColor"></path><path d="M24.71 4H7.29a2.672 2.672 0 0 0-2.665 2.678v17.576a2.671 2.671 0 0 0 2.665 2.678h14.742l-.689-2.405 1.664 1.547 1.573 1.456L27.375 30V6.678A2.672 2.672 0 0 0 24.71 4zm-5.018 16.978s-.468-.559-.858-1.053a4.102 4.102 0 0 0 2.353-1.547c-.468.311-.97.569-1.495.767a8.56 8.56 0 0 1-1.885.559 9.106 9.106 0 0 1-3.367-.013 10.91 10.91 0 0 1-1.911-.559 7.62 7.62 0 0 1-.949-.442c-.039-.026-.078-.039-.117-.065a.18.18 0 0 1-.052-.039c-.234-.13-.364-.221-.364-.221a4.043 4.043 0 0 0 2.275 1.534c-.39.494-.871 1.079-.871 1.079a4.714 4.714 0 0 1-3.965-1.976 17.409 17.409 0 0 1 1.872-7.579 6.429 6.429 0 0 1 3.653-1.365l.13.156a8.77 8.77 0 0 0-3.419 1.703s.286-.156.767-.377a9.76 9.76 0 0 1 2.951-.819c.073-.015.147-.024.221-.026a10.597 10.597 0 0 1 6.539 1.222 8.652 8.652 0 0 0-3.237-1.651l.182-.208a6.428 6.428 0 0 1 3.653 1.365 17.409 17.409 0 0 1 1.872 7.579 4.752 4.752 0 0 1-3.978 1.976z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DistributeHorizontalCenterIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DistributeHorizontalCenterIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DistributeHorizontalCenterIconComponent, isStandalone: true, selector: "iui-distribute-horizontal-center-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 10h-1V2h-2v8h-1a2.002 2.002 0 0 0-2 2v8a2.002 2.002 0 0 0 2 2h1v8h2v-8h1a2.002 2.002 0 0 0 2-2v-8a2.002 2.002 0 0 0-2-2zm0 10h-4v-8h4v8zM12 6h-1V2H9v4H8a2.002 2.002 0 0 0-2 2v16a2.002 2.002 0 0 0 2 2h1v4h2v-4h1a2.002 2.002 0 0 0 2-2V8a2.002 2.002 0 0 0-2-2zm0 18H8V8h4v16z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DistributeHorizontalCenterIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-distribute-horizontal-center-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 10h-1V2h-2v8h-1a2.002 2.002 0 0 0-2 2v8a2.002 2.002 0 0 0 2 2h1v8h2v-8h1a2.002 2.002 0 0 0 2-2v-8a2.002 2.002 0 0 0-2-2zm0 10h-4v-8h4v8zM12 6h-1V2H9v4H8a2.002 2.002 0 0 0-2 2v16a2.002 2.002 0 0 0 2 2h1v4h2v-4h1a2.002 2.002 0 0 0 2-2V8a2.002 2.002 0 0 0-2-2zm0 18H8V8h4v16z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DistributeHorizontalLeftIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DistributeHorizontalLeftIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DistributeHorizontalLeftIconComponent, isStandalone: true, selector: "iui-distribute-horizontal-left-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 22h-4a2.002 2.002 0 0 1-2-2v-8a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v8a2.002 2.002 0 0 1-2 2zm-4-10v8h4v-8h-4zM20 2h-2v28h2V2zM12 26H8a2.002 2.002 0 0 1-2-2V8a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v16a2.002 2.002 0 0 1-2 2zM8 8v16h4V8H8zM4 2H2v28h2V2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DistributeHorizontalLeftIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-distribute-horizontal-left-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 22h-4a2.002 2.002 0 0 1-2-2v-8a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v8a2.002 2.002 0 0 1-2 2zm-4-10v8h4v-8h-4zM20 2h-2v28h2V2zM12 26H8a2.002 2.002 0 0 1-2-2V8a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v16a2.002 2.002 0 0 1-2 2zM8 8v16h4V8H8zM4 2H2v28h2V2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DistributeHorizontalRightIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DistributeHorizontalRightIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DistributeHorizontalRightIconComponent, isStandalone: true, selector: "iui-distribute-horizontal-right-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 2h-2v28h2V2zM24 22h-4a2.002 2.002 0 0 1-2-2v-8a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v8a2.002 2.002 0 0 1-2 2zm-4.002-10L20 20h4v-8h-4.002zM14 2h-2v28h2V2zM8 26H4a2.002 2.002 0 0 1-2-2V8a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v16a2.002 2.002 0 0 1-2 2zM3.998 8 4 24h4V8H3.998z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DistributeHorizontalRightIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-distribute-horizontal-right-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 2h-2v28h2V2zM24 22h-4a2.002 2.002 0 0 1-2-2v-8a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v8a2.002 2.002 0 0 1-2 2zm-4.002-10L20 20h4v-8h-4.002zM14 2h-2v28h2V2zM8 26H4a2.002 2.002 0 0 1-2-2V8a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v16a2.002 2.002 0 0 1-2 2zM3.998 8 4 24h4V8H3.998z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DistributeVerticalBottomIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DistributeVerticalBottomIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DistributeVerticalBottomIconComponent, isStandalone: true, selector: "iui-distribute-vertical-bottom-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 28H2v2h28v-2zM24 26H8a2.002 2.002 0 0 1-2-2v-4a2.002 2.002 0 0 1 2-2h16a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zm0-6.001L8 20v4h16v-4.001zM30 12H2v2h28v-2zM20 10h-8a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h8a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zm0-6.001L12 4v4h8V3.999z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DistributeVerticalBottomIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-distribute-vertical-bottom-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 28H2v2h28v-2zM24 26H8a2.002 2.002 0 0 1-2-2v-4a2.002 2.002 0 0 1 2-2h16a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zm0-6.001L8 20v4h16v-4.001zM30 12H2v2h28v-2zM20 10h-8a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h8a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zm0-6.001L12 4v4h8V3.999z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DistributeVerticalCenterIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DistributeVerticalCenterIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DistributeVerticalCenterIconComponent, isStandalone: true, selector: "iui-distribute-vertical-center-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 21h-4v-1a2.002 2.002 0 0 0-2-2H8a2.002 2.002 0 0 0-2 2v1H2v2h4v1a2.002 2.002 0 0 0 2 2h16a2.002 2.002 0 0 0 2-2v-1h4v-2zm-6 3H8v-4l16-.001V24zM30 9h-8V8a2.002 2.002 0 0 0-2-2h-8a2.002 2.002 0 0 0-2 2v1H2v2h8v1a2.002 2.002 0 0 0 2 2h8a2.002 2.002 0 0 0 2-2v-1h8V9zm-10 3h-8V8l8-.001V12z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DistributeVerticalCenterIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-distribute-vertical-center-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 21h-4v-1a2.002 2.002 0 0 0-2-2H8a2.002 2.002 0 0 0-2 2v1H2v2h4v1a2.002 2.002 0 0 0 2 2h16a2.002 2.002 0 0 0 2-2v-1h4v-2zm-6 3H8v-4l16-.001V24zM30 9h-8V8a2.002 2.002 0 0 0-2-2h-8a2.002 2.002 0 0 0-2 2v1H2v2h8v1a2.002 2.002 0 0 0 2 2h8a2.002 2.002 0 0 0 2-2v-1h8V9zm-10 3h-8V8l8-.001V12z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DistributeVerticalTopIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DistributeVerticalTopIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DistributeVerticalTopIconComponent, isStandalone: true, selector: "iui-distribute-vertical-top-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 30H8a2.002 2.002 0 0 1-2-2v-4a2.002 2.002 0 0 1 2-2h16a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zM8 24v4h16v-4H8zM30 18H2v2h28v-2zM20 14h-8a2.002 2.002 0 0 1-2-2V8a2.002 2.002 0 0 1 2-2h8a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zm-8-6v4h8V8h-8zM30 2H2v2h28V2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DistributeVerticalTopIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-distribute-vertical-top-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 30H8a2.002 2.002 0 0 1-2-2v-4a2.002 2.002 0 0 1 2-2h16a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zM8 24v4h16v-4H8zM30 18H2v2h28v-2zM20 14h-8a2.002 2.002 0 0 1-2-2V8a2.002 2.002 0 0 1 2-2h8a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zm-8-6v4h8V8h-8zM30 2H2v2h28V2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocIconComponent, isStandalone: true, selector: "iui-doc-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 23h-6a2.002 2.002 0 0 1-2-2V11a2.002 2.002 0 0 1 2-2h6v2h-6v10h6v2zM18 23h-4a2.002 2.002 0 0 1-2-2V11a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v10a2.002 2.002 0 0 1-2 2zm-4-12v10h4V11h-4zM6 23H2V9h4a4.004 4.004 0 0 1 4 4v6a4.004 4.004 0 0 1-4 4zm-2-2h2a2.002 2.002 0 0 0 2-2v-6a2.002 2.002 0 0 0-2-2H4v10z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-doc-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 23h-6a2.002 2.002 0 0 1-2-2V11a2.002 2.002 0 0 1 2-2h6v2h-6v10h6v2zM18 23h-4a2.002 2.002 0 0 1-2-2V11a2.002 2.002 0 0 1 2-2h4a2.002 2.002 0 0 1 2 2v10a2.002 2.002 0 0 1-2 2zm-4-12v10h4V11h-4zM6 23H2V9h4a4.004 4.004 0 0 1 4 4v6a4.004 4.004 0 0 1-4 4zm-2-2h2a2.002 2.002 0 0 0 2-2v-6a2.002 2.002 0 0 0-2-2H4v10z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentAddIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentAddIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentAddIconComponent, isStandalone: true, selector: "iui-document-add-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 24h-4v-4h-2v4h-4v2h4v4h2v-4h4v-2z" fill="currentColor"></path><path d="M16 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v4h2v-6a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h8v-2zm2-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentAddIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-add-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 24h-4v-4h-2v4h-4v2h4v4h2v-4h4v-2z" fill="currentColor"></path><path d="M16 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v4h2v-6a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h8v-2zm2-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentAudioIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentAudioIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentAudioIconComponent, isStandalone: true, selector: "iui-document-audio-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29 31a1 1 0 0 1-.625-.22L23.65 27H20a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1h3.65l4.726-3.78A1 1 0 0 1 30 17v13a1 1 0 0 1-1 1zm-8-6h3a1 1 0 0 1 .625.22L28 27.92v-8.84l-3.375 2.7A1 1 0 0 1 24 22h-3v3z" fill="currentColor"></path><path d="M16 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v3h2v-5a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h8v-2zm2-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentAudioIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-audio-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29 31a1 1 0 0 1-.625-.22L23.65 27H20a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1h3.65l4.726-3.78A1 1 0 0 1 30 17v13a1 1 0 0 1-1 1zm-8-6h3a1 1 0 0 1 .625.22L28 27.92v-8.84l-3.375 2.7A1 1 0 0 1 24 22h-3v3z" fill="currentColor"></path><path d="M16 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v3h2v-5a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h8v-2zm2-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentCheckIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentCheckIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentCheckIconComponent, isStandalone: true, selector: "iui-document-check-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m22 27.18-2.59-2.59L18 26l4 4 8-8-1.41-1.41L22 27.18z" fill="currentColor"></path><path d="M15 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v6h2v-8a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h7v-2zm3-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentCheckIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-check-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m22 27.18-2.59-2.59L18 26l4 4 8-8-1.41-1.41L22 27.18z" fill="currentColor"></path><path d="M15 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v6h2v-8a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h7v-2zm3-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentDownloadIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentDownloadIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentDownloadIconComponent, isStandalone: true, selector: "iui-document-download-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m30 25-1.414-1.414L26 26.172V18h-2v8.172l-2.586-2.586L20 25l5 5 5-5z" fill="currentColor"></path><path d="M18 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v3h2v-5a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h10v-2zm0-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentDownloadIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-download-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m30 25-1.414-1.414L26 26.172V18h-2v8.172l-2.586-2.586L20 25l5 5 5-5z" fill="currentColor"></path><path d="M18 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v3h2v-5a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h10v-2zm0-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentExportIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentExportIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentExportIconComponent, isStandalone: true, selector: "iui-document-export-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M13 21h13.17l-2.58 2.59L25 25l5-5-5-5-1.41 1.41L26.17 19H13v2z" fill="currentColor"></path><path d="M22 14v-4a1 1 0 0 0-.29-.71l-7-7A1 1 0 0 0 14 2H4a2 2 0 0 0-2 2v24a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2h-2v2H4V4h8v6a2 2 0 0 0 2 2h6v2h2zm-8-4V4.41L19.59 10H14z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentExportIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-export-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M13 21h13.17l-2.58 2.59L25 25l5-5-5-5-1.41 1.41L26.17 19H13v2z" fill="currentColor"></path><path d="M22 14v-4a1 1 0 0 0-.29-.71l-7-7A1 1 0 0 0 14 2H4a2 2 0 0 0-2 2v24a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2h-2v2H4V4h8v6a2 2 0 0 0 2 2h6v2h2zm-8-4V4.41L19.59 10H14z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentIconComponent, isStandalone: true, selector: "iui-document-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m25.7 9.3-7-7c-.2-.2-.4-.3-.7-.3H8c-1.1 0-2 .9-2 2v24c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V10c0-.3-.1-.5-.3-.7zM18 4.4l5.6 5.6H18V4.4zM24 28H8V4h8v6c0 1.1.9 2 2 2h6v16z" fill="currentColor"></path><path d="M22 22H10v2h12v-2zM22 16H10v2h12v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m25.7 9.3-7-7c-.2-.2-.4-.3-.7-.3H8c-1.1 0-2 .9-2 2v24c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V10c0-.3-.1-.5-.3-.7zM18 4.4l5.6 5.6H18V4.4zM24 28H8V4h8v6c0 1.1.9 2 2 2h6v16z" fill="currentColor"></path><path d="M22 22H10v2h12v-2zM22 16H10v2h12v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentImportIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentImportIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentImportIconComponent, isStandalone: true, selector: "iui-document-import-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 19H14.83l2.58-2.59L16 15l-5 5 5 5 1.41-1.41L14.83 21H28v-2z" fill="currentColor"></path><path d="M24 14v-4a1 1 0 0 0-.29-.71l-7-7A1 1 0 0 0 16 2H6a2 2 0 0 0-2 2v24a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2h-2v2H6V4h8v6a2 2 0 0 0 2 2h6v2h2zm-8-4V4.41L21.59 10H16z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentImportIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-import-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 19H14.83l2.58-2.59L16 15l-5 5 5 5 1.41-1.41L14.83 21H28v-2z" fill="currentColor"></path><path d="M24 14v-4a1 1 0 0 0-.29-.71l-7-7A1 1 0 0 0 16 2H6a2 2 0 0 0-2 2v24a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2h-2v2H6V4h8v6a2 2 0 0 0 2 2h6v2h2zm-8-4V4.41L21.59 10H16z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentLockedIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentLockedIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentLockedIconComponent, isStandalone: true, selector: "iui-document-locked-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 21v-3a4 4 0 1 0-8 0v3a2.003 2.003 0 0 0-2 2v5a2.003 2.003 0 0 0 2 2h8a2.003 2.003 0 0 0 2-2v-5a2.003 2.003 0 0 0-2-2zm-6-3a2 2 0 0 1 4 0v3h-4v-3zm-2 10v-5h8v5h-8z" fill="currentColor"></path><path d="m23.499 9.085-6.792-6.792A1 1 0 0 0 16 2H6a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h8v-2H6V4h8v6a2.002 2.002 0 0 0 2 2h6.292a1.708 1.708 0 0 0 1.207-2.915zM16 10V4.414L21.585 10H16z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentLockedIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-locked-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 21v-3a4 4 0 1 0-8 0v3a2.003 2.003 0 0 0-2 2v5a2.003 2.003 0 0 0 2 2h8a2.003 2.003 0 0 0 2-2v-5a2.003 2.003 0 0 0-2-2zm-6-3a2 2 0 0 1 4 0v3h-4v-3zm-2 10v-5h8v5h-8z" fill="currentColor"></path><path d="m23.499 9.085-6.792-6.792A1 1 0 0 0 16 2H6a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h8v-2H6V4h8v6a2.002 2.002 0 0 0 2 2h6.292a1.708 1.708 0 0 0 1.207-2.915zM16 10V4.414L21.585 10H16z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentProtectedIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentProtectedIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentProtectedIconComponent, isStandalone: true, selector: "iui-document-protected-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m23 30-2.139-1.013A5.02 5.02 0 0 1 18 24.467V18h10v6.468a5.021 5.021 0 0 1-2.861 4.52L23 30zm-3-10v4.468a3.012 3.012 0 0 0 1.717 2.71l1.283.608 1.283-.607A3.011 3.011 0 0 0 26 24.468V20h-6z" fill="currentColor"></path><path d="M16 28H6V4h8v6a2.005 2.005 0 0 0 2 2h6v3h2v-5a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 16 2H6a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h10v-2zm0-23.6 5.6 5.6H16V4.4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentProtectedIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-protected-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m23 30-2.139-1.013A5.02 5.02 0 0 1 18 24.467V18h10v6.468a5.021 5.021 0 0 1-2.861 4.52L23 30zm-3-10v4.468a3.012 3.012 0 0 0 1.717 2.71l1.283.608 1.283-.607A3.011 3.011 0 0 0 26 24.468V20h-6z" fill="currentColor"></path><path d="M16 28H6V4h8v6a2.005 2.005 0 0 0 2 2h6v3h2v-5a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 16 2H6a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h10v-2zm0-23.6 5.6 5.6H16V4.4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentSignedIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentSignedIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentSignedIconComponent, isStandalone: true, selector: "iui-document-signed-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M19.414 30H15v-4.414l5.034-5.034A4.61 4.61 0 0 1 20 20a5 5 0 1 1 4.448 4.966L19.414 30zM17 28h1.586l5.206-5.206.54.123a3.035 3.035 0 1 0-2.25-2.248l.124.539L17 26.414V28z" fill="currentColor"></path><path d="M25 21a1 1 0 1 0 0-2 1 1 0 0 0 0 2zM20 6H8v2h12V6zM20 10H8v2h12v-2zM14 14H8v2h6v-2zM12 24H8v2h4v-2z" fill="currentColor"></path><path d="M12 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h16a2.002 2.002 0 0 1 2 2v9h-2V4H6v24h6v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentSignedIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-signed-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M19.414 30H15v-4.414l5.034-5.034A4.61 4.61 0 0 1 20 20a5 5 0 1 1 4.448 4.966L19.414 30zM17 28h1.586l5.206-5.206.54.123a3.035 3.035 0 1 0-2.25-2.248l.124.539L17 26.414V28z" fill="currentColor"></path><path d="M25 21a1 1 0 1 0 0-2 1 1 0 0 0 0 2zM20 6H8v2h12V6zM20 10H8v2h12v-2zM14 14H8v2h6v-2zM12 24H8v2h4v-2z" fill="currentColor"></path><path d="M12 30H6a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h16a2.002 2.002 0 0 1 2 2v9h-2V4H6v24h6v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentSubtractIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentSubtractIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentSubtractIconComponent, isStandalone: true, selector: "iui-document-subtract-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 24H20v2h10v-2z" fill="currentColor"></path><path d="M16 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v8h2V10a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h8v-2zm2-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentSubtractIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-subtract-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 24H20v2h10v-2z" fill="currentColor"></path><path d="M16 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v8h2V10a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h8v-2zm2-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentUnlockIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentUnlockIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentUnlockIconComponent, isStandalone: true, selector: "iui-document-unlock-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m23.499 9.085-6.792-6.792A1 1 0 0 0 16 2H6a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h8v-2H6V4h8v6a2.002 2.002 0 0 0 2 2h6.292a1.708 1.708 0 0 0 1.207-2.915zM16 10V4.414L21.585 10H16z" fill="currentColor"></path><path d="M28 21h-6v-3a2 2 0 0 1 4 0h2a4 4 0 1 0-8 0v3a2.003 2.003 0 0 0-2 2v5a2.003 2.003 0 0 0 2 2h8a2.003 2.003 0 0 0 2-2v-5a2.003 2.003 0 0 0-2-2zm-8 7v-5h8v5h-8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentUnlockIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-unlock-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m23.499 9.085-6.792-6.792A1 1 0 0 0 16 2H6a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h8v-2H6V4h8v6a2.002 2.002 0 0 0 2 2h6.292a1.708 1.708 0 0 0 1.207-2.915zM16 10V4.414L21.585 10H16z" fill="currentColor"></path><path d="M28 21h-6v-3a2 2 0 0 1 4 0h2a4 4 0 1 0-8 0v3a2.003 2.003 0 0 0-2 2v5a2.003 2.003 0 0 0 2 2h8a2.003 2.003 0 0 0 2-2v-5a2.003 2.003 0 0 0-2-2zm-8 7v-5h8v5h-8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentVideoIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentVideoIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentVideoIconComponent, isStandalone: true, selector: "iui-document-video-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m30 19-4 3.2V20a2.002 2.002 0 0 0-2-2h-8a2.002 2.002 0 0 0-2 2v6a2.002 2.002 0 0 0 2 2h8a2.002 2.002 0 0 0 2-2v-2.2l4 3.2v-8zm-14 7v-6h8l.002 6H16z" fill="currentColor"></path><path d="M12 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v3h2v-5a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h4v-2zm6-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentVideoIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-video-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m30 19-4 3.2V20a2.002 2.002 0 0 0-2-2h-8a2.002 2.002 0 0 0-2 2v6a2.002 2.002 0 0 0 2 2h8a2.002 2.002 0 0 0 2-2v-2.2l4 3.2v-8zm-14 7v-6h8l.002 6H16z" fill="currentColor"></path><path d="M12 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v3h2v-5a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h4v-2zm6-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DocumentViewIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentViewIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DocumentViewIconComponent, isStandalone: true, selector: "iui-document-view-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 26a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" fill="currentColor"></path><path d="M29.777 23.479A8.64 8.64 0 0 0 22 18a8.639 8.639 0 0 0-7.777 5.479L14 24l.223.521A8.64 8.64 0 0 0 22 30a8.64 8.64 0 0 0 7.777-5.479L30 24l-.223-.521zM22 28a4 4 0 1 1 0-8 4 4 0 0 1 0 8z" fill="currentColor"></path><path d="M12 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v4h2v-6a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h4v-2zm6-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DocumentViewIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-document-view-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 26a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" fill="currentColor"></path><path d="M29.777 23.479A8.64 8.64 0 0 0 22 18a8.639 8.639 0 0 0-7.777 5.479L14 24l.223.521A8.64 8.64 0 0 0 22 30a8.64 8.64 0 0 0 7.777-5.479L30 24l-.223-.521zM22 28a4 4 0 1 1 0-8 4 4 0 0 1 0 8z" fill="currentColor"></path><path d="M12 28H8V4h8v6a2.005 2.005 0 0 0 2 2h6v4h2v-6a.909.909 0 0 0-.3-.7l-7-7A.908.908 0 0 0 18 2H8a2.006 2.006 0 0 0-2 2v24a2.006 2.006 0 0 0 2 2h4v-2zm6-23.6 5.6 5.6H18V4.4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DownloadIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DownloadIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DownloadIconComponent, isStandalone: true, selector: "iui-download-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4h-2zM26 14l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10 10-10z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DownloadIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-download-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4h-2zM26 14l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10 10-10z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DragDropIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DragDropIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DragDropIconComponent, isStandalone: true, selector: "iui-drag-drop-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M14 6h-4v4h4V6zM22 6h-4v4h4V6zM14 14h-4v4h4v-4zM22 14h-4v4h4v-4zM14 22h-4v4h4v-4zM22 22h-4v4h4v-4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DragDropIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-drag-drop-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M14 6h-4v4h4V6zM22 6h-4v4h4V6zM14 14h-4v4h4v-4zM22 14h-4v4h4v-4zM14 22h-4v4h4v-4zM22 22h-4v4h4v-4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DragHorizontalIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DragHorizontalIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DragHorizontalIconComponent, isStandalone: true, selector: "iui-drag-horizontal-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 4v11H5.83l2.58-2.59L7 11l-5 5 5 5 1.41-1.41L5.83 17H12v11h2V4h-2zM25 11l-1.41 1.41L26.17 15H20V4h-2v24h2V17h6.17l-2.58 2.59L25 21l5-5-5-5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DragHorizontalIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-drag-horizontal-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 4v11H5.83l2.58-2.59L7 11l-5 5 5 5 1.41-1.41L5.83 17H12v11h2V4h-2zM25 11l-1.41 1.41L26.17 15H20V4h-2v24h2V17h6.17l-2.58 2.59L25 21l5-5-5-5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DragVerticalIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DragVerticalIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DragVerticalIconComponent, isStandalone: true, selector: "iui-drag-vertical-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 20h11v6.17l-2.59-2.58L11 25l5 5 5-5-1.41-1.41L17 26.17V20h11v-2H4v2zM11 7l1.41 1.41L15 5.83V12H4v2h24v-2H17V5.83l2.59 2.58L21 7l-5-5-5 5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DragVerticalIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-drag-vertical-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 20h11v6.17l-2.59-2.58L11 25l5 5 5-5-1.41-1.41L17 26.17V20h11v-2H4v2zM11 7l1.41 1.41L15 5.83V12H4v2h24v-2H17V5.83l2.59 2.58L21 7l-5-5-5 5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DrawIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DrawIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DrawIconComponent, isStandalone: true, selector: "iui-draw-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M19.14 28a3.42 3.42 0 0 1-2.42-5.85L21.86 17a1.42 1.42 0 1 0-2-2L13 21.85a3.5 3.5 0 0 1-4.85 0 3.43 3.43 0 0 1 0-4.84l8.58-8.58a1.42 1.42 0 1 0-2-2L6.41 14.7 5 13.3 13.29 5a3.43 3.43 0 0 1 4.84 4.85l-8.57 8.57a1.42 1.42 0 0 0 0 2 1.45 1.45 0 0 0 2 0l6.86-6.86a3.43 3.43 0 1 1 4.85 4.84l-5.15 5.15a1.42 1.42 0 0 0 2 2l4.44-4.43L26 22.56 21.56 27a3.381 3.381 0 0 1-2.42 1z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DrawIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-draw-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M19.14 28a3.42 3.42 0 0 1-2.42-5.85L21.86 17a1.42 1.42 0 1 0-2-2L13 21.85a3.5 3.5 0 0 1-4.85 0 3.43 3.43 0 0 1 0-4.84l8.58-8.58a1.42 1.42 0 1 0-2-2L6.41 14.7 5 13.3 13.29 5a3.43 3.43 0 0 1 4.84 4.85l-8.57 8.57a1.42 1.42 0 0 0 0 2 1.45 1.45 0 0 0 2 0l6.86-6.86a3.43 3.43 0 1 1 4.85 4.84l-5.15 5.15a1.42 1.42 0 0 0 2 2l4.44-4.43L26 22.56 21.56 27a3.381 3.381 0 0 1-2.42 1z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class DvrIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DvrIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DvrIconComponent, isStandalone: true, selector: "iui-dvr-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 15v-4a2 2 0 0 0-2-2h-6v14h2v-6h1.48l2.34 6H30l-2.33-6H28a2 2 0 0 0 2-2zm-6-4h4v4h-4v-4zM18 9l-2 13-2-13h-2l2.52 14h2.96L20 9h-2zM6 23H2V9h4a4 4 0 0 1 4 4v6a4 4 0 0 1-4 4zm-2-2h2a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2H4v10z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DvrIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-dvr-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 15v-4a2 2 0 0 0-2-2h-6v14h2v-6h1.48l2.34 6H30l-2.33-6H28a2 2 0 0 0 2-2zm-6-4h4v4h-4v-4zM18 9l-2 13-2-13h-2l2.52 14h2.96L20 9h-2zM6 23H2V9h4a4 4 0 0 1 4 4v6a4 4 0 0 1-4 4zm-2-2h2a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2H4v10z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class EditIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: EditIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: EditIconComponent, isStandalone: true, selector: "iui-edit-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 26H2v2h28v-2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zm-5-5L24 7.6l-3 3L17.4 7l3-3zM6 22v-3.6l10-10 3.6 3.6-10 10H6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: EditIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-edit-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 26H2v2h28v-2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zm-5-5L24 7.6l-3 3L17.4 7l3-3zM6 22v-3.6l10-10 3.6 3.6-10 10H6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class EducationIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: EducationIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: EducationIconComponent, isStandalone: true, selector: "iui-education-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30h-2v-3a5.006 5.006 0 0 0-5-5h-6a5.006 5.006 0 0 0-5 5v3H6v-3a7.008 7.008 0 0 1 7-7h6a7.009 7.009 0 0 1 7 7v3zM5 6a1 1 0 0 0-1 1v9h2V7a1 1 0 0 0-1-1z" fill="currentColor"></path><path d="M4 2v2h5v7a7 7 0 1 0 14 0V4h5V2H4zm7 2h10v3H11V4zm5 12a5 5 0 0 1-5-5V9h10v2a5 5 0 0 1-5 5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: EducationIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-education-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30h-2v-3a5.006 5.006 0 0 0-5-5h-6a5.006 5.006 0 0 0-5 5v3H6v-3a7.008 7.008 0 0 1 7-7h6a7.009 7.009 0 0 1 7 7v3zM5 6a1 1 0 0 0-1 1v9h2V7a1 1 0 0 0-1-1z" fill="currentColor"></path><path d="M4 2v2h5v7a7 7 0 1 0 14 0V4h5V2H4zm7 2h10v3H11V4zm5 12a5 5 0 0 1-5-5V9h10v2a5 5 0 0 1-5 5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class EmailIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: EmailIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: EmailIconComponent, isStandalone: true, selector: "iui-email-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 6H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zm-2.2 2L16 14.78 6.2 8h19.6zM4 24V8.91l11.43 7.91a1 1 0 0 0 1.14 0L28 8.91V24H4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: EmailIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-email-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 6H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zm-2.2 2L16 14.78 6.2 8h19.6zM4 24V8.91l11.43 7.91a1 1 0 0 0 1.14 0L28 8.91V24H4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class EraseIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: EraseIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: EraseIconComponent, isStandalone: true, selector: "iui-erase-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 27H7v2h23v-2zM27.38 10.51l-7.93-7.92a2 2 0 0 0-2.83 0l-14 14a2 2 0 0 0 0 2.83L7.13 24h9.59l10.66-10.66a2.001 2.001 0 0 0 0-2.83zM15.89 22H8l-4-4 6.31-6.31 7.93 7.92L15.89 22zm3.76-3.76-7.92-7.93L18 4l8 7.93-6.35 6.31z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: EraseIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-erase-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 27H7v2h23v-2zM27.38 10.51l-7.93-7.92a2 2 0 0 0-2.83 0l-14 14a2 2 0 0 0 0 2.83L7.13 24h9.59l10.66-10.66a2.001 2.001 0 0 0 0-2.83zM15.89 22H8l-4-4 6.31-6.31 7.93 7.92L15.89 22zm3.76-3.76-7.92-7.93L18 4l8 7.93-6.35 6.31z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ErrorIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ErrorIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ErrorIconComponent, isStandalone: true, selector: "iui-error-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2C8.3 2 2 8.3 2 16s6.3 14 14 14 14-6.3 14-14S23.7 2 16 2zm-1.1 6h2.2v11h-2.2V8zM16 25c-.8 0-1.5-.7-1.5-1.5S15.2 22 16 22s1.5.7 1.5 1.5S16.8 25 16 25z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ErrorIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-error-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2C8.3 2 2 8.3 2 16s6.3 14 14 14 14-6.3 14-14S23.7 2 16 2zm-1.1 6h2.2v11h-2.2V8zM16 25c-.8 0-1.5-.7-1.5-1.5S15.2 22 16 22s1.5.7 1.5 1.5S16.8 25 16 25z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ExitIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ExitIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ExitIconComponent, isStandalone: true, selector: "iui-exit-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4h-2v24h2V4zM11.414 20.586 7.828 17H22v-2H7.828l3.586-3.586L10 10l-6 6 6 6 1.414-1.414z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ExitIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-exit-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4h-2v24h2V4zM11.414 20.586 7.828 17H22v-2H7.828l3.586-3.586L10 10l-6 6 6 6 1.414-1.414z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ExportIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ExportIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ExportIconComponent, isStandalone: true, selector: "iui-export-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 24v4H6v-4H4v4l.008-.005A1.998 1.998 0 0 0 6 30h20a2 2 0 0 0 2-2v-4h-2zM6 12l1.411 1.405L15 5.825V24h2V5.825l7.591 7.58L26 12 16 2 6 12z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ExportIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-export-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 24v4H6v-4H4v4l.008-.005A1.998 1.998 0 0 0 6 30h20a2 2 0 0 0 2-2v-4h-2zM6 12l1.411 1.405L15 5.825V24h2V5.825l7.591 7.58L26 12 16 2 6 12z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FaceDissatisfiedFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceDissatisfiedFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FaceDissatisfiedFillIconComponent, isStandalone: true, selector: "iui-face-dissatisfied-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm-4.5 9A2.5 2.5 0 1 1 9 13.5a2.48 2.48 0 0 1 2.54-2.5h-.04zm9.64 12.92a6 6 0 0 0-10.28 0l-1.71-1a8 8 0 0 1 13.7 0l-1.71 1zM20.5 16a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceDissatisfiedFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-dissatisfied-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm-4.5 9A2.5 2.5 0 1 1 9 13.5a2.48 2.48 0 0 1 2.54-2.5h-.04zm9.64 12.92a6 6 0 0 0-10.28 0l-1.71-1a8 8 0 0 1 13.7 0l-1.71 1zM20.5 16a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FaceDissatisfiedOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceDissatisfiedOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FaceDissatisfiedOutlineIconComponent, isStandalone: true, selector: "iui-face-dissatisfied-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M11.5 11a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM20.5 11a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM16 19a8 8 0 0 0-6.85 3.89l1.71 1a6 6 0 0 1 10.28 0l1.71-1A8 8 0 0 0 16 19z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceDissatisfiedOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-dissatisfied-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M11.5 11a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM20.5 11a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM16 19a8 8 0 0 0-6.85 3.89l1.71 1a6 6 0 0 1 10.28 0l1.71-1A8 8 0 0 0 16 19z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FaceDizzyFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceDizzyFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FaceDizzyFillIconComponent, isStandalone: true, selector: "iui-face-dizzy-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zM9 16.41 7.59 15l2-2-2-2L9 9.59l2 2 2-2L14.41 11l-2 2 2 2L13 16.41l-2-2-2 2zM16 25a3 3 0 1 1 0-5.999A3 3 0 0 1 16 25zm8.41-10L23 16.41l-2-2-2 2L17.59 15l2-2-2-2L19 9.59l2 2 2-2L24.41 11l-2 2 2 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceDizzyFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-dizzy-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zM9 16.41 7.59 15l2-2-2-2L9 9.59l2 2 2-2L14.41 11l-2 2 2 2L13 16.41l-2-2-2 2zM16 25a3 3 0 1 1 0-5.999A3 3 0 0 1 16 25zm8.41-10L23 16.41l-2-2-2 2L17.59 15l2-2-2-2L19 9.59l2 2 2-2L24.41 11l-2 2 2 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FaceDizzyOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceDizzyOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FaceDizzyOutlineIconComponent, isStandalone: true, selector: "iui-face-dizzy-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M24.41 11 23 9.59l-2 2-2-2L17.59 11l2 2-2 2L19 16.41l2-2 2 2L24.41 15l-2-2 2-2zM14.41 11 13 9.59l-2 2-2-2L7.59 11l2 2-2 2L9 16.41l2-2 2 2L14.41 15l-2-2 2-2zM16 19a3 3 0 1 0 0 5.999A3 3 0 0 0 16 19z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceDizzyOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-dizzy-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M24.41 11 23 9.59l-2 2-2-2L17.59 11l2 2-2 2L19 16.41l2-2 2 2L24.41 15l-2-2 2-2zM14.41 11 13 9.59l-2 2-2-2L7.59 11l2 2-2 2L9 16.41l2-2 2 2L14.41 15l-2-2 2-2zM16 19a3 3 0 1 0 0 5.999A3 3 0 0 0 16 19z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FaceIdIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceIdIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FaceIdIconComponent, isStandalone: true, selector: "iui-face-id-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 12a1 1 0 1 1 2 0v2a1 1 0 1 1-2 0v-2zM20 12a1 1 0 1 1 2 0v2a1 1 0 1 1-2 0v-2z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M11.757 18.828a1 1 0 0 1 1.415 0 3.998 3.998 0 0 0 5.656 0 1 1 0 0 1 1.415 1.415 6 6 0 0 1-8.486 0 1 1 0 0 1 0-1.415zM15 15a1 1 0 1 0 0 2h1a1 1 0 0 0 1-1v-4a1 1 0 1 0-2 0v3z" fill="currentColor"></path><path d="M20 6h6v6h2V6a2 2 0 0 0-2-2h-6v2zM12 6V4H6a2 2 0 0 0-2 2v6h2V6h6zM6 20H4v6a2 2 0 0 0 2 2h6v-2H6v-6zM20 26v2h6a2 2 0 0 0 2-2v-6h-2v6h-6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceIdIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-id-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 12a1 1 0 1 1 2 0v2a1 1 0 1 1-2 0v-2zM20 12a1 1 0 1 1 2 0v2a1 1 0 1 1-2 0v-2z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M11.757 18.828a1 1 0 0 1 1.415 0 3.998 3.998 0 0 0 5.656 0 1 1 0 0 1 1.415 1.415 6 6 0 0 1-8.486 0 1 1 0 0 1 0-1.415zM15 15a1 1 0 1 0 0 2h1a1 1 0 0 0 1-1v-4a1 1 0 1 0-2 0v3z" fill="currentColor"></path><path d="M20 6h6v6h2V6a2 2 0 0 0-2-2h-6v2zM12 6V4H6a2 2 0 0 0-2 2v6h2V6h6zM6 20H4v6a2 2 0 0 0 2 2h6v-2H6v-6zM20 26v2h6a2 2 0 0 0 2-2v-6h-2v6h-6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FaceNeutralFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceNeutralFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FaceNeutralFillIconComponent, isStandalone: true, selector: "iui-face-neutral-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zM9 13.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0zM22 22H10v-2h12v2zm-1.5-6a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceNeutralFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-neutral-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zM9 13.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0zM22 22H10v-2h12v2zm-1.5-6a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FaceNeutralOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceNeutralOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FaceNeutralOutlineIconComponent, isStandalone: true, selector: "iui-face-neutral-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M11.5 11a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM20.5 11a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM22 20H10v2h12v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceNeutralOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-neutral-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M11.5 11a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM20.5 11a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM22 20H10v2h12v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FacePendingFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FacePendingFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FacePendingFillIconComponent, isStandalone: true, selector: "iui-face-pending-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm-4.5 14a2.5 2.5 0 1 1 2.5-2.5 2.48 2.48 0 0 1-2.5 2.5zm9 0a2.5 2.5 0 1 1 2.5-2.5 2.48 2.48 0 0 1-2.5 2.5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FacePendingFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-pending-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm-4.5 14a2.5 2.5 0 1 1 2.5-2.5 2.48 2.48 0 0 1-2.5 2.5zm9 0a2.5 2.5 0 1 1 2.5-2.5 2.48 2.48 0 0 1-2.5 2.5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FacePendingOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FacePendingOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FacePendingOutlineIconComponent, isStandalone: true, selector: "iui-face-pending-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M11.5 11a2.5 2.5 0 1 0 2.5 2.5 2.48 2.48 0 0 0-2.5-2.5zM20.5 11a2.5 2.5 0 1 0 2.5 2.5 2.48 2.48 0 0 0-2.5-2.5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FacePendingOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-pending-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M11.5 11a2.5 2.5 0 1 0 2.5 2.5 2.48 2.48 0 0 0-2.5-2.5zM20.5 11a2.5 2.5 0 1 0 2.5 2.5 2.48 2.48 0 0 0-2.5-2.5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FaceSatisfiedFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceSatisfiedFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FaceSatisfiedFillIconComponent, isStandalone: true, selector: "iui-face-satisfied-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm-4.5 9A2.5 2.5 0 1 1 9 13.5a2.48 2.48 0 0 1 2.5-2.5zM16 24a8 8 0 0 1-6.85-3.89l1.71-1a6 6 0 0 0 10.28 0l1.71 1A8 8 0 0 1 16 24zm4.5-8a2.5 2.5 0 1 1 2.5-2.5 2.48 2.48 0 0 1-2.5 2.5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceSatisfiedFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-satisfied-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm-4.5 9A2.5 2.5 0 1 1 9 13.5a2.48 2.48 0 0 1 2.5-2.5zM16 24a8 8 0 0 1-6.85-3.89l1.71-1a6 6 0 0 0 10.28 0l1.71 1A8 8 0 0 1 16 24zm4.5-8a2.5 2.5 0 1 1 2.5-2.5 2.48 2.48 0 0 1-2.5 2.5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FaceSatisfiedOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceSatisfiedOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FaceSatisfiedOutlineIconComponent, isStandalone: true, selector: "iui-face-satisfied-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M11.5 11a2.5 2.5 0 1 0 2.5 2.5 2.48 2.48 0 0 0-2.5-2.5zM20.5 11a2.5 2.5 0 1 0 2.5 2.5 2.48 2.48 0 0 0-2.5-2.5zM16 24a8 8 0 0 0 6.85-3.89l-1.71-1a6 6 0 0 1-10.28 0l-1.71 1A8 8 0 0 0 16 24z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceSatisfiedOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-satisfied-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M11.5 11a2.5 2.5 0 1 0 2.5 2.5 2.48 2.48 0 0 0-2.5-2.5zM20.5 11a2.5 2.5 0 1 0 2.5 2.5 2.48 2.48 0 0 0-2.5-2.5zM16 24a8 8 0 0 0 6.85-3.89l-1.71-1a6 6 0 0 1-10.28 0l-1.71 1A8 8 0 0 0 16 24z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FaceWideFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceWideFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FaceWideFillIconComponent, isStandalone: true, selector: "iui-face-wide-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm-4.5 9A2.5 2.5 0 1 1 9 13.5a2.48 2.48 0 0 1 2.5-2.5zM16 24a8.11 8.11 0 0 1-7-4h14a8.11 8.11 0 0 1-7 4zm4.5-8a2.5 2.5 0 1 1 2.5-2.5 2.48 2.48 0 0 1-2.5 2.5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceWideFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-wide-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm-4.5 9A2.5 2.5 0 1 1 9 13.5a2.48 2.48 0 0 1 2.5-2.5zM16 24a8.11 8.11 0 0 1-7-4h14a8.11 8.11 0 0 1-7 4zm4.5-8a2.5 2.5 0 1 1 2.5-2.5 2.48 2.48 0 0 1-2.5 2.5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FaceWideOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceWideOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FaceWideOutlineIconComponent, isStandalone: true, selector: "iui-face-wide-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M11.5 11a2.5 2.5 0 1 0 2.5 2.5 2.48 2.48 0 0 0-2.5-2.5zM20.5 11a2.5 2.5 0 1 0 2.5 2.5 2.48 2.48 0 0 0-2.5-2.5zM9 20a8.13 8.13 0 0 0 14 0H9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceWideOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-wide-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M11.5 11a2.5 2.5 0 1 0 2.5 2.5 2.48 2.48 0 0 0-2.5-2.5zM20.5 11a2.5 2.5 0 1 0 2.5 2.5 2.48 2.48 0 0 0-2.5-2.5zM9 20a8.13 8.13 0 0 0 14 0H9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FaceWinkFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceWinkFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FaceWinkFillIconComponent, isStandalone: true, selector: "iui-face-wink-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zM8 13h6v2H8v-2zm8 11a8 8 0 0 1-6.85-3.89l1.71-1a6 6 0 0 0 10.28 0l1.71 1A8 8 0 0 1 16 24zm4.5-8a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceWinkFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-wink-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zM8 13h6v2H8v-2zm8 11a8 8 0 0 1-6.85-3.89l1.71-1a6 6 0 0 0 10.28 0l1.71 1A8 8 0 0 1 16 24zm4.5-8a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FaceWinkOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceWinkOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FaceWinkOutlineIconComponent, isStandalone: true, selector: "iui-face-wink-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M20.5 11a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM14 13H8v2h6v-2zM16 24a8 8 0 0 0 6.85-3.89l-1.71-1a6 6 0 0 1-10.28 0l-1.71 1A8 8 0 0 0 16 24z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FaceWinkOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-face-wink-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M20.5 11a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM14 13H8v2h6v-2zM16 24a8 8 0 0 0 6.85-3.89l-1.71-1a6 6 0 0 1-10.28 0l-1.71 1A8 8 0 0 0 16 24z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FacebookIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FacebookIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FacebookIconComponent, isStandalone: true, selector: "iui-facebook-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26.67 4H5.33A1.34 1.34 0 0 0 4 5.33v21.34A1.34 1.34 0 0 0 5.33 28h11.49v-9.28H13.7v-3.63h3.12v-2.67c0-3.1 1.89-4.79 4.67-4.79.93 0 1.86 0 2.79.14V11h-1.91c-1.51 0-1.8.72-1.8 1.77v2.31h3.6l-.47 3.63h-3.13V28h6.1A1.34 1.34 0 0 0 28 26.67V5.33A1.34 1.34 0 0 0 26.67 4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FacebookIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-facebook-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26.67 4H5.33A1.34 1.34 0 0 0 4 5.33v21.34A1.34 1.34 0 0 0 5.33 28h11.49v-9.28H13.7v-3.63h3.12v-2.67c0-3.1 1.89-4.79 4.67-4.79.93 0 1.86 0 2.79.14V11h-1.91c-1.51 0-1.8.72-1.8 1.77v2.31h3.6l-.47 3.63h-3.13V28h6.1A1.34 1.34 0 0 0 28 26.67V5.33A1.34 1.34 0 0 0 26.67 4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FactoryIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FactoryIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FactoryIconComponent, isStandalone: true, selector: "iui-factory-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)"><path d="M29.53 6.15a1 1 0 0 0-1 0L20 10.38V7a1 1 0 0 0-1.45-.89L10 10.38V3a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1v25h28V7a1 1 0 0 0-.47-.85zM22 26h-4v-7h4v7zm6 0h-4v-8a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v8H4V4h4v9.62l10-5v5l10-5V26z" fill="currentColor"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FactoryIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-factory-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)"><path d="M29.53 6.15a1 1 0 0 0-1 0L20 10.38V7a1 1 0 0 0-1.45-.89L10 10.38V3a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1v25h28V7a1 1 0 0 0-.47-.85zM22 26h-4v-7h4v7zm6 0h-4v-8a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v8H4V4h4v9.62l10-5v5l10-5V26z" fill="currentColor"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FavoriteFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FavoriteFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FavoriteFillIconComponent, isStandalone: true, selector: "iui-favorite-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22.5 4c-2 0-3.9.8-5.3 2.2L16 7.4l-1.1-1.1c-2.9-3-7.7-3-10.6-.1l-.1.1c-3 3-3 7.8 0 10.8L16 29l11.8-11.9c3-3 3-7.8 0-10.8C26.4 4.8 24.5 4 22.5 4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FavoriteFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-favorite-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22.5 4c-2 0-3.9.8-5.3 2.2L16 7.4l-1.1-1.1c-2.9-3-7.7-3-10.6-.1l-.1.1c-3 3-3 7.8 0 10.8L16 29l11.8-11.9c3-3 3-7.8 0-10.8C26.4 4.8 24.5 4 22.5 4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FavoriteHalfIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FavoriteHalfIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FavoriteHalfIconComponent, isStandalone: true, selector: "iui-favorite-half-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4.21 17.061 16 29l11.79-11.939a7.731 7.731 0 0 0 0-10.823 7.494 7.494 0 0 0-10.684 0L16 7.364l-1.106-1.126a7.494 7.494 0 0 0-10.684 0 7.731 7.731 0 0 0 0 10.823zm22.145-1.416L16 26.125V10.23l2.541-2.574a5.477 5.477 0 0 1 7.814 0 5.708 5.708 0 0 1 0 7.989z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FavoriteHalfIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-favorite-half-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4.21 17.061 16 29l11.79-11.939a7.731 7.731 0 0 0 0-10.823 7.494 7.494 0 0 0-10.684 0L16 7.364l-1.106-1.126a7.494 7.494 0 0 0-10.684 0 7.731 7.731 0 0 0 0 10.823zm22.145-1.416L16 26.125V10.23l2.541-2.574a5.477 5.477 0 0 1 7.814 0 5.708 5.708 0 0 1 0 7.989z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FavoriteOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FavoriteOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FavoriteOutlineIconComponent, isStandalone: true, selector: "iui-favorite-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22.45 6a5.47 5.47 0 0 1 3.91 1.64 5.7 5.7 0 0 1 0 8L16 26.13 5.64 15.64a5.7 5.7 0 0 1 0-8 5.48 5.48 0 0 1 7.82 0l2.54 2.6 2.53-2.58A5.441 5.441 0 0 1 22.45 6zm0-2a7.47 7.47 0 0 0-5.34 2.24L16 7.36l-1.11-1.12a7.49 7.49 0 0 0-10.68 0 7.72 7.72 0 0 0 0 10.82L16 29l11.79-11.94a7.72 7.72 0 0 0 0-10.82A7.49 7.49 0 0 0 22.45 4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FavoriteOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-favorite-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22.45 6a5.47 5.47 0 0 1 3.91 1.64 5.7 5.7 0 0 1 0 8L16 26.13 5.64 15.64a5.7 5.7 0 0 1 0-8 5.48 5.48 0 0 1 7.82 0l2.54 2.6 2.53-2.58A5.441 5.441 0 0 1 22.45 6zm0-2a7.47 7.47 0 0 0-5.34 2.24L16 7.36l-1.11-1.12a7.49 7.49 0 0 0-10.68 0 7.72 7.72 0 0 0 0 10.82L16 29l11.79-11.94a7.72 7.72 0 0 0 0-10.82A7.49 7.49 0 0 0 22.45 4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FilterIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FilterIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FilterIconComponent, isStandalone: true, selector: "iui-filter-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 28h-4a2 2 0 0 1-2-2v-7.59L4.59 11A2 2 0 0 1 4 9.59V6a2 2 0 0 1 2-2h20a2 2 0 0 1 2 2v3.59a2 2 0 0 1-.59 1.41L20 18.41V26a2 2 0 0 1-2 2zM6 6v3.59l8 8V26h4v-8.41l8-8V6H6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FilterIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-filter-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 28h-4a2 2 0 0 1-2-2v-7.59L4.59 11A2 2 0 0 1 4 9.59V6a2 2 0 0 1 2-2h20a2 2 0 0 1 2 2v3.59a2 2 0 0 1-.59 1.41L20 18.41V26a2 2 0 0 1-2 2zM6 6v3.59l8 8V26h4v-8.41l8-8V6H6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FitToHeightIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FitToHeightIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FitToHeightIconComponent, isStandalone: true, selector: "iui-fit-to-height-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m11 10 1.41 1.41L15 8.83v14.34l-2.59-2.58L11 22l5 5 5-5-1.41-1.41L17 23.17V8.83l2.59 2.58L21 10l-5-5-5 5z" fill="currentColor"></path><path d="M28 30H4a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h24a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM4 4v24h24V4H4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FitToHeightIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-fit-to-height-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m11 10 1.41 1.41L15 8.83v14.34l-2.59-2.58L11 22l5 5 5-5-1.41-1.41L17 23.17V8.83l2.59 2.58L21 10l-5-5-5 5z" fill="currentColor"></path><path d="M28 30H4a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h24a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM4 4v24h24V4H4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FitToScreenIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FitToScreenIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FitToScreenIconComponent, isStandalone: true, selector: "iui-fit-to-screen-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 16h2V8h-8v2h6v6zM8 24h8v-2h-6v-6H8v8z" fill="currentColor"></path><path d="M26 28H6a2.002 2.002 0 0 1-2-2V6a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v20a2.002 2.002 0 0 1-2 2zM6 6v20h20.001L26 6H6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FitToScreenIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-fit-to-screen-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 16h2V8h-8v2h6v6zM8 24h8v-2h-6v-6H8v8z" fill="currentColor"></path><path d="M26 28H6a2.002 2.002 0 0 1-2-2V6a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v20a2.002 2.002 0 0 1-2 2zM6 6v20h20.001L26 6H6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FitToWidthIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FitToWidthIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FitToWidthIconComponent, isStandalone: true, selector: "iui-fit-to-width-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m22 11-1.41 1.41L23.17 15H8.83l2.58-2.59L10 11l-5 5 5 5 1.41-1.41L8.83 17h14.34l-2.58 2.59L22 21l5-5-5-5z" fill="currentColor"></path><path d="M28 30H4a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h24a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM4 4v24h24V4H4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FitToWidthIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-fit-to-width-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m22 11-1.41 1.41L23.17 15H8.83l2.58-2.59L10 11l-5 5 5 5 1.41-1.41L8.83 17h14.34l-2.58 2.59L22 21l5-5-5-5z" fill="currentColor"></path><path d="M28 30H4a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h24a2.002 2.002 0 0 1 2 2v24a2.002 2.002 0 0 1-2 2zM4 4v24h24V4H4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FlagFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FlagFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FlagFillIconComponent, isStandalone: true, selector: "iui-flag-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M6 30H4V2h24l-5.8 9 5.8 9H6v10z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FlagFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-flag-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M6 30H4V2h24l-5.8 9 5.8 9H6v10z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FlagOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FlagOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FlagOutlineIconComponent, isStandalone: true, selector: "iui-flag-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M6 30H4V2h24l-5.8 9 5.8 9H6v10zm0-12h18.33l-4.53-7 4.53-7H6v14z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FlagOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-flag-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M6 30H4V2h24l-5.8 9 5.8 9H6v10zm0-12h18.33l-4.53-7 4.53-7H6v14z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FlashFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FlashFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FlashFillIconComponent, isStandalone: true, selector: "iui-flash-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M11.61 29.92a1 1 0 0 1-.6-1.07L12.83 17H8a1 1 0 0 1-1-1.23l3-13A1 1 0 0 1 11 2h10a1 1 0 0 1 .98 1.22L20.25 11H25a1 1 0 0 1 .9.56.999.999 0 0 1-.11 1l-13 17A1 1 0 0 1 12 30a1.09 1.09 0 0 1-.39-.08z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FlashFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-flash-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M11.61 29.92a1 1 0 0 1-.6-1.07L12.83 17H8a1 1 0 0 1-1-1.23l3-13A1 1 0 0 1 11 2h10a1 1 0 0 1 .98 1.22L20.25 11H25a1 1 0 0 1 .9.56.999.999 0 0 1-.11 1l-13 17A1 1 0 0 1 12 30a1.09 1.09 0 0 1-.39-.08z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FlashOffFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FlashOffFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FlashOffFillIconComponent, isStandalone: true, selector: "iui-flash-off-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 28.59 3.41 2 2 3.41l6.4 6.41L7 15.77A1 1 0 0 0 8 17h4.83L11 28.85A1 1 0 0 0 12 30a1 1 0 0 0 .79-.39l6.68-8.73L28.59 30 30 28.59zM22.53 16.87l3.26-4.26a1 1 0 0 0 .11-1A1 1 0 0 0 25 11h-4.75L22 3.22A1 1 0 0 0 21 2H11a1 1 0 0 0-1 .77l-.3 1.3 12.83 12.8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FlashOffFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-flash-off-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 28.59 3.41 2 2 3.41l6.4 6.41L7 15.77A1 1 0 0 0 8 17h4.83L11 28.85A1 1 0 0 0 12 30a1 1 0 0 0 .79-.39l6.68-8.73L28.59 30 30 28.59zM22.53 16.87l3.26-4.26a1 1 0 0 0 .11-1A1 1 0 0 0 25 11h-4.75L22 3.22A1 1 0 0 0 21 2H11a1 1 0 0 0-1 .77l-.3 1.3 12.83 12.8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FlashOffOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FlashOffOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FlashOffOutlineIconComponent, isStandalone: true, selector: "iui-flash-off-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M11.13 6.89 11.8 4h8l-2 9H23l-2.49 3.25 1.43 1.43 3.87-5.07a1 1 0 0 0 .11-1A1 1 0 0 0 25 11h-4.75L22 3.22A1 1 0 0 0 21 2H11a1 1 0 0 0-1 .77l-.54 2.45 1.67 1.67zM30 28.59l-9.31-9.31-1.42-1.43L3.41 2 2 3.41l6.4 6.41L7 15.77A1 1 0 0 0 8 17h4.83L11 28.85A1 1 0 0 0 12 30a1 1 0 0 0 .79-.39l6.68-8.73L28.59 30 30 28.59zM9.26 15l.81-3.52L13.59 15H9.26zm4.32 10.28L15 16.37l3 3.08-4.42 5.83z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FlashOffOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-flash-off-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M11.13 6.89 11.8 4h8l-2 9H23l-2.49 3.25 1.43 1.43 3.87-5.07a1 1 0 0 0 .11-1A1 1 0 0 0 25 11h-4.75L22 3.22A1 1 0 0 0 21 2H11a1 1 0 0 0-1 .77l-.54 2.45 1.67 1.67zM30 28.59l-9.31-9.31-1.42-1.43L3.41 2 2 3.41l6.4 6.41L7 15.77A1 1 0 0 0 8 17h4.83L11 28.85A1 1 0 0 0 12 30a1 1 0 0 0 .79-.39l6.68-8.73L28.59 30 30 28.59zM9.26 15l.81-3.52L13.59 15H9.26zm4.32 10.28L15 16.37l3 3.08-4.42 5.83z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FlashOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FlashOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FlashOutlineIconComponent, isStandalone: true, selector: "iui-flash-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M11.61 29.92a1 1 0 0 1-.6-1.07L12.83 17H8a1 1 0 0 1-1-1.23l3-13A1 1 0 0 1 11 2h10a1 1 0 0 1 .98 1.22L20.25 11H25a1 1 0 0 1 .9.56.999.999 0 0 1-.11 1l-13 17A1 1 0 0 1 12 30a1.09 1.09 0 0 1-.39-.08zM17.75 13l2-9H11.8L9.26 15h5.91l-1.59 10.28L23 13h-5.25z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FlashOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-flash-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M11.61 29.92a1 1 0 0 1-.6-1.07L12.83 17H8a1 1 0 0 1-1-1.23l3-13A1 1 0 0 1 11 2h10a1 1 0 0 1 .98 1.22L20.25 11H25a1 1 0 0 1 .9.56.999.999 0 0 1-.11 1l-13 17A1 1 0 0 1 12 30a1.09 1.09 0 0 1-.39-.08zM17.75 13l2-9H11.8L9.26 15h5.91l-1.59 10.28L23 13h-5.25z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FolderAddIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderAddIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FolderAddIconComponent, isStandalone: true, selector: "iui-folder-add-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 20h-2v4h-4v2h4v4h2v-4h4v-2h-4v-4z" fill="currentColor"></path><path d="M28 8H16l-3.4-3.4c-.4-.4-.9-.6-1.4-.6H4c-1.1 0-2 .9-2 2v20c0 1.1.9 2 2 2h14v-2H4V6h7.2l4 4H28v8h2v-8c0-1.1-.9-2-2-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderAddIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-folder-add-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 20h-2v4h-4v2h4v4h2v-4h4v-2h-4v-4z" fill="currentColor"></path><path d="M28 8H16l-3.4-3.4c-.4-.4-.9-.6-1.4-.6H4c-1.1 0-2 .9-2 2v20c0 1.1.9 2 2 2h14v-2H4V6h7.2l4 4H28v8h2v-8c0-1.1-.9-2-2-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FolderDetailIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderDetailIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FolderDetailIconComponent, isStandalone: true, selector: "iui-folder-detail-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 20H16v2h14v-2zM30 24H16v2h14v-2zM23 28h-7v2h7v-2z" fill="currentColor"></path><path d="M14 26H4V6h7.17l3.42 3.41.58.59H28v8h2v-8a2 2 0 0 0-2-2H16l-3.41-3.41A2 2 0 0 0 11.17 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h10v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderDetailIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-folder-detail-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 20H16v2h14v-2zM30 24H16v2h14v-2zM23 28h-7v2h7v-2z" fill="currentColor"></path><path d="M14 26H4V6h7.17l3.42 3.41.58.59H28v8h2v-8a2 2 0 0 0-2-2H16l-3.41-3.41A2 2 0 0 0 11.17 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h10v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FolderIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FolderIconComponent, isStandalone: true, selector: "iui-folder-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m11.17 6 3.42 3.41.58.59H28v16H4V6h7.17zm0-2H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2H16l-3.41-3.41A2 2 0 0 0 11.17 4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-folder-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m11.17 6 3.42 3.41.58.59H28v16H4V6h7.17zm0-2H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2H16l-3.41-3.41A2 2 0 0 0 11.17 4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FolderMoveToIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderMoveToIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FolderMoveToIconComponent, isStandalone: true, selector: "iui-folder-move-to-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m18 13-1.41 1.41L19.17 17H10v2h9.17l-2.58 2.59L18 23l5-5-5-5z" fill="currentColor"></path><path d="m11.172 6 4 4H28v16H4V6h7.172zm0-2H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2H16l-3.414-3.414A2 2 0 0 0 11.172 4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderMoveToIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-folder-move-to-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m18 13-1.41 1.41L19.17 17H10v2h9.17l-2.58 2.59L18 23l5-5-5-5z" fill="currentColor"></path><path d="m11.172 6 4 4H28v16H4V6h7.172zm0-2H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2H16l-3.414-3.414A2 2 0 0 0 11.172 4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FolderOffIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderOffIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FolderOffIconComponent, isStandalone: true, selector: "iui-folder-off-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 8h-2.586L30 3.414 28.586 2 2 28.586 3.414 30l2-2H28a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zm0 18H7.414l16-16H28v16zM4 6h7.172l4 4H18V8h-2l-3.414-3.414A2 2 0 0 0 11.172 4H4a2 2 0 0 0-2 2v18h2V6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderOffIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-folder-off-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 8h-2.586L30 3.414 28.586 2 2 28.586 3.414 30l2-2H28a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zm0 18H7.414l16-16H28v16zM4 6h7.172l4 4H18V8h-2l-3.414-3.414A2 2 0 0 0 11.172 4H4a2 2 0 0 0-2 2v18h2V6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FolderOpenIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderOpenIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FolderOpenIconComponent, isStandalone: true, selector: "iui-folder-open-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 8h-7.172l-3.414-3.414A2 2 0 0 0 16 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zM8 26V14h8v6.17l-2.59-2.58L12 19l5 5 5-5-1.41-1.41L18 20.17V14a2.003 2.003 0 0 0-2-2H8a2.003 2.003 0 0 0-2 2v12H4V6h12l4 4h8v2h-6v2h6v12H8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderOpenIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-folder-open-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 8h-7.172l-3.414-3.414A2 2 0 0 0 16 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zM8 26V14h8v6.17l-2.59-2.58L12 19l5 5 5-5-1.41-1.41L18 20.17V14a2.003 2.003 0 0 0-2-2H8a2.003 2.003 0 0 0-2 2v12H4V6h12l4 4h8v2h-6v2h6v12H8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FolderSharedIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderSharedIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FolderSharedIconComponent, isStandalone: true, selector: "iui-folder-shared-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 8H16l-3.41-3.41A2 2 0 0 0 11.17 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zm-6 18h-8v-1a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v1zm6 0h-4v-1a3 3 0 0 0-3-3h-6a3 3 0 0 0-3 3v1H4V6h7.17l3.42 3.41.58.59H28v16z" fill="currentColor"></path><path d="M14 17a4 4 0 1 0 8 0 4 4 0 0 0-8 0zm4-2a2 2 0 1 1 0 4 2 2 0 0 1 0-4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FolderSharedIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-folder-shared-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 8H16l-3.41-3.41A2 2 0 0 0 11.17 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zm-6 18h-8v-1a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v1zm6 0h-4v-1a3 3 0 0 0-3-3h-6a3 3 0 0 0-3 3v1H4V6h7.17l3.42 3.41.58.59H28v16z" fill="currentColor"></path><path d="M14 17a4 4 0 1 0 8 0 4 4 0 0 0-8 0zm4-2a2 2 0 1 1 0 4 2 2 0 0 1 0-4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class FoldersIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FoldersIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FoldersIconComponent, isStandalone: true, selector: "iui-folders-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 28H6a2.002 2.002 0 0 1-2-2V11a2.002 2.002 0 0 1 2-2h5.666c.433 0 .854.141 1.201.4l3.466 2.6H26a2.002 2.002 0 0 1 2 2v12a2.002 2.002 0 0 1-2 2zM11.666 11H5.998L6 26h20V14H15.666l-4-3zM28 9H17.666l-4-3H6V4h7.666c.433 0 .854.141 1.201.4L18.333 7H28v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FoldersIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-folders-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 28H6a2.002 2.002 0 0 1-2-2V11a2.002 2.002 0 0 1 2-2h5.666c.433 0 .854.141 1.201.4l3.466 2.6H26a2.002 2.002 0 0 1 2 2v12a2.002 2.002 0 0 1-2 2zM11.666 11H5.998L6 26h20V14H15.666l-4-3zM28 9H17.666l-4-3H6V4h7.666c.433 0 .854.141 1.201.4L18.333 7H28v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class Forward10IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Forward10IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: Forward10IconComponent, isStandalone: true, selector: "iui-forward10-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 18A10 10 0 1 1 16 8h4v5l6-6-6-6v5h-4a12 12 0 1 0 12 12h-2z" fill="currentColor"></path><path d="M19.63 22.13a2.84 2.84 0 0 1-1.28-.27 2.44 2.44 0 0 1-.89-.77 3.57 3.57 0 0 1-.52-1.25 7.687 7.687 0 0 1-.17-1.68 7.825 7.825 0 0 1 .17-1.68c.094-.445.27-.87.52-1.25.23-.325.535-.59.89-.77.4-.188.838-.28 1.28-.27a2.44 2.44 0 0 1 2.16 1 5.23 5.23 0 0 1 .7 2.93 5.23 5.23 0 0 1-.7 2.93 2.44 2.44 0 0 1-2.16 1.08zm0-1.22a1.07 1.07 0 0 0 1-.55 3.38 3.38 0 0 0 .37-1.51v-1.38a3.31 3.31 0 0 0-.29-1.5 1.23 1.23 0 0 0-2.06 0 3.31 3.31 0 0 0-.29 1.5v1.38a3.38 3.38 0 0 0 .29 1.51 1.06 1.06 0 0 0 .98.55zM10.63 22v-1.18h2v-5.19l-1.86 1-.55-1.06 2.32-1.3H14v6.5h1.78V22h-5.15z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Forward10IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-forward10-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 18A10 10 0 1 1 16 8h4v5l6-6-6-6v5h-4a12 12 0 1 0 12 12h-2z" fill="currentColor"></path><path d="M19.63 22.13a2.84 2.84 0 0 1-1.28-.27 2.44 2.44 0 0 1-.89-.77 3.57 3.57 0 0 1-.52-1.25 7.687 7.687 0 0 1-.17-1.68 7.825 7.825 0 0 1 .17-1.68c.094-.445.27-.87.52-1.25.23-.325.535-.59.89-.77.4-.188.838-.28 1.28-.27a2.44 2.44 0 0 1 2.16 1 5.23 5.23 0 0 1 .7 2.93 5.23 5.23 0 0 1-.7 2.93 2.44 2.44 0 0 1-2.16 1.08zm0-1.22a1.07 1.07 0 0 0 1-.55 3.38 3.38 0 0 0 .37-1.51v-1.38a3.31 3.31 0 0 0-.29-1.5 1.23 1.23 0 0 0-2.06 0 3.31 3.31 0 0 0-.29 1.5v1.38a3.38 3.38 0 0 0 .29 1.51 1.06 1.06 0 0 0 .98.55zM10.63 22v-1.18h2v-5.19l-1.86 1-.55-1.06 2.32-1.3H14v6.5h1.78V22h-5.15z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class Forward30IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Forward30IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: Forward30IconComponent, isStandalone: true, selector: "iui-forward30-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M26 18A10 10 0 1 1 16 8h4v5l6-6-6-6v5h-4a12 12 0 1 0 12 12h-2z"></path><path d="M19.64 22.13a2.81 2.81 0 0 1-1.28-.27 2.36 2.36 0 0 1-.89-.77 3.39 3.39 0 0 1-.47-1.25 7.119 7.119 0 0 1-.17-1.68 7.238 7.238 0 0 1 .17-1.68c.09-.447.266-.872.52-1.25a2.36 2.36 0 0 1 .89-.77c.4-.19.838-.282 1.28-.27a2.44 2.44 0 0 1 2.16 1 5.31 5.31 0 0 1 .7 2.93 5.31 5.31 0 0 1-.7 2.93 2.44 2.44 0 0 1-2.21 1.08zm0-1.22a1 1 0 0 0 1-.55c.22-.472.323-.99.3-1.51v-1.38a3.169 3.169 0 0 0-.3-1.5 1.22 1.22 0 0 0-2.05 0 3.18 3.18 0 0 0-.29 1.5v1.38a3.25 3.25 0 0 0 .29 1.51 1 1 0 0 0 1.05.55zM12.62 17.42c.355.035.71-.06 1-.27a.84.84 0 0 0 .31-.68v-.08a.94.94 0 0 0-.3-.74 1.2 1.2 0 0 0-.83-.27 1.65 1.65 0 0 0-.89.24 2.1 2.1 0 0 0-.68.68l-.93-.83c.136-.179.283-.35.44-.51.163-.155.344-.29.54-.4a2.55 2.55 0 0 1 .7-.27 3.25 3.25 0 0 1 .87-.1 3.94 3.94 0 0 1 1.06.14c.297.078.576.214.82.4.224.168.408.383.54.63.123.26.184.543.18.83a2 2 0 0 1-.11.67 1.82 1.82 0 0 1-.32.52 1.789 1.789 0 0 1-.47.36c-.18.092-.372.159-.57.2V18c.219.04.431.11.63.21a1.701 1.701 0 0 1 .85.93c.083.234.124.481.12.73a2 2 0 0 1-.2.92 2 2 0 0 1-.58.72 2.658 2.658 0 0 1-.89.45 3.76 3.76 0 0 1-1.15.16 4.1 4.1 0 0 1-1-.11 3.1 3.1 0 0 1-.76-.31 2.76 2.76 0 0 1-.56-.45 4.226 4.226 0 0 1-.44-.55l1.07-.81c.082.147.175.288.28.42.105.128.226.242.36.34.137.097.29.171.45.22.186.05.378.074.57.07a1.45 1.45 0 0 0 1-.3 1.12 1.12 0 0 0 .34-.85v-.08a1.001 1.001 0 0 0-.37-.8 1.78 1.78 0 0 0-1.06-.28h-.76v-1.21h.74z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Forward30IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-forward30-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M26 18A10 10 0 1 1 16 8h4v5l6-6-6-6v5h-4a12 12 0 1 0 12 12h-2z"></path><path d="M19.64 22.13a2.81 2.81 0 0 1-1.28-.27 2.36 2.36 0 0 1-.89-.77 3.39 3.39 0 0 1-.47-1.25 7.119 7.119 0 0 1-.17-1.68 7.238 7.238 0 0 1 .17-1.68c.09-.447.266-.872.52-1.25a2.36 2.36 0 0 1 .89-.77c.4-.19.838-.282 1.28-.27a2.44 2.44 0 0 1 2.16 1 5.31 5.31 0 0 1 .7 2.93 5.31 5.31 0 0 1-.7 2.93 2.44 2.44 0 0 1-2.21 1.08zm0-1.22a1 1 0 0 0 1-.55c.22-.472.323-.99.3-1.51v-1.38a3.169 3.169 0 0 0-.3-1.5 1.22 1.22 0 0 0-2.05 0 3.18 3.18 0 0 0-.29 1.5v1.38a3.25 3.25 0 0 0 .29 1.51 1 1 0 0 0 1.05.55zM12.62 17.42c.355.035.71-.06 1-.27a.84.84 0 0 0 .31-.68v-.08a.94.94 0 0 0-.3-.74 1.2 1.2 0 0 0-.83-.27 1.65 1.65 0 0 0-.89.24 2.1 2.1 0 0 0-.68.68l-.93-.83c.136-.179.283-.35.44-.51.163-.155.344-.29.54-.4a2.55 2.55 0 0 1 .7-.27 3.25 3.25 0 0 1 .87-.1 3.94 3.94 0 0 1 1.06.14c.297.078.576.214.82.4.224.168.408.383.54.63.123.26.184.543.18.83a2 2 0 0 1-.11.67 1.82 1.82 0 0 1-.32.52 1.789 1.789 0 0 1-.47.36c-.18.092-.372.159-.57.2V18c.219.04.431.11.63.21a1.701 1.701 0 0 1 .85.93c.083.234.124.481.12.73a2 2 0 0 1-.2.92 2 2 0 0 1-.58.72 2.658 2.658 0 0 1-.89.45 3.76 3.76 0 0 1-1.15.16 4.1 4.1 0 0 1-1-.11 3.1 3.1 0 0 1-.76-.31 2.76 2.76 0 0 1-.56-.45 4.226 4.226 0 0 1-.44-.55l1.07-.81c.082.147.175.288.28.42.105.128.226.242.36.34.137.097.29.171.45.22.186.05.378.074.57.07a1.45 1.45 0 0 0 1-.3 1.12 1.12 0 0 0 .34-.85v-.08a1.001 1.001 0 0 0-.37-.8 1.78 1.78 0 0 0-1.06-.28h-.76v-1.21h.74z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class Forward5IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Forward5IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: Forward5IconComponent, isStandalone: true, selector: "iui-forward5-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 18A10 10 0 1 1 16 8h4v5l6-6-6-6v5h-4a12 12 0 1 0 12 12h-2z" fill="currentColor"></path><path d="M18.58 15.58h-3.45L15 18.15a4.81 4.81 0 0 1 .26-.45c.092-.133.203-.25.33-.35.133-.1.282-.178.44-.23a2 2 0 0 1 .6-.08c.314-.004.626.05.92.16.278.105.53.268.74.48.217.22.387.482.5.77.122.32.183.658.18 1a2.87 2.87 0 0 1-.19 1.07 2.36 2.36 0 0 1-1.44 1.39 3.231 3.231 0 0 1-1.21.2 3.788 3.788 0 0 1-.94-.11 3.001 3.001 0 0 1-.74-.32 2.452 2.452 0 0 1-.55-.45 4.127 4.127 0 0 1-.41-.55l1.06-.81.27.41c.098.128.212.242.34.34a1.59 1.59 0 0 0 .98.3 1.29 1.29 0 0 0 1-.36 1.41 1.41 0 0 0 .33-1v-.06a1.18 1.18 0 0 0-1.28-1.27 1.44 1.44 0 0 0-.77.18c-.18.104-.342.235-.48.39l-1.19-.17.29-4.31h4.52l.02 1.26z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Forward5IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-forward5-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 18A10 10 0 1 1 16 8h4v5l6-6-6-6v5h-4a12 12 0 1 0 12 12h-2z" fill="currentColor"></path><path d="M18.58 15.58h-3.45L15 18.15a4.81 4.81 0 0 1 .26-.45c.092-.133.203-.25.33-.35.133-.1.282-.178.44-.23a2 2 0 0 1 .6-.08c.314-.004.626.05.92.16.278.105.53.268.74.48.217.22.387.482.5.77.122.32.183.658.18 1a2.87 2.87 0 0 1-.19 1.07 2.36 2.36 0 0 1-1.44 1.39 3.231 3.231 0 0 1-1.21.2 3.788 3.788 0 0 1-.94-.11 3.001 3.001 0 0 1-.74-.32 2.452 2.452 0 0 1-.55-.45 4.127 4.127 0 0 1-.41-.55l1.06-.81.27.41c.098.128.212.242.34.34a1.59 1.59 0 0 0 .98.3 1.29 1.29 0 0 0 1-.36 1.41 1.41 0 0 0 .33-1v-.06a1.18 1.18 0 0 0-1.28-1.27 1.44 1.44 0 0 0-.77.18c-.18.104-.342.235-.48.39l-1.19-.17.29-4.31h4.52l.02 1.26z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ForwardIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ForwardIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ForwardIconComponent, isStandalone: true, selector: "iui-forward-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M2.114 30a1 1 0 0 0 .88-.5 15.19 15.19 0 0 1 13-7.5v6a1 1 0 0 0 .62.92 1 1 0 0 0 1.09-.21l12-12a.999.999 0 0 0 0-1.42l-12-12a1 1 0 0 0-1.09-.21 1 1 0 0 0-.62.92v6.11a17.19 17.19 0 0 0-15 17c.003.669.046 1.337.13 2a1 1 0 0 0 .79.86l.2.03zm14.38-10a17.62 17.62 0 0 0-13.5 6 15.31 15.31 0 0 1 14.09-14 1 1 0 0 0 .91-1V6.41l9.59 9.59-9.59 9.59V21a1 1 0 0 0-1-1h-.54.04z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ForwardIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-forward-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M2.114 30a1 1 0 0 0 .88-.5 15.19 15.19 0 0 1 13-7.5v6a1 1 0 0 0 .62.92 1 1 0 0 0 1.09-.21l12-12a.999.999 0 0 0 0-1.42l-12-12a1 1 0 0 0-1.09-.21 1 1 0 0 0-.62.92v6.11a17.19 17.19 0 0 0-15 17c.003.669.046 1.337.13 2a1 1 0 0 0 .79.86l.2.03zm14.38-10a17.62 17.62 0 0 0-13.5 6 15.31 15.31 0 0 1 14.09-14 1 1 0 0 0 .91-1V6.41l9.59 9.59-9.59 9.59V21a1 1 0 0 0-1-1h-.54.04z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class GalleryIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GalleryIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: GalleryIconComponent, isStandalone: true, selector: "iui-gallery-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 4H6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 8H6V6h6v6zM26 4h-6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 8h-6V6h6v6zM12 18H6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2zm0 8H6v-6h6v6zM26 18h-6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2zm0 8h-6v-6h6v6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GalleryIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-gallery-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 4H6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 8H6V6h6v6zM26 4h-6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 8h-6V6h6v6zM12 18H6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2zm0 8H6v-6h6v6zM26 18h-6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2zm0 8h-6v-6h6v6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class GenderFemaleIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GenderFemaleIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: GenderFemaleIconComponent, isStandalone: true, selector: "iui-gender-female-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17 19.93a8 8 0 1 0-2 0V22h-5v2h5v4h2v-4h5v-2h-5v-2.07zM10 12a6 6 0 1 1 6 6 6.006 6.006 0 0 1-6-6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GenderFemaleIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-gender-female-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17 19.93a8 8 0 1 0-2 0V22h-5v2h5v4h2v-4h5v-2h-5v-2.07zM10 12a6 6 0 1 1 6 6 6.006 6.006 0 0 1-6-6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class GenderMaleIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GenderMaleIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: GenderMaleIconComponent, isStandalone: true, selector: "iui-gender-male-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 4v2h6.586l-7.688 7.688a8.028 8.028 0 1 0 1.414 1.414L26 7.414V14h2V4H18zm-6 22a6 6 0 1 1 6-6 6.007 6.007 0 0 1-6 6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GenderMaleIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-gender-male-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 4v2h6.586l-7.688 7.688a8.028 8.028 0 1 0 1.414 1.414L26 7.414V14h2V4H18zm-6 22a6 6 0 1 1 6-6 6.007 6.007 0 0 1-6 6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class GifIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GifIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: GifIconComponent, isStandalone: true, selector: "iui-gif-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M2 12v8a3 3 0 0 0 3 3h5v-8H6v2h2v4H5a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1h5V9H5a3 3 0 0 0-3 3zM30 11V9h-8v14h2v-6h5v-2h-5v-4h6zM12 9v2h3v10h-3v2h8v-2h-3V11h3V9h-8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GifIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-gif-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M2 12v8a3 3 0 0 0 3 3h5v-8H6v2h2v4H5a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1h5V9H5a3 3 0 0 0-3 3zM30 11V9h-8v14h2v-6h5v-2h-5v-4h6zM12 9v2h3v10h-3v2h8v-2h-3V11h3V9h-8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class GiftIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GiftIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: GiftIconComponent, isStandalone: true, selector: "iui-gift-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 10h-2.762A4.487 4.487 0 0 0 16 4.707 4.487 4.487 0 0 0 8.762 10H6a2.003 2.003 0 0 0-2 2v4a2.003 2.003 0 0 0 2 2v10a2.003 2.003 0 0 0 2 2h16a2.003 2.003 0 0 0 2-2V18a2.003 2.003 0 0 0 2-2v-4a2.003 2.003 0 0 0-2-2zm-9-2.5a2.5 2.5 0 1 1 2.5 2.5H17V7.5zM12.5 5A2.503 2.503 0 0 1 15 7.5V10h-2.5a2.5 2.5 0 0 1 0-5zM6 12h9v4H6v-4zm2 6h7v10H8V18zm16.001 10H17V18h7l.001 10zM17 16v-4h9l.001 4H17z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GiftIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-gift-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 10h-2.762A4.487 4.487 0 0 0 16 4.707 4.487 4.487 0 0 0 8.762 10H6a2.003 2.003 0 0 0-2 2v4a2.003 2.003 0 0 0 2 2v10a2.003 2.003 0 0 0 2 2h16a2.003 2.003 0 0 0 2-2V18a2.003 2.003 0 0 0 2-2v-4a2.003 2.003 0 0 0-2-2zm-9-2.5a2.5 2.5 0 1 1 2.5 2.5H17V7.5zM12.5 5A2.503 2.503 0 0 1 15 7.5V10h-2.5a2.5 2.5 0 0 1 0-5zM6 12h9v4H6v-4zm2 6h7v10H8V18zm16.001 10H17V18h7l.001 10zM17 16v-4h9l.001 4H17z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class GithubIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GithubIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: GithubIconComponent, isStandalone: true, selector: "iui-github-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.71 3.71 0 0 0-1.62-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.45 3 3 0 0 0 4.08 1.16 2.93 2.93 0 0 1 .88-1.87c-3.1-.36-6.37-1.56-6.37-6.92a5.4 5.4 0 0 1 1.44-3.76 5 5 0 0 1 .14-3.7s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.7 5.4 5.4 0 0 1 1.44 3.76c0 5.38-3.27 6.56-6.39 6.91a3.33 3.33 0 0 1 .95 2.59v3.84c0 .46.25.81 1 .67A14 14 0 0 0 16 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GithubIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-github-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.71 3.71 0 0 0-1.62-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.45 3 3 0 0 0 4.08 1.16 2.93 2.93 0 0 1 .88-1.87c-3.1-.36-6.37-1.56-6.37-6.92a5.4 5.4 0 0 1 1.44-3.76 5 5 0 0 1 .14-3.7s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.7 5.4 5.4 0 0 1 1.44 3.76c0 5.38-3.27 6.56-6.39 6.91a3.33 3.33 0 0 1 .95 2.59v3.84c0 .46.25.81 1 .67A14 14 0 0 0 16 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class GrowIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GrowIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: GrowIconComponent, isStandalone: true, selector: "iui-grow-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M20 8v2h6.586L18 18.586l-4.293-4.293a1 1 0 0 0-1.414 0L2 24.586 3.414 26 13 16.414l4.293 4.293a1 1 0 0 0 1.414 0L28 11.414V18h2V8H20z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GrowIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-grow-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M20 8v2h6.586L18 18.586l-4.293-4.293a1 1 0 0 0-1.414 0L2 24.586 3.414 26 13 16.414l4.293 4.293a1 1 0 0 0 1.414 0L28 11.414V18h2V8H20z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class HelpFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HelpFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: HelpFillIconComponent, isStandalone: true, selector: "iui-help-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 23a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm1.142-7.754v2.501h-2.25V15h2.125a2.376 2.376 0 0 0 0-4.753h-1.5a2.378 2.378 0 0 0-2.375 2.375v.638h-2.25v-.638A4.628 4.628 0 0 1 15.517 8h1.5a4.624 4.624 0 0 1 .125 9.246z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HelpFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-help-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 23a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm1.142-7.754v2.501h-2.25V15h2.125a2.376 2.376 0 0 0 0-4.753h-1.5a2.378 2.378 0 0 0-2.375 2.375v.638h-2.25v-.638A4.628 4.628 0 0 1 15.517 8h1.5a4.624 4.624 0 0 1 .125 9.246z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class HelpOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HelpOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: HelpOutlineIconComponent, isStandalone: true, selector: "iui-help-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M16 25a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM17 8h-1.5a4.49 4.49 0 0 0-4.5 4.5v.5h2v-.5a2.5 2.5 0 0 1 2.5-2.5H17a2.5 2.5 0 0 1 0 5h-2v4.5h2V17a4.5 4.5 0 1 0 0-9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HelpOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-help-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm0 26a12 12 0 1 1 0-24 12 12 0 0 1 0 24z" fill="currentColor"></path><path d="M16 25a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM17 8h-1.5a4.49 4.49 0 0 0-4.5 4.5v.5h2v-.5a2.5 2.5 0 0 1 2.5-2.5H17a2.5 2.5 0 0 1 0 5h-2v4.5h2V17a4.5 4.5 0 1 0 0-9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class HomeIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HomeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: HomeIconComponent, isStandalone: true, selector: "iui-home-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16.612 2.214a1.01 1.01 0 0 0-1.242 0L1 13.419l1.243 1.572L4 13.621V26a2.004 2.004 0 0 0 2 2h20a2.004 2.004 0 0 0 2-2V13.63L29.757 15 31 13.428 16.612 2.214zM18 26h-4v-8h4v8zm2 0v-8a2.002 2.002 0 0 0-2-2h-4a2.002 2.002 0 0 0-2 2v8H6V12.062l10-7.79 10 7.8V26h-6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HomeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-home-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16.612 2.214a1.01 1.01 0 0 0-1.242 0L1 13.419l1.243 1.572L4 13.621V26a2.004 2.004 0 0 0 2 2h20a2.004 2.004 0 0 0 2-2V13.63L29.757 15 31 13.428 16.612 2.214zM18 26h-4v-8h4v8zm2 0v-8a2.002 2.002 0 0 0-2-2h-4a2.002 2.002 0 0 0-2 2v8H6V12.062l10-7.79 10 7.8V26h-6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class HtmlIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HtmlIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: HtmlIconComponent, isStandalone: true, selector: "iui-html-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 19v-8h-2v10h6v-2h-4zM24 11h-2l-1.5 4-1.5-4h-2v10h2v-7l1.5 4 1.5-4v7h2V11zM9 13h2v8h2v-8h2v-2H9v2zM5 11v4H2v-4H0v10h2v-4h3v4h2V11H5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: HtmlIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-html-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 19v-8h-2v10h6v-2h-4zM24 11h-2l-1.5 4-1.5-4h-2v10h2v-7l1.5 4 1.5-4v7h2V11zM9 13h2v8h2v-8h2v-2H9v2zM5 11v4H2v-4H0v10h2v-4h3v4h2V11H5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class IteroScannerIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IteroScannerIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IteroScannerIconComponent, isStandalone: true, selector: "iui-itero-scanner-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27 5H5a2 2 0 0 0-2 2v6c-1 .5-1 1.5-1 1.5V23a2 2 0 0 0 2 2h12v2h-4v2h8v-2h-4v-2h12a2 2 0 0 0 2-2v-8.5s0-1-1-1.5V7a2 2 0 0 0-2-2zm0 17H5V7h22v15z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IteroScannerIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-itero-scanner-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27 5H5a2 2 0 0 0-2 2v6c-1 .5-1 1.5-1 1.5V23a2 2 0 0 0 2 2h12v2h-4v2h8v-2h-4v-2h12a2 2 0 0 0 2-2v-8.5s0-1-1-1.5V7a2 2 0 0 0-2-2zm0 17H5V7h22v15z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class IdentificationIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IdentificationIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IdentificationIconComponent, isStandalone: true, selector: "iui-identification-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 6v20H4V6h24zm0-2H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z" fill="currentColor"></path><path d="M13 10H6v2h7v-2zM10 14H6v2h4v-2zM23 18h-6a3 3 0 0 0-3 3v2h2v-2a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2h2v-2a3 3 0 0 0-3-3zM20 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0-6a2 2 0 1 1 0 4 2 2 0 0 1 0-4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IdentificationIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-identification-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 6v20H4V6h24zm0-2H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z" fill="currentColor"></path><path d="M13 10H6v2h7v-2zM10 14H6v2h4v-2zM23 18h-6a3 3 0 0 0-3 3v2h2v-2a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2h2v-2a3 3 0 0 0-3-3zM20 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0-6a2 2 0 1 1 0 4 2 2 0 0 1 0-4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ImageDrawIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ImageDrawIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ImageDrawIconComponent, isStandalone: true, selector: "iui-image-draw-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 24v-6.003L9 13l5.586 5.586L16 17.168l-5.586-5.585a2 2 0 0 0-2.828 0L4 15.168V4h20v10h2V4a2.002 2.002 0 0 0-2-2H4a2.002 2.002 0 0 0-2 2v20a2.002 2.002 0 0 0 2 2h10v-2H4z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="m29.707 19.293-3-3a.998.998 0 0 0-1.414 0L16 25.586V30h4.414l9.293-9.293a1 1 0 0 0 0-1.414zM19.586 28H18v-1.586l5-5L24.586 23l-5 5zM26 21.586 24.414 20 26 18.414 27.586 20 26 21.586zM18.667 11.494a3 3 0 1 1-3.333-4.987 3 3 0 0 1 3.333 4.987zM17.556 8.17a1 1 0 1 0-1.112 1.663 1 1 0 0 0 1.112-1.663z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ImageDrawIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-image-draw-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 24v-6.003L9 13l5.586 5.586L16 17.168l-5.586-5.585a2 2 0 0 0-2.828 0L4 15.168V4h20v10h2V4a2.002 2.002 0 0 0-2-2H4a2.002 2.002 0 0 0-2 2v20a2.002 2.002 0 0 0 2 2h10v-2H4z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="m29.707 19.293-3-3a.998.998 0 0 0-1.414 0L16 25.586V30h4.414l9.293-9.293a1 1 0 0 0 0-1.414zM19.586 28H18v-1.586l5-5L24.586 23l-5 5zM26 21.586 24.414 20 26 18.414 27.586 20 26 21.586zM18.667 11.494a3 3 0 1 1-3.333-4.987 3 3 0 0 1 3.333 4.987zM17.556 8.17a1 1 0 1 0-1.112 1.663 1 1 0 0 0 1.112-1.663z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ImageIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ImageIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ImageIconComponent, isStandalone: true, selector: "iui-image-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 4H6a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 22H6v-6l5-5 5.59 5.59a2 2 0 0 0 2.82 0L21 19l5 5v2zm0-4.83-3.59-3.59a2 2 0 0 0-2.82 0L18 19.17l-5.59-5.59a2 2 0 0 0-2.82 0L6 17.17V6h20v15.17z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M19 12a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 2a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ImageIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-image-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 4H6a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 22H6v-6l5-5 5.59 5.59a2 2 0 0 0 2.82 0L21 19l5 5v2zm0-4.83-3.59-3.59a2 2 0 0 0-2.82 0L18 19.17l-5.59-5.59a2 2 0 0 0-2.82 0L6 17.17V6h20v15.17z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M19 12a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 2a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class InProgressIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: InProgressIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: InProgressIconComponent, isStandalone: true, selector: "iui-in-progress-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 14 14A14.016 14.016 0 0 0 16 2zm0 26a12 12 0 0 1 0-24v12l8.481 8.481A11.962 11.962 0 0 1 16 28z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: InProgressIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-in-progress-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 14 14A14.016 14.016 0 0 0 16 2zm0 26a12 12 0 0 1 0-24v12l8.481 8.481A11.962 11.962 0 0 1 16 28z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class IncompleteIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IncompleteIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IncompleteIconComponent, isStandalone: true, selector: "iui-incomplete-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m23.764 6.86 1.285-1.532a13.976 13.976 0 0 0-4.182-2.441l-.683 1.878a11.974 11.974 0 0 1 3.58 2.094zM27.81 14l1.968-.413a13.89 13.89 0 0 0-1.638-4.541L26.409 10a12.521 12.521 0 0 1 1.401 4zM20.184 27.235l.683 1.878a13.978 13.978 0 0 0 4.182-2.44l-1.285-1.532a11.973 11.973 0 0 1-3.58 2.094zM26.409 22l1.731 1a14.14 14.14 0 0 0 1.638-4.587l-1.968-.347A12.153 12.153 0 0 1 26.409 22zM16 30V2a14 14 0 0 0 0 28z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IncompleteIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-incomplete-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m23.764 6.86 1.285-1.532a13.976 13.976 0 0 0-4.182-2.441l-.683 1.878a11.974 11.974 0 0 1 3.58 2.094zM27.81 14l1.968-.413a13.89 13.89 0 0 0-1.638-4.541L26.409 10a12.521 12.521 0 0 1 1.401 4zM20.184 27.235l.683 1.878a13.978 13.978 0 0 0 4.182-2.44l-1.285-1.532a11.973 11.973 0 0 1-3.58 2.094zM26.409 22l1.731 1a14.14 14.14 0 0 0 1.638-4.587l-1.968-.347A12.153 12.153 0 0 1 26.409 22zM16 30V2a14 14 0 0 0 0 28z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class InformationIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: InformationIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: InformationIconComponent, isStandalone: true, selector: "iui-information-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 4H6a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM16 8a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zm4 16.125h-8v-2.25h2.875v-5.75H13v-2.25h4.125v8H20v2.25z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: InformationIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-information-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 4H6a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM16 8a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zm4 16.125h-8v-2.25h2.875v-5.75H13v-2.25h4.125v8H20v2.25z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class InstagramIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: InstagramIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: InstagramIconComponent, isStandalone: true, selector: "iui-instagram-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22.406 11.034a1.44 1.44 0 1 0 0-2.88 1.44 1.44 0 0 0 0 2.88zM16 9.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM16 20a4 4 0 1 1 0-8 4 4 0 0 1 0 8z" fill="currentColor"></path><path d="M16 6.162c3.204 0 3.584.012 4.849.07.761.01 1.515.149 2.228.413a3.975 3.975 0 0 1 2.278 2.278c.264.713.404 1.467.413 2.228.058 1.265.07 1.645.07 4.85 0 3.203-.012 3.583-.07 4.848a6.642 6.642 0 0 1-.413 2.228 3.975 3.975 0 0 1-2.278 2.278 6.642 6.642 0 0 1-2.228.413c-1.265.058-1.645.07-4.849.07s-3.584-.012-4.849-.07a6.642 6.642 0 0 1-2.228-.413 3.975 3.975 0 0 1-2.278-2.278 6.642 6.642 0 0 1-.413-2.228c-.058-1.265-.07-1.645-.07-4.849s.012-3.584.07-4.849c.01-.76.149-1.515.413-2.228a3.975 3.975 0 0 1 2.278-2.278 6.642 6.642 0 0 1 2.228-.413c1.265-.058 1.645-.07 4.849-.07zM16 4c-3.259 0-3.668.014-4.948.072-.995.02-1.98.209-2.912.558a6.136 6.136 0 0 0-3.51 3.51 8.807 8.807 0 0 0-.558 2.913C4.014 12.333 4 12.74 4 16c0 3.259.014 3.668.072 4.948.02.995.209 1.98.558 2.912a6.137 6.137 0 0 0 3.51 3.51c.932.35 1.917.538 2.913.558 1.28.058 1.688.072 4.947.072 3.259 0 3.668-.014 4.948-.072a8.806 8.806 0 0 0 2.912-.558 6.137 6.137 0 0 0 3.51-3.51c.35-.933.538-1.917.558-2.913.058-1.28.072-1.688.072-4.947 0-3.259-.014-3.668-.072-4.948a8.808 8.808 0 0 0-.558-2.912 6.137 6.137 0 0 0-3.51-3.51 8.808 8.808 0 0 0-2.913-.557C19.667 4.013 19.26 4 16 4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: InstagramIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-instagram-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22.406 11.034a1.44 1.44 0 1 0 0-2.88 1.44 1.44 0 0 0 0 2.88zM16 9.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM16 20a4 4 0 1 1 0-8 4 4 0 0 1 0 8z" fill="currentColor"></path><path d="M16 6.162c3.204 0 3.584.012 4.849.07.761.01 1.515.149 2.228.413a3.975 3.975 0 0 1 2.278 2.278c.264.713.404 1.467.413 2.228.058 1.265.07 1.645.07 4.85 0 3.203-.012 3.583-.07 4.848a6.642 6.642 0 0 1-.413 2.228 3.975 3.975 0 0 1-2.278 2.278 6.642 6.642 0 0 1-2.228.413c-1.265.058-1.645.07-4.849.07s-3.584-.012-4.849-.07a6.642 6.642 0 0 1-2.228-.413 3.975 3.975 0 0 1-2.278-2.278 6.642 6.642 0 0 1-.413-2.228c-.058-1.265-.07-1.645-.07-4.849s.012-3.584.07-4.849c.01-.76.149-1.515.413-2.228a3.975 3.975 0 0 1 2.278-2.278 6.642 6.642 0 0 1 2.228-.413c1.265-.058 1.645-.07 4.849-.07zM16 4c-3.259 0-3.668.014-4.948.072-.995.02-1.98.209-2.912.558a6.136 6.136 0 0 0-3.51 3.51 8.807 8.807 0 0 0-.558 2.913C4.014 12.333 4 12.74 4 16c0 3.259.014 3.668.072 4.948.02.995.209 1.98.558 2.912a6.137 6.137 0 0 0 3.51 3.51c.932.35 1.917.538 2.913.558 1.28.058 1.688.072 4.947.072 3.259 0 3.668-.014 4.948-.072a8.806 8.806 0 0 0 2.912-.558 6.137 6.137 0 0 0 3.51-3.51c.35-.933.538-1.917.558-2.913.058-1.28.072-1.688.072-4.947 0-3.259-.014-3.668-.072-4.948a8.808 8.808 0 0 0-.558-2.912 6.137 6.137 0 0 0-3.51-3.51 8.808 8.808 0 0 0-2.913-.557C19.667 4.013 19.26 4 16 4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class IsoIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IsoIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IsoIconComponent, isStandalone: true, selector: "iui-iso-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 23h-4a2 2 0 0 1-2-2V11a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2zm-4-12v10h4V11h-4zM18 23h-6v-2h6v-4h-4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h6v2h-6v4h4a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2zM2 11h3v10H2v2h8v-2H7V11h3V9H2v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IsoIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-iso-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 23h-4a2 2 0 0 1-2-2V11a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2zm-4-12v10h4V11h-4zM18 23h-6v-2h6v-4h-4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h6v2h-6v4h4a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2zM2 11h3v10H2v2h8v-2H7V11h3V9H2v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class JpgIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: JpgIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: JpgIconComponent, isStandalone: true, selector: "iui-jpg-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 23h-6a2 2 0 0 1-2-2V11a2 2 0 0 1 2-2h6v2h-6v10h4v-4h-2v-2h4v8zM14 23h-2V9h6a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-4v5zm0-7h4v-5h-4v5zM8 23H4a2 2 0 0 1-2-2v-2h2v2h4V9h2v12a2 2 0 0 1-2 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: JpgIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-jpg-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 23h-6a2 2 0 0 1-2-2V11a2 2 0 0 1 2-2h6v2h-6v10h4v-4h-2v-2h4v8zM14 23h-2V9h6a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-4v5zm0-7h4v-5h-4v5zM8 23H4a2 2 0 0 1-2-2v-2h2v2h4V9h2v12a2 2 0 0 1-2 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class JsonIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: JsonIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: JsonIconComponent, isStandalone: true, selector: "iui-json-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M31 11v10h-2l-2-6v6h-2V11h2l2 6v-6h2zM21.334 21h-2.668A1.668 1.668 0 0 1 17 19.334v-6.668A1.668 1.668 0 0 1 18.666 11h2.668A1.668 1.668 0 0 1 23 12.666v6.668A1.668 1.668 0 0 1 21.334 21zM19 19h2v-6h-2v6zM13.334 21H9v-2h4v-2h-2a2.002 2.002 0 0 1-2-2v-2.334A1.668 1.668 0 0 1 10.666 11H15v2h-4v2h2a2.002 2.002 0 0 1 2 2v2.334A1.668 1.668 0 0 1 13.334 21zM5.333 21H2.667A1.668 1.668 0 0 1 1 19.334V17h2v2h2v-8h2v8.334A1.668 1.668 0 0 1 5.333 21z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: JsonIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-json-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M31 11v10h-2l-2-6v6h-2V11h2l2 6v-6h2zM21.334 21h-2.668A1.668 1.668 0 0 1 17 19.334v-6.668A1.668 1.668 0 0 1 18.666 11h2.668A1.668 1.668 0 0 1 23 12.666v6.668A1.668 1.668 0 0 1 21.334 21zM19 19h2v-6h-2v6zM13.334 21H9v-2h4v-2h-2a2.002 2.002 0 0 1-2-2v-2.334A1.668 1.668 0 0 1 10.666 11H15v2h-4v2h2a2.002 2.002 0 0 1 2 2v2.334A1.668 1.668 0 0 1 13.334 21zM5.333 21H2.667A1.668 1.668 0 0 1 1 19.334V17h2v2h2v-8h2v8.334A1.668 1.668 0 0 1 5.333 21z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class LanguageIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LanguageIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: LanguageIconComponent, isStandalone: true, selector: "iui-language-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm12 13h-6a24.26 24.26 0 0 0-2.79-10.55A12 12 0 0 1 28 15zM16 28a4.993 4.993 0 0 1-.67 0A21.85 21.85 0 0 1 12 17h8a21.85 21.85 0 0 1-3.3 11 4.986 4.986 0 0 1-.7 0zm-4-13a21.85 21.85 0 0 1 3.3-11 6 6 0 0 1 1.34 0A21.85 21.85 0 0 1 20 15h-8zm.76-10.55A24.26 24.26 0 0 0 10 15H4a12 12 0 0 1 8.79-10.55h-.03zM4.05 17h6a24.26 24.26 0 0 0 2.75 10.55A12 12 0 0 1 4.05 17zm15.16 10.55A24.26 24.26 0 0 0 22 17h6a12 12 0 0 1-8.79 10.55z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LanguageIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-language-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28zm12 13h-6a24.26 24.26 0 0 0-2.79-10.55A12 12 0 0 1 28 15zM16 28a4.993 4.993 0 0 1-.67 0A21.85 21.85 0 0 1 12 17h8a21.85 21.85 0 0 1-3.3 11 4.986 4.986 0 0 1-.7 0zm-4-13a21.85 21.85 0 0 1 3.3-11 6 6 0 0 1 1.34 0A21.85 21.85 0 0 1 20 15h-8zm.76-10.55A24.26 24.26 0 0 0 10 15H4a12 12 0 0 1 8.79-10.55h-.03zM4.05 17h6a24.26 24.26 0 0 0 2.75 10.55A12 12 0 0 1 4.05 17zm15.16 10.55A24.26 24.26 0 0 0 22 17h6a12 12 0 0 1-8.79 10.55z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class LaptopIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LaptopIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: LaptopIconComponent, isStandalone: true, selector: "iui-laptop-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 24.005H6a2.002 2.002 0 0 1-2-2v-14a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v14a2.003 2.003 0 0 1-2 2zm-20-16v14h20v-14H6zM30 26.005H2v2h28v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LaptopIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-laptop-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 24.005H6a2.002 2.002 0 0 1-2-2v-14a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v14a2.003 2.003 0 0 1-2 2zm-20-16v14h20v-14H6zM30 26.005H2v2h28v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class LightFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LightFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: LightFillIconComponent, isStandalone: true, selector: "iui-light-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17 2h-2v5h2V2zM25.192 5.394l-3.505 3.505 1.414 1.415 3.506-3.506-1.415-1.414zM30 15h-5v2h5v-2zM23.1 21.686l-1.413 1.415 3.505 3.506 1.415-1.415-3.506-3.506zM17 25h-2v5h2v-5zM8.9 21.686l-3.506 3.506 1.414 1.414 3.505-3.505L8.9 21.686zM7 15H2v2h5v-2zM6.808 5.394 5.394 6.808l3.505 3.505L10.314 8.9 6.807 5.394zM16 10a6 6 0 1 0 0 12 6 6 0 0 0 0-12z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LightFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-light-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17 2h-2v5h2V2zM25.192 5.394l-3.505 3.505 1.414 1.415 3.506-3.506-1.415-1.414zM30 15h-5v2h5v-2zM23.1 21.686l-1.413 1.415 3.505 3.506 1.415-1.415-3.506-3.506zM17 25h-2v5h2v-5zM8.9 21.686l-3.506 3.506 1.414 1.414 3.505-3.505L8.9 21.686zM7 15H2v2h5v-2zM6.808 5.394 5.394 6.808l3.505 3.505L10.314 8.9 6.807 5.394zM16 10a6 6 0 1 0 0 12 6 6 0 0 0 0-12z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class LightIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LightIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: LightIconComponent, isStandalone: true, selector: "iui-light-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17 2h-2v5h2V2zM25.192 5.394l-3.505 3.505 1.414 1.415 3.506-3.506-1.415-1.414zM30 15h-5v2h5v-2zM23.1 21.686l-1.413 1.415 3.505 3.506 1.415-1.415-3.506-3.506zM17 25h-2v5h2v-5zM8.9 21.686l-3.506 3.506 1.414 1.414 3.505-3.505L8.9 21.686zM7 15H2v2h5v-2zM6.808 5.394 5.394 6.808l3.505 3.505L10.314 8.9 6.807 5.394zM16 12a4 4 0 1 1 0 8 4 4 0 0 1 0-8zm0-2a6 6 0 1 0 0 12 6 6 0 0 0 0-12z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LightIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-light-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17 2h-2v5h2V2zM25.192 5.394l-3.505 3.505 1.414 1.415 3.506-3.506-1.415-1.414zM30 15h-5v2h5v-2zM23.1 21.686l-1.413 1.415 3.505 3.506 1.415-1.415-3.506-3.506zM17 25h-2v5h2v-5zM8.9 21.686l-3.506 3.506 1.414 1.414 3.505-3.505L8.9 21.686zM7 15H2v2h5v-2zM6.808 5.394 5.394 6.808l3.505 3.505L10.314 8.9 6.807 5.394zM16 12a4 4 0 1 1 0 8 4 4 0 0 1 0-8zm0-2a6 6 0 1 0 0 12 6 6 0 0 0 0-12z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class LinkIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LinkIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: LinkIconComponent, isStandalone: true, selector: "iui-link-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29.25 6.76a6 6 0 0 0-8.5 0l1.42 1.42a4.009 4.009 0 1 1 5.67 5.67l-8 8a4.006 4.006 0 0 1-5.67-5.66l1.41-1.42-1.41-1.42-1.42 1.42a5.999 5.999 0 0 0 0 8.5A6 6 0 0 0 17 25a5.999 5.999 0 0 0 4.27-1.76l8-8a6 6 0 0 0-.02-8.48z" fill="currentColor"></path><path d="M4.19 24.82a4 4 0 0 1 0-5.67l8-8a4 4 0 0 1 5.67 0A3.94 3.94 0 0 1 19 14a4.002 4.002 0 0 1-1.17 2.85L15.71 19l1.42 1.42 2.12-2.12a6.017 6.017 0 0 0-8.51-8.51l-8 8a6 6 0 0 0 0 8.51A6 6 0 0 0 7 28a6.07 6.07 0 0 0 4.28-1.76l-1.42-1.42a4 4 0 0 1-5.67 0z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LinkIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-link-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29.25 6.76a6 6 0 0 0-8.5 0l1.42 1.42a4.009 4.009 0 1 1 5.67 5.67l-8 8a4.006 4.006 0 0 1-5.67-5.66l1.41-1.42-1.41-1.42-1.42 1.42a5.999 5.999 0 0 0 0 8.5A6 6 0 0 0 17 25a5.999 5.999 0 0 0 4.27-1.76l8-8a6 6 0 0 0-.02-8.48z" fill="currentColor"></path><path d="M4.19 24.82a4 4 0 0 1 0-5.67l8-8a4 4 0 0 1 5.67 0A3.94 3.94 0 0 1 19 14a4.002 4.002 0 0 1-1.17 2.85L15.71 19l1.42 1.42 2.12-2.12a6.017 6.017 0 0 0-8.51-8.51l-8 8a6 6 0 0 0 0 8.51A6 6 0 0 0 7 28a6.07 6.07 0 0 0 4.28-1.76l-1.42-1.42a4 4 0 0 1-5.67 0z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class LinkedinIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LinkedinIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: LinkedinIconComponent, isStandalone: true, selector: "iui-linkedin-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)"><path d="M26.2 4H5.8C4.8 4 4 4.8 4 5.7v20.5c0 .9.8 1.7 1.8 1.7h20.4c1 0 1.8-.8 1.8-1.7V5.7c0-.9-.8-1.7-1.8-1.7zM11.1 24.4H7.6V13h3.5v11.4zm-1.7-13c-1.1 0-2.1-.9-2.1-2.1 0-1.2.9-2.1 2.1-2.1 1.1 0 2.1.9 2.1 2.1 0 1.2-1 2.1-2.1 2.1zm15.1 12.9H21v-5.6c0-1.3 0-3.1-1.9-3.1S17 17.1 17 18.5v5.7h-3.5V13h3.3v1.5h.1c.5-.9 1.7-1.9 3.4-1.9 3.6 0 4.3 2.4 4.3 5.5v6.2h-.1z" fill="currentColor"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LinkedinIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-linkedin-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)"><path d="M26.2 4H5.8C4.8 4 4 4.8 4 5.7v20.5c0 .9.8 1.7 1.8 1.7h20.4c1 0 1.8-.8 1.8-1.7V5.7c0-.9-.8-1.7-1.8-1.7zM11.1 24.4H7.6V13h3.5v11.4zm-1.7-13c-1.1 0-2.1-.9-2.1-2.1 0-1.2.9-2.1 2.1-2.1 1.1 0 2.1.9 2.1 2.1 0 1.2-1 2.1-2.1 2.1zm15.1 12.9H21v-5.6c0-1.3 0-3.1-1.9-3.1S17 17.1 17 18.5v5.7h-3.5V13h3.3v1.5h.1c.5-.9 1.7-1.9 3.4-1.9 3.6 0 4.3 2.4 4.3 5.5v6.2h-.1z" fill="currentColor"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ListIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ListIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ListIconComponent, isStandalone: true, selector: "iui-list-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 6H10v2h18V6zM28 24H10v2h18v-2zM28 15H10v2h18v-2zM6 15H4v2h2v-2zM6 6H4v2h2V6zM6 24H4v2h2v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ListIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-list-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 6H10v2h18V6zM28 24H10v2h18v-2zM28 15H10v2h18v-2zM6 15H4v2h2v-2zM6 6H4v2h2V6zM6 24H4v2h2v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class LocationStarFilledIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LocationStarFilledIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: LocationStarFilledIconComponent, isStandalone: true, selector: "iui-location-star-filled-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2A11.013 11.013 0 0 0 5 13a10.889 10.889 0 0 0 2.216 6.6s.3.394.349.452L16 30l8.439-9.953c.044-.053.345-.447.345-.447l.001-.003A10.884 10.884 0 0 0 27 13 11.013 11.013 0 0 0 16 2zm3.6 16L16 15.708 12.4 18l.6-4.074-3-2.753 4.2-.506L16 7l1.912 3.667 4.088.506-3 2.753.6 4.074z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LocationStarFilledIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-location-star-filled-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2A11.013 11.013 0 0 0 5 13a10.889 10.889 0 0 0 2.216 6.6s.3.394.349.452L16 30l8.439-9.953c.044-.053.345-.447.345-.447l.001-.003A10.884 10.884 0 0 0 27 13 11.013 11.013 0 0 0 16 2zm3.6 16L16 15.708 12.4 18l.6-4.074-3-2.753 4.2-.506L16 7l1.912 3.667 4.088.506-3 2.753.6 4.074z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class LocationStarOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LocationStarOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: LocationStarOutlineIconComponent, isStandalone: true, selector: "iui-location-star-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m16 7 1.912 3.667 4.088.506-3 2.753.6 4.074-3.6-2.292L12.4 18l.6-4.074-3-2.753 4.2-.506L16 7z" fill="currentColor"></path><path d="m16 30-8.435-9.949a35.076 35.076 0 0 1-.349-.451A10.889 10.889 0 0 1 5 13a11 11 0 1 1 22 0c.004 2.382-.774 4.7-2.215 6.597l-.001.003s-.3.394-.345.447L16 30zM8.813 18.395s.233.308.286.374L16 26.908l6.91-8.15c.044-.055.278-.365.279-.366A8.9 8.9 0 0 0 25 13a9 9 0 0 0-18 0 8.905 8.905 0 0 0 1.813 5.395z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LocationStarOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-location-star-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m16 7 1.912 3.667 4.088.506-3 2.753.6 4.074-3.6-2.292L12.4 18l.6-4.074-3-2.753 4.2-.506L16 7z" fill="currentColor"></path><path d="m16 30-8.435-9.949a35.076 35.076 0 0 1-.349-.451A10.889 10.889 0 0 1 5 13a11 11 0 1 1 22 0c.004 2.382-.774 4.7-2.215 6.597l-.001.003s-.3.394-.345.447L16 30zM8.813 18.395s.233.308.286.374L16 26.908l6.91-8.15c.044-.055.278-.365.279-.366A8.9 8.9 0 0 0 25 13a9 9 0 0 0-18 0 8.905 8.905 0 0 0 1.813 5.395z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class LockedIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LockedIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: LockedIconComponent, isStandalone: true, selector: "iui-locked-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 14h-2V8a6 6 0 1 0-12 0v6H8a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V16a2 2 0 0 0-2-2zM12 8a4 4 0 1 1 8 0v6h-8V8zm12 20H8V16h16v12z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LockedIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-locked-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 14h-2V8a6 6 0 1 0-12 0v6H8a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V16a2 2 0 0 0-2-2zM12 8a4 4 0 1 1 8 0v6h-8V8zm12 20H8V16h16v12z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class LoginIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LoginIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: LoginIconComponent, isStandalone: true, selector: "iui-login-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H14a2 2 0 0 1-2-2v-3h2v3h12V4H14v3h-2V4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v24a2 2 0 0 1-2 2z" fill="currentColor"></path><path d="M14.59 20.59 18.17 17H4v-2h14.17l-3.58-3.59L16 10l6 6-6 6-1.41-1.41z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LoginIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-login-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 30H14a2 2 0 0 1-2-2v-3h2v3h12V4H14v3h-2V4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v24a2 2 0 0 1-2 2z" fill="currentColor"></path><path d="M14.59 20.59 18.17 17H4v-2h14.17l-3.58-3.59L16 10l6 6-6 6-1.41-1.41z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class LogoutIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LogoutIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: LogoutIconComponent, isStandalone: true, selector: "iui-logout-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M6 30h12a2.002 2.002 0 0 0 2-2v-3h-2v3H6V4h12v3h2V4a2.002 2.002 0 0 0-2-2H6a2.002 2.002 0 0 0-2 2v24a2.002 2.002 0 0 0 2 2z" fill="currentColor"></path><path d="M20.586 20.586 24.172 17H10v-2h14.172l-3.586-3.586L22 10l6 6-6 6-1.414-1.414z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LogoutIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-logout-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M6 30h12a2.002 2.002 0 0 0 2-2v-3h-2v3H6V4h12v3h2V4a2.002 2.002 0 0 0-2-2H6a2.002 2.002 0 0 0-2 2v24a2.002 2.002 0 0 0 2 2z" fill="currentColor"></path><path d="M20.586 20.586 24.172 17H10v-2h14.172l-3.586-3.586L22 10l6 6-6 6-1.414-1.414z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MaximizeIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MaximizeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MaximizeIconComponent, isStandalone: true, selector: "iui-maximize-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M20 2v2h6.586L18 12.582 19.414 14 28 5.414V12h2V2H20zM14 19.416 12.592 18 4 26.586V20H2v10h10v-2H5.414L14 19.416z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MaximizeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-maximize-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M20 2v2h6.586L18 12.582 19.414 14 28 5.414V12h2V2H20zM14 19.416 12.592 18 4 26.586V20H2v10h10v-2H5.414L14 19.416z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MediumIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MediumIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MediumIconComponent, isStandalone: true, selector: "iui-medium-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 4v24h24V4H4zm19.939 5.687L22.65 10.92a.377.377 0 0 0-.143.361v9.068a.376.376 0 0 0 .143.361l1.257 1.234v.27h-6.323v-.27l1.303-1.264c.128-.128.128-.166.128-.36v-7.33l-3.62 9.196h-.49l-4.215-9.196v6.163a.851.851 0 0 0 .233.707l1.694 2.055v.27H7.815v-.27L9.51 19.86a.82.82 0 0 0 .218-.707v-7.127a.623.623 0 0 0-.203-.526L8.019 9.687v-.271h4.674l3.613 7.923 3.176-7.923h4.457v.27z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MediumIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-medium-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 4v24h24V4H4zm19.939 5.687L22.65 10.92a.377.377 0 0 0-.143.361v9.068a.376.376 0 0 0 .143.361l1.257 1.234v.27h-6.323v-.27l1.303-1.264c.128-.128.128-.166.128-.36v-7.33l-3.62 9.196h-.49l-4.215-9.196v6.163a.851.851 0 0 0 .233.707l1.694 2.055v.27H7.815v-.27L9.51 19.86a.82.82 0 0 0 .218-.707v-7.127a.623.623 0 0 0-.203-.526L8.019 9.687v-.271h4.674l3.613 7.923 3.176-7.923h4.457v.27z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MenuIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MenuIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MenuIconComponent, isStandalone: true, selector: "iui-menu-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 15H4v2h24v-2zM28 21H4v2h24v-2zM28 9H4v2h24V9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MenuIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-menu-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 15H4v2h24v-2zM28 21H4v2h24v-2zM28 9H4v2h24V9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MicrophoneFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MicrophoneFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MicrophoneFillIconComponent, isStandalone: true, selector: "iui-microphone-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 14v3a7 7 0 1 1-14 0v-3H7v3a9 9 0 0 0 8 8.94V28h-4v2h10v-2h-4v-2.06A9 9 0 0 0 25 17v-3h-2z" fill="currentColor"></path><path d="M16 22a5 5 0 0 0 5-5V7a5 5 0 0 0-10 0v10a5 5 0 0 0 5 5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MicrophoneFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-microphone-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 14v3a7 7 0 1 1-14 0v-3H7v3a9 9 0 0 0 8 8.94V28h-4v2h10v-2h-4v-2.06A9 9 0 0 0 25 17v-3h-2z" fill="currentColor"></path><path d="M16 22a5 5 0 0 0 5-5V7a5 5 0 0 0-10 0v10a5 5 0 0 0 5 5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MicrophoneOffFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MicrophoneOffFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MicrophoneOffFillIconComponent, isStandalone: true, selector: "iui-microphone-off-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 17a7 7 0 0 1-11.73 5.14l1.42-1.41A5 5 0 0 0 21 17v-4.58l9-9L28.59 2 2 28.59 3.41 30l6.44-6.44A8.91 8.91 0 0 0 15 25.94V28h-4v2h10v-2h-4v-2.06A9 9 0 0 0 25 17v-3h-2v3zM9 17.32V14H7v3a9 9 0 0 0 .25 2.09L9 17.32zM20.76 5.58A5 5 0 0 0 11 7v8.34l9.76-9.76z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MicrophoneOffFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-microphone-off-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 17a7 7 0 0 1-11.73 5.14l1.42-1.41A5 5 0 0 0 21 17v-4.58l9-9L28.59 2 2 28.59 3.41 30l6.44-6.44A8.91 8.91 0 0 0 15 25.94V28h-4v2h10v-2h-4v-2.06A9 9 0 0 0 25 17v-3h-2v3zM9 17.32V14H7v3a9 9 0 0 0 .25 2.09L9 17.32zM20.76 5.58A5 5 0 0 0 11 7v8.34l9.76-9.76z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MicrophoneOffOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MicrophoneOffOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MicrophoneOffOutlineIconComponent, isStandalone: true, selector: "iui-microphone-off-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M9.18 18.57A7.41 7.41 0 0 1 9 17v-3H7v3a8.84 8.84 0 0 0 .58 3.18l1.6-1.61zM13 15V7a3 3 0 0 1 6 0v1.75l2-2A5.001 5.001 0 0 0 11 7v8h2zM23 17a7 7 0 0 1-11.73 5.14l1.42-1.41A5 5 0 0 0 21 17v-4.58l9-9L28.59 2 2 28.59 3.41 30l6.44-6.44A8.91 8.91 0 0 0 15 25.94V28h-4v2h10v-2h-4v-2.06A9 9 0 0 0 25 17v-3h-2v3zm-4 0a3 3 0 0 1-4.9 2.31l4.9-4.89V17z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MicrophoneOffOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-microphone-off-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M9.18 18.57A7.41 7.41 0 0 1 9 17v-3H7v3a8.84 8.84 0 0 0 .58 3.18l1.6-1.61zM13 15V7a3 3 0 0 1 6 0v1.75l2-2A5.001 5.001 0 0 0 11 7v8h2zM23 17a7 7 0 0 1-11.73 5.14l1.42-1.41A5 5 0 0 0 21 17v-4.58l9-9L28.59 2 2 28.59 3.41 30l6.44-6.44A8.91 8.91 0 0 0 15 25.94V28h-4v2h10v-2h-4v-2.06A9 9 0 0 0 25 17v-3h-2v3zm-4 0a3 3 0 0 1-4.9 2.31l4.9-4.89V17z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MicrophoneOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MicrophoneOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MicrophoneOutlineIconComponent, isStandalone: true, selector: "iui-microphone-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 14v3a7 7 0 1 1-14 0v-3H7v3a9 9 0 0 0 8 8.94V28h-4v2h10v-2h-4v-2.06A9 9 0 0 0 25 17v-3h-2z" fill="currentColor"></path><path d="M16 22a5 5 0 0 0 5-5V7a5 5 0 0 0-10 0v10a5 5 0 0 0 5 5zM13 7a3 3 0 0 1 6 0v10a3 3 0 0 1-6 0V7z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MicrophoneOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-microphone-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 14v3a7 7 0 1 1-14 0v-3H7v3a9 9 0 0 0 8 8.94V28h-4v2h10v-2h-4v-2.06A9 9 0 0 0 25 17v-3h-2z" fill="currentColor"></path><path d="M16 22a5 5 0 0 0 5-5V7a5 5 0 0 0-10 0v10a5 5 0 0 0 5 5zM13 7a3 3 0 0 1 6 0v10a3 3 0 0 1-6 0V7z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MinimizeIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MinimizeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MinimizeIconComponent, isStandalone: true, selector: "iui-minimize-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 18v2h6.586L2 28.582 3.414 30 12 21.414V28h2V18H4zM30 3.416 28.592 2 20 10.586V4h-2v10h10v-2h-6.586L30 3.416z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MinimizeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-minimize-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 18v2h6.586L2 28.582 3.414 30 12 21.414V28h2V18H4zM30 3.416 28.592 2 20 10.586V4h-2v10h10v-2h-6.586L30 3.416z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MobileLandscapeIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MobileLandscapeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MobileLandscapeIconComponent, isStandalone: true, selector: "iui-mobile-landscape-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M3 10v12a2.002 2.002 0 0 0 2 2h22a2.002 2.002 0 0 0 2-2V10a2.003 2.003 0 0 0-2-2H5a2.002 2.002 0 0 0-2 2zm2 0h2v12H5V10zm22 12H9V10h18v12z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MobileLandscapeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-mobile-landscape-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M3 10v12a2.002 2.002 0 0 0 2 2h22a2.002 2.002 0 0 0 2-2V10a2.003 2.003 0 0 0-2-2H5a2.002 2.002 0 0 0-2 2zm2 0h2v12H5V10zm22 12H9V10h18v12z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MobilePortraitIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MobilePortraitIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MobilePortraitIconComponent, isStandalone: true, selector: "iui-mobile-portrait-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 4H10a2.002 2.002 0 0 0-2 2v22a2.002 2.002 0 0 0 2 2h12a2.003 2.003 0 0 0 2-2V6a2.002 2.002 0 0 0-2-2zm0 2v2H10V6h12zM10 28V10h12v18H10z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MobilePortraitIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-mobile-portrait-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 4H10a2.002 2.002 0 0 0-2 2v22a2.002 2.002 0 0 0 2 2h12a2.003 2.003 0 0 0 2-2V6a2.002 2.002 0 0 0-2-2zm0 2v2H10V6h12zM10 28V10h12v18H10z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MoneyIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoneyIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MoneyIconComponent, isStandalone: true, selector: "iui-money-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 22H2v2h28v-2zM30 26H2v2h28v-2zM24 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM16 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm0-6a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM8 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4z" fill="currentColor"></path><path d="M28 20H4a2.005 2.005 0 0 1-2-2V6a2.005 2.005 0 0 1 2-2h24a2.005 2.005 0 0 1 2 2v12a2.003 2.003 0 0 1-2 2zm0-14H4v12h24V6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoneyIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-money-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 22H2v2h28v-2zM30 26H2v2h28v-2zM24 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM16 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm0-6a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM8 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4z" fill="currentColor"></path><path d="M28 20H4a2.005 2.005 0 0 1-2-2V6a2.005 2.005 0 0 1 2-2h24a2.005 2.005 0 0 1 2 2v12a2.003 2.003 0 0 1-2 2zm0-14H4v12h24V6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MoreHorizontalIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoreHorizontalIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MoreHorizontalIconComponent, isStandalone: true, selector: "iui-more-horizontal-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M8 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM16 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoreHorizontalIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-more-horizontal-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M8 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM16 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MoreVerticalIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoreVerticalIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MoreVerticalIconComponent, isStandalone: true, selector: "iui-more-vertical-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 24a2 2 0 1 0-4 0 2 2 0 0 0 4 0zM18 16a2 2 0 1 0-4 0 2 2 0 0 0 4 0zM18 8a2 2 0 1 0-4 0 2 2 0 0 0 4 0z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoreVerticalIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-more-vertical-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 24a2 2 0 1 0-4 0 2 2 0 0 0 4 0zM18 16a2 2 0 1 0-4 0 2 2 0 0 0 4 0zM18 8a2 2 0 1 0-4 0 2 2 0 0 0 4 0z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MovIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MovIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MovIconComponent, isStandalone: true, selector: "iui-mov-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m28 9-2 13-2-13h-2l2.52 14h2.96L30 9h-2zM18 23h-4a2 2 0 0 1-2-2V11a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2zm-4-12v10h4V11h-4zM8 9l-1.51 5L6 15.98 5.54 14 4 9H2v14h2v-8l-.16-2 .58 2L6 19.63 7.58 15l.58-2L8 15v8h2V9H8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MovIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-mov-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m28 9-2 13-2-13h-2l2.52 14h2.96L30 9h-2zM18 23h-4a2 2 0 0 1-2-2V11a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2zm-4-12v10h4V11h-4zM8 9l-1.51 5L6 15.98 5.54 14 4 9H2v14h2v-8l-.16-2 .58 2L6 19.63 7.58 15l.58-2L8 15v8h2V9H8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MoveIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoveIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MoveIconComponent, isStandalone: true, selector: "iui-move-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m25 11-1.41 1.41L26.17 15H17V5.83l2.59 2.58L21 7l-5-5-5 5 1.41 1.41L15 5.83V15H5.83l2.58-2.59L7 11l-5 5 5 5 1.41-1.41L5.83 17H15v9.17l-2.59-2.58L11 25l5 5 5-5-1.41-1.41L17 26.17V17h9.17l-2.58 2.59L25 21l5-5-5-5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MoveIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-move-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m25 11-1.41 1.41L26.17 15H17V5.83l2.59 2.58L21 7l-5-5-5 5 1.41 1.41L15 5.83V15H5.83l2.58-2.59L7 11l-5 5 5 5 1.41-1.41L5.83 17H15v9.17l-2.59-2.58L11 25l5 5 5-5-1.41-1.41L17 26.17V17h9.17l-2.58 2.59L25 21l5-5-5-5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class Mp3IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Mp3IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: Mp3IconComponent, isStandalone: true, selector: "iui-mp3-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 9h-6v2h6v4h-4v2h4v4h-6v2h6a2 2 0 0 0 2-2V11a2 2 0 0 0-2-2zM14 23h-2V9h6a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-4v5zm0-7h4v-5h-4v5zM8 9l-1.51 5L6 15.98 5.54 14 4 9H2v14h2v-8l-.16-2 .58 2L6 19.63 7.58 15l.58-2L8 15v8h2V9H8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Mp3IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-mp3-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 9h-6v2h6v4h-4v2h4v4h-6v2h6a2 2 0 0 0 2-2V11a2 2 0 0 0-2-2zM14 23h-2V9h6a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-4v5zm0-7h4v-5h-4v5zM8 9l-1.51 5L6 15.98 5.54 14 4 9H2v14h2v-8l-.16-2 .58 2L6 19.63 7.58 15l.58-2L8 15v8h2V9H8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class Mp4IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Mp4IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: Mp4IconComponent, isStandalone: true, selector: "iui-mp4-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29 9h-2v8h-3V9h-2v10h5v4h2v-4h1v-2h-1V9zM14 23h-2V9h6a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-4v5zm0-7h4v-5h-4v5zM8 9l-1.51 5L6 15.98 5.54 14 4 9H2v14h2v-8l-.16-2 .58 2L6 19.63 7.58 15l.58-2L8 15v8h2V9H8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Mp4IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-mp4-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29 9h-2v8h-3V9h-2v10h5v4h2v-4h1v-2h-1V9zM14 23h-2V9h6a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-4v5zm0-7h4v-5h-4v5zM8 9l-1.51 5L6 15.98 5.54 14 4 9H2v14h2v-8l-.16-2 .58 2L6 19.63 7.58 15l.58-2L8 15v8h2V9H8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class MpegIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MpegIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: MpegIconComponent, isStandalone: true, selector: "iui-mpeg-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M32 21h-4a2.002 2.002 0 0 1-2-2v-6a2.002 2.002 0 0 1 2-2h4v2h-4v6h2v-2h-1v-2h3v6zM24 13v-1.976h-6V21h6v-2h-4v-2h2v-2h-2v-2h4zM14 11H9v10h2v-3h3a2.003 2.003 0 0 0 2-2v-3a2.002 2.002 0 0 0-2-2zm-3 5v-3h3l.001 3H11zM7 11H5l-1.5 4L2 11H0v10h2v-7l1.5 4L5 14v7h2V11z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MpegIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-mpeg-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M32 21h-4a2.002 2.002 0 0 1-2-2v-6a2.002 2.002 0 0 1 2-2h4v2h-4v6h2v-2h-1v-2h3v6zM24 13v-1.976h-6V21h6v-2h-4v-2h2v-2h-2v-2h4zM14 11H9v10h2v-3h3a2.003 2.003 0 0 0 2-2v-3a2.002 2.002 0 0 0-2-2zm-3 5v-3h3l.001 3H11zM7 11H5l-1.5 4L2 11H0v10h2v-7l1.5 4L5 14v7h2V11z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class Mpg2IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Mpg2IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: Mpg2IconComponent, isStandalone: true, selector: "iui-mpg2-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M32 21h-6v-4a2.002 2.002 0 0 1 2-2h2v-2h-4v-2h4a2.002 2.002 0 0 1 2 2v2a2.002 2.002 0 0 1-2 2h-2v2h4v2zM24 21h-4a2.002 2.002 0 0 1-2-2v-6a2.002 2.002 0 0 1 2-2h4v2h-4v6h2v-2h-1v-2h3v6zM14 11H9v10h2v-3h3a2.003 2.003 0 0 0 2-2v-3a2.002 2.002 0 0 0-2-2zm-3 5v-3h3l.001 3H11zM7 11H5l-1.5 4L2 11H0v10h2v-7l1.5 4L5 14v7h2V11z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Mpg2IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-mpg2-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M32 21h-6v-4a2.002 2.002 0 0 1 2-2h2v-2h-4v-2h4a2.002 2.002 0 0 1 2 2v2a2.002 2.002 0 0 1-2 2h-2v2h4v2zM24 21h-4a2.002 2.002 0 0 1-2-2v-6a2.002 2.002 0 0 1 2-2h4v2h-4v6h2v-2h-1v-2h3v6zM14 11H9v10h2v-3h3a2.003 2.003 0 0 0 2-2v-3a2.002 2.002 0 0 0-2-2zm-3 5v-3h3l.001 3H11zM7 11H5l-1.5 4L2 11H0v10h2v-7l1.5 4L5 14v7h2V11z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NewMessageIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NewMessageIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NewMessageIconComponent, isStandalone: true, selector: "iui-new-message-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 22v6H4V4h12V2H4a2 2 0 0 0-2 2v24a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-6h-2z" fill="currentColor"></path><path d="m29.552 5.76-3.302-3.3a1.602 1.602 0 0 0-2.241 0L10 16.46V22h5.534L29.541 8a1.6 1.6 0 0 0 0-2.24h.01zM14.703 20h-2.702v-2.7l9.446-9.45 2.712 2.71L14.703 20zM25.57 9.15l-2.712-2.71 2.272-2.27 2.711 2.71-2.271 2.27z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NewMessageIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-new-message-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 22v6H4V4h12V2H4a2 2 0 0 0-2 2v24a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-6h-2z" fill="currentColor"></path><path d="m29.552 5.76-3.302-3.3a1.602 1.602 0 0 0-2.241 0L10 16.46V22h5.534L29.541 8a1.6 1.6 0 0 0 0-2.24h.01zM14.703 20h-2.702v-2.7l9.446-9.45 2.712 2.71L14.703 20zM25.57 9.15l-2.712-2.71 2.272-2.27 2.711 2.71-2.271 2.27z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NoImageIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NoImageIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NoImageIconComponent, isStandalone: true, selector: "iui-no-image-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 3.414 28.586 2 2 28.586 3.414 30l2-2H26a2.003 2.003 0 0 0 2-2V5.414l2-2zM26 26H7.414l7.793-7.793 2.379 2.379a2 2 0 0 0 2.828 0L22 19l4 3.997V26zm0-5.832-2.586-2.586a2 2 0 0 0-2.828 0L19 19.168l-2.377-2.377L26 7.414v12.754zM6 22v-3l5-4.997 1.373 1.374 1.416-1.416-1.375-1.375a2 2 0 0 0-2.828 0L6 16.172V6h16V4H6a2.002 2.002 0 0 0-2 2v16h2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NoImageIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-no-image-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 3.414 28.586 2 2 28.586 3.414 30l2-2H26a2.003 2.003 0 0 0 2-2V5.414l2-2zM26 26H7.414l7.793-7.793 2.379 2.379a2 2 0 0 0 2.828 0L22 19l4 3.997V26zm0-5.832-2.586-2.586a2 2 0 0 0-2.828 0L19 19.168l-2.377-2.377L26 7.414v12.754zM6 22v-3l5-4.997 1.373 1.374 1.416-1.416-1.375-1.375a2 2 0 0 0-2.828 0L6 16.172V6h16V4H6a2.002 2.002 0 0 0-2 2v16h2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NonCertifiedIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NonCertifiedIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NonCertifiedIconComponent, isStandalone: true, selector: "iui-non-certified-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 8H6v2h10V8zM14 12H6v2h8v-2zM10 16H6v2h4v-2z" fill="currentColor"></path><path d="M28 26H7.414L30 3.414 28.586 2l-2 2H4a2.002 2.002 0 0 0-2 2v16h2V6h20.586L2 28.586 3.414 30l2-2H28a2.002 2.002 0 0 0 2-2V10h-2v16z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NonCertifiedIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-non-certified-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 8H6v2h10V8zM14 12H6v2h8v-2zM10 16H6v2h4v-2z" fill="currentColor"></path><path d="M28 26H7.414L30 3.414 28.586 2l-2 2H4a2.002 2.002 0 0 0-2 2v16h2V6h20.586L2 28.586 3.414 30l2-2H28a2.002 2.002 0 0 0 2-2V10h-2v16z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NotificationFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NotificationFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NotificationFillIconComponent, isStandalone: true, selector: "iui-notification-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28.707 19.293 26 16.586V13a10.014 10.014 0 0 0-9-9.95V1h-2v2.05A10.014 10.014 0 0 0 6 13v3.586l-2.707 2.707A.999.999 0 0 0 3 20v3a1 1 0 0 0 1 1h7v1a5 5 0 1 0 10 0v-1h7a1 1 0 0 0 1-1v-3a1.001 1.001 0 0 0-.293-.707zM19 25a3 3 0 0 1-6 0v-1h6v1z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NotificationFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-notification-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28.707 19.293 26 16.586V13a10.014 10.014 0 0 0-9-9.95V1h-2v2.05A10.014 10.014 0 0 0 6 13v3.586l-2.707 2.707A.999.999 0 0 0 3 20v3a1 1 0 0 0 1 1h7v1a5 5 0 1 0 10 0v-1h7a1 1 0 0 0 1-1v-3a1.001 1.001 0 0 0-.293-.707zM19 25a3 3 0 0 1-6 0v-1h6v1z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NotificationNewIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NotificationNewIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NotificationNewIconComponent, isStandalone: true, selector: "iui-notification-new-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M26 16.586V14h-2v3a1 1 0 0 0 .293.707L27 20.414V22H5v-1.586l2.707-2.707A1 1 0 0 0 8 17v-4a7.985 7.985 0 0 1 12-6.918V3.847a9.896 9.896 0 0 0-3-.796V1h-2v2.05A10.014 10.014 0 0 0 6 13v3.586l-2.707 2.707A1 1 0 0 0 3 20v3a1 1 0 0 0 1 1h7v1a5 5 0 1 0 10 0v-1h7a1 1 0 0 0 1-1v-3a1 1 0 0 0-.293-.707L26 16.586zM19 25a3 3 0 0 1-6 0v-1h6v1z"></path><path d="M26 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NotificationNewIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-notification-new-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M26 16.586V14h-2v3a1 1 0 0 0 .293.707L27 20.414V22H5v-1.586l2.707-2.707A1 1 0 0 0 8 17v-4a7.985 7.985 0 0 1 12-6.918V3.847a9.896 9.896 0 0 0-3-.796V1h-2v2.05A10.014 10.014 0 0 0 6 13v3.586l-2.707 2.707A1 1 0 0 0 3 20v3a1 1 0 0 0 1 1h7v1a5 5 0 1 0 10 0v-1h7a1 1 0 0 0 1-1v-3a1 1 0 0 0-.293-.707L26 16.586zM19 25a3 3 0 0 1-6 0v-1h6v1z"></path><path d="M26 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NotificationOffFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NotificationOffFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NotificationOffFillIconComponent, isStandalone: true, selector: "iui-notification-off-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 16.586V13a9.883 9.883 0 0 0-1.087-4.499L30 3.414 28.586 2 2 28.586 3.414 30l6-6H11v1a5 5 0 1 0 10 0v-1h7a1 1 0 0 0 1-1v-3a1.001 1.001 0 0 0-.293-.707L26 16.586zM19 25a3 3 0 0 1-6 0v-1h6v1zM21.61 4.738A9.926 9.926 0 0 0 17 3.051V1h-2v2.05A10.014 10.014 0 0 0 6 13v3.586l-2.707 2.707A.999.999 0 0 0 3 20v3c.005.1.024.197.058.29L21.61 4.738z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NotificationOffFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-notification-off-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 16.586V13a9.883 9.883 0 0 0-1.087-4.499L30 3.414 28.586 2 2 28.586 3.414 30l6-6H11v1a5 5 0 1 0 10 0v-1h7a1 1 0 0 0 1-1v-3a1.001 1.001 0 0 0-.293-.707L26 16.586zM19 25a3 3 0 0 1-6 0v-1h6v1zM21.61 4.738A9.926 9.926 0 0 0 17 3.051V1h-2v2.05A10.014 10.014 0 0 0 6 13v3.586l-2.707 2.707A.999.999 0 0 0 3 20v3c.005.1.024.197.058.29L21.61 4.738z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NotificationOffOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NotificationOffOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NotificationOffOutlineIconComponent, isStandalone: true, selector: "iui-notification-off-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 16.586V13a9.922 9.922 0 0 0-1.083-4.502L30 3.414 28.586 2 2 28.586 3.414 30l6-6H11v1a5 5 0 1 0 10 0v-1h7a1 1 0 0 0 1-1v-3a1 1 0 0 0-.293-.707L26 16.586zM19 25a3 3 0 0 1-6 0v-1h6v1zm8-3H11.414l11.998-11.998A7.95 7.95 0 0 1 24 13v4a1 1 0 0 0 .293.707L27 20.414V22zM7.707 17.707A1 1 0 0 0 8 17v-4a8.01 8.01 0 0 1 8-8 7.925 7.925 0 0 1 4.986 1.768l1.426-1.426A9.934 9.934 0 0 0 17 3.05V1h-2v2.05A10.014 10.014 0 0 0 6 13v3.586l-3 3L4.414 21l3.293-3.293z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NotificationOffOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-notification-off-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 16.586V13a9.922 9.922 0 0 0-1.083-4.502L30 3.414 28.586 2 2 28.586 3.414 30l6-6H11v1a5 5 0 1 0 10 0v-1h7a1 1 0 0 0 1-1v-3a1 1 0 0 0-.293-.707L26 16.586zM19 25a3 3 0 0 1-6 0v-1h6v1zm8-3H11.414l11.998-11.998A7.95 7.95 0 0 1 24 13v4a1 1 0 0 0 .293.707L27 20.414V22zM7.707 17.707A1 1 0 0 0 8 17v-4a8.01 8.01 0 0 1 8-8 7.925 7.925 0 0 1 4.986 1.768l1.426-1.426A9.934 9.934 0 0 0 17 3.05V1h-2v2.05A10.014 10.014 0 0 0 6 13v3.586l-3 3L4.414 21l3.293-3.293z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NotificationOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NotificationOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NotificationOutlineIconComponent, isStandalone: true, selector: "iui-notification-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28.707 19.293 26 16.586V13a10.014 10.014 0 0 0-9-9.95V1h-2v2.05A10.014 10.014 0 0 0 6 13v3.586l-2.707 2.707A1 1 0 0 0 3 20v3a1 1 0 0 0 1 1h7v.777a5.152 5.152 0 0 0 4.5 5.198A5.005 5.005 0 0 0 21 25v-1h7a1 1 0 0 0 1-1v-3a1 1 0 0 0-.293-.707zM19 25a3 3 0 0 1-6 0v-1h6v1zm8-3H5v-1.586l2.707-2.707A1 1 0 0 0 8 17v-4a8 8 0 0 1 16 0v4a1 1 0 0 0 .293.707L27 20.414V22z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NotificationOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-notification-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28.707 19.293 26 16.586V13a10.014 10.014 0 0 0-9-9.95V1h-2v2.05A10.014 10.014 0 0 0 6 13v3.586l-2.707 2.707A1 1 0 0 0 3 20v3a1 1 0 0 0 1 1h7v.777a5.152 5.152 0 0 0 4.5 5.198A5.005 5.005 0 0 0 21 25v-1h7a1 1 0 0 0 1-1v-3a1 1 0 0 0-.293-.707zM19 25a3 3 0 0 1-6 0v-1h6v1zm8-3H5v-1.586l2.707-2.707A1 1 0 0 0 8 17v-4a8 8 0 0 1 16 0v4a1 1 0 0 0 .293.707L27 20.414V22z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberFilled1IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled1IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberFilled1IconComponent, isStandalone: true, selector: "iui-number-filled1-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zM12 9h5v12h3v2h-8v-2h3V11h-3V9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled1IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-filled1-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zM12 9h5v12h3v2h-8v-2h3V11h-3V9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberFilled2IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled2IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberFilled2IconComponent, isStandalone: true, selector: "iui-number-filled2-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zm-4-13v6h8v-2h-6v-4h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-6v2h6v4h-4a2 2 0 0 0-2 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled2IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-filled2-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zm-4-13v6h8v-2h-6v-4h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-6v2h6v4h-4a2 2 0 0 0-2 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberFilled3IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled3IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberFilled3IconComponent, isStandalone: true, selector: "iui-number-filled3-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zM12 9h6a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-6v-2h6v-4h-4v-2h4v-4h-6V9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled3IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-filled3-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zM12 9h6a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-6v-2h6v-4h-4v-2h4v-4h-6V9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberFilled4IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled4IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberFilled4IconComponent, isStandalone: true, selector: "iui-number-filled4-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zm1-21h2v8h1v2h-1v4h-2v-4h-5V9h2v8h3V9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled4IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-filled4-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zm1-21h2v8h1v2h-1v4h-2v-4h-5V9h2v8h3V9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberFilled5IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled5IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberFilled5IconComponent, isStandalone: true, selector: "iui-number-filled5-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zm-4-7h6a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-4v-4h6V9h-8v8h6v4h-6v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled5IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-filled5-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zm-4-7h6a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-4v-4h6V9h-8v8h6v4h-6v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberFilled6IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled6IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberFilled6IconComponent, isStandalone: true, selector: "iui-number-filled6-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M14 16v5h4v-5h-4z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zm-2-19v3h4a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2V11a2 2 0 0 1 2-2h5v2h-5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled6IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-filled6-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M14 16v5h4v-5h-4z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zm-2-19v3h4a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2V11a2 2 0 0 1 2-2h5v2h-5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberFilled7IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled7IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberFilled7IconComponent, isStandalone: true, selector: "iui-number-filled7-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zm-4-17V9h8v2l-4.84 12H13l4.85-12H14v2h-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled7IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-filled7-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zm-4-17V9h8v2l-4.84 12H13l4.85-12H14v2h-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberFilled8IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled8IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberFilled8IconComponent, isStandalone: true, selector: "iui-number-filled8-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 15v-4h-4v4h4zM14 17v4h4v-4h-4z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zM12.586 9.586A2 2 0 0 1 14 9h4a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2V11a2 2 0 0 1 .586-1.414z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled8IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-filled8-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 15v-4h-4v4h4zM14 17v4h4v-4h-4z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zM12.586 9.586A2 2 0 0 1 14 9h4a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2V11a2 2 0 0 1 .586-1.414z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberFilled9IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled9IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberFilled9IconComponent, isStandalone: true, selector: "iui-number-filled9-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M14 11v5h4v-5h-4z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zM12.586 9.586A2 2 0 0 1 14 9h4a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-5v-2h5v-3h-4a2 2 0 0 1-2-2v-5a2 2 0 0 1 .586-1.414z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberFilled9IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-filled9-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M14 11v5h4v-5h-4z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zM12.586 9.586A2 2 0 0 1 14 9h4a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-5v-2h5v-3h-4a2 2 0 0 1-2-2v-5a2 2 0 0 1 .586-1.414z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberOutline1IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline1IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberOutline1IconComponent, isStandalone: true, selector: "iui-number-outline1-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path d="M12 9h5v12h3v2h-8v-2h3V11h-3V9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline1IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-outline1-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path d="M12 9h5v12h3v2h-8v-2h3V11h-3V9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberOutline2IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline2IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberOutline2IconComponent, isStandalone: true, selector: "iui-number-outline2-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path d="M12 17v6h8v-2h-6v-4h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-6v2h6v4h-4a2 2 0 0 0-2 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline2IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-outline2-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path d="M12 17v6h8v-2h-6v-4h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-6v2h6v4h-4a2 2 0 0 0-2 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberOutline3IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline3IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberOutline3IconComponent, isStandalone: true, selector: "iui-number-outline3-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path d="M12 9h6a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-6v-2h6v-4h-4v-2h4v-4h-6V9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline3IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-outline3-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path d="M12 9h6a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-6v-2h6v-4h-4v-2h4v-4h-6V9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberOutline4IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline4IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberOutline4IconComponent, isStandalone: true, selector: "iui-number-outline4-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path d="M17 9h2v8h1v2h-1v4h-2v-4h-5V9h2v8h3V9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline4IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-outline4-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path d="M17 9h2v8h1v2h-1v4h-2v-4h-5V9h2v8h3V9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberOutline5IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline5IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberOutline5IconComponent, isStandalone: true, selector: "iui-number-outline5-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path d="M12 23h6a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-4v-4h6V9h-8v8h6v4h-6v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline5IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-outline5-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path d="M12 23h6a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-4v-4h6V9h-8v8h6v4h-6v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberOutline6IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline6IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberOutline6IconComponent, isStandalone: true, selector: "iui-number-outline6-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M14 14v-3h5V9h-5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-5a2 2 0 0 0-2-2h-4zm0 7v-5h4v5h-4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline6IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-outline6-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M14 14v-3h5V9h-5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-5a2 2 0 0 0-2-2h-4zm0 7v-5h4v5h-4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberOutline7IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline7IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberOutline7IconComponent, isStandalone: true, selector: "iui-number-outline7-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path d="M12 13V9h8v2l-4.84 12H13l4.85-12H14v2h-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline7IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-outline7-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path d="M12 13V9h8v2l-4.84 12H13l4.85-12H14v2h-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberOutline8IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline8IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberOutline8IconComponent, isStandalone: true, selector: "iui-number-outline8-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M14 9a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V11a2 2 0 0 0-2-2h-4zm4 2v4h-4v-4h4zm-4 10v-4h4v4h-4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline8IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-outline8-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M14 9a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V11a2 2 0 0 0-2-2h-4zm4 2v4h-4v-4h4zm-4 10v-4h4v4h-4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class NumberOutline9IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline9IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: NumberOutline9IconComponent, isStandalone: true, selector: "iui-number-outline9-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M14 9a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h4v3h-5v2h5a2 2 0 0 0 2-2V11a2 2 0 0 0-2-2h-4zm0 7v-5h4v5h-4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NumberOutline9IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-outline9-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 28c6.627 0 12-5.373 12-12S22.627 4 16 4 4 9.373 4 16s5.373 12 12 12zm14-12c0 7.732-6.268 14-14 14S2 23.732 2 16 8.268 2 16 2s14 6.268 14 14z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M14 9a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h4v3h-5v2h5a2 2 0 0 0 2-2V11a2 2 0 0 0-2-2h-4zm0 7v-5h4v5h-4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class OpenBottomPanelFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenBottomPanelFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: OpenBottomPanelFillIconComponent, isStandalone: true, selector: "iui-open-bottom-panel-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 2v12H4V6h24z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenBottomPanelFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-open-bottom-panel-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 2v12H4V6h24z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class OpenBottomPanelOutllineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenBottomPanelOutllineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: OpenBottomPanelOutllineIconComponent, isStandalone: true, selector: "iui-open-bottom-panel-outlline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 2v12H4V6h24zM4 26v-6h24v6H4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenBottomPanelOutllineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-open-bottom-panel-outlline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 2v12H4V6h24zM4 26v-6h24v6H4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class OpenLeftPanelFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenLeftPanelFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: OpenLeftPanelFillIconComponent, isStandalone: true, selector: "iui-open-left-panel-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM4 6h6v20H4V6zm24 20H12V6h16v20z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenLeftPanelFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-open-left-panel-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM4 6h6v20H4V6zm24 20H12V6h16v20z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class OpenLeftPanelOutllineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenLeftPanelOutllineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: OpenLeftPanelOutllineIconComponent, isStandalone: true, selector: "iui-open-left-panel-outlline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 22H12V6h16v20z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenLeftPanelOutllineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-open-left-panel-outlline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 22H12V6h16v20z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class OpenRightPanelFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenRightPanelFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: OpenRightPanelFillIconComponent, isStandalone: true, selector: "iui-open-right-panel-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM4 6h16v20H4V6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenRightPanelFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-open-right-panel-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM4 6h16v20H4V6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class OpenRightPanelOutllineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenRightPanelOutllineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: OpenRightPanelOutllineIconComponent, isStandalone: true, selector: "iui-open-right-panel-outlline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM4 6h16v20H4V6zm24 20h-6V6h6v20z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenRightPanelOutllineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-open-right-panel-outlline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM4 6h16v20H4V6zm24 20h-6V6h6v20z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class OpenTopPanelFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenTopPanelFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: OpenTopPanelFillIconComponent, isStandalone: true, selector: "iui-open-top-panel-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM4 26V14h24v12H4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenTopPanelFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-open-top-panel-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM4 26V14h24v12H4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class OpenTopPanelOutllineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenTopPanelOutllineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: OpenTopPanelOutllineIconComponent, isStandalone: true, selector: "iui-open-top-panel-outlline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 2v6H4V6h24zM4 26V14h24v12H4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OpenTopPanelOutllineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-open-top-panel-outlline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 2v6H4V6h24zM4 26V14h24v12H4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class OrderHistoryIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OrderHistoryIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: OrderHistoryIconComponent, isStandalone: true, selector: "iui-order-history-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M20.59 22 15 16.41V7h2v8.58l5 5.01L20.59 22z" fill="currentColor"></path><path d="M16 2A13.94 13.94 0 0 0 6 6.23V2H4v8h8V8H7.08A12 12 0 1 1 4 16H2A14 14 0 1 0 16 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: OrderHistoryIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-order-history-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M20.59 22 15 16.41V7h2v8.58l5 5.01L20.59 22z" fill="currentColor"></path><path d="M16 2A13.94 13.94 0 0 0 6 6.23V2H4v8h8V8H7.08A12 12 0 1 1 4 16H2A14 14 0 1 0 16 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PageFirstIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PageFirstIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PageFirstIconComponent, isStandalone: true, selector: "iui-page-first-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M14 16 24 6l1.4 1.4-8.6 8.6 8.6 8.6L24 26 14 16zM10 4H8v24h2V4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PageFirstIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-page-first-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M14 16 24 6l1.4 1.4-8.6 8.6 8.6 8.6L24 26 14 16zM10 4H8v24h2V4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PageLastIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PageLastIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PageLastIconComponent, isStandalone: true, selector: "iui-page-last-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 16 8 26l-1.4-1.4 8.6-8.6-8.6-8.6L8 6l10 10zM24 4h-2v24h2V4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PageLastIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-page-last-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 16 8 26l-1.4-1.4 8.6-8.6-8.6-8.6L8 6l10 10zM24 4h-2v24h2V4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PauseFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PauseFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PauseFillIconComponent, isStandalone: true, selector: "iui-pause-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 6h-2a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zM22 6h-2a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PauseFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-pause-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 6h-2a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zM22 6h-2a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PauseOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PauseOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PauseOutlineIconComponent, isStandalone: true, selector: "iui-pause-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 8v16H8V8h4zm0-2H8a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zM24 8v16h-4V8h4zm0-2h-4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PauseOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-pause-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 8v16H8V8h4zm0-2H8a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zM24 8v16h-4V8h4zm0-2h-4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PdfIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PdfIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PdfIconComponent, isStandalone: true, selector: "iui-pdf-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 11V9h-8v14h2v-6h5v-2h-5v-4h6zM8 9H2v14h2v-5h4a2 2 0 0 0 2-2v-5a2 2 0 0 0-2-2zm0 7H4v-5h4v5zM16 23h-4V9h4a4 4 0 0 1 4 4v6a4 4 0 0 1-4 4zm-2-2h2a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2h-2v10z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PdfIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-pdf-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 11V9h-8v14h2v-6h5v-2h-5v-4h6zM8 9H2v14h2v-5h4a2 2 0 0 0 2-2v-5a2 2 0 0 0-2-2zm0 7H4v-5h4v5zM16 23h-4V9h4a4 4 0 0 1 4 4v6a4 4 0 0 1-4 4zm-2-2h2a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2h-2v10z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PhoneBlockFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneBlockFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PhoneBlockFillIconComponent, isStandalone: true, selector: "iui-phone-block-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m20.333 21.482 2.24-2.24a2.167 2.167 0 0 1 2.337-.48l2.728 1.092A2.167 2.167 0 0 1 29 21.866v4.961a2.165 2.165 0 0 1-2.284 2.169C7.594 27.806 3.732 11.61 3.015 5.408A2.162 2.162 0 0 1 5.169 3h4.873a2.167 2.167 0 0 1 2.012 1.362l1.09 2.728a2.166 2.166 0 0 1-.48 2.337l-2.24 2.24s1.243 8.732 9.91 9.815z" fill="currentColor"></path><path d="M24.41 9 28 5.41 26.59 4 23 7.59 19.41 4 18 5.41 21.59 9 18 12.59 19.41 14 23 10.41 26.59 14 28 12.59 24.41 9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneBlockFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-phone-block-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m20.333 21.482 2.24-2.24a2.167 2.167 0 0 1 2.337-.48l2.728 1.092A2.167 2.167 0 0 1 29 21.866v4.961a2.165 2.165 0 0 1-2.284 2.169C7.594 27.806 3.732 11.61 3.015 5.408A2.162 2.162 0 0 1 5.169 3h4.873a2.167 2.167 0 0 1 2.012 1.362l1.09 2.728a2.166 2.166 0 0 1-.48 2.337l-2.24 2.24s1.243 8.732 9.91 9.815z" fill="currentColor"></path><path d="M24.41 9 28 5.41 26.59 4 23 7.59 19.41 4 18 5.41 21.59 9 18 12.59 19.41 14 23 10.41 26.59 14 28 12.59 24.41 9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PhoneBlockOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneBlockOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PhoneBlockOutlineIconComponent, isStandalone: true, selector: "iui-phone-block-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 29h-.17C6.18 27.87 3.39 11.29 3 6.23A3 3 0 0 1 6 3h5.27a2 2 0 0 1 1.86 1.26L14.65 8a2 2 0 0 1-.44 2.16l-2.13 2.15a9.36 9.36 0 0 0 7.58 7.6l2.17-2.15a2.001 2.001 0 0 1 2.17-.41l3.77 1.51A2 2 0 0 1 29 20.72V26a3 3 0 0 1-3 3zM6 5a1 1 0 0 0-1 1.08C5.46 12 8.41 26 25.94 27A1 1 0 0 0 27 26v-5.28l-3.77-1.51-2.87 2.85-.48-.06c-8.7-1.09-9.88-9.79-9.88-9.88l-.06-.48 2.84-2.87L11.28 5H6z" fill="currentColor"></path><path d="M24.41 9 28 5.41 26.59 4 23 7.59 19.41 4 18 5.41 21.59 9 18 12.59 19.41 14 23 10.41 26.59 14 28 12.59 24.41 9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneBlockOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-phone-block-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 29h-.17C6.18 27.87 3.39 11.29 3 6.23A3 3 0 0 1 6 3h5.27a2 2 0 0 1 1.86 1.26L14.65 8a2 2 0 0 1-.44 2.16l-2.13 2.15a9.36 9.36 0 0 0 7.58 7.6l2.17-2.15a2.001 2.001 0 0 1 2.17-.41l3.77 1.51A2 2 0 0 1 29 20.72V26a3 3 0 0 1-3 3zM6 5a1 1 0 0 0-1 1.08C5.46 12 8.41 26 25.94 27A1 1 0 0 0 27 26v-5.28l-3.77-1.51-2.87 2.85-.48-.06c-8.7-1.09-9.88-9.79-9.88-9.88l-.06-.48 2.84-2.87L11.28 5H6z" fill="currentColor"></path><path d="M24.41 9 28 5.41 26.59 4 23 7.59 19.41 4 18 5.41 21.59 9 18 12.59 19.41 14 23 10.41 26.59 14 28 12.59 24.41 9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PhoneFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PhoneFillIconComponent, isStandalone: true, selector: "iui-phone-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m20.33 21.48 2.24-2.24a2.19 2.19 0 0 1 2.34-.48l2.73 1.09a2.18 2.18 0 0 1 1.36 2v5A2.169 2.169 0 0 1 26.72 29C7.59 27.81 3.73 11.61 3 5.41A2.17 2.17 0 0 1 5.17 3H10a2.16 2.16 0 0 1 2 1.36l1.09 2.73a2.16 2.16 0 0 1-.47 2.34l-2.24 2.24s1.29 8.73 9.95 9.81z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-phone-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m20.33 21.48 2.24-2.24a2.19 2.19 0 0 1 2.34-.48l2.73 1.09a2.18 2.18 0 0 1 1.36 2v5A2.169 2.169 0 0 1 26.72 29C7.59 27.81 3.73 11.61 3 5.41A2.17 2.17 0 0 1 5.17 3H10a2.16 2.16 0 0 1 2 1.36l1.09 2.73a2.16 2.16 0 0 1-.47 2.34l-2.24 2.24s1.29 8.73 9.95 9.81z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PhoneIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PhoneIconComponent, isStandalone: true, selector: "iui-phone-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 29h-.17C6.18 27.87 3.39 11.29 3 6.23A3 3 0 0 1 5.76 3h5.51a2 2 0 0 1 1.86 1.26L14.65 8a2 2 0 0 1-.44 2.16l-2.13 2.15a9.37 9.37 0 0 0 7.58 7.6l2.17-2.15a2 2 0 0 1 2.17-.41l3.77 1.51A2 2 0 0 1 29 20.72V26a3 3 0 0 1-3 3zM6 5a1 1 0 0 0-1 1v.08C5.46 12 8.41 26 25.94 27a1 1 0 0 0 1.06-.94v-5.34l-3.77-1.51-2.87 2.85-.48-.06c-8.7-1.09-9.88-9.79-9.88-9.88l-.06-.48 2.84-2.87L11.28 5H6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-phone-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 29h-.17C6.18 27.87 3.39 11.29 3 6.23A3 3 0 0 1 5.76 3h5.51a2 2 0 0 1 1.86 1.26L14.65 8a2 2 0 0 1-.44 2.16l-2.13 2.15a9.37 9.37 0 0 0 7.58 7.6l2.17-2.15a2 2 0 0 1 2.17-.41l3.77 1.51A2 2 0 0 1 29 20.72V26a3 3 0 0 1-3 3zM6 5a1 1 0 0 0-1 1v.08C5.46 12 8.41 26 25.94 27a1 1 0 0 0 1.06-.94v-5.34l-3.77-1.51-2.87 2.85-.48-.06c-8.7-1.09-9.88-9.79-9.88-9.88l-.06-.48 2.84-2.87L11.28 5H6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PhoneIncomingFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneIncomingFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PhoneIncomingFillIconComponent, isStandalone: true, selector: "iui-phone-incoming-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m20.333 21.482 2.24-2.24a2.167 2.167 0 0 1 2.337-.48l2.728 1.092A2.167 2.167 0 0 1 29 21.866v4.961a2.165 2.165 0 0 1-2.284 2.169C7.594 27.806 3.732 11.61 3.015 5.408A2.162 2.162 0 0 1 5.169 3h4.873a2.167 2.167 0 0 1 2.012 1.362l1.09 2.728a2.166 2.166 0 0 1-.48 2.337l-2.24 2.24s1.243 8.732 9.91 9.815z" fill="currentColor"></path><path d="M27 13v-2h-4.586L29 4.414 27.586 3 21 9.586V5h-2v8h8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneIncomingFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-phone-incoming-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m20.333 21.482 2.24-2.24a2.167 2.167 0 0 1 2.337-.48l2.728 1.092A2.167 2.167 0 0 1 29 21.866v4.961a2.165 2.165 0 0 1-2.284 2.169C7.594 27.806 3.732 11.61 3.015 5.408A2.162 2.162 0 0 1 5.169 3h4.873a2.167 2.167 0 0 1 2.012 1.362l1.09 2.728a2.166 2.166 0 0 1-.48 2.337l-2.24 2.24s1.243 8.732 9.91 9.815z" fill="currentColor"></path><path d="M27 13v-2h-4.586L29 4.414 27.586 3 21 9.586V5h-2v8h8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PhoneIncomingOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneIncomingOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PhoneIncomingOutlineIconComponent, isStandalone: true, selector: "iui-phone-incoming-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 29h-.17C6.18 27.87 3.39 11.29 3 6.23A3 3 0 0 1 6 3h5.27a2 2 0 0 1 1.86 1.26L14.65 8a2 2 0 0 1-.44 2.16l-2.13 2.15a9.36 9.36 0 0 0 7.58 7.6l2.17-2.15a2.001 2.001 0 0 1 2.17-.41l3.77 1.51A2 2 0 0 1 29 20.72V26a3 3 0 0 1-3 3zM6 5a1 1 0 0 0-1 1.08C5.46 12 8.41 26 25.94 27A1 1 0 0 0 27 26v-5.28l-3.77-1.51-2.87 2.85-.48-.06c-8.7-1.09-9.88-9.79-9.88-9.88l-.06-.48 2.84-2.87L11.28 5H6z" fill="currentColor"></path><path d="M27 13v-2h-4.586L29 4.414 27.586 3 21 9.586V5h-2v8h8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneIncomingOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-phone-incoming-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 29h-.17C6.18 27.87 3.39 11.29 3 6.23A3 3 0 0 1 6 3h5.27a2 2 0 0 1 1.86 1.26L14.65 8a2 2 0 0 1-.44 2.16l-2.13 2.15a9.36 9.36 0 0 0 7.58 7.6l2.17-2.15a2.001 2.001 0 0 1 2.17-.41l3.77 1.51A2 2 0 0 1 29 20.72V26a3 3 0 0 1-3 3zM6 5a1 1 0 0 0-1 1.08C5.46 12 8.41 26 25.94 27A1 1 0 0 0 27 26v-5.28l-3.77-1.51-2.87 2.85-.48-.06c-8.7-1.09-9.88-9.79-9.88-9.88l-.06-.48 2.84-2.87L11.28 5H6z" fill="currentColor"></path><path d="M27 13v-2h-4.586L29 4.414 27.586 3 21 9.586V5h-2v8h8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PhoneOffFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneOffFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PhoneOffFillIconComponent, isStandalone: true, selector: "iui-phone-off-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m26.74 19.56-2.52-1a2 2 0 0 0-2.15.44L20 21.06a9.93 9.93 0 0 1-5.35-2.29L30 3.41 28.59 2 2 28.59 3.41 30l7.93-7.92c3.24 3.12 7.89 5.5 14.55 5.92A2 2 0 0 0 28 26v-4.59a2 2 0 0 0-1.26-1.85zM8.15 18.19l3.52-3.52c-.38-.854-.654-1.75-.82-2.67l2.07-2.07a2 2 0 0 0 .44-2.15l-1-2.52A2 2 0 0 0 10.5 4H6a2 2 0 0 0-2 2.22 29 29 0 0 0 4.15 11.97z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneOffFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-phone-off-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m26.74 19.56-2.52-1a2 2 0 0 0-2.15.44L20 21.06a9.93 9.93 0 0 1-5.35-2.29L30 3.41 28.59 2 2 28.59 3.41 30l7.93-7.92c3.24 3.12 7.89 5.5 14.55 5.92A2 2 0 0 0 28 26v-4.59a2 2 0 0 0-1.26-1.85zM8.15 18.19l3.52-3.52c-.38-.854-.654-1.75-.82-2.67l2.07-2.07a2 2 0 0 0 .44-2.15l-1-2.52A2 2 0 0 0 10.5 4H6a2 2 0 0 0-2 2.22 29 29 0 0 0 4.15 11.97z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PhoneOffOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneOffOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PhoneOffOutlineIconComponent, isStandalone: true, selector: "iui-phone-off-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M9.19 18.56A25.66 25.66 0 0 1 5 6.08V6a1 1 0 0 1 1-1h5.28l1.5 3.77-2.84 2.87.06.48a13.002 13.002 0 0 0 1.46 4.17l1.46-1.46a9.341 9.341 0 0 1-.84-2.52l2.13-2.15A2 2 0 0 0 14.65 8l-1.52-3.74A2 2 0 0 0 11.27 3H5.76A3 3 0 0 0 3 6.23 28 28 0 0 0 7.79 20l1.4-1.44zM27.77 18.86 24 17.35a2 2 0 0 0-2.17.41l-2.17 2.15A9.17 9.17 0 0 1 15.45 18L30 3.41 28.59 2 2 28.59 3.41 30l7-7c3.38 3.18 8.28 5.62 15.39 6h.2a3 3 0 0 0 3-3v-5.28a2 2 0 0 0-1.23-1.86zm-.77 7.2a1 1 0 0 1-1.06.94c-6.51-.37-11-2.54-14.11-5.42L14 19.44A10.77 10.77 0 0 0 19.88 22l.48.06 2.87-2.85L27 20.72v5.34z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneOffOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-phone-off-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M9.19 18.56A25.66 25.66 0 0 1 5 6.08V6a1 1 0 0 1 1-1h5.28l1.5 3.77-2.84 2.87.06.48a13.002 13.002 0 0 0 1.46 4.17l1.46-1.46a9.341 9.341 0 0 1-.84-2.52l2.13-2.15A2 2 0 0 0 14.65 8l-1.52-3.74A2 2 0 0 0 11.27 3H5.76A3 3 0 0 0 3 6.23 28 28 0 0 0 7.79 20l1.4-1.44zM27.77 18.86 24 17.35a2 2 0 0 0-2.17.41l-2.17 2.15A9.17 9.17 0 0 1 15.45 18L30 3.41 28.59 2 2 28.59 3.41 30l7-7c3.38 3.18 8.28 5.62 15.39 6h.2a3 3 0 0 0 3-3v-5.28a2 2 0 0 0-1.23-1.86zm-.77 7.2a1 1 0 0 1-1.06.94c-6.51-.37-11-2.54-14.11-5.42L14 19.44A10.77 10.77 0 0 0 19.88 22l.48.06 2.87-2.85L27 20.72v5.34z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PhoneOutgoingFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneOutgoingFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PhoneOutgoingFillIconComponent, isStandalone: true, selector: "iui-phone-outgoing-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m20.333 21.482 2.24-2.24a2.167 2.167 0 0 1 2.337-.48l2.728 1.092A2.167 2.167 0 0 1 29 21.866v4.961a2.165 2.165 0 0 1-2.284 2.169C7.594 27.806 3.732 11.61 3.015 5.408A2.162 2.162 0 0 1 5.169 3h4.873a2.167 2.167 0 0 1 2.012 1.362l1.09 2.728a2.166 2.166 0 0 1-.48 2.337l-2.24 2.24s1.243 8.732 9.91 9.815z" fill="currentColor"></path><path d="M20 4v2h4.586L18 12.586 19.414 14 26 7.414V12h2V4h-8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneOutgoingFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-phone-outgoing-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m20.333 21.482 2.24-2.24a2.167 2.167 0 0 1 2.337-.48l2.728 1.092A2.167 2.167 0 0 1 29 21.866v4.961a2.165 2.165 0 0 1-2.284 2.169C7.594 27.806 3.732 11.61 3.015 5.408A2.162 2.162 0 0 1 5.169 3h4.873a2.167 2.167 0 0 1 2.012 1.362l1.09 2.728a2.166 2.166 0 0 1-.48 2.337l-2.24 2.24s1.243 8.732 9.91 9.815z" fill="currentColor"></path><path d="M20 4v2h4.586L18 12.586 19.414 14 26 7.414V12h2V4h-8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PhoneOutgoingOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneOutgoingOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PhoneOutgoingOutlineIconComponent, isStandalone: true, selector: "iui-phone-outgoing-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 29h-.2C6.2 27.9 3.4 11.3 3 6.2 2.9 4.6 4.1 3.1 5.8 3h5.5c.8 0 1.6.5 1.9 1.3L14.6 8c.3.7.1 1.6-.4 2.2l-2.1 2.1c.7 3.9 3.7 6.9 7.6 7.6l2.2-2.1c.6-.6 1.4-.7 2.2-.4l3.8 1.5c.7.3 1.2 1 1.2 1.9V26c-.1 1.7-1.4 3-3.1 3zM6 5c-.6 0-1 .4-1 1v.1C5.5 12 8.4 26 25.9 27c.6 0 1-.4 1.1-.9V20.7l-3.8-1.5-2.9 2.9-.4-.1c-8.7-1.1-9.9-9.8-9.9-9.9l-.1-.5 2.8-2.9L11.3 5H6z" fill="currentColor"></path><path d="M20 4v2h4.6L18 12.6l1.4 1.4L26 7.4V12h2V4h-8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneOutgoingOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-phone-outgoing-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 29h-.2C6.2 27.9 3.4 11.3 3 6.2 2.9 4.6 4.1 3.1 5.8 3h5.5c.8 0 1.6.5 1.9 1.3L14.6 8c.3.7.1 1.6-.4 2.2l-2.1 2.1c.7 3.9 3.7 6.9 7.6 7.6l2.2-2.1c.6-.6 1.4-.7 2.2-.4l3.8 1.5c.7.3 1.2 1 1.2 1.9V26c-.1 1.7-1.4 3-3.1 3zM6 5c-.6 0-1 .4-1 1v.1C5.5 12 8.4 26 25.9 27c.6 0 1-.4 1.1-.9V20.7l-3.8-1.5-2.9 2.9-.4-.1c-8.7-1.1-9.9-9.8-9.9-9.9l-.1-.5 2.8-2.9L11.3 5H6z" fill="currentColor"></path><path d="M20 4v2h4.6L18 12.6l1.4 1.4L26 7.4V12h2V4h-8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PhoneVoiseFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneVoiseFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PhoneVoiseFillIconComponent, isStandalone: true, selector: "iui-phone-voise-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 13h-2a3.004 3.004 0 0 0-3-3V8a5.006 5.006 0 0 1 5 5z" fill="currentColor"></path><path d="M28 13h-2a7.008 7.008 0 0 0-7-7V4a9.01 9.01 0 0 1 9 9zM20.333 21.482l2.24-2.24a2.167 2.167 0 0 1 2.337-.48l2.728 1.092A2.167 2.167 0 0 1 29 21.866v4.961a2.165 2.165 0 0 1-2.284 2.169C7.594 27.806 3.732 11.61 3.015 5.408A2.162 2.162 0 0 1 5.169 3h4.873a2.167 2.167 0 0 1 2.012 1.362l1.09 2.728a2.166 2.166 0 0 1-.48 2.337l-2.24 2.24s1.243 8.732 9.91 9.815z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneVoiseFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-phone-voise-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 13h-2a3.004 3.004 0 0 0-3-3V8a5.006 5.006 0 0 1 5 5z" fill="currentColor"></path><path d="M28 13h-2a7.008 7.008 0 0 0-7-7V4a9.01 9.01 0 0 1 9 9zM20.333 21.482l2.24-2.24a2.167 2.167 0 0 1 2.337-.48l2.728 1.092A2.167 2.167 0 0 1 29 21.866v4.961a2.165 2.165 0 0 1-2.284 2.169C7.594 27.806 3.732 11.61 3.015 5.408A2.162 2.162 0 0 1 5.169 3h4.873a2.167 2.167 0 0 1 2.012 1.362l1.09 2.728a2.166 2.166 0 0 1-.48 2.337l-2.24 2.24s1.243 8.732 9.91 9.815z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PhoneVoiseOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneVoiseOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PhoneVoiseOutlineIconComponent, isStandalone: true, selector: "iui-phone-voise-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 13h-2a3.003 3.003 0 0 0-3-3V8a5.006 5.006 0 0 1 5 5z" fill="currentColor"></path><path d="M28 13h-2a7.008 7.008 0 0 0-7-7V4a9.01 9.01 0 0 1 9 9zM26 29h-.17C6.18 27.87 3.39 11.29 3 6.23A3 3 0 0 1 6 3h5.27a2 2 0 0 1 1.86 1.26L14.65 8a2 2 0 0 1-.44 2.16l-2.13 2.15a9.36 9.36 0 0 0 7.58 7.6l2.17-2.15a2.001 2.001 0 0 1 2.17-.41l3.77 1.51A2 2 0 0 1 29 20.72V26a3 3 0 0 1-3 3zM6 5a1 1 0 0 0-1 1.08C5.46 12 8.41 26 25.94 27A1 1 0 0 0 27 26v-5.28l-3.77-1.51-2.87 2.85-.48-.06c-8.7-1.09-9.88-9.79-9.88-9.88l-.06-.48 2.84-2.87L11.28 5H6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PhoneVoiseOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-phone-voise-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 13h-2a3.003 3.003 0 0 0-3-3V8a5.006 5.006 0 0 1 5 5z" fill="currentColor"></path><path d="M28 13h-2a7.008 7.008 0 0 0-7-7V4a9.01 9.01 0 0 1 9 9zM26 29h-.17C6.18 27.87 3.39 11.29 3 6.23A3 3 0 0 1 6 3h5.27a2 2 0 0 1 1.86 1.26L14.65 8a2 2 0 0 1-.44 2.16l-2.13 2.15a9.36 9.36 0 0 0 7.58 7.6l2.17-2.15a2.001 2.001 0 0 1 2.17-.41l3.77 1.51A2 2 0 0 1 29 20.72V26a3 3 0 0 1-3 3zM6 5a1 1 0 0 0-1 1.08C5.46 12 8.41 26 25.94 27A1 1 0 0 0 27 26v-5.28l-3.77-1.51-2.87 2.85-.48-.06c-8.7-1.09-9.88-9.79-9.88-9.88l-.06-.48 2.84-2.87L11.28 5H6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PieChartIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PieChartIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PieChartIconComponent, isStandalone: true, selector: "iui-pie-chart-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 4a12 12 0 1 0 0 24 12 12 0 0 0 0-24zm10 11h-9V6.05A10 10 0 0 1 26 15zM15.42 26A10 10 0 0 1 15 6.05v9a2 2 0 0 0 2 2h9A10 10 0 0 1 15.42 26z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PieChartIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-pie-chart-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 4a12 12 0 1 0 0 24 12 12 0 0 0 0-24zm10 11h-9V6.05A10 10 0 0 1 26 15zM15.42 26A10 10 0 0 1 15 6.05v9a2 2 0 0 0 2 2h9A10 10 0 0 1 15.42 26z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PiggyBankIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PiggyBankIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PiggyBankIconComponent, isStandalone: true, selector: "iui-piggy-bank-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M20 11h-7v2h7v-2z"></path><path d="M29 13h-2.02A5.778 5.778 0 0 0 25 8.852V5a1 1 0 0 0-1.6-.8L19.667 7H15c-5.51 0-9.463 3.241-9.948 8H5a1 1 0 0 1-1-1v-2H2v2a3.003 3.003 0 0 0 3 3h.07A9.173 9.173 0 0 0 9 23.557V27a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1v-2h3v2a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1v-3.363A5.093 5.093 0 0 0 26.819 20H29a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1zm-1 5h-2.876c-.305 2.753-.823 3.485-3.124 4.315V26h-2v-3h-7v3h-2v-3.622A7.013 7.013 0 0 1 7 16c0-4.835 4.018-7 8-7h5.334L23 7v2.776c2.418 1.86 1.913 3.186 2.018 5.224H28v3z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PiggyBankIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-piggy-bank-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M20 11h-7v2h7v-2z"></path><path d="M29 13h-2.02A5.778 5.778 0 0 0 25 8.852V5a1 1 0 0 0-1.6-.8L19.667 7H15c-5.51 0-9.463 3.241-9.948 8H5a1 1 0 0 1-1-1v-2H2v2a3.003 3.003 0 0 0 3 3h.07A9.173 9.173 0 0 0 9 23.557V27a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1v-2h3v2a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1v-3.363A5.093 5.093 0 0 0 26.819 20H29a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1zm-1 5h-2.876c-.305 2.753-.823 3.485-3.124 4.315V26h-2v-3h-7v3h-2v-3.622A7.013 7.013 0 0 1 7 16c0-4.835 4.018-7 8-7h5.334L23 7v2.776c2.418 1.86 1.913 3.186 2.018 5.224H28v3z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PinFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PinFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PinFillIconComponent, isStandalone: true, selector: "iui-pin-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28.586 13.314 30 11.9 20 2l-1.314 1.415 1.186 1.186L8.38 14.322l-1.716-1.715L5.25 14l5.657 5.677L2 28.583 3.41 30l8.911-8.909L18 26.748l1.393-1.414-1.716-1.716 9.724-11.49 1.185 1.186z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PinFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-pin-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28.586 13.314 30 11.9 20 2l-1.314 1.415 1.186 1.186L8.38 14.322l-1.716-1.715L5.25 14l5.657 5.677L2 28.583 3.41 30l8.911-8.909L18 26.748l1.393-1.414-1.716-1.716 9.724-11.49 1.185 1.186z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PinOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PinOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PinOutlineIconComponent, isStandalone: true, selector: "iui-pin-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28.59 13.31 30 11.9 20 2l-1.31 1.42 1.18 1.18-11.49 9.72-1.72-1.71L5.25 14l5.66 5.68L2 28.58 3.41 30l8.91-8.91L18 26.75l1.39-1.42-1.71-1.71 9.72-11.49 1.19 1.18zM16.26 22.2 9.8 15.74 21.29 6 26 10.71 16.26 22.2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PinOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-pin-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28.59 13.31 30 11.9 20 2l-1.31 1.42 1.18 1.18-11.49 9.72-1.72-1.71L5.25 14l5.66 5.68L2 28.58 3.41 30l8.91-8.91L18 26.75l1.39-1.42-1.71-1.71 9.72-11.49 1.19 1.18zM16.26 22.2 9.8 15.74 21.29 6 26 10.71 16.26 22.2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PlanIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PlanIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PlanIconComponent, isStandalone: true, selector: "iui-plan-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M15 2h2v4h-2V2zM30 15v2h-4v-2h4zM15 26h2v4h-2v-4zM6 15v2H2v-2h4z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M16 22a6 6 0 1 0 0-12 6 6 0 0 0 0 12zm0 2a8 8 0 1 0 0-16 8 8 0 0 0 0 16z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M16 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm0 2a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PlanIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-plan-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M15 2h2v4h-2V2zM30 15v2h-4v-2h4zM15 26h2v4h-2v-4zM6 15v2H2v-2h4z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M16 22a6 6 0 1 0 0-12 6 6 0 0 0 0 12zm0 2a8 8 0 1 0 0-16 8 8 0 0 0 0 16z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M16 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm0 2a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PlayFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PlayFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PlayFillIconComponent, isStandalone: true, selector: "iui-play-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M7 28a1 1 0 0 1-1-1V5a1 1 0 0 1 1.482-.876l20 11a1 1 0 0 1 0 1.752l-20 11A1 1 0 0 1 7 28z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PlayFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-play-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M7 28a1 1 0 0 1-1-1V5a1 1 0 0 1 1.482-.876l20 11a1 1 0 0 1 0 1.752l-20 11A1 1 0 0 1 7 28z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PlayOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PlayOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PlayOutlineIconComponent, isStandalone: true, selector: "iui-play-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M7 28a1 1 0 0 1-1-1V5a1 1 0 0 1 1.482-.876l20 11a1 1 0 0 1 0 1.752l-20 11A1 1 0 0 1 7 28zM8 6.69V25.31L24.925 16 8 6.69z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PlayOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-play-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M7 28a1 1 0 0 1-1-1V5a1 1 0 0 1 1.482-.876l20 11a1 1 0 0 1 0 1.752l-20 11A1 1 0 0 1 7 28zM8 6.69V25.31L24.925 16 8 6.69z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PngIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PngIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PngIconComponent, isStandalone: true, selector: "iui-png-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 23h-6a2 2 0 0 1-2-2V11a2 2 0 0 1 2-2h6v2h-6v10h4v-4h-2v-2h4v8zM18 19 14.32 9H12v14h2V13l3.68 10H20V9h-2v10zM4 23H2V9h6a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2H4v5zm0-7h4v-5H4v5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PngIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-png-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 23h-6a2 2 0 0 1-2-2V11a2 2 0 0 1 2-2h6v2h-6v10h4v-4h-2v-2h4v8zM18 19 14.32 9H12v14h2V13l3.68 10H20V9h-2v10zM4 23H2V9h6a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2H4v5zm0-7h4v-5H4v5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PptIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PptIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PptIconComponent, isStandalone: true, selector: "iui-ppt-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 11h3v12h2V11h3V9h-8v2zM14 23h-2V9h6a2.002 2.002 0 0 1 2 2v5a2.002 2.002 0 0 1-2 2h-4v5zm0-7h4v-5.002h-4V16zM4 23H2V9h6a2.002 2.002 0 0 1 2 2v5a2.002 2.002 0 0 1-2 2H4v5zm0-7h4v-5.002H4V16z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PptIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-ppt-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 11h3v12h2V11h3V9h-8v2zM14 23h-2V9h6a2.002 2.002 0 0 1 2 2v5a2.002 2.002 0 0 1-2 2h-4v5zm0-7h4v-5.002h-4V16zM4 23H2V9h6a2.002 2.002 0 0 1 2 2v5a2.002 2.002 0 0 1-2 2H4v5zm0-7h4v-5.002H4V16z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PrintIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PrintIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PrintIconComponent, isStandalone: true, selector: "iui-print-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 9h-3V3H7v6H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h3v6h18v-6h3a2 2 0 0 0 2-2V11a2 2 0 0 0-2-2zM9 5h14v4H9V5zm14 22H9V17h14v10zm5-6h-3v-6H7v6H4V11h24v10z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PrintIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-print-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 9h-3V3H7v6H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h3v6h18v-6h3a2 2 0 0 0 2-2V11a2 2 0 0 0-2-2zM9 5h14v4H9V5zm14 22H9V17h14v10zm5-6h-3v-6H7v6H4V11h24v10z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ProtectionIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ProtectionIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ProtectionIconComponent, isStandalone: true, selector: "iui-protection-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m16 30-6.176-3.293A10.982 10.982 0 0 1 4 17V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v13a10.982 10.982 0 0 1-5.824 9.707L16 30zM6 4v13a8.985 8.985 0 0 0 4.766 7.942L16 27.733l5.234-2.79A8.985 8.985 0 0 0 26 17V4H6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ProtectionIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-protection-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m16 30-6.176-3.293A10.982 10.982 0 0 1 4 17V4a2.002 2.002 0 0 1 2-2h20a2.002 2.002 0 0 1 2 2v13a10.982 10.982 0 0 1-5.824 9.707L16 30zM6 4v13a8.985 8.985 0 0 0 4.766 7.942L16 27.733l5.234-2.79A8.985 8.985 0 0 0 26 17V4H6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class PurchaseIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PurchaseIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PurchaseIconComponent, isStandalone: true, selector: "iui-purchase-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 6H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zm0 2v3H4V8h24zM4 24V13h24v11H4z" fill="currentColor"></path><path d="M16 20H6v2h10v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PurchaseIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-purchase-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 6H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zm0 2v3H4V8h24zM4 24V13h24v11H4z" fill="currentColor"></path><path d="M16 20H6v2h10v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class QrCodeIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: QrCodeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: QrCodeIconComponent, isStandalone: true, selector: "iui-qr-code-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M24 26v2h2v-2h-2zM18 22v2h2v-2h-2zM18 30h4v-2h-2v-2h-2v4zM26 22v4h2v-4h-2zM28 26h2v4h-4v-2h2v-2zM26 20v-2h4v4h-2v-2h-2zM24 20h-2v4h-2v2h4v-6zM18 18v2h4v-2h-4zM10 22H6v4h4v-4z"></path><path d="M14 30H2V18h12v12zM4 28h8v-8H4v8zM26 6h-4v4h4V6z"></path><path d="M30 14H18V2h12v12zm-10-2h8V4h-8v8zM10 6H6v4h4V6z"></path><path d="M14 14H2V2h12v12zM4 12h8V4H4v8z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: QrCodeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-qr-code-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M24 26v2h2v-2h-2zM18 22v2h2v-2h-2zM18 30h4v-2h-2v-2h-2v4zM26 22v4h2v-4h-2zM28 26h2v4h-4v-2h2v-2zM26 20v-2h4v4h-2v-2h-2zM24 20h-2v4h-2v2h4v-6zM18 18v2h4v-2h-4zM10 22H6v4h4v-4z"></path><path d="M14 30H2V18h12v12zM4 28h8v-8H4v8zM26 6h-4v4h4V6z"></path><path d="M30 14H18V2h12v12zm-10-2h8V4h-8v8zM10 6H6v4h4V6z"></path><path d="M14 14H2V2h12v12zM4 12h8V4H4v8z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class RawIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RawIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: RawIconComponent, isStandalone: true, selector: "iui-raw-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m29.2 9-.34 8-.26 4.54-.41-3.54-.68-5.46h-2.02L24.81 18l-.41 3.54-.26-4.54-.34-8H22l1 14h2.27l.76-4.93.46-4.07.01-.03.01.03.46 4.07.76 4.93H30l1-14h-1.8zM18 9h-4a2 2 0 0 0-2 2v12h2v-5h4v5h2V11a2 2 0 0 0-2-2zm-4 7v-5h4v5h-4zM10 15v-4a2 2 0 0 0-2-2H2v14h2v-6h1.48l2.34 6H10l-2.37-6H8a2 2 0 0 0 2-2zm-6-4h4v4H4v-4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RawIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-raw-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m29.2 9-.34 8-.26 4.54-.41-3.54-.68-5.46h-2.02L24.81 18l-.41 3.54-.26-4.54-.34-8H22l1 14h2.27l.76-4.93.46-4.07.01-.03.01.03.46 4.07.76 4.93H30l1-14h-1.8zM18 9h-4a2 2 0 0 0-2 2v12h2v-5h4v5h2V11a2 2 0 0 0-2-2zm-4 7v-5h4v5h-4zM10 15v-4a2 2 0 0 0-2-2H2v14h2v-6h1.48l2.34 6H10l-2.37-6H8a2 2 0 0 0 2-2zm-6-4h4v4H4v-4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ReceiptIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ReceiptIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ReceiptIconComponent, isStandalone: true, selector: "iui-receipt-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 16h-2v2h2v-2zM17 16H9v2h8v-2zM23 12h-2v2h2v-2zM17 12H9v2h8v-2zM23 8H9v2h14V8z" fill="currentColor"></path><path d="M25 2H7a2.002 2.002 0 0 0-2 2v25a1 1 0 0 0 1 1h1a1 1 0 0 0 .8-.4l2.2-2.933 2.2 2.933a1.035 1.035 0 0 0 1.6 0l2.2-2.933 2.2 2.933a1.035 1.035 0 0 0 1.6 0l2.2-2.933 2.2 2.933a1 1 0 0 0 .8.4h1a1 1 0 0 0 1-1V4a2.002 2.002 0 0 0-2-2zm0 25.333L22.8 24.4a1.035 1.035 0 0 0-1.6 0L19 27.333 16.8 24.4a1.035 1.035 0 0 0-1.6 0L13 27.333 10.8 24.4a1.035 1.035 0 0 0-1.6 0L7 27.333V4h18v23.333z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ReceiptIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-receipt-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 16h-2v2h2v-2zM17 16H9v2h8v-2zM23 12h-2v2h2v-2zM17 12H9v2h8v-2zM23 8H9v2h14V8z" fill="currentColor"></path><path d="M25 2H7a2.002 2.002 0 0 0-2 2v25a1 1 0 0 0 1 1h1a1 1 0 0 0 .8-.4l2.2-2.933 2.2 2.933a1.035 1.035 0 0 0 1.6 0l2.2-2.933 2.2 2.933a1.035 1.035 0 0 0 1.6 0l2.2-2.933 2.2 2.933a1 1 0 0 0 .8.4h1a1 1 0 0 0 1-1V4a2.002 2.002 0 0 0-2-2zm0 25.333L22.8 24.4a1.035 1.035 0 0 0-1.6 0L19 27.333 16.8 24.4a1.035 1.035 0 0 0-1.6 0L13 27.333 10.8 24.4a1.035 1.035 0 0 0-1.6 0L7 27.333V4h18v23.333z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class RecordFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RecordFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: RecordFillIconComponent, isStandalone: true, selector: "iui-record-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2C8.3 2 2 8.3 2 16s6.3 14 14 14 14-6.3 14-14S23.7 2 16 2zm0 20c-3.3 0-6-2.7-6-6s2.7-6 6-6 6 2.7 6 6-2.7 6-6 6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RecordFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-record-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 2C8.3 2 2 8.3 2 16s6.3 14 14 14 14-6.3 14-14S23.7 2 16 2zm0 20c-3.3 0-6-2.7-6-6s2.7-6 6-6 6 2.7 6 6-2.7 6-6 6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class RecordOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RecordOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: RecordOutlineIconComponent, isStandalone: true, selector: "iui-record-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 4a12 12 0 1 1 0 24 12 12 0 0 1 0-24zm0-2a14 14 0 1 0 0 28 14 14 0 0 0 0-28z" fill="currentColor"></path><path d="M16 12a4 4 0 1 1 0 8 4 4 0 0 1 0-8zm0-2a6 6 0 1 0 0 12 6 6 0 0 0 0-12z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RecordOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-record-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 4a12 12 0 1 1 0 24 12 12 0 0 1 0-24zm0-2a14 14 0 1 0 0 28 14 14 0 0 0 0-28z" fill="currentColor"></path><path d="M16 12a4 4 0 1 1 0 8 4 4 0 0 1 0-8zm0-2a6 6 0 1 0 0 12 6 6 0 0 0 0-12z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class RedoIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RedoIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: RedoIconComponent, isStandalone: true, selector: "iui-redo-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 10h12.185l-3.587-3.586L22 5l6 6-6 6-1.402-1.415L24.182 12H12a6 6 0 1 0 0 12h8v2h-8a8 8 0 0 1 0-16z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RedoIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-redo-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 10h12.185l-3.587-3.586L22 5l6 6-6 6-1.402-1.415L24.182 12H12a6 6 0 1 0 0 12h8v2h-8a8 8 0 0 1 0-16z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class RefreshIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RefreshIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: RefreshIconComponent, isStandalone: true, selector: "iui-refresh-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 10H6.78A11 11 0 0 1 27 16h2A13 13 0 0 0 6 7.68V4H4v8h8v-2zM20 22h5.22A11 11 0 0 1 5 16H3a13 13 0 0 0 23 8.32V28h2v-8h-8v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RefreshIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-refresh-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12 10H6.78A11 11 0 0 1 27 16h2A13 13 0 0 0 6 7.68V4H4v8h8v-2zM20 22h5.22A11 11 0 0 1 5 16H3a13 13 0 0 0 23 8.32V28h2v-8h-8v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ReplyAllIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ReplyAllIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ReplyAllIconComponent, isStandalone: true, selector: "iui-reply-all-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M19 29a1 1 0 0 1-.768-.36l-10-12a1 1 0 0 1 0-1.28l10-12A1 1 0 0 1 20 4v7.033c7.007.462 11 5.86 11 14.967a1 1 0 0 1-1.8.6c-2.822-3.762-5.391-5.346-9.2-5.571V28a1 1 0 0 1-1 1zM10.3 16 18 25.238V20a1 1 0 0 1 1-1 12.712 12.712 0 0 1 9.841 4.09C28.086 16.556 24.658 13 19 13a1 1 0 0 1-1-1V6.762L10.3 16z" fill="currentColor"></path><path d="M11.464 28.918 1.232 16.64a1 1 0 0 1 0-1.28L11.464 3.08 13 4.36 3.3 16 13 27.638l-1.536 1.28z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ReplyAllIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-reply-all-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M19 29a1 1 0 0 1-.768-.36l-10-12a1 1 0 0 1 0-1.28l10-12A1 1 0 0 1 20 4v7.033c7.007.462 11 5.86 11 14.967a1 1 0 0 1-1.8.6c-2.822-3.762-5.391-5.346-9.2-5.571V28a1 1 0 0 1-1 1zM10.3 16 18 25.238V20a1 1 0 0 1 1-1 12.712 12.712 0 0 1 9.841 4.09C28.086 16.556 24.658 13 19 13a1 1 0 0 1-1-1V6.762L10.3 16z" fill="currentColor"></path><path d="M11.464 28.918 1.232 16.64a1 1 0 0 1 0-1.28L11.464 3.08 13 4.36 3.3 16 13 27.638l-1.536 1.28z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ReplyIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ReplyIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ReplyIconComponent, isStandalone: true, selector: "iui-reply-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28.88 30a1 1 0 0 1-.88-.5A15.189 15.189 0 0 0 15 22v6a1 1 0 0 1-.62.92 1 1 0 0 1-1.09-.21l-12-12a1 1 0 0 1 0-1.42l12-12a1 1 0 0 1 1.09-.21A1 1 0 0 1 15 4v6.11a17.19 17.19 0 0 1 15 17 16.31 16.31 0 0 1-.13 2 1 1 0 0 1-.79.86l-.2.03zM14.5 20A17.62 17.62 0 0 1 28 26a15.31 15.31 0 0 0-14.09-14 1 1 0 0 1-.91-1V6.41L3.41 16 13 25.59V21a1 1 0 0 1 1-1h.54-.04z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ReplyIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-reply-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28.88 30a1 1 0 0 1-.88-.5A15.189 15.189 0 0 0 15 22v6a1 1 0 0 1-.62.92 1 1 0 0 1-1.09-.21l-12-12a1 1 0 0 1 0-1.42l12-12a1 1 0 0 1 1.09-.21A1 1 0 0 1 15 4v6.11a17.19 17.19 0 0 1 15 17 16.31 16.31 0 0 1-.13 2 1 1 0 0 1-.79.86l-.2.03zM14.5 20A17.62 17.62 0 0 1 28 26a15.31 15.31 0 0 0-14.09-14 1 1 0 0 1-.91-1V6.41L3.41 16 13 25.59V21a1 1 0 0 1 1-1h.54-.04z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class Rewind10IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Rewind10IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: Rewind10IconComponent, isStandalone: true, selector: "iui-rewind10-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M4 18A12 12 0 1 0 16 6h-4V1L6 7l6 6V8h4A10 10 0 1 1 6 18H4z"></path><path d="M19.63 22.13a2.84 2.84 0 0 1-1.28-.27 2.44 2.44 0 0 1-.89-.77 3.57 3.57 0 0 1-.52-1.25 7.687 7.687 0 0 1-.17-1.68 7.825 7.825 0 0 1 .17-1.68c.094-.445.27-.87.52-1.25.23-.325.535-.59.89-.77.4-.188.838-.28 1.28-.27a2.44 2.44 0 0 1 2.16 1 5.23 5.23 0 0 1 .7 2.93 5.23 5.23 0 0 1-.7 2.93 2.44 2.44 0 0 1-2.16 1.08zm0-1.22a1.07 1.07 0 0 0 1-.55 3.38 3.38 0 0 0 .37-1.51v-1.38a3.31 3.31 0 0 0-.29-1.5 1.23 1.23 0 0 0-2.06 0 3.31 3.31 0 0 0-.29 1.5v1.38a3.38 3.38 0 0 0 .29 1.51 1.06 1.06 0 0 0 .98.55zM10.63 22v-1.18h2v-5.19l-1.86 1-.55-1.06 2.32-1.3H14v6.5h1.78V22h-5.15z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Rewind10IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-rewind10-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M4 18A12 12 0 1 0 16 6h-4V1L6 7l6 6V8h4A10 10 0 1 1 6 18H4z"></path><path d="M19.63 22.13a2.84 2.84 0 0 1-1.28-.27 2.44 2.44 0 0 1-.89-.77 3.57 3.57 0 0 1-.52-1.25 7.687 7.687 0 0 1-.17-1.68 7.825 7.825 0 0 1 .17-1.68c.094-.445.27-.87.52-1.25.23-.325.535-.59.89-.77.4-.188.838-.28 1.28-.27a2.44 2.44 0 0 1 2.16 1 5.23 5.23 0 0 1 .7 2.93 5.23 5.23 0 0 1-.7 2.93 2.44 2.44 0 0 1-2.16 1.08zm0-1.22a1.07 1.07 0 0 0 1-.55 3.38 3.38 0 0 0 .37-1.51v-1.38a3.31 3.31 0 0 0-.29-1.5 1.23 1.23 0 0 0-2.06 0 3.31 3.31 0 0 0-.29 1.5v1.38a3.38 3.38 0 0 0 .29 1.51 1.06 1.06 0 0 0 .98.55zM10.63 22v-1.18h2v-5.19l-1.86 1-.55-1.06 2.32-1.3H14v6.5h1.78V22h-5.15z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class Rewind30IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Rewind30IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: Rewind30IconComponent, isStandalone: true, selector: "iui-rewind30-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 18A12 12 0 1 0 16 6h-4V1L6 7l6 6V8h4A10 10 0 1 1 6 18H4z" fill="currentColor"></path><path d="M19.64 22.13a2.81 2.81 0 0 1-1.28-.27 2.36 2.36 0 0 1-.89-.77 3.39 3.39 0 0 1-.47-1.25 7.119 7.119 0 0 1-.17-1.68 7.238 7.238 0 0 1 .17-1.68 3.46 3.46 0 0 1 .52-1.25 2.36 2.36 0 0 1 .89-.77c.4-.19.838-.282 1.28-.27a2.44 2.44 0 0 1 2.16 1 5.31 5.31 0 0 1 .7 2.93 5.31 5.31 0 0 1-.7 2.93 2.44 2.44 0 0 1-2.21 1.08zm0-1.22a1 1 0 0 0 1-.55c.22-.472.323-.99.3-1.51v-1.38a3.171 3.171 0 0 0-.3-1.5 1.22 1.22 0 0 0-2.05 0 3.18 3.18 0 0 0-.29 1.5v1.38a3.25 3.25 0 0 0 .29 1.51 1 1 0 0 0 1.05.55zM12.62 17.42c.355.035.71-.06 1-.27a.841.841 0 0 0 .31-.68v-.08a.94.94 0 0 0-.3-.74 1.2 1.2 0 0 0-.83-.27 1.65 1.65 0 0 0-.89.24 2.1 2.1 0 0 0-.68.68l-.93-.83c.136-.179.283-.35.44-.51.163-.155.344-.29.54-.4a2.55 2.55 0 0 1 .7-.27 3.25 3.25 0 0 1 .87-.1 3.94 3.94 0 0 1 1.06.14c.297.078.576.214.82.4.224.168.408.383.54.63.123.26.184.543.18.83a2 2 0 0 1-.11.67 1.82 1.82 0 0 1-.32.52 1.789 1.789 0 0 1-.47.36c-.18.092-.372.159-.57.2V18c.219.04.431.11.63.21a1.701 1.701 0 0 1 .85.93c.083.234.124.481.12.73a2 2 0 0 1-.2.92 2 2 0 0 1-.58.72 2.658 2.658 0 0 1-.89.45 3.76 3.76 0 0 1-1.15.16 4.1 4.1 0 0 1-1-.11 3.099 3.099 0 0 1-.76-.31 2.76 2.76 0 0 1-.56-.45 4.226 4.226 0 0 1-.44-.55l1.07-.81c.082.147.175.288.28.42.105.128.226.242.36.34.137.097.29.171.45.22.186.05.378.074.57.07a1.45 1.45 0 0 0 1-.3 1.12 1.12 0 0 0 .34-.85v-.08a1.001 1.001 0 0 0-.37-.8 1.78 1.78 0 0 0-1.06-.28h-.76v-1.21h.74z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Rewind30IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-rewind30-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4 18A12 12 0 1 0 16 6h-4V1L6 7l6 6V8h4A10 10 0 1 1 6 18H4z" fill="currentColor"></path><path d="M19.64 22.13a2.81 2.81 0 0 1-1.28-.27 2.36 2.36 0 0 1-.89-.77 3.39 3.39 0 0 1-.47-1.25 7.119 7.119 0 0 1-.17-1.68 7.238 7.238 0 0 1 .17-1.68 3.46 3.46 0 0 1 .52-1.25 2.36 2.36 0 0 1 .89-.77c.4-.19.838-.282 1.28-.27a2.44 2.44 0 0 1 2.16 1 5.31 5.31 0 0 1 .7 2.93 5.31 5.31 0 0 1-.7 2.93 2.44 2.44 0 0 1-2.21 1.08zm0-1.22a1 1 0 0 0 1-.55c.22-.472.323-.99.3-1.51v-1.38a3.171 3.171 0 0 0-.3-1.5 1.22 1.22 0 0 0-2.05 0 3.18 3.18 0 0 0-.29 1.5v1.38a3.25 3.25 0 0 0 .29 1.51 1 1 0 0 0 1.05.55zM12.62 17.42c.355.035.71-.06 1-.27a.841.841 0 0 0 .31-.68v-.08a.94.94 0 0 0-.3-.74 1.2 1.2 0 0 0-.83-.27 1.65 1.65 0 0 0-.89.24 2.1 2.1 0 0 0-.68.68l-.93-.83c.136-.179.283-.35.44-.51.163-.155.344-.29.54-.4a2.55 2.55 0 0 1 .7-.27 3.25 3.25 0 0 1 .87-.1 3.94 3.94 0 0 1 1.06.14c.297.078.576.214.82.4.224.168.408.383.54.63.123.26.184.543.18.83a2 2 0 0 1-.11.67 1.82 1.82 0 0 1-.32.52 1.789 1.789 0 0 1-.47.36c-.18.092-.372.159-.57.2V18c.219.04.431.11.63.21a1.701 1.701 0 0 1 .85.93c.083.234.124.481.12.73a2 2 0 0 1-.2.92 2 2 0 0 1-.58.72 2.658 2.658 0 0 1-.89.45 3.76 3.76 0 0 1-1.15.16 4.1 4.1 0 0 1-1-.11 3.099 3.099 0 0 1-.76-.31 2.76 2.76 0 0 1-.56-.45 4.226 4.226 0 0 1-.44-.55l1.07-.81c.082.147.175.288.28.42.105.128.226.242.36.34.137.097.29.171.45.22.186.05.378.074.57.07a1.45 1.45 0 0 0 1-.3 1.12 1.12 0 0 0 .34-.85v-.08a1.001 1.001 0 0 0-.37-.8 1.78 1.78 0 0 0-1.06-.28h-.76v-1.21h.74z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class Rewind5IconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Rewind5IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: Rewind5IconComponent, isStandalone: true, selector: "iui-rewind5-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M4 18A12 12 0 1 0 16 6h-4V1L6 7l6 6V8h4A10 10 0 1 1 6 18H4z"></path><path d="M18.58 15.58h-3.45L15 18.15a4.81 4.81 0 0 1 .26-.45c.092-.133.203-.25.33-.35.133-.1.282-.178.44-.23a2 2 0 0 1 .6-.08c.314-.004.626.05.92.16.278.105.53.268.74.48.217.22.387.482.5.77.122.32.183.658.18 1a2.87 2.87 0 0 1-.19 1.07 2.36 2.36 0 0 1-1.44 1.39 3.231 3.231 0 0 1-1.21.2 3.788 3.788 0 0 1-.94-.11 3 3 0 0 1-.74-.32 2.452 2.452 0 0 1-.55-.45 4.127 4.127 0 0 1-.41-.55l1.06-.81.27.41c.098.128.212.242.34.34a1.59 1.59 0 0 0 .98.3 1.29 1.29 0 0 0 1-.36 1.41 1.41 0 0 0 .33-1v-.06a1.18 1.18 0 0 0-1.28-1.27 1.44 1.44 0 0 0-.77.18c-.18.104-.342.235-.48.39l-1.19-.17.29-4.31h4.52l.02 1.26z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: Rewind5IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-rewind5-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M4 18A12 12 0 1 0 16 6h-4V1L6 7l6 6V8h4A10 10 0 1 1 6 18H4z"></path><path d="M18.58 15.58h-3.45L15 18.15a4.81 4.81 0 0 1 .26-.45c.092-.133.203-.25.33-.35.133-.1.282-.178.44-.23a2 2 0 0 1 .6-.08c.314-.004.626.05.92.16.278.105.53.268.74.48.217.22.387.482.5.77.122.32.183.658.18 1a2.87 2.87 0 0 1-.19 1.07 2.36 2.36 0 0 1-1.44 1.39 3.231 3.231 0 0 1-1.21.2 3.788 3.788 0 0 1-.94-.11 3 3 0 0 1-.74-.32 2.452 2.452 0 0 1-.55-.45 4.127 4.127 0 0 1-.41-.55l1.06-.81.27.41c.098.128.212.242.34.34a1.59 1.59 0 0 0 .98.3 1.29 1.29 0 0 0 1-.36 1.41 1.41 0 0 0 .33-1v-.06a1.18 1.18 0 0 0-1.28-1.27 1.44 1.44 0 0 0-.77.18c-.18.104-.342.235-.48.39l-1.19-.17.29-4.31h4.52l.02 1.26z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class RotateIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RotateIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: RotateIconComponent, isStandalone: true, selector: "iui-rotate-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m14.091 26.823-.346 1.968a12.896 12.896 0 0 1-4.24-1.541l1-1.731a10.91 10.91 0 0 0 3.586 1.305zM7.577 23.068l-1.532 1.285a12.981 12.981 0 0 1-2.25-3.91l1.877-.684a10.981 10.981 0 0 0 1.905 3.31zM22.495 27.25a12.896 12.896 0 0 1-4.24 1.542l-.347-1.968a10.91 10.91 0 0 0 3.587-1.305l1 1.731zM26.327 19.759l1.878.683a12.982 12.982 0 0 1-2.25 3.911l-1.531-1.285a10.983 10.983 0 0 0 1.903-3.31zM13.662 5.256c-.16.034-.315.08-.472.121a10.96 10.96 0 0 0-.633.183c-.164.054-.325.116-.486.178-.193.074-.383.15-.57.235a11.16 11.16 0 0 0-1.002.516c-.154.09-.305.18-.454.276-.168.11-.33.224-.492.341-.14.103-.282.204-.417.313-.161.13-.315.268-.47.406-.122.11-.248.217-.365.332-.167.164-.322.338-.479.512A10.944 10.944 0 0 0 5 16H3a12.936 12.936 0 0 1 3.05-8.35l-.005-.004c.092-.11.197-.206.293-.312.184-.205.367-.41.563-.603.139-.136.286-.262.43-.391.183-.165.366-.329.558-.482.16-.128.325-.247.49-.367.192-.14.385-.277.585-.406a13.513 13.513 0 0 1 1.718-.935c.222-.1.449-.191.678-.28.19-.072.378-.145.571-.208.246-.082.498-.15.75-.217.186-.049.368-.102.556-.143.29-.063.587-.107.883-.15.16-.024.315-.056.476-.073A12.933 12.933 0 0 1 26 7.703V4h2v8h-8v-2h5.189A10.962 10.962 0 0 0 16 5c-.397.001-.794.023-1.189.067-.136.014-.268.042-.403.061-.25.037-.501.075-.746.128z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RotateIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-rotate-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m14.091 26.823-.346 1.968a12.896 12.896 0 0 1-4.24-1.541l1-1.731a10.91 10.91 0 0 0 3.586 1.305zM7.577 23.068l-1.532 1.285a12.981 12.981 0 0 1-2.25-3.91l1.877-.684a10.981 10.981 0 0 0 1.905 3.31zM22.495 27.25a12.896 12.896 0 0 1-4.24 1.542l-.347-1.968a10.91 10.91 0 0 0 3.587-1.305l1 1.731zM26.327 19.759l1.878.683a12.982 12.982 0 0 1-2.25 3.911l-1.531-1.285a10.983 10.983 0 0 0 1.903-3.31zM13.662 5.256c-.16.034-.315.08-.472.121a10.96 10.96 0 0 0-.633.183c-.164.054-.325.116-.486.178-.193.074-.383.15-.57.235a11.16 11.16 0 0 0-1.002.516c-.154.09-.305.18-.454.276-.168.11-.33.224-.492.341-.14.103-.282.204-.417.313-.161.13-.315.268-.47.406-.122.11-.248.217-.365.332-.167.164-.322.338-.479.512A10.944 10.944 0 0 0 5 16H3a12.936 12.936 0 0 1 3.05-8.35l-.005-.004c.092-.11.197-.206.293-.312.184-.205.367-.41.563-.603.139-.136.286-.262.43-.391.183-.165.366-.329.558-.482.16-.128.325-.247.49-.367.192-.14.385-.277.585-.406a13.513 13.513 0 0 1 1.718-.935c.222-.1.449-.191.678-.28.19-.072.378-.145.571-.208.246-.082.498-.15.75-.217.186-.049.368-.102.556-.143.29-.063.587-.107.883-.15.16-.024.315-.056.476-.073A12.933 12.933 0 0 1 26 7.703V4h2v8h-8v-2h5.189A10.962 10.962 0 0 0 16 5c-.397.001-.794.023-1.189.067-.136.014-.268.042-.403.061-.25.037-.501.075-.746.128z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class RxIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RxIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: RxIconComponent, isStandalone: true, selector: "iui-rx-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 4a12 12 0 1 1 0 24 12 12 0 0 1 0-24zm0-2a14 14 0 1 0 0 28 14 14 0 0 0 0-28z" fill="currentColor"></path><path d="M14.18 9.23H11v8.541h1.76V14.64h1.15l2.25 3.815-2.55 4.308h2l1.64-3 1.65 3.001h2l-2.55-4.307 2.497-4.227H18.84l-1.49 2.87-1.54-2.9a2.55 2.55 0 0 0 1.19-.93c.269-.438.401-.946.38-1.46a2.31 2.31 0 0 0-.82-1.9 3.58 3.58 0 0 0-2.33-.68h-.05zm-1.41 4v-2.57h1.41a1.43 1.43 0 0 1 1.05.34 1.29 1.29 0 0 1 .34.95 1.201 1.201 0 0 1-.36.931 1.41 1.41 0 0 1-1 .34l-1.44.01z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RxIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-rx-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 4a12 12 0 1 1 0 24 12 12 0 0 1 0-24zm0-2a14 14 0 1 0 0 28 14 14 0 0 0 0-28z" fill="currentColor"></path><path d="M14.18 9.23H11v8.541h1.76V14.64h1.15l2.25 3.815-2.55 4.308h2l1.64-3 1.65 3.001h2l-2.55-4.307 2.497-4.227H18.84l-1.49 2.87-1.54-2.9a2.55 2.55 0 0 0 1.19-.93c.269-.438.401-.946.38-1.46a2.31 2.31 0 0 0-.82-1.9 3.58 3.58 0 0 0-2.33-.68h-.05zm-1.41 4v-2.57h1.41a1.43 1.43 0 0 1 1.05.34 1.29 1.29 0 0 1 .34.95 1.201 1.201 0 0 1-.36.931 1.41 1.41 0 0 1-1 .34l-1.44.01z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SaveIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SaveIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SaveIconComponent, isStandalone: true, selector: "iui-save-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m27.71 9.29-5-5A1 1 0 0 0 22 4H6a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2V10a1 1 0 0 0-.29-.71zM12 6h8v4h-8V6zm8 20h-8v-8h8v8zm2 0v-8a2 2 0 0 0-2-2h-8a2 2 0 0 0-2 2v8H6V6h4v4a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V6.41l4 4V26h-4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SaveIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-save-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m27.71 9.29-5-5A1 1 0 0 0 22 4H6a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2V10a1 1 0 0 0-.29-.71zM12 6h8v4h-8V6zm8 20h-8v-8h8v8zm2 0v-8a2 2 0 0 0-2-2h-8a2 2 0 0 0-2 2v8H6V6h4v4a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V6.41l4 4V26h-4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SdkIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SdkIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SdkIconComponent, isStandalone: true, selector: "iui-sdk-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 9h-2.1L24 15.6V9h-2v14h2v-4.3l.9-1.5 3 5.8H30l-3.9-7.6L30 9zM16 23h-4V9h4a4.012 4.012 0 0 1 4 4v6a4.012 4.012 0 0 1-4 4zm-2-2h2a2.006 2.006 0 0 0 2-2v-6a2.006 2.006 0 0 0-2-2h-2v10zM8 23H2v-2h6v-4H4a2.006 2.006 0 0 1-2-2v-4a2.006 2.006 0 0 1 2-2h6v2H4v4h4a2.006 2.006 0 0 1 2 2v4a2.006 2.006 0 0 1-2 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SdkIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-sdk-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 9h-2.1L24 15.6V9h-2v14h2v-4.3l.9-1.5 3 5.8H30l-3.9-7.6L30 9zM16 23h-4V9h4a4.012 4.012 0 0 1 4 4v6a4.012 4.012 0 0 1-4 4zm-2-2h2a2.006 2.006 0 0 0 2-2v-6a2.006 2.006 0 0 0-2-2h-2v10zM8 23H2v-2h6v-4H4a2.006 2.006 0 0 1-2-2v-4a2.006 2.006 0 0 1 2-2h6v2H4v4h4a2.006 2.006 0 0 1 2 2v4a2.006 2.006 0 0 1-2 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SearchIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SearchIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SearchIconComponent, isStandalone: true, selector: "iui-search-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 28.59 22.45 21A11 11 0 1 0 21 22.45L28.59 30 30 28.59zM5 14a9 9 0 1 1 18 0 9 9 0 0 1-18 0z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SearchIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-search-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 28.59 22.45 21A11 11 0 1 0 21 22.45L28.59 30 30 28.59zM5 14a9 9 0 1 1 18 0 9 9 0 0 1-18 0z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SendFilledIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SendFilledIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SendFilledIconComponent, isStandalone: true, selector: "iui-send-filled-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m27.45 15.11-22-11a1 1 0 0 0-1.08.12 1 1 0 0 0-.33 1L6.69 15H18v2H6.69L4 26.74A1 1 0 0 0 5 28a1 1 0 0 0 .45-.11l22-11a1 1 0 0 0 0-1.78z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SendFilledIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-send-filled-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m27.45 15.11-22-11a1 1 0 0 0-1.08.12 1 1 0 0 0-.33 1L6.69 15H18v2H6.69L4 26.74A1 1 0 0 0 5 28a1 1 0 0 0 .45-.11l22-11a1 1 0 0 0 0-1.78z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SendOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SendOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SendOutlineIconComponent, isStandalone: true, selector: "iui-send-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m27.45 15.11-22-11a1 1 0 0 0-1.08.12 1 1 0 0 0-.33 1L7 16 4 26.74A1 1 0 0 0 5 28a1 1 0 0 0 .45-.11l22-11a1 1 0 0 0 0-1.78zm-20.9 10L8.76 17H18v-2H8.76L6.55 6.89 24.76 16 6.55 25.11z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SendOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-send-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m27.45 15.11-22-11a1 1 0 0 0-1.08.12 1 1 0 0 0-.33 1L7 16 4 26.74A1 1 0 0 0 5 28a1 1 0 0 0 .45-.11l22-11a1 1 0 0 0 0-1.78zm-20.9 10L8.76 17H18v-2H8.76L6.55 6.89 24.76 16 6.55 25.11z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SettingsIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SettingsIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SettingsIconComponent, isStandalone: true, selector: "iui-settings-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27 16.76v-1.53l1.92-1.68A2 2 0 0 0 29.3 11l-2.36-4a2 2 0 0 0-1.73-1 2 2 0 0 0-.64.1l-2.43.82c-.42-.279-.857-.53-1.31-.75l-.51-2.52a2 2 0 0 0-2-1.61h-4.68a2 2 0 0 0-2 1.61l-.51 2.52c-.456.22-.897.471-1.32.75l-2.38-.86A2 2 0 0 0 6.79 6a2 2 0 0 0-1.73 1L2.7 11a2 2 0 0 0 .41 2.51L5 15.24v1.53l-1.89 1.68A2 2 0 0 0 2.7 21l2.36 4a2 2 0 0 0 1.73 1c.217.002.434-.032.64-.1l2.43-.82c.42.279.857.53 1.31.75l.51 2.52a2 2 0 0 0 2 1.61h4.72a2 2 0 0 0 2-1.61l.51-2.52c.456-.22.897-.471 1.32-.75l2.42.82c.207.068.423.102.64.1a2 2 0 0 0 1.73-1l2.28-4a2 2 0 0 0-.41-2.51L27 16.76zM25.21 24l-3.43-1.16a8.859 8.859 0 0 1-2.71 1.57L18.36 28h-4.72l-.71-3.55a9.358 9.358 0 0 1-2.7-1.57L6.79 24l-2.36-4 2.72-2.4a8.9 8.9 0 0 1 0-3.13L4.43 12l2.36-4 3.43 1.16a8.86 8.86 0 0 1 2.71-1.57L13.64 4h4.72l.71 3.55a9.36 9.36 0 0 1 2.7 1.57L25.21 8l2.36 4-2.72 2.4a8.9 8.9 0 0 1 0 3.13L27.57 20l-2.36 4z" fill="currentColor"></path><path d="M16 22a6 6 0 1 1 6-6 5.94 5.94 0 0 1-6 6zm0-10a3.91 3.91 0 0 0-4 4 3.91 3.91 0 0 0 4 4 3.91 3.91 0 0 0 4-4 3.91 3.91 0 0 0-4-4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SettingsIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-settings-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27 16.76v-1.53l1.92-1.68A2 2 0 0 0 29.3 11l-2.36-4a2 2 0 0 0-1.73-1 2 2 0 0 0-.64.1l-2.43.82c-.42-.279-.857-.53-1.31-.75l-.51-2.52a2 2 0 0 0-2-1.61h-4.68a2 2 0 0 0-2 1.61l-.51 2.52c-.456.22-.897.471-1.32.75l-2.38-.86A2 2 0 0 0 6.79 6a2 2 0 0 0-1.73 1L2.7 11a2 2 0 0 0 .41 2.51L5 15.24v1.53l-1.89 1.68A2 2 0 0 0 2.7 21l2.36 4a2 2 0 0 0 1.73 1c.217.002.434-.032.64-.1l2.43-.82c.42.279.857.53 1.31.75l.51 2.52a2 2 0 0 0 2 1.61h4.72a2 2 0 0 0 2-1.61l.51-2.52c.456-.22.897-.471 1.32-.75l2.42.82c.207.068.423.102.64.1a2 2 0 0 0 1.73-1l2.28-4a2 2 0 0 0-.41-2.51L27 16.76zM25.21 24l-3.43-1.16a8.859 8.859 0 0 1-2.71 1.57L18.36 28h-4.72l-.71-3.55a9.358 9.358 0 0 1-2.7-1.57L6.79 24l-2.36-4 2.72-2.4a8.9 8.9 0 0 1 0-3.13L4.43 12l2.36-4 3.43 1.16a8.86 8.86 0 0 1 2.71-1.57L13.64 4h4.72l.71 3.55a9.36 9.36 0 0 1 2.7 1.57L25.21 8l2.36 4-2.72 2.4a8.9 8.9 0 0 1 0 3.13L27.57 20l-2.36 4z" fill="currentColor"></path><path d="M16 22a6 6 0 1 1 6-6 5.94 5.94 0 0 1-6 6zm0-10a3.91 3.91 0 0 0-4 4 3.91 3.91 0 0 0 4 4 3.91 3.91 0 0 0 4-4 3.91 3.91 0 0 0-4-4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ShareIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShareIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ShareIconComponent, isStandalone: true, selector: "iui-share-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 20a5 5 0 0 0-3.89 1.89l-7.31-4.57a4.46 4.46 0 0 0 0-2.64l7.31-4.57A5 5 0 1 0 18 7c.005.447.072.891.2 1.32l-7.31 4.57a5 5 0 1 0 0 6.22l7.31 4.57A4.788 4.788 0 0 0 18 25a5 5 0 1 0 5-5zm0-16a3 3 0 1 1 0 6 3 3 0 0 1 0-6zM7 19a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm16 9a3 3 0 1 1 0-5.999A3 3 0 0 1 23 28z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShareIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-share-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 20a5 5 0 0 0-3.89 1.89l-7.31-4.57a4.46 4.46 0 0 0 0-2.64l7.31-4.57A5 5 0 1 0 18 7c.005.447.072.891.2 1.32l-7.31 4.57a5 5 0 1 0 0 6.22l7.31 4.57A4.788 4.788 0 0 0 18 25a5 5 0 1 0 5-5zm0-16a3 3 0 1 1 0 6 3 3 0 0 1 0-6zM7 19a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm16 9a3 3 0 1 1 0-5.999A3 3 0 0 1 23 28z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ShoppingBagIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingBagIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ShoppingBagIconComponent, isStandalone: true, selector: "iui-shopping-bag-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28.76 11.35A1 1 0 0 0 28 11h-6V7a3 3 0 0 0-3-3h-6a3 3 0 0 0-3 3v4H4a1.001 1.001 0 0 0-1 1.15L4.88 24.3a2 2 0 0 0 2 1.7h18.26a2 2 0 0 0 2-1.7L29 12.15a1.001 1.001 0 0 0-.24-.8zM12 7a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v4h-8V7zm13.14 17H6.86L5.17 13h21.66l-1.69 11z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingBagIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-shopping-bag-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28.76 11.35A1 1 0 0 0 28 11h-6V7a3 3 0 0 0-3-3h-6a3 3 0 0 0-3 3v4H4a1.001 1.001 0 0 0-1 1.15L4.88 24.3a2 2 0 0 0 2 1.7h18.26a2 2 0 0 0 2-1.7L29 12.15a1.001 1.001 0 0 0-.24-.8zM12 7a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v4h-8V7zm13.14 17H6.86L5.17 13h21.66l-1.69 11z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ShoppingCartAddIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartAddIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ShoppingCartAddIconComponent, isStandalone: true, selector: "iui-shopping-cart-add-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM4.98 2.804A1 1 0 0 0 4 2H0v2h3.18l3.84 19.196A1 1 0 0 0 8 24h18v-2H8.82l-.8-4H26a1 1 0 0 0 .976-.783L29.244 7h-2.047l-1.999 9H7.62L4.98 2.804z" fill="currentColor"></path><path d="M18 6V2h-2v4h-4v2h4v4h2V8h4V6h-4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartAddIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-shopping-cart-add-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM4.98 2.804A1 1 0 0 0 4 2H0v2h3.18l3.84 19.196A1 1 0 0 0 8 24h18v-2H8.82l-.8-4H26a1 1 0 0 0 .976-.783L29.244 7h-2.047l-1.999 9H7.62L4.98 2.804z" fill="currentColor"></path><path d="M18 6V2h-2v4h-4v2h4v4h2V8h4V6h-4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ShoppingCartArrowDownIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartArrowDownIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ShoppingCartArrowDownIconComponent, isStandalone: true, selector: "iui-shopping-cart-arrow-down-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM4.98 2.804A1 1 0 0 0 4 2H0v2h3.18l3.84 19.196A1 1 0 0 0 8 24h18v-2H8.82l-.8-4H26a1 1 0 0 0 .976-.783L29.244 7h-2.047l-1.999 9H7.62L4.98 2.804z" fill="currentColor"></path><path d="M21.586 6.586 18 10.172V2h-2v8.172l-3.586-3.586L11 8l6 6 6-6-1.414-1.414z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartArrowDownIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-shopping-cart-arrow-down-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM4.98 2.804A1 1 0 0 0 4 2H0v2h3.18l3.84 19.196A1 1 0 0 0 8 24h18v-2H8.82l-.8-4H26a1 1 0 0 0 .976-.783L29.244 7h-2.047l-1.999 9H7.62L4.98 2.804z" fill="currentColor"></path><path d="M21.586 6.586 18 10.172V2h-2v8.172l-3.586-3.586L11 8l6 6 6-6-1.414-1.414z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ShoppingCartArrowUpIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartArrowUpIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ShoppingCartArrowUpIconComponent, isStandalone: true, selector: "iui-shopping-cart-arrow-up-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM4.98 2.804A1 1 0 0 0 4 2H0v2h3.18l3.84 19.196A1 1 0 0 0 8 24h18v-2H8.82l-.8-4H26a1 1 0 0 0 .976-.783L29.244 7h-2.047l-1.999 9H7.62L4.98 2.804z" fill="currentColor"></path><path d="M21.586 9.414 18 5.828V14h-2V5.828l-3.586 3.586L11 8l6-6 6 6-1.414 1.414z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartArrowUpIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-shopping-cart-arrow-up-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM4.98 2.804A1 1 0 0 0 4 2H0v2h3.18l3.84 19.196A1 1 0 0 0 8 24h18v-2H8.82l-.8-4H26a1 1 0 0 0 .976-.783L29.244 7h-2.047l-1.999 9H7.62L4.98 2.804z" fill="currentColor"></path><path d="M21.586 9.414 18 5.828V14h-2V5.828l-3.586 3.586L11 8l6-6 6 6-1.414 1.414z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ShoppingCartClearIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartClearIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ShoppingCartClearIconComponent, isStandalone: true, selector: "iui-shopping-cart-clear-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM4.98 2.804A1 1 0 0 0 4 2H0v2h3.18l3.84 19.196A1 1 0 0 0 8 24h18v-2H8.82l-.8-4H26a1 1 0 0 0 .976-.783L29.244 7h-2.047l-1.999 9H7.62L4.98 2.804z" fill="currentColor"></path><path d="M18.41 8 22 4.41 20.59 3 17 6.59 13.41 3 12 4.41 15.59 8 12 11.59 13.41 13 17 9.41 20.59 13 22 11.59 18.41 8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartClearIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-shopping-cart-clear-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM4.98 2.804A1 1 0 0 0 4 2H0v2h3.18l3.84 19.196A1 1 0 0 0 8 24h18v-2H8.82l-.8-4H26a1 1 0 0 0 .976-.783L29.244 7h-2.047l-1.999 9H7.62L4.98 2.804z" fill="currentColor"></path><path d="M18.41 8 22 4.41 20.59 3 17 6.59 13.41 3 12 4.41 15.59 8 12 11.59 13.41 13 17 9.41 20.59 13 22 11.59 18.41 8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ShoppingCartErrorIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartErrorIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ShoppingCartErrorIconComponent, isStandalone: true, selector: "iui-shopping-cart-error-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM4.98 2.804A1 1 0 0 0 4 2H0v2h3.18l3.84 19.196A1 1 0 0 0 8 24h18v-2H8.82l-.8-4H26a1 1 0 0 0 .976-.783L29.244 7h-2.047l-1.999 9H7.62L4.98 2.804z" fill="currentColor"></path><path d="M17 2a6 6 0 1 0 6 6 6.006 6.006 0 0 0-6-6zm0 2c.712.004 1.41.2 2.019.567l-5.452 5.452A3.952 3.952 0 0 1 13 8a4.004 4.004 0 0 1 4-4zm0 8a3.952 3.952 0 0 1-2.019-.567l5.452-5.452c.367.61.563 1.307.567 2.019a4.004 4.004 0 0 1-4 4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartErrorIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-shopping-cart-error-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM4.98 2.804A1 1 0 0 0 4 2H0v2h3.18l3.84 19.196A1 1 0 0 0 8 24h18v-2H8.82l-.8-4H26a1 1 0 0 0 .976-.783L29.244 7h-2.047l-1.999 9H7.62L4.98 2.804z" fill="currentColor"></path><path d="M17 2a6 6 0 1 0 6 6 6.006 6.006 0 0 0-6-6zm0 2c.712.004 1.41.2 2.019.567l-5.452 5.452A3.952 3.952 0 0 1 13 8a4.004 4.004 0 0 1 4-4zm0 8a3.952 3.952 0 0 1-2.019-.567l5.452-5.452c.367.61.563 1.307.567 2.019a4.004 4.004 0 0 1-4 4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ShoppingCartIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ShoppingCartIconComponent, isStandalone: true, selector: "iui-shopping-cart-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM28 7H5.82L5 2.8A1 1 0 0 0 4 2H0v2h3.18L7 23.2a1 1 0 0 0 1 .8h18v-2H8.82L8 18h18a1 1 0 0 0 1-.78l2-9A1 1 0 0 0 28 7zm-2.8 9H7.62l-1.4-7h20.53l-1.55 7z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-shopping-cart-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM28 7H5.82L5 2.8A1 1 0 0 0 4 2H0v2h3.18L7 23.2a1 1 0 0 0 1 .8h18v-2H8.82L8 18h18a1 1 0 0 0 1-.78l2-9A1 1 0 0 0 28 7zm-2.8 9H7.62l-1.4-7h20.53l-1.55 7z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ShoppingCartSubtractIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartSubtractIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ShoppingCartSubtractIconComponent, isStandalone: true, selector: "iui-shopping-cart-subtract-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM4.98 2.804A1 1 0 0 0 4 2H0v2h3.18l3.84 19.196A1 1 0 0 0 8 24h18v-2H8.82l-.8-4H26a1 1 0 0 0 .976-.783L29.244 7h-2.047l-1.999 9H7.62L4.98 2.804z" fill="currentColor"></path><path d="M12 6v2h10V6H12z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShoppingCartSubtractIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-shopping-cart-subtract-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M10 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM24 30a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM4.98 2.804A1 1 0 0 0 4 2H0v2h3.18l3.84 19.196A1 1 0 0 0 8 24h18v-2H8.82l-.8-4H26a1 1 0 0 0 .976-.783L29.244 7h-2.047l-1.999 9H7.62L4.98 2.804z" fill="currentColor"></path><path d="M12 6v2h10V6H12z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ShrinkScreenFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShrinkScreenFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ShrinkScreenFillIconComponent, isStandalone: true, selector: "iui-shrink-screen-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 18H17a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2zM12 10v3.586L7.707 9.293l-1.414 1.414L10.586 15H7v2h7v-7h-2z" fill="currentColor"></path><path d="M13 22H4a2.002 2.002 0 0 1-2-2V7a2.002 2.002 0 0 1 2-2h22a2.002 2.002 0 0 1 2 2v9h-2V7H4v13h9v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShrinkScreenFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-shrink-screen-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 18H17a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2zM12 10v3.586L7.707 9.293l-1.414 1.414L10.586 15H7v2h7v-7h-2z" fill="currentColor"></path><path d="M13 22H4a2.002 2.002 0 0 1-2-2V7a2.002 2.002 0 0 1 2-2h22a2.002 2.002 0 0 1 2 2v9h-2V7H4v13h9v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ShrinkScreenOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShrinkScreenOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ShrinkScreenOutlineIconComponent, isStandalone: true, selector: "iui-shrink-screen-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 28H17a2.002 2.002 0 0 1-2-2v-6a2.002 2.002 0 0 1 2-2h11a2.003 2.003 0 0 1 2 2v6a2.003 2.003 0 0 1-2 2zm-11-8v6h11.002L28 20H17zM12 10v3.586L7.707 9.293l-1.414 1.414L10.586 15H7v2h7v-7h-2z" fill="currentColor"></path><path d="M13 22H4a2.002 2.002 0 0 1-2-2V7a2.002 2.002 0 0 1 2-2h22a2.002 2.002 0 0 1 2 2v9h-2V7H4v13h9v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShrinkScreenOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-shrink-screen-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 28H17a2.002 2.002 0 0 1-2-2v-6a2.002 2.002 0 0 1 2-2h11a2.003 2.003 0 0 1 2 2v6a2.003 2.003 0 0 1-2 2zm-11-8v6h11.002L28 20H17zM12 10v3.586L7.707 9.293l-1.414 1.414L10.586 15H7v2h7v-7h-2z" fill="currentColor"></path><path d="M13 22H4a2.002 2.002 0 0 1-2-2V7a2.002 2.002 0 0 1 2-2h22a2.002 2.002 0 0 1 2 2v9h-2V7H4v13h9v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SkipBackFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SkipBackFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SkipBackFillIconComponent, isStandalone: true, selector: "iui-skip-back-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27 28a.998.998 0 0 1-.501-.135l-19-11a1 1 0 0 1 0-1.73l19-11A1 1 0 0 1 28 5v22a1 1 0 0 1-1 1zM4 4H2v24h2V4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SkipBackFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-skip-back-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27 28a.998.998 0 0 1-.501-.135l-19-11a1 1 0 0 1 0-1.73l19-11A1 1 0 0 1 28 5v22a1 1 0 0 1-1 1zM4 4H2v24h2V4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SkipBackOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SkipBackOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SkipBackOutlineIconComponent, isStandalone: true, selector: "iui-skip-back-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27 28a1 1 0 0 1-.5-.13l-19-11a1 1 0 0 1 0-1.74l19-11A1 1 0 0 1 28 5v22a1 1 0 0 1-1 1zM10 16l16 9.27V6.73L10 16zM4 4H2v24h2V4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SkipBackOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-skip-back-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27 28a1 1 0 0 1-.5-.13l-19-11a1 1 0 0 1 0-1.74l19-11A1 1 0 0 1 28 5v22a1 1 0 0 1-1 1zM10 16l16 9.27V6.73L10 16zM4 4H2v24h2V4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SkipForwardFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SkipForwardFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SkipForwardFillIconComponent, isStandalone: true, selector: "iui-skip-forward-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 4h-2v24h2V4zM5 28a1 1 0 0 1-1-1V5a1 1 0 0 1 1.501-.865l19 11a1 1 0 0 1 0 1.73l-19 11A.997.997 0 0 1 5 28z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SkipForwardFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-skip-forward-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 4h-2v24h2V4zM5 28a1 1 0 0 1-1-1V5a1 1 0 0 1 1.501-.865l19 11a1 1 0 0 1 0 1.73l-19 11A.997.997 0 0 1 5 28z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SkipForwardOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SkipForwardOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SkipForwardOutlineIconComponent, isStandalone: true, selector: "iui-skip-forward-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M5 28a1 1 0 0 1-1-1V5a1 1 0 0 1 1.5-.87l19 11a1 1 0 0 1 0 1.74l-19 11A1 1 0 0 1 5 28zM6 6.73v18.54L22 16 6 6.73zM30 4h-2v24h2V4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SkipForwardOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-skip-forward-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M5 28a1 1 0 0 1-1-1V5a1 1 0 0 1 1.5-.87l19 11a1 1 0 0 1 0 1.74l-19 11A1 1 0 0 1 5 28zM6 6.73v18.54L22 16 6 6.73zM30 4h-2v24h2V4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SkypeIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SkypeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SkypeIconComponent, isStandalone: true, selector: "iui-skype-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27.91 17.88c.1-.622.15-1.25.15-1.88A12.06 12.06 0 0 0 16 3.94a11.63 11.63 0 0 0-1.88.15 7.29 7.29 0 0 0-10 10A11.63 11.63 0 0 0 3.94 16 12.06 12.06 0 0 0 16 28.06c.63.001 1.258-.05 1.88-.15a7.29 7.29 0 0 0 10-10l.03-.03zm-6.18 3.6a5 5 0 0 1-2.24 1.73 9 9 0 0 1-3.48.62A8.41 8.41 0 0 1 12 23a5.2 5.2 0 0 1-1.82-1.63 3.59 3.59 0 0 1-.7-2 1.36 1.36 0 0 1 .43-1A1.56 1.56 0 0 1 11 18a1.38 1.38 0 0 1 .91.32 2.5 2.5 0 0 1 .63.94c.173.418.395.814.66 1.18a2.61 2.61 0 0 0 1 .78 3.87 3.87 0 0 0 1.69.31 4 4 0 0 0 2.34-.62 1.8 1.8 0 0 0 .89-1.53 1.54 1.54 0 0 0-.47-1.17 3.09 3.09 0 0 0-1.25-.7c-.52-.17-1.21-.34-2.08-.53-1-.233-1.974-.56-2.91-.98a4.781 4.781 0 0 1-1.89-1.4 3.5 3.5 0 0 1-.7-2.21 3.65 3.65 0 0 1 .74-2.24 4.7 4.7 0 0 1 2.14-1.5 9.51 9.51 0 0 1 3.3-.48 8.63 8.63 0 0 1 2.59.35 5.81 5.81 0 0 1 1.83.92 3.91 3.91 0 0 1 1.06 1.21c.216.382.333.811.34 1.25a1.398 1.398 0 0 1-.43 1 1.43 1.43 0 0 1-1.07.46 1.25 1.25 0 0 1-.89-.28 3.361 3.361 0 0 1-.65-.87 3.788 3.788 0 0 0-1.05-1.31 3.13 3.13 0 0 0-1.95-.46 3.64 3.64 0 0 0-2 .5 1.44 1.44 0 0 0-.76 1.2c-.008.272.08.537.25.75.2.231.444.418.72.55.293.152.602.272.92.36.32.09.84.22 1.57.39.92.2 1.74.42 2.49.66.67.204 1.31.5 1.9.88.514.325.938.776 1.23 1.31.297.609.435 1.283.4 1.96.009.887-.26 1.754-.77 2.48z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SkypeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-skype-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27.91 17.88c.1-.622.15-1.25.15-1.88A12.06 12.06 0 0 0 16 3.94a11.63 11.63 0 0 0-1.88.15 7.29 7.29 0 0 0-10 10A11.63 11.63 0 0 0 3.94 16 12.06 12.06 0 0 0 16 28.06c.63.001 1.258-.05 1.88-.15a7.29 7.29 0 0 0 10-10l.03-.03zm-6.18 3.6a5 5 0 0 1-2.24 1.73 9 9 0 0 1-3.48.62A8.41 8.41 0 0 1 12 23a5.2 5.2 0 0 1-1.82-1.63 3.59 3.59 0 0 1-.7-2 1.36 1.36 0 0 1 .43-1A1.56 1.56 0 0 1 11 18a1.38 1.38 0 0 1 .91.32 2.5 2.5 0 0 1 .63.94c.173.418.395.814.66 1.18a2.61 2.61 0 0 0 1 .78 3.87 3.87 0 0 0 1.69.31 4 4 0 0 0 2.34-.62 1.8 1.8 0 0 0 .89-1.53 1.54 1.54 0 0 0-.47-1.17 3.09 3.09 0 0 0-1.25-.7c-.52-.17-1.21-.34-2.08-.53-1-.233-1.974-.56-2.91-.98a4.781 4.781 0 0 1-1.89-1.4 3.5 3.5 0 0 1-.7-2.21 3.65 3.65 0 0 1 .74-2.24 4.7 4.7 0 0 1 2.14-1.5 9.51 9.51 0 0 1 3.3-.48 8.63 8.63 0 0 1 2.59.35 5.81 5.81 0 0 1 1.83.92 3.91 3.91 0 0 1 1.06 1.21c.216.382.333.811.34 1.25a1.398 1.398 0 0 1-.43 1 1.43 1.43 0 0 1-1.07.46 1.25 1.25 0 0 1-.89-.28 3.361 3.361 0 0 1-.65-.87 3.788 3.788 0 0 0-1.05-1.31 3.13 3.13 0 0 0-1.95-.46 3.64 3.64 0 0 0-2 .5 1.44 1.44 0 0 0-.76 1.2c-.008.272.08.537.25.75.2.231.444.418.72.55.293.152.602.272.92.36.32.09.84.22 1.57.39.92.2 1.74.42 2.49.66.67.204 1.31.5 1.9.88.514.325.938.776 1.23 1.31.297.609.435 1.283.4 1.96.009.887-.26 1.754-.77 2.48z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SlackIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SlackIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SlackIconComponent, isStandalone: true, selector: "iui-slack-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M9.042 19.166a2.521 2.521 0 1 1-2.52-2.521h2.52v2.521zM10.313 19.166a2.521 2.521 0 0 1 5.042 0v6.313a2.522 2.522 0 1 1-5.042 0v-6.313zM12.834 9.042a2.521 2.521 0 1 1 2.521-2.52v2.52h-2.521zM12.834 10.313a2.521 2.521 0 0 1 0 5.042H6.52a2.522 2.522 0 1 1 0-5.042h6.313zM22.958 12.834a2.52 2.52 0 1 1 2.52 2.521h-2.52v-2.521zM21.687 12.834a2.521 2.521 0 0 1-5.042 0V6.52a2.522 2.522 0 1 1 5.042 0v6.313zM19.166 22.958a2.521 2.521 0 1 1-2.521 2.52v-2.52h2.521zM19.166 21.687a2.521 2.521 0 0 1 0-5.042h6.313a2.522 2.522 0 1 1 0 5.042h-6.313z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SlackIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-slack-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M9.042 19.166a2.521 2.521 0 1 1-2.52-2.521h2.52v2.521zM10.313 19.166a2.521 2.521 0 0 1 5.042 0v6.313a2.522 2.522 0 1 1-5.042 0v-6.313zM12.834 9.042a2.521 2.521 0 1 1 2.521-2.52v2.52h-2.521zM12.834 10.313a2.521 2.521 0 0 1 0 5.042H6.52a2.522 2.522 0 1 1 0-5.042h6.313zM22.958 12.834a2.52 2.52 0 1 1 2.52 2.521h-2.52v-2.521zM21.687 12.834a2.521 2.521 0 0 1-5.042 0V6.52a2.522 2.522 0 1 1 5.042 0v6.313zM19.166 22.958a2.521 2.521 0 1 1-2.521 2.52v-2.52h2.521zM19.166 21.687a2.521 2.521 0 0 1 0-5.042h6.313a2.522 2.522 0 1 1 0 5.042h-6.313z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SnapchatIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SnapchatIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SnapchatIconComponent, isStandalone: true, selector: "iui-snapchat-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27.977 9.628a7.33 7.33 0 0 0-.118-1.289 5.245 5.245 0 0 0-.487-1.495 5.187 5.187 0 0 0-1-1.332 4.956 4.956 0 0 0-2.18-1.243 8.845 8.845 0 0 0-2.306-.246l-.004-.012H10.114v.012c-.442-.004-.883.016-1.323.059A6.296 6.296 0 0 0 7.38 4.4a5.116 5.116 0 0 0-3.125 3.415 8.8 8.8 0 0 0-.246 2.286L4 21.907c.008.534.044 1.068.109 1.599.08.56.246 1.104.491 1.614a5.17 5.17 0 0 0 1.443 1.744c.432.344.92.609 1.444.783.769.237 1.57.355 2.374.348.504.003 1.007.016 1.51.014 3.66-.016 7.319.026 10.978-.023a8.63 8.63 0 0 0 1.44-.153 4.877 4.877 0 0 0 2.411-1.172 4.992 4.992 0 0 0 1.593-2.654c.146-.69.215-1.395.207-2.1v-.141c0-.055-.02-11.98-.023-12.138zm-3.213 11.105c-.154.36-.93.657-2.244.86-.123.02-.175.218-.246.545-.03.134-.06.267-.1.405a.245.245 0 0 1-.26.195h-.02a2.1 2.1 0 0 1-.374-.047 4.92 4.92 0 0 0-.986-.105c-.238 0-.475.02-.71.06-.496.126-.957.361-1.349.689a3.913 3.913 0 0 1-2.366.933c-.05 0-.098-.002-.134-.004a1.063 1.063 0 0 1-.088.004 3.906 3.906 0 0 1-2.365-.933 3.412 3.412 0 0 0-1.35-.69 4.364 4.364 0 0 0-.71-.06c-.331.004-.662.041-.985.112a2.191 2.191 0 0 1-.374.054.258.258 0 0 1-.28-.202c-.042-.14-.072-.277-.1-.408-.072-.328-.124-.528-.247-.547-1.313-.203-2.09-.501-2.244-.863a.335.335 0 0 1-.027-.114.21.21 0 0 1 .176-.22 4.586 4.586 0 0 0 2.757-1.639c.38-.44.697-.932.94-1.461l.004-.01a.943.943 0 0 0 .09-.79c-.169-.4-.73-.577-1.1-.695a3.842 3.842 0 0 1-.25-.084c-.328-.13-.868-.404-.796-.783a.734.734 0 0 1 .712-.468.505.505 0 0 1 .216.043c.277.141.581.222.892.235a.747.747 0 0 0 .513-.157c-.01-.175-.02-.35-.032-.525a8.875 8.875 0 0 1 .213-3.545 4.607 4.607 0 0 1 4.277-2.758l.354-.003a4.615 4.615 0 0 1 4.285 2.76 8.885 8.885 0 0 1 .212 3.548l-.003.058-.028.466c.132.105.297.16.465.156.293-.022.579-.102.84-.234a.662.662 0 0 1 .276-.055c.107 0 .213.02.313.06l.005.002a.582.582 0 0 1 .44.478c.004.184-.132.458-.803.723a4.055 4.055 0 0 1-.249.084c-.371.118-.931.296-1.1.695a.943.943 0 0 0 .09.789l.004.01a5.431 5.431 0 0 0 3.697 3.1.21.21 0 0 1 .176.22.342.342 0 0 1-.027.116z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SnapchatIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-snapchat-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M27.977 9.628a7.33 7.33 0 0 0-.118-1.289 5.245 5.245 0 0 0-.487-1.495 5.187 5.187 0 0 0-1-1.332 4.956 4.956 0 0 0-2.18-1.243 8.845 8.845 0 0 0-2.306-.246l-.004-.012H10.114v.012c-.442-.004-.883.016-1.323.059A6.296 6.296 0 0 0 7.38 4.4a5.116 5.116 0 0 0-3.125 3.415 8.8 8.8 0 0 0-.246 2.286L4 21.907c.008.534.044 1.068.109 1.599.08.56.246 1.104.491 1.614a5.17 5.17 0 0 0 1.443 1.744c.432.344.92.609 1.444.783.769.237 1.57.355 2.374.348.504.003 1.007.016 1.51.014 3.66-.016 7.319.026 10.978-.023a8.63 8.63 0 0 0 1.44-.153 4.877 4.877 0 0 0 2.411-1.172 4.992 4.992 0 0 0 1.593-2.654c.146-.69.215-1.395.207-2.1v-.141c0-.055-.02-11.98-.023-12.138zm-3.213 11.105c-.154.36-.93.657-2.244.86-.123.02-.175.218-.246.545-.03.134-.06.267-.1.405a.245.245 0 0 1-.26.195h-.02a2.1 2.1 0 0 1-.374-.047 4.92 4.92 0 0 0-.986-.105c-.238 0-.475.02-.71.06-.496.126-.957.361-1.349.689a3.913 3.913 0 0 1-2.366.933c-.05 0-.098-.002-.134-.004a1.063 1.063 0 0 1-.088.004 3.906 3.906 0 0 1-2.365-.933 3.412 3.412 0 0 0-1.35-.69 4.364 4.364 0 0 0-.71-.06c-.331.004-.662.041-.985.112a2.191 2.191 0 0 1-.374.054.258.258 0 0 1-.28-.202c-.042-.14-.072-.277-.1-.408-.072-.328-.124-.528-.247-.547-1.313-.203-2.09-.501-2.244-.863a.335.335 0 0 1-.027-.114.21.21 0 0 1 .176-.22 4.586 4.586 0 0 0 2.757-1.639c.38-.44.697-.932.94-1.461l.004-.01a.943.943 0 0 0 .09-.79c-.169-.4-.73-.577-1.1-.695a3.842 3.842 0 0 1-.25-.084c-.328-.13-.868-.404-.796-.783a.734.734 0 0 1 .712-.468.505.505 0 0 1 .216.043c.277.141.581.222.892.235a.747.747 0 0 0 .513-.157c-.01-.175-.02-.35-.032-.525a8.875 8.875 0 0 1 .213-3.545 4.607 4.607 0 0 1 4.277-2.758l.354-.003a4.615 4.615 0 0 1 4.285 2.76 8.885 8.885 0 0 1 .212 3.548l-.003.058-.028.466c.132.105.297.16.465.156.293-.022.579-.102.84-.234a.662.662 0 0 1 .276-.055c.107 0 .213.02.313.06l.005.002a.582.582 0 0 1 .44.478c.004.184-.132.458-.803.723a4.055 4.055 0 0 1-.249.084c-.371.118-.931.296-1.1.695a.943.943 0 0 0 .09.789l.004.01a5.431 5.431 0 0 0 3.697 3.1.21.21 0 0 1 .176.22.342.342 0 0 1-.027.116z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SortAscendingIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SortAscendingIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SortAscendingIconComponent, isStandalone: true, selector: "iui-sort-ascending-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m18 22 1.414-1.414L23 24.172V4h2v20.172l3.586-3.586L30 22l-6 6-6-6zM16 18H2v2h14v-2zM16 12H6v2h10v-2zM16 6h-6v2h6V6z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SortAscendingIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-sort-ascending-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m18 22 1.414-1.414L23 24.172V4h2v20.172l3.586-3.586L30 22l-6 6-6-6zM16 18H2v2h14v-2zM16 12H6v2h10v-2zM16 6h-6v2h6V6z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SortDescendingIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SortDescendingIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SortDescendingIconComponent, isStandalone: true, selector: "iui-sort-descending-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m18 22 1.414-1.414L23 24.172V4h2v20.172l3.586-3.586L30 22l-6 6-6-6zM16 6H2v2h14V6zM16 12H6v2h10v-2zM16 18h-6v2h6v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SortDescendingIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-sort-descending-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m18 22 1.414-1.414L23 24.172V4h2v20.172l3.586-3.586L30 22l-6 6-6-6zM16 6H2v2h14V6zM16 12H6v2h10v-2zM16 18h-6v2h6v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SqlIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SqlIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SqlIconComponent, isStandalone: true, selector: "iui-sql-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 21V9h-2v14h8v-2h-6zM18 9h-4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h1v2a2 2 0 0 0 2 2h2v-2h-2v-2h1a2 2 0 0 0 2-2V11a2 2 0 0 0-2-2zm-4 12V11h4v10h-4zM8 23H2v-2h6v-4H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h6v2H4v4h4a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SqlIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-sql-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 21V9h-2v14h8v-2h-6zM18 9h-4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h1v2a2 2 0 0 0 2 2h2v-2h-2v-2h1a2 2 0 0 0 2-2V11a2 2 0 0 0-2-2zm-4 12V11h4v10h-4zM8 23H2v-2h6v-4H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h6v2H4v4h4a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class StarFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: StarFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: StarFillIconComponent, isStandalone: true, selector: "iui-star-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m16 2-4.55 9.22-10.17 1.47 7.36 7.18L6.9 30l9.1-4.78L25.1 30l-1.74-10.13 7.36-7.17-10.17-1.48L16 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: StarFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-star-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m16 2-4.55 9.22-10.17 1.47 7.36 7.18L6.9 30l9.1-4.78L25.1 30l-1.74-10.13 7.36-7.17-10.17-1.48L16 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class StarHalfIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: StarHalfIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: StarHalfIconComponent, isStandalone: true, selector: "iui-star-half-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m16 6.52 2.76 5.58.46 1 1 .15 6.16.89-4.38 4.3-.75.73.18 1 1.05 6.13-5.51-2.89L16 23V6.52zM16 2l-4.55 9.22-10.17 1.47 7.36 7.18L6.9 30l9.1-4.78L25.1 30l-1.74-10.13 7.36-7.17-10.17-1.48L16 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: StarHalfIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-star-half-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m16 6.52 2.76 5.58.46 1 1 .15 6.16.89-4.38 4.3-.75.73.18 1 1.05 6.13-5.51-2.89L16 23V6.52zM16 2l-4.55 9.22-10.17 1.47 7.36 7.18L6.9 30l9.1-4.78L25.1 30l-1.74-10.13 7.36-7.17-10.17-1.48L16 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class StarOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: StarOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: StarOutlineIconComponent, isStandalone: true, selector: "iui-star-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m16 6.52 2.76 5.58.46 1 1 .15 6.16.89-4.38 4.3-.75.73.18 1 1.05 6.13-5.51-2.89L16 23l-.93.49-5.51 2.85 1-6.13.18-1-.74-.77-4.42-4.35 6.16-.89 1-.15.46-1L16 6.52zM16 2l-4.55 9.22-10.17 1.47 7.36 7.18L6.9 30l9.1-4.78L25.1 30l-1.74-10.13 7.36-7.17-10.17-1.48L16 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: StarOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-star-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m16 6.52 2.76 5.58.46 1 1 .15 6.16.89-4.38 4.3-.75.73.18 1 1.05 6.13-5.51-2.89L16 23l-.93.49-5.51 2.85 1-6.13.18-1-.74-.77-4.42-4.35 6.16-.89 1-.15.46-1L16 6.52zM16 2l-4.55 9.22-10.17 1.47 7.36 7.18L6.9 30l9.1-4.78L25.1 30l-1.74-10.13 7.36-7.17-10.17-1.48L16 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class StopFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: StopFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: StopFillIconComponent, isStandalone: true, selector: "iui-stop-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 6H8a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: StopFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-stop-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 6H8a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class StopOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: StopOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: StopOutlineIconComponent, isStandalone: true, selector: "iui-stop-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 8v16H8V8h16zm0-2H8a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: StopOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-stop-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 8v16H8V8h16zm0-2H8a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SubtractEmptyIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SubtractEmptyIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SubtractEmptyIconComponent, isStandalone: true, selector: "iui-subtract-empty-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 15H8v2h16v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SubtractEmptyIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-subtract-empty-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 15H8v2h16v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SubtractFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SubtractFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SubtractFillIconComponent, isStandalone: true, selector: "iui-subtract-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M2 16C2 8.3 8.3 2 16 2s14 6.3 14 14-6.3 14-14 14S2 23.7 2 16zm6-1h16v2H8v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SubtractFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-subtract-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M2 16C2 8.3 8.3 2 16 2s14 6.3 14 14-6.3 14-14 14S2 23.7 2 16zm6-1h16v2H8v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SubtractOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SubtractOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SubtractOutlineIconComponent, isStandalone: true, selector: "iui-subtract-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 4c6.6 0 12 5.4 12 12s-5.4 12-12 12S4 22.6 4 16 9.4 4 16 4zm0-2C8.3 2 2 8.3 2 16s6.3 14 14 14 14-6.3 14-14S23.7 2 16 2z" fill="currentColor"></path><path d="M24 15H8v2h16v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SubtractOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-subtract-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 4c6.6 0 12 5.4 12 12s-5.4 12-12 12S4 22.6 4 16 9.4 4 16 4zm0-2C8.3 2 2 8.3 2 16s6.3 14 14 14 14-6.3 14-14S23.7 2 16 2z" fill="currentColor"></path><path d="M24 15H8v2h16v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class SvgIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SvgIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SvgIconComponent, isStandalone: true, selector: "iui-svg-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 23h-6a2 2 0 0 1-2-2V11a2 2 0 0 1 2-2h6v2h-6v10h4v-4h-2v-2h4v8zM18 9l-2 13-2-13h-2l2.52 14h2.96L20 9h-2zM8 23H2v-2h6v-4H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h6v2H4v4h4a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SvgIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-svg-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 23h-6a2 2 0 0 1-2-2V11a2 2 0 0 1 2-2h6v2h-6v10h4v-4h-2v-2h4v8zM18 9l-2 13-2-13h-2l2.52 14h2.96L20 9h-2zM8 23H2v-2h6v-4H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h6v2H4v4h4a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class TabletLandscapeIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TabletLandscapeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: TabletLandscapeIconComponent, isStandalone: true, selector: "iui-tablet-landscape-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 13h-2v6h2v-6z" fill="currentColor"></path><path d="M30 7v18a2.002 2.002 0 0 1-2 2H4a2.002 2.002 0 0 1-2-2V7a2.002 2.002 0 0 1 2-2h24a2.003 2.003 0 0 1 2 2zM4 25h24V7H4v18z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TabletLandscapeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-tablet-landscape-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 13h-2v6h2v-6z" fill="currentColor"></path><path d="M30 7v18a2.002 2.002 0 0 1-2 2H4a2.002 2.002 0 0 1-2-2V7a2.002 2.002 0 0 1 2-2h24a2.003 2.003 0 0 1 2 2zM4 25h24V7H4v18z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class TabletPortraitIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TabletPortraitIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: TabletPortraitIconComponent, isStandalone: true, selector: "iui-tablet-portrait-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M19 26v-2h-6v2h6z" fill="currentColor"></path><path d="M25 30H7a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h18a2.002 2.002 0 0 1 2 2v24a2.003 2.003 0 0 1-2 2zM7 4v24h18V4H7z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TabletPortraitIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-tablet-portrait-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M19 26v-2h-6v2h6z" fill="currentColor"></path><path d="M25 30H7a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h18a2.002 2.002 0 0 1 2 2v24a2.003 2.003 0 0 1-2 2zM7 4v24h18V4H7z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class TextScaleIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TextScaleIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: TextScaleIconComponent, isStandalone: true, selector: "iui-text-scale-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 5v3h-8v18h-3V8h-8V5h19z" fill="currentColor"></path><path d="M7 26V14H2v-2h12v2H9v12H7z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TextScaleIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-text-scale-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 5v3h-8v18h-3V8h-8V5h19z" fill="currentColor"></path><path d="M7 26V14H2v-2h12v2H9v12H7z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ThumbsDownFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ThumbsDownFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ThumbsDownFillIconComponent, isStandalone: true, selector: "iui-thumbs-down-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M7 2H2v14h5V2zM23 2H9v14.803l3.042 4.563.845 5.917A2.01 2.01 0 0 0 14.867 29H15a3.004 3.004 0 0 0 3-3v-6h8a4.004 4.004 0 0 0 4-4V9a7.008 7.008 0 0 0-7-7z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ThumbsDownFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-thumbs-down-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M7 2H2v14h5V2zM23 2H9v14.803l3.042 4.563.845 5.917A2.01 2.01 0 0 0 14.867 29H15a3.004 3.004 0 0 0 3-3v-6h8a4.004 4.004 0 0 0 4-4V9a7.008 7.008 0 0 0-7-7z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ThumbsDownOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ThumbsDownOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ThumbsDownOutlineIconComponent, isStandalone: true, selector: "iui-thumbs-down-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 16V9a7.008 7.008 0 0 0-7-7H2v14h6.465l3.577 5.366.845 5.917A2.01 2.01 0 0 0 14.867 29H17a3.004 3.004 0 0 0 3-3v-6h6a4.004 4.004 0 0 0 4-4zM8 14H4V4h4v10zm20 2a2.003 2.003 0 0 1-2 2h-8v8a1 1 0 0 1-1 1h-2.133l-.91-6.366L10 14.697V4h13a5.006 5.006 0 0 1 5 5v7z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ThumbsDownOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-thumbs-down-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 16V9a7.008 7.008 0 0 0-7-7H2v14h6.465l3.577 5.366.845 5.917A2.01 2.01 0 0 0 14.867 29H17a3.004 3.004 0 0 0 3-3v-6h6a4.004 4.004 0 0 0 4-4zM8 14H4V4h4v10zm20 2a2.003 2.003 0 0 1-2 2h-8v8a1 1 0 0 1-1 1h-2.133l-.91-6.366L10 14.697V4h13a5.006 5.006 0 0 1 5 5v7z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ThumbsUpFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ThumbsUpFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ThumbsUpFillIconComponent, isStandalone: true, selector: "iui-thumbs-up-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M7 16H2v14h5V16zM23 30H9V15.197l3.042-4.563.845-5.917A2.01 2.01 0 0 1 14.867 3H15a3.003 3.003 0 0 1 3 3v6h8a4.004 4.004 0 0 1 4 4v7a7.008 7.008 0 0 1-7 7z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ThumbsUpFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-thumbs-up-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M7 16H2v14h5V16zM23 30H9V15.197l3.042-4.563.845-5.917A2.01 2.01 0 0 1 14.867 3H15a3.003 3.003 0 0 1 3 3v6h8a4.004 4.004 0 0 1 4 4v7a7.008 7.008 0 0 1-7 7z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ThumbsUpOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ThumbsUpOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ThumbsUpOutlineIconComponent, isStandalone: true, selector: "iui-thumbs-up-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 12h-6V6a3.003 3.003 0 0 0-3-3h-2.133a2.01 2.01 0 0 0-1.98 1.717l-.845 5.917L8.465 16H2v14h21a7.008 7.008 0 0 0 7-7v-7a4.004 4.004 0 0 0-4-4zM8 28H4V18h4v10zm20-5a5.006 5.006 0 0 1-5 5H10V17.303l3.958-5.937.91-6.366H17a1 1 0 0 1 1 1v8h8a2.003 2.003 0 0 1 2 2v7z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ThumbsUpOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-thumbs-up-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 12h-6V6a3.003 3.003 0 0 0-3-3h-2.133a2.01 2.01 0 0 0-1.98 1.717l-.845 5.917L8.465 16H2v14h21a7.008 7.008 0 0 0 7-7v-7a4.004 4.004 0 0 0-4-4zM8 28H4V18h4v10zm20-5a5.006 5.006 0 0 1-5 5H10V17.303l3.958-5.937.91-6.366H17a1 1 0 0 1 1 1v8h8a2.003 2.003 0 0 1 2 2v7z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class TifIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TifIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: TifIconComponent, isStandalone: true, selector: "iui-tif-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 11V9h-8v14h2v-6h5v-2h-5v-4h6zM12 11h3v10h-3v2h8v-2h-3V11h3V9h-8v2zM2 11h3v12h2V11h3V9H2v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TifIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-tif-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 11V9h-8v14h2v-6h5v-2h-5v-4h6zM12 11h3v10h-3v2h8v-2h-3V11h3V9h-8v2zM2 11h3v12h2V11h3V9H2v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class TikTokIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TikTokIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: TikTokIconComponent, isStandalone: true, selector: "iui-tik-tok-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M13 17a4 4 0 1 0 4 4h4a8 8 0 1 1-8-8v4zM21 3a6 6 0 0 0 6 6v4A10 10 0 0 1 17 3h4z" fill="currentColor"></path><path d="M17 3h4v18h-4V3z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TikTokIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-tik-tok-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M13 17a4 4 0 1 0 4 4h4a8 8 0 1 1-8-8v4zM21 3a6 6 0 0 0 6 6v4A10 10 0 0 1 17 3h4z" fill="currentColor"></path><path d="M17 3h4v18h-4V3z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class TimeIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TimeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: TimeIconComponent, isStandalone: true, selector: "iui-time-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 30a14 14 0 1 1 0-28 14 14 0 0 1 0 28zm0-26a12 12 0 1 0 0 24 12 12 0 0 0 0-24z" fill="currentColor"></path><path d="M20.59 22 15 16.41V7h2v8.58l5 5.01L20.59 22z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TimeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-time-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 30a14 14 0 1 1 0-28 14 14 0 0 1 0 28zm0-26a12 12 0 1 0 0 24 12 12 0 0 0 0-24z" fill="currentColor"></path><path d="M20.59 22 15 16.41V7h2v8.58l5 5.01L20.59 22z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class TimerIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TimerIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: TimerIconComponent, isStandalone: true, selector: "iui-timer-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17 11h-2v9h2v-9zM19 2h-6v2h6V2z" fill="currentColor"></path><path d="m28 9-1.42-1.41-2.25 2.25a10.94 10.94 0 1 0 1.18 1.65L28 9zM16 26a9 9 0 1 1 0-17.999A9 9 0 0 1 16 26z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TimerIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-timer-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17 11h-2v9h2v-9zM19 2h-6v2h6V2z" fill="currentColor"></path><path d="m28 9-1.42-1.41-2.25 2.25a10.94 10.94 0 1 0 1.18 1.65L28 9zM16 26a9 9 0 1 1 0-17.999A9 9 0 0 1 16 26z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class TransgenderIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TransgenderIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: TransgenderIconComponent, isStandalone: true, selector: "iui-transgender-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 2v2h4.586l-6.402 6.401a6.947 6.947 0 0 0-8.368 0L10.414 9 13 6.414 11.586 5 9 7.586 5.414 4H10V2H2v8h2V5.414L7.586 9 5 11.585 6.414 13 9 10.414l1.401 1.401A6.979 6.979 0 0 0 15 22.92V25h-4v2h4v3h2v-3h4v-2h-4v-2.08a6.979 6.979 0 0 0 4.598-11.105L28 5.415V10h2V2h-8zm-6 19a5 5 0 1 1 0-10 5 5 0 0 1 0 10z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TransgenderIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-transgender-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 2v2h4.586l-6.402 6.401a6.947 6.947 0 0 0-8.368 0L10.414 9 13 6.414 11.586 5 9 7.586 5.414 4H10V2H2v8h2V5.414L7.586 9 5 11.585 6.414 13 9 10.414l1.401 1.401A6.979 6.979 0 0 0 15 22.92V25h-4v2h4v3h2v-3h4v-2h-4v-2.08a6.979 6.979 0 0 0 4.598-11.105L28 5.415V10h2V2h-8zm-6 19a5 5 0 1 1 0-10 5 5 0 0 1 0 10z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class TrophyIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TrophyIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: TrophyIconComponent, isStandalone: true, selector: "iui-trophy-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 7h-2V6a2.002 2.002 0 0 0-2-2H10a2.002 2.002 0 0 0-2 2v1H6a2.002 2.002 0 0 0-2 2v3a4.004 4.004 0 0 0 4 4h.322A8.17 8.17 0 0 0 15 21.934V26h-5v2h12v-2h-5v-4.069A7.966 7.966 0 0 0 23.74 16H24a4.004 4.004 0 0 0 4-4V9a2.002 2.002 0 0 0-2-2zM8 14a2.002 2.002 0 0 1-2-2V9h2v5zm14 0a6 6 0 0 1-6.185 5.997A6.2 6.2 0 0 1 10 13.707V6h12v8zm4-2a2.002 2.002 0 0 1-2 2V9h2v3z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TrophyIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-trophy-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M26 7h-2V6a2.002 2.002 0 0 0-2-2H10a2.002 2.002 0 0 0-2 2v1H6a2.002 2.002 0 0 0-2 2v3a4.004 4.004 0 0 0 4 4h.322A8.17 8.17 0 0 0 15 21.934V26h-5v2h12v-2h-5v-4.069A7.966 7.966 0 0 0 23.74 16H24a4.004 4.004 0 0 0 4-4V9a2.002 2.002 0 0 0-2-2zM8 14a2.002 2.002 0 0 1-2-2V9h2v5zm14 0a6 6 0 0 1-6.185 5.997A6.2 6.2 0 0 1 10 13.707V6h12v8zm4-2a2.002 2.002 0 0 1-2 2V9h2v3z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class TsvIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TsvIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: TsvIconComponent, isStandalone: true, selector: "iui-tsv-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m28 9-2 13-2-13h-2l2.516 14h2.968L30 9h-2zM18 23h-6v-2h6v-4h-4a2.002 2.002 0 0 1-2-2v-4a2.002 2.002 0 0 1 2-2h6v2h-6v4h4a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zM2 11h3v12h2V11h3V9H2v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TsvIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-tsv-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m28 9-2 13-2-13h-2l2.516 14h2.968L30 9h-2zM18 23h-6v-2h6v-4h-4a2.002 2.002 0 0 1-2-2v-4a2.002 2.002 0 0 1 2-2h6v2h-6v4h4a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zM2 11h3v12h2V11h3V9H2v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class TumblrIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TumblrIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: TumblrIconComponent, isStandalone: true, selector: "iui-tumblr-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22.6 28h-4c-3.59 0-6.3-1.86-6.3-6.3v-7.12H9v-3.86A7.17 7.17 0 0 0 14.3 4h3.76v6.12h4.36v4.46h-4.36v6.2c0 1.86.94 2.49 2.42 2.49h2.12V28z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TumblrIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-tumblr-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22.6 28h-4c-3.59 0-6.3-1.86-6.3-6.3v-7.12H9v-3.86A7.17 7.17 0 0 0 14.3 4h3.76v6.12h4.36v4.46h-4.36v6.2c0 1.86.94 2.49 2.42 2.49h2.12V28z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class TwitterIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TwitterIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: TwitterIconComponent, isStandalone: true, selector: "iui-twitter-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M11.92 24.94A12.76 12.76 0 0 0 24.76 12.1v-.59A9.398 9.398 0 0 0 27 9.18a9.31 9.31 0 0 1-2.59.71 4.56 4.56 0 0 0 2-2.5 8.89 8.89 0 0 1-2.86 1.1 4.52 4.52 0 0 0-7.7 4.11 12.79 12.79 0 0 1-9.3-4.71 4.51 4.51 0 0 0 1.4 6 4.47 4.47 0 0 1-2-.56v.05a4.53 4.53 0 0 0 3.55 4.45 4.53 4.53 0 0 1-2 .08A4.51 4.51 0 0 0 11.68 21a9.05 9.05 0 0 1-5.61 2A9.777 9.777 0 0 1 5 22.91a12.77 12.77 0 0 0 6.92 2" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TwitterIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-twitter-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M11.92 24.94A12.76 12.76 0 0 0 24.76 12.1v-.59A9.398 9.398 0 0 0 27 9.18a9.31 9.31 0 0 1-2.59.71 4.56 4.56 0 0 0 2-2.5 8.89 8.89 0 0 1-2.86 1.1 4.52 4.52 0 0 0-7.7 4.11 12.79 12.79 0 0 1-9.3-4.71 4.51 4.51 0 0 0 1.4 6 4.47 4.47 0 0 1-2-.56v.05a4.53 4.53 0 0 0 3.55 4.45 4.53 4.53 0 0 1-2 .08A4.51 4.51 0 0 0 11.68 21a9.05 9.05 0 0 1-5.61 2A9.777 9.777 0 0 1 5 22.91a12.77 12.77 0 0 0 6.92 2" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class TxtIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TxtIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: TxtIconComponent, isStandalone: true, selector: "iui-txt-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M21 11h3v12h2V11h3V9h-8v2zM20 9h-2l-2 6-2-6h-2l2.75 7L12 23h2l2-6 2 6h2l-2.75-7L20 9zM3 11h3v12h2V11h3V9H3v2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: TxtIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-txt-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M21 11h3v12h2V11h3V9h-8v2zM20 9h-2l-2 6-2-6h-2l2.75 7L12 23h2l2-6 2 6h2l-2.75-7L20 9zM3 11h3v12h2V11h3V9H3v2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UndoIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UndoIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UndoIconComponent, isStandalone: true, selector: "iui-undo-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M20 10H7.815l3.587-3.586L10 5l-6 6 6 6 1.402-1.415L7.818 12H20a6 6 0 1 1 0 12h-8v2h8a8 8 0 0 0 0-16z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UndoIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-undo-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M20 10H7.815l3.587-3.586L10 5l-6 6 6 6 1.402-1.415L7.818 12H20a6 6 0 1 1 0 12h-8v2h8a8 8 0 0 0 0-16z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UnlinkIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UnlinkIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UnlinkIconComponent, isStandalone: true, selector: "iui-unlink-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4.998 3.587 3.584 5.002 7 8.417l1.414-1.415-3.416-3.415zM24.996 23.578l-1.415 1.414 3.415 3.416 1.415-1.414-3.415-3.416zM13 2h-2v4h2V2zM6 11H2v2h4v-2zM30 19h-4v2h4v-2zM21 26h-2v4h2v-4zM16.58 21.07l-3.71 3.72a4.003 4.003 0 0 1-5.66-5.66l3.72-3.72L9.51 14 5.8 17.72a6 6 0 0 0-.06 8.54A6 6 0 0 0 10 28a6.07 6.07 0 0 0 4.32-1.8L18 22.49l-1.42-1.42zM15.41 10.93l3.72-3.72a4.001 4.001 0 1 1 5.66 5.66l-3.72 3.72L22.49 18l3.71-3.72a6 6 0 0 0 .06-8.54A5.999 5.999 0 0 0 22 4a6.07 6.07 0 0 0-4.32 1.8L14 9.51l1.41 1.42z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UnlinkIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-unlink-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M4.998 3.587 3.584 5.002 7 8.417l1.414-1.415-3.416-3.415zM24.996 23.578l-1.415 1.414 3.415 3.416 1.415-1.414-3.415-3.416zM13 2h-2v4h2V2zM6 11H2v2h4v-2zM30 19h-4v2h4v-2zM21 26h-2v4h2v-4zM16.58 21.07l-3.71 3.72a4.003 4.003 0 0 1-5.66-5.66l3.72-3.72L9.51 14 5.8 17.72a6 6 0 0 0-.06 8.54A6 6 0 0 0 10 28a6.07 6.07 0 0 0 4.32-1.8L18 22.49l-1.42-1.42zM15.41 10.93l3.72-3.72a4.001 4.001 0 1 1 5.66 5.66l-3.72 3.72L22.49 18l3.71-3.72a6 6 0 0 0 .06-8.54A5.999 5.999 0 0 0 22 4a6.07 6.07 0 0 0-4.32 1.8L14 9.51l1.41 1.42z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UnlockedIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UnlockedIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UnlockedIconComponent, isStandalone: true, selector: "iui-unlocked-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 14H12V8a4 4 0 1 1 8 0h2a6 6 0 1 0-12 0v6H8a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V16a2 2 0 0 0-2-2zm0 14H8V16h16v12z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UnlockedIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-unlocked-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 14H12V8a4 4 0 1 1 8 0h2a6 6 0 1 0-12 0v6H8a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V16a2 2 0 0 0-2-2zm0 14H8V16h16v12z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UpToBottomIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UpToBottomIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UpToBottomIconComponent, isStandalone: true, selector: "iui-up-to-bottom-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 18 6 8l1.4-1.4 8.6 8.6 8.6-8.6L26 8 16 18zM28 22H4v2h24v-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UpToBottomIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-up-to-bottom-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 18 6 8l1.4-1.4 8.6 8.6 8.6-8.6L26 8 16 18zM28 22H4v2h24v-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UpToTopIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UpToTopIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UpToTopIconComponent, isStandalone: true, selector: "iui-up-to-top-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 14 6 24l1.4 1.4 8.6-8.6 8.6 8.6L26 24 16 14zM28 8H4v2h24V8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UpToTopIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-up-to-top-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 14 6 24l1.4 1.4 8.6-8.6 8.6 8.6L26 24 16 14zM28 8H4v2h24V8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UploadIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UploadIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UploadIconComponent, isStandalone: true, selector: "iui-upload-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m6 18 1.41 1.41L15 11.83V30h2V11.83l7.59 7.58L26 18 16 8 6 18zM6 8V4h20v4h2V4a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v4h2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UploadIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-upload-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m6 18 1.41 1.41L15 11.83V30h2V11.83l7.59 7.58L26 18 16 8 6 18zM6 8V4h20v4h2V4a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v4h2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UrrencyBahtIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyBahtIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UrrencyBahtIconComponent, isStandalone: true, selector: "iui-urrency-baht-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M21.402 15.643A4.971 4.971 0 0 0 23 12v-1a5.006 5.006 0 0 0-5-5h-1V3h-2v3h-5v20h5v3h2v-3h2a5.006 5.006 0 0 0 5-5v-1a4.983 4.983 0 0 0-2.598-4.357zM12 8h6a3.003 3.003 0 0 1 3 3v1a3.004 3.004 0 0 1-3 3h-6V8zm10 13a3.004 3.004 0 0 1-3 3h-7v-7h7a3.004 3.004 0 0 1 3 3v1z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyBahtIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-urrency-baht-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M21.402 15.643A4.971 4.971 0 0 0 23 12v-1a5.006 5.006 0 0 0-5-5h-1V3h-2v3h-5v20h5v3h2v-3h2a5.006 5.006 0 0 0 5-5v-1a4.983 4.983 0 0 0-2.598-4.357zM12 8h6a3.003 3.003 0 0 1 3 3v1a3.004 3.004 0 0 1-3 3h-6V8zm10 13a3.004 3.004 0 0 1-3 3h-7v-7h7a3.004 3.004 0 0 1 3 3v1z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UrrencyDollarIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyDollarIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UrrencyDollarIconComponent, isStandalone: true, selector: "iui-urrency-dollar-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 20.515c0-4.615-3.78-5.141-6.817-5.563-3.31-.46-5.183-.86-5.183-3.71C11 8.85 13.507 8 15.654 8a6.754 6.754 0 0 1 5.568 2.628l1.556-1.256A8.65 8.65 0 0 0 17 6.096V3h-2v3.022c-3.615.22-6 2.26-6 5.22 0 4.73 3.83 5.263 6.907 5.69 3.253.453 5.093.842 5.093 3.583C21 23.547 17.867 24 16 24c-3.43 0-4.878-.964-6.222-2.628l-1.556 1.256A8.437 8.437 0 0 0 15 25.965V29h2v-3.045c3.725-.304 6-2.327 6-5.44z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyDollarIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-urrency-dollar-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 20.515c0-4.615-3.78-5.141-6.817-5.563-3.31-.46-5.183-.86-5.183-3.71C11 8.85 13.507 8 15.654 8a6.754 6.754 0 0 1 5.568 2.628l1.556-1.256A8.65 8.65 0 0 0 17 6.096V3h-2v3.022c-3.615.22-6 2.26-6 5.22 0 4.73 3.83 5.263 6.907 5.69 3.253.453 5.093.842 5.093 3.583C21 23.547 17.867 24 16 24c-3.43 0-4.878-.964-6.222-2.628l-1.556 1.256A8.437 8.437 0 0 0 15 25.965V29h2v-3.045c3.725-.304 6-2.327 6-5.44z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UrrencyEuroIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyEuroIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UrrencyEuroIconComponent, isStandalone: true, selector: "iui-urrency-euro-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17 26c-3.616 0-6.333-2.297-7.446-6H19v-2H9.132A15.28 15.28 0 0 1 9 16c0-.33.01-.664.026-1H19v-2H9.237C9.845 9.352 11.81 6 17 6c3.853 0 5.532 1.646 7.128 4.49l1.744-.98C24.265 6.649 22.078 4 17 4 10.645 4 7 8.374 7 16c0 7.065 4.112 12 10 12 5.078 0 7.265-2.648 8.872-5.51l-1.744-.98C22.532 24.354 20.853 26 17 26z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyEuroIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-urrency-euro-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M17 26c-3.616 0-6.333-2.297-7.446-6H19v-2H9.132A15.28 15.28 0 0 1 9 16c0-.33.01-.664.026-1H19v-2H9.237C9.845 9.352 11.81 6 17 6c3.853 0 5.532 1.646 7.128 4.49l1.744-.98C24.265 6.649 22.078 4 17 4 10.645 4 7 8.374 7 16c0 7.065 4.112 12 10 12 5.078 0 7.265-2.648 8.872-5.51l-1.744-.98C22.532 24.354 20.853 26 17 26z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UrrencyLiraIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyLiraIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UrrencyLiraIconComponent, isStandalone: true, selector: "iui-urrency-lira-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 19a6.006 6.006 0 0 1-6 6h-4v-6.892L21.214 15v-2L13 16.108v-3L21.214 10V8L13 11.108V5h-2v6.865L8 13v2l3-1.135v3L8 18v2l3-1.135V27h6a8.01 8.01 0 0 0 8-8h-2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyLiraIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-urrency-lira-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M23 19a6.006 6.006 0 0 1-6 6h-4v-6.892L21.214 15v-2L13 16.108v-3L21.214 10V8L13 11.108V5h-2v6.865L8 13v2l3-1.135v3L8 18v2l3-1.135V27h6a8.01 8.01 0 0 0 8-8h-2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UrrencyPoundIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyPoundIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UrrencyPoundIconComponent, isStandalone: true, selector: "iui-urrency-pound-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12.453 25A8.778 8.778 0 0 0 14 20c.003-.67-.057-1.34-.18-2H22v-2h-8.783c-.084-.21-.17-.42-.255-.624A9.859 9.859 0 0 1 12 11a4.793 4.793 0 0 1 5-5 6.124 6.124 0 0 1 5.222 2.628l1.556-1.256A8.11 8.11 0 0 0 17 4a6.778 6.778 0 0 0-7 7 11.65 11.65 0 0 0 1.056 5H8v2h3.773c.157.655.234 1.326.227 2 0 2.523-1.486 5-3 5v2h15v-2H12.453z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyPoundIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-urrency-pound-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M12.453 25A8.778 8.778 0 0 0 14 20c.003-.67-.057-1.34-.18-2H22v-2h-8.783c-.084-.21-.17-.42-.255-.624A9.859 9.859 0 0 1 12 11a4.793 4.793 0 0 1 5-5 6.124 6.124 0 0 1 5.222 2.628l1.556-1.256A8.11 8.11 0 0 0 17 4a6.778 6.778 0 0 0-7 7 11.65 11.65 0 0 0 1.056 5H8v2h3.773c.157.655.234 1.326.227 2 0 2.523-1.486 5-3 5v2h15v-2H12.453z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UrrencyRubleIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyRubleIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UrrencyRubleIconComponent, isStandalone: true, selector: "iui-urrency-ruble-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M19 4h-9v11H7v2h3v3H7v2h3v6h2v-6h9v-2h-9v-3h7a6.007 6.007 0 0 0 6-6v-1a6.007 6.007 0 0 0-6-6zm4 7a4.004 4.004 0 0 1-4 4h-7V6h7a4.004 4.004 0 0 1 4 4v1z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyRubleIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-urrency-ruble-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M19 4h-9v11H7v2h3v3H7v2h3v6h2v-6h9v-2h-9v-3h7a6.007 6.007 0 0 0 6-6v-1a6.007 6.007 0 0 0-6-6zm4 7a4.004 4.004 0 0 1-4 4h-7V6h7a4.004 4.004 0 0 1 4 4v1z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UrrencyRupeeIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyRupeeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UrrencyRupeeIconComponent, isStandalone: true, selector: "iui-urrency-rupee-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 7V5H8v2h5.5a4.49 4.49 0 0 1 4.45 4H8v2h9.95a4.49 4.49 0 0 1-4.45 4H8v2.345L17.617 28l1.338-1.486L10.606 19H13.5a6.504 6.504 0 0 0 6.475-6H24v-2h-4.025a6.472 6.472 0 0 0-1.795-4H24z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyRupeeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-urrency-rupee-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 7V5H8v2h5.5a4.49 4.49 0 0 1 4.45 4H8v2h9.95a4.49 4.49 0 0 1-4.45 4H8v2.345L17.617 28l1.338-1.486L10.606 19H13.5a6.504 6.504 0 0 0 6.475-6H24v-2h-4.025a6.472 6.472 0 0 0-1.795-4H24z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UrrencyShekelIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyShekelIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UrrencyShekelIconComponent, isStandalone: true, selector: "iui-urrency-shekel-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M9 27H7V5h8a5.006 5.006 0 0 1 5 5v12h-2V10a3.003 3.003 0 0 0-3-3H9v20z" fill="currentColor"></path><path d="M20 27h-8V10h2v15h6a3.004 3.004 0 0 0 3-3V5h2v17a5.006 5.006 0 0 1-5 5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyShekelIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-urrency-shekel-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M9 27H7V5h8a5.006 5.006 0 0 1 5 5v12h-2V10a3.003 3.003 0 0 0-3-3H9v20z" fill="currentColor"></path><path d="M20 27h-8V10h2v15h6a3.004 3.004 0 0 0 3-3V5h2v17a5.006 5.006 0 0 1-5 5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UrrencyWonIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyWonIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UrrencyWonIconComponent, isStandalone: true, selector: "iui-urrency-won-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 14v-2h-4.955L24 5h-2l-2 18-3-15h-2l-3 15-2-18H8l.955 7H4v2h5.227l.409 3H4v2h5.909L11 27h2l3-15 3 15h2l1.091-8H28v-2h-5.636l.409-3H28z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyWonIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-urrency-won-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 14v-2h-4.955L24 5h-2l-2 18-3-15h-2l-3 15-2-18H8l.955 7H4v2h5.227l.409 3H4v2h5.909L11 27h2l3-15 3 15h2l1.091-8H28v-2h-5.636l.409-3H28z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UrrencyYenIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyYenIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UrrencyYenIconComponent, isStandalone: true, selector: "iui-urrency-yen-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24.271 5H22l-6 11-6-11H7.729l6.065 11H8v2h7v3H8v2h7v4h2v-4h7v-2h-7v-3h7v-2h-5.794l6.065-11z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UrrencyYenIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-urrency-yen-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24.271 5H22l-6 11-6-11H7.729l6.065 11H8v2h7v3H8v2h7v4h2v-4h7v-2h-7v-3h7v-2h-5.794l6.065-11z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UserIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UserIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UserIconComponent, isStandalone: true, selector: "iui-user-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 4a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0-2a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM26 30h-2v-5a5 5 0 0 0-5-5h-6a5 5 0 0 0-5 5v5H6v-5a7 7 0 0 1 7-7h6a7 7 0 0 1 7 7v5z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UserIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-user-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M16 4a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0-2a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM26 30h-2v-5a5 5 0 0 0-5-5h-6a5 5 0 0 0-5 5v5H6v-5a7 7 0 0 1 7-7h6a7 7 0 0 1 7 7v5z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class UsersIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UsersIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: UsersIconComponent, isStandalone: true, selector: "iui-users-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 30h-2v-5a5.006 5.006 0 0 0-5-5v-2a7.008 7.008 0 0 1 7 7v5zM22 30h-2v-5a5.006 5.006 0 0 0-5-5H9a5.006 5.006 0 0 0-5 5v5H2v-5a7.008 7.008 0 0 1 7-7h6a7.009 7.009 0 0 1 7 7v5zM20 2v2a5 5 0 1 1 0 10v2a7 7 0 1 0 0-14zM12 4a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0-2a7 7 0 1 0 0 14 7 7 0 0 0 0-14z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: UsersIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-users-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30 30h-2v-5a5.006 5.006 0 0 0-5-5v-2a7.008 7.008 0 0 1 7 7v5zM22 30h-2v-5a5.006 5.006 0 0 0-5-5H9a5.006 5.006 0 0 0-5 5v5H2v-5a7.008 7.008 0 0 1 7-7h6a7.009 7.009 0 0 1 7 7v5zM20 2v2a5 5 0 1 1 0 10v2a7 7 0 1 0 0-14zM12 4a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0-2a7 7 0 1 0 0 14 7 7 0 0 0 0-14z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class VideoAddIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VideoAddIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: VideoAddIconComponent, isStandalone: true, selector: "iui-video-add-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M18 15h-4v-4h-2v4H8v2h4v4h2v-4h4v-2z"></path><path d="M21 26H4a2.002 2.002 0 0 1-2-2V8a2.002 2.002 0 0 1 2-2h17a2.002 2.002 0 0 1 2 2v4.057l5.419-3.87A1 1 0 0 1 30 9v14a1 1 0 0 1-1.581.814L23 19.944V24a2.002 2.002 0 0 1-2 2zM4 8v16.001L21 24v-6a1 1 0 0 1 1.581-.814L28 21.056V10.944l-5.419 3.87A1 1 0 0 1 21 14V8H4z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VideoAddIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-video-add-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><g clip-path="url(#a)" fill="#000" fill-opacity=".93"><path d="M18 15h-4v-4h-2v4H8v2h4v4h2v-4h4v-2z"></path><path d="M21 26H4a2.002 2.002 0 0 1-2-2V8a2.002 2.002 0 0 1 2-2h17a2.002 2.002 0 0 1 2 2v4.057l5.419-3.87A1 1 0 0 1 30 9v14a1 1 0 0 1-1.581.814L23 19.944V24a2.002 2.002 0 0 1-2 2zM4 8v16.001L21 24v-6a1 1 0 0 1 1.581-.814L28 21.056V10.944l-5.419 3.87A1 1 0 0 1 21 14V8H4z"></path></g><defs><clipPath id="a"><path fill="currentColor" d="M0 0h32v32H0z"></path></clipPath></defs></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class VideoFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VideoFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: VideoFillIconComponent, isStandalone: true, selector: "iui-video-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M21 26H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h17a2 2 0 0 1 2 2v4.06l5.42-3.87A1 1 0 0 1 30 9v14a1 1 0 0 1-1.58.81L23 19.94V24a2 2 0 0 1-2 2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VideoFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-video-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M21 26H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h17a2 2 0 0 1 2 2v4.06l5.42-3.87A1 1 0 0 1 30 9v14a1 1 0 0 1-1.58.81L23 19.94V24a2 2 0 0 1-2 2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class VideoOffFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VideoOffFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: VideoOffFillIconComponent, isStandalone: true, selector: "iui-video-off-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M20.31 6H4a2 2 0 0 0-2 2v16a2.85 2.85 0 0 0 0 .29L20.31 6zM29.46 8.11a1 1 0 0 0-1 .08L23 12.06v-1.62l7-7L28.56 2 2 28.56 3.44 30l4-4H21a2 2 0 0 0 2-2v-4.06l5.42 3.87A1 1 0 0 0 30 23V9a1 1 0 0 0-.54-.89z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VideoOffFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-video-off-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M20.31 6H4a2 2 0 0 0-2 2v16a2.85 2.85 0 0 0 0 .29L20.31 6zM29.46 8.11a1 1 0 0 0-1 .08L23 12.06v-1.62l7-7L28.56 2 2 28.56 3.44 30l4-4H21a2 2 0 0 0 2-2v-4.06l5.42 3.87A1 1 0 0 0 30 23V9a1 1 0 0 0-.54-.89z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class VideoOffOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VideoOffOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: VideoOffOutlineIconComponent, isStandalone: true, selector: "iui-video-off-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29.46 8.11a1 1 0 0 0-1 .08L23 12.06v-1.62l7-7L28.56 2 2 28.56 3.44 30l4-4H21a2 2 0 0 0 2-2v-4.06l5.42 3.87A1 1 0 0 0 30 23V9a1 1 0 0 0-.54-.89zM28 21.06l-5.42-3.87A1 1 0 0 0 21 18v6H9.44L21 12.44V14a1 1 0 0 0 1.58.81L28 10.94v10.12zM4 24V8h16V6H4a2 2 0 0 0-2 2v16h2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VideoOffOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-video-off-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29.46 8.11a1 1 0 0 0-1 .08L23 12.06v-1.62l7-7L28.56 2 2 28.56 3.44 30l4-4H21a2 2 0 0 0 2-2v-4.06l5.42 3.87A1 1 0 0 0 30 23V9a1 1 0 0 0-.54-.89zM28 21.06l-5.42-3.87A1 1 0 0 0 21 18v6H9.44L21 12.44V14a1 1 0 0 0 1.58.81L28 10.94v10.12zM4 24V8h16V6H4a2 2 0 0 0-2 2v16h2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class VideoOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VideoOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: VideoOutlineIconComponent, isStandalone: true, selector: "iui-video-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M21 26H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h17a2 2 0 0 1 2 2v4.06l5.42-3.87A1 1 0 0 1 30 9v14a1 1 0 0 1-1.58.81L23 19.94V24a2 2 0 0 1-2 2zM4 8v16h17v-6a1 1 0 0 1 1.58-.81L28 21.06V10.94l-5.42 3.87A1 1 0 0 1 21 14V8H4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VideoOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-video-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M21 26H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h17a2 2 0 0 1 2 2v4.06l5.42-3.87A1 1 0 0 1 30 9v14a1 1 0 0 1-1.58.81L23 19.94V24a2 2 0 0 1-2 2zM4 8v16h17v-6a1 1 0 0 1 1.58-.81L28 21.06V10.94l-5.42 3.87A1 1 0 0 1 21 14V8H4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ViewOffIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ViewOffIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ViewOffIconComponent, isStandalone: true, selector: "iui-view-off-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m5.24 22.51 1.43-1.42A14.06 14.06 0 0 1 3.07 16C5.1 10.93 10.7 7 16 7a12.38 12.38 0 0 1 4 .72l1.55-1.56A14.72 14.72 0 0 0 16 5 16.69 16.69 0 0 0 1.06 15.66a1 1 0 0 0 0 .68 16 16 0 0 0 4.18 6.17z" fill="currentColor"></path><path d="M12 15.73a4 4 0 0 1 3.7-3.7l1.81-1.82a6 6 0 0 0-7.33 7.33L12 15.73zM30.94 15.66a16.4 16.4 0 0 0-5.74-7.44L30 3.41 28.59 2 2 28.59 3.41 30l5.1-5.1A15.29 15.29 0 0 0 16 27a16.69 16.69 0 0 0 14.94-10.66 1 1 0 0 0 0-.68zM20 16a4 4 0 0 1-6 3.44L19.44 14a4 4 0 0 1 .56 2zm-4 9a13.049 13.049 0 0 1-6-1.58l2.54-2.54a6 6 0 0 0 8.35-8.35l2.87-2.87A14.54 14.54 0 0 1 28.93 16C26.9 21.07 21.3 25 16 25z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ViewOffIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-view-off-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m5.24 22.51 1.43-1.42A14.06 14.06 0 0 1 3.07 16C5.1 10.93 10.7 7 16 7a12.38 12.38 0 0 1 4 .72l1.55-1.56A14.72 14.72 0 0 0 16 5 16.69 16.69 0 0 0 1.06 15.66a1 1 0 0 0 0 .68 16 16 0 0 0 4.18 6.17z" fill="currentColor"></path><path d="M12 15.73a4 4 0 0 1 3.7-3.7l1.81-1.82a6 6 0 0 0-7.33 7.33L12 15.73zM30.94 15.66a16.4 16.4 0 0 0-5.74-7.44L30 3.41 28.59 2 2 28.59 3.41 30l5.1-5.1A15.29 15.29 0 0 0 16 27a16.69 16.69 0 0 0 14.94-10.66 1 1 0 0 0 0-.68zM20 16a4 4 0 0 1-6 3.44L19.44 14a4 4 0 0 1 .56 2zm-4 9a13.049 13.049 0 0 1-6-1.58l2.54-2.54a6 6 0 0 0 8.35-8.35l2.87-2.87A14.54 14.54 0 0 1 28.93 16C26.9 21.07 21.3 25 16 25z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ViewOnIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ViewOnIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ViewOnIconComponent, isStandalone: true, selector: "iui-view-on-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30.94 15.66A16.69 16.69 0 0 0 16 5 16.69 16.69 0 0 0 1.06 15.66a1 1 0 0 0 0 .68A16.69 16.69 0 0 0 16 27a16.69 16.69 0 0 0 14.94-10.66 1 1 0 0 0 0-.68zM16 25c-5.3 0-10.9-3.93-12.93-9C5.1 10.93 10.7 7 16 7s10.9 3.93 12.93 9C26.9 21.07 21.3 25 16 25z" fill="currentColor"></path><path d="M16 10a6 6 0 1 0 0 12 6 6 0 0 0 0-12zm0 10a4 4 0 1 1 0-8 4 4 0 0 1 0 8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ViewOnIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-view-on-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M30.94 15.66A16.69 16.69 0 0 0 16 5 16.69 16.69 0 0 0 1.06 15.66a1 1 0 0 0 0 .68A16.69 16.69 0 0 0 16 27a16.69 16.69 0 0 0 14.94-10.66 1 1 0 0 0 0-.68zM16 25c-5.3 0-10.9-3.93-12.93-9C5.1 10.93 10.7 7 16 7s10.9 3.93 12.93 9C26.9 21.07 21.3 25 16 25z" fill="currentColor"></path><path d="M16 10a6 6 0 1 0 0 12 6 6 0 0 0 0-12zm0 10a4 4 0 1 1 0-8 4 4 0 0 1 0 8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class VolumeDownFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VolumeDownFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: VolumeDownFillIconComponent, isStandalone: true, selector: "iui-volume-down-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M25.1 10.66 23.58 12a6 6 0 0 1-.18 7.94l1.47 1.36a8 8 0 0 0 .23-10.59v-.05zM20 30a1.001 1.001 0 0 1-.71-.3L11.67 22H5a1 1 0 0 1-1-1V11a1 1 0 0 1 1-1h6.67l7.62-7.7a1 1 0 0 1 1.41 0 1 1 0 0 1 .3.7v26a1 1 0 0 1-1 1z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VolumeDownFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-volume-down-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M25.1 10.66 23.58 12a6 6 0 0 1-.18 7.94l1.47 1.36a8 8 0 0 0 .23-10.59v-.05zM20 30a1.001 1.001 0 0 1-.71-.3L11.67 22H5a1 1 0 0 1-1-1V11a1 1 0 0 1 1-1h6.67l7.62-7.7a1 1 0 0 1 1.41 0 1 1 0 0 1 .3.7v26a1 1 0 0 1-1 1z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class VolumeDownOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VolumeDownOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: VolumeDownOutlineIconComponent, isStandalone: true, selector: "iui-volume-down-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M25.1 10.66 23.58 12a6 6 0 0 1-.18 7.94l1.47 1.36a8 8 0 0 0 .23-10.59v-.05zM20 30a1 1 0 0 1-.71-.3L11.67 22H5a1 1 0 0 1-1-1V11a1 1 0 0 1 1-1h6.67l7.62-7.7a1 1 0 0 1 1.41 0 1 1 0 0 1 .3.7v26a1 1 0 0 1-1 1zM6 20h6a1.17 1.17 0 0 1 .79.3L19 26.57V5.43l-6.21 6.27a1.17 1.17 0 0 1-.79.3H6v8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VolumeDownOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-volume-down-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M25.1 10.66 23.58 12a6 6 0 0 1-.18 7.94l1.47 1.36a8 8 0 0 0 .23-10.59v-.05zM20 30a1 1 0 0 1-.71-.3L11.67 22H5a1 1 0 0 1-1-1V11a1 1 0 0 1 1-1h6.67l7.62-7.7a1 1 0 0 1 1.41 0 1 1 0 0 1 .3.7v26a1 1 0 0 1-1 1zM6 20h6a1.17 1.17 0 0 1 .79.3L19 26.57V5.43l-6.21 6.27a1.17 1.17 0 0 1-.79.3H6v8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class VolumeMuteFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VolumeMuteFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: VolumeMuteFillIconComponent, isStandalone: true, selector: "iui-volume-mute-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M31 12.41 29.59 11 26 14.59 22.41 11 21 12.41 24.59 16 21 19.59 22.41 21 26 17.41 29.59 21 31 19.59 27.41 16 31 12.41zM18 30a1 1 0 0 1-.71-.3L9.67 22H3a1 1 0 0 1-1-1V11a1 1 0 0 1 1-1h6.67l7.62-7.7a1 1 0 0 1 1.41 0 1 1 0 0 1 .3.7v26a1 1 0 0 1-1 1z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VolumeMuteFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-volume-mute-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M31 12.41 29.59 11 26 14.59 22.41 11 21 12.41 24.59 16 21 19.59 22.41 21 26 17.41 29.59 21 31 19.59 27.41 16 31 12.41zM18 30a1 1 0 0 1-.71-.3L9.67 22H3a1 1 0 0 1-1-1V11a1 1 0 0 1 1-1h6.67l7.62-7.7a1 1 0 0 1 1.41 0 1 1 0 0 1 .3.7v26a1 1 0 0 1-1 1z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class VolumeMuteIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VolumeMuteIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: VolumeMuteIconComponent, isStandalone: true, selector: "iui-volume-mute-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M31 12.41 29.59 11 26 14.59 22.41 11 21 12.41 24.59 16 21 19.59 22.41 21 26 17.41 29.59 21 31 19.59 27.41 16 31 12.41zM18 30a1.001 1.001 0 0 1-.71-.3L9.67 22H3a1 1 0 0 1-1-1V11a1 1 0 0 1 1-1h6.67l7.62-7.7a1 1 0 0 1 1.41 0 1 1 0 0 1 .3.7v26a1 1 0 0 1-1 1zM4 20h6a1.17 1.17 0 0 1 .79.3L17 26.57V5.43l-6.21 6.27a1.17 1.17 0 0 1-.79.3H4v8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VolumeMuteIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-volume-mute-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M31 12.41 29.59 11 26 14.59 22.41 11 21 12.41 24.59 16 21 19.59 22.41 21 26 17.41 29.59 21 31 19.59 27.41 16 31 12.41zM18 30a1.001 1.001 0 0 1-.71-.3L9.67 22H3a1 1 0 0 1-1-1V11a1 1 0 0 1 1-1h6.67l7.62-7.7a1 1 0 0 1 1.41 0 1 1 0 0 1 .3.7v26a1 1 0 0 1-1 1zM4 20h6a1.17 1.17 0 0 1 .79.3L17 26.57V5.43l-6.21 6.27a1.17 1.17 0 0 1-.79.3H4v8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class VolumeUpFillIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VolumeUpFillIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: VolumeUpFillIconComponent, isStandalone: true, selector: "iui-volume-up-fill-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m27.16 8.08-1.53 1.29a10 10 0 0 1-.29 13.23l1.47 1.4a12 12 0 0 0 .35-15.88v-.04z" fill="currentColor"></path><path d="M21.58 12a6 6 0 0 1-.18 7.94l1.47 1.36a8 8 0 0 0 .23-10.59L21.58 12zM18 30a1 1 0 0 1-.71-.3L9.67 22H3a1 1 0 0 1-1-1V11a1 1 0 0 1 1-1h6.67l7.62-7.7a1 1 0 0 1 1.41 0 1 1 0 0 1 .3.7v26a1 1 0 0 1-1 1z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VolumeUpFillIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-volume-up-fill-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m27.16 8.08-1.53 1.29a10 10 0 0 1-.29 13.23l1.47 1.4a12 12 0 0 0 .35-15.88v-.04z" fill="currentColor"></path><path d="M21.58 12a6 6 0 0 1-.18 7.94l1.47 1.36a8 8 0 0 0 .23-10.59L21.58 12zM18 30a1 1 0 0 1-.71-.3L9.67 22H3a1 1 0 0 1-1-1V11a1 1 0 0 1 1-1h6.67l7.62-7.7a1 1 0 0 1 1.41 0 1 1 0 0 1 .3.7v26a1 1 0 0 1-1 1z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class VolumeUpOutlineIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VolumeUpOutlineIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: VolumeUpOutlineIconComponent, isStandalone: true, selector: "iui-volume-up-outline-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m27.16 8.08-1.53 1.29a10 10 0 0 1-.29 13.23l1.47 1.4a12 12 0 0 0 .35-15.88v-.04z" fill="currentColor"></path><path d="M21.58 12a6 6 0 0 1-.18 7.94l1.47 1.36a8 8 0 0 0 .23-10.59L21.58 12zM18 30a1 1 0 0 1-.71-.3L9.67 22H3a1 1 0 0 1-1-1V11a1 1 0 0 1 1-1h6.67l7.62-7.7a1 1 0 0 1 1.41 0 1 1 0 0 1 .3.7v26a1 1 0 0 1-1 1zM4 20h6.08a1.003 1.003 0 0 1 .71.3L17 26.57V5.43l-6.21 6.27a1 1 0 0 1-.71.3H4v8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: VolumeUpOutlineIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-volume-up-outline-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m27.16 8.08-1.53 1.29a10 10 0 0 1-.29 13.23l1.47 1.4a12 12 0 0 0 .35-15.88v-.04z" fill="currentColor"></path><path d="M21.58 12a6 6 0 0 1-.18 7.94l1.47 1.36a8 8 0 0 0 .23-10.59L21.58 12zM18 30a1 1 0 0 1-.71-.3L9.67 22H3a1 1 0 0 1-1-1V11a1 1 0 0 1 1-1h6.67l7.62-7.7a1 1 0 0 1 1.41 0 1 1 0 0 1 .3.7v26a1 1 0 0 1-1 1zM4 20h6.08a1.003 1.003 0 0 1 .71.3L17 26.57V5.43l-6.21 6.27a1 1 0 0 1-.71.3H4v8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class WalletIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: WalletIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: WalletIconComponent, isStandalone: true, selector: "iui-wallet-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 17h-2v2h2v-2z" fill="currentColor"></path><path d="M28 8H4V5h22V3H4a2 2 0 0 0-2 2v21a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zM4 26V10h24v3h-8a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h8v3H4zm24-11v6h-8v-6h8z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: WalletIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-wallet-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 17h-2v2h2v-2z" fill="currentColor"></path><path d="M28 8H4V5h22V3H4a2 2 0 0 0-2 2v21a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zM4 26V10h24v3h-8a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h8v3H4zm24-11v6h-8v-6h8z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class WarningIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: WarningIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: WarningIconComponent, isStandalone: true, selector: "iui-warning-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="m29.887 28.539-13-25a1 1 0 0 0-1.774 0l-13 25A1 1 0 0 0 3 30h26a1 1 0 0 0 .887-1.461zM14.875 11h2.25v10h-2.25V11zM16 27a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: WarningIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-warning-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="m29.887 28.539-13-25a1 1 0 0 0-1.774 0l-13 25A1 1 0 0 0 3 30h26a1 1 0 0 0 .887-1.461zM14.875 11h2.25v10h-2.25V11zM16 27a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class WatchIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: WatchIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: WatchIconComponent, isStandalone: true, selector: "iui-watch-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 8h-1V2h-2v6h-6V2h-2v6h-1a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h1v6h2v-6h6v6h2v-6h1a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zM10 22V10h12v12H10zM27 14h-2v4h2v-4z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: WatchIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-watch-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M22 8h-1V2h-2v6h-6V2h-2v6h-1a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h1v6h2v-6h6v6h2v-6h1a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zM10 22V10h12v12H10zM27 14h-2v4h2v-4z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class WechatIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: WechatIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: WechatIconComponent, isStandalone: true, selector: "iui-wechat-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M27.086 24.78A6.618 6.618 0 0 0 30 19.465c0-3.88-3.776-7.027-8.434-7.027-4.657 0-8.434 3.147-8.434 7.027 0 3.88 3.777 7.028 8.434 7.028a9.953 9.953 0 0 0 2.754-.385l.247-.037a.892.892 0 0 1 .448.13l1.847 1.066.162.053a.281.281 0 0 0 .281-.282l-.046-.205-.38-1.417-.029-.18a.56.56 0 0 1 .236-.458zM12.12 4.68C6.53 4.68 2 8.455 2 13.114a7.939 7.939 0 0 0 3.497 6.374.671.671 0 0 1 .283.55l-.035.215-.456 1.701-.055.246a.338.338 0 0 0 .337.338l.196-.063 2.216-1.28c.161-.099.347-.152.536-.155l.298.044c1.074.308 2.186.464 3.304.464l.555-.014a6.515 6.515 0 0 1-.34-2.067c0-4.247 4.133-7.691 9.23-7.691l.55.014c-.762-4.029-4.947-7.11-9.995-7.11zm6.633 13.663a1.124 1.124 0 1 1 0-2.249 1.124 1.124 0 0 1 0 2.249zm5.624 0a1.125 1.125 0 1 1-.003-2.249 1.125 1.125 0 0 1 .003 2.249zm-15.631-6.58a1.349 1.349 0 1 1 0-2.697 1.349 1.349 0 0 1 0 2.698zm6.747 0a1.349 1.349 0 1 1 0-2.697 1.349 1.349 0 0 1 0 2.698z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: WechatIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-wechat-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M27.086 24.78A6.618 6.618 0 0 0 30 19.465c0-3.88-3.776-7.027-8.434-7.027-4.657 0-8.434 3.147-8.434 7.027 0 3.88 3.777 7.028 8.434 7.028a9.953 9.953 0 0 0 2.754-.385l.247-.037a.892.892 0 0 1 .448.13l1.847 1.066.162.053a.281.281 0 0 0 .281-.282l-.046-.205-.38-1.417-.029-.18a.56.56 0 0 1 .236-.458zM12.12 4.68C6.53 4.68 2 8.455 2 13.114a7.939 7.939 0 0 0 3.497 6.374.671.671 0 0 1 .283.55l-.035.215-.456 1.701-.055.246a.338.338 0 0 0 .337.338l.196-.063 2.216-1.28c.161-.099.347-.152.536-.155l.298.044c1.074.308 2.186.464 3.304.464l.555-.014a6.515 6.515 0 0 1-.34-2.067c0-4.247 4.133-7.691 9.23-7.691l.55.014c-.762-4.029-4.947-7.11-9.995-7.11zm6.633 13.663a1.124 1.124 0 1 1 0-2.249 1.124 1.124 0 0 1 0 2.249zm5.624 0a1.125 1.125 0 1 1-.003-2.249 1.125 1.125 0 0 1 .003 2.249zm-15.631-6.58a1.349 1.349 0 1 1 0-2.697 1.349 1.349 0 0 1 0 2.698zm6.747 0a1.349 1.349 0 1 1 0-2.697 1.349 1.349 0 0 1 0 2.698z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class WmvIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: WmvIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: WmvIconComponent, isStandalone: true, selector: "iui-wmv-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m29 9-2 13-2-13h-2l2.52 14h2.96L31 9h-2zM19 9l-1.52 5-.48 1.98-.46-1.98L15 9h-2v14h2v-8l-.16-2 .58 2L17 19.63 18.58 15l.58-2-.16 2v8h2V9h-2zM9.2 9l-.34 8-.26 4.54L8.19 18l-.68-5.46H5.49L4.81 18l-.41 3.54L4.14 17 3.8 9H2l1 14h2.27l.76-4.93.46-4.07.01-.03.01.03.46 4.07.76 4.93H10l1-14H9.2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: WmvIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-wmv-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="m29 9-2 13-2-13h-2l2.52 14h2.96L31 9h-2zM19 9l-1.52 5-.48 1.98-.46-1.98L15 9h-2v14h2v-8l-.16-2 .58 2L17 19.63 18.58 15l.58-2-.16 2v8h2V9h-2zM9.2 9l-.34 8-.26 4.54L8.19 18l-.68-5.46H5.49L4.81 18l-.41 3.54L4.14 17 3.8 9H2l1 14h2.27l.76-4.93.46-4.07.01-.03.01.03.46 4.07.76 4.93H10l1-14H9.2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class XlsIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: XlsIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: XlsIconComponent, isStandalone: true, selector: "iui-xls-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 23h-6v-2h6v-4h-4a2.002 2.002 0 0 1-2-2v-4a2.002 2.002 0 0 1 2-2h6v2h-6v4h4a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zM14 21V9h-2v14h8v-2h-6zM10 9H8l-2 6-2-6H2l2.752 7L2 23h2l2-6 2 6h2l-2.755-7L10 9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: XlsIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-xls-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 23h-6v-2h6v-4h-4a2.002 2.002 0 0 1-2-2v-4a2.002 2.002 0 0 1 2-2h6v2h-6v4h4a2.002 2.002 0 0 1 2 2v4a2.002 2.002 0 0 1-2 2zM14 21V9h-2v14h8v-2h-6zM10 9H8l-2 6-2-6H2l2.752 7L2 23h2l2-6 2 6h2l-2.755-7L10 9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class XmlIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: XmlIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: XmlIconComponent, isStandalone: true, selector: "iui-xml-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 21V9h-2v14h8v-2h-6zM18 9l-1.52 5-.48 1.98-.46-1.98L14 9h-2v14h2v-8l-.16-2 .58 2L16 19.63 17.58 15l.58-2-.16 2v8h2V9h-2zM10 9H8l-2 6-2-6H2l2.75 7L2 23h2l2-6 2 6h2l-2.75-7L10 9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: XmlIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-xml-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M24 21V9h-2v14h8v-2h-6zM18 9l-1.52 5-.48 1.98-.46-1.98L14 9h-2v14h2v-8l-.16-2 .58 2L16 19.63 17.58 15l.58-2-.16 2v8h2V9h-2zM10 9H8l-2 6-2-6H2l2.75 7L2 23h2l2-6 2 6h2l-2.75-7L10 9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class YelpIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: YelpIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: YelpIconComponent, isStandalone: true, selector: "iui-yelp-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="m9.09 15.246 4.67 2.277a1.07 1.07 0 0 1-.21 2.002L8.51 20.782a1.073 1.073 0 0 1-1.324-.921 9.218 9.218 0 0 1 .42-3.997 1.07 1.07 0 0 1 1.485-.618zM10.96 24.86 14.436 21a1.072 1.072 0 0 1 1.866.753l-.181 5.194a1.072 1.072 0 0 1-1.25 1.02 9.301 9.301 0 0 1-3.722-1.507 1.07 1.07 0 0 1-.189-1.6zM19.203 19.722l4.94 1.606a1.071 1.071 0 0 1 .637 1.48 9.302 9.302 0 0 1-2.47 3.166 1.073 1.073 0 0 1-1.592-.258l-2.754-4.408a1.07 1.07 0 0 1 1.239-1.586zM24.227 16.57l-4.994 1.432a1.07 1.07 0 0 1-1.183-1.628l2.906-4.308a1.072 1.072 0 0 1 1.594-.206 9.216 9.216 0 0 1 2.363 3.25 1.073 1.073 0 0 1-.686 1.46zM12.556 4.45c-.883.236-1.742.553-2.567.946a1.07 1.07 0 0 0-.464 1.501l4.882 8.456a1.071 1.071 0 0 0 1.998-.535V5.053a1.07 1.07 0 0 0-1.152-1.068c-.912.072-1.814.228-2.697.465z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: YelpIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-yelp-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="m9.09 15.246 4.67 2.277a1.07 1.07 0 0 1-.21 2.002L8.51 20.782a1.073 1.073 0 0 1-1.324-.921 9.218 9.218 0 0 1 .42-3.997 1.07 1.07 0 0 1 1.485-.618zM10.96 24.86 14.436 21a1.072 1.072 0 0 1 1.866.753l-.181 5.194a1.072 1.072 0 0 1-1.25 1.02 9.301 9.301 0 0 1-3.722-1.507 1.07 1.07 0 0 1-.189-1.6zM19.203 19.722l4.94 1.606a1.071 1.071 0 0 1 .637 1.48 9.302 9.302 0 0 1-2.47 3.166 1.073 1.073 0 0 1-1.592-.258l-2.754-4.408a1.07 1.07 0 0 1 1.239-1.586zM24.227 16.57l-4.994 1.432a1.07 1.07 0 0 1-1.183-1.628l2.906-4.308a1.072 1.072 0 0 1 1.594-.206 9.216 9.216 0 0 1 2.363 3.25 1.073 1.073 0 0 1-.686 1.46zM12.556 4.45c-.883.236-1.742.553-2.567.946a1.07 1.07 0 0 0-.464 1.501l4.882 8.456a1.071 1.071 0 0 0 1.998-.535V5.053a1.07 1.07 0 0 0-1.152-1.068c-.912.072-1.814.228-2.697.465z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class YoutubeIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: YoutubeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: YoutubeIconComponent, isStandalone: true, selector: "iui-youtube-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29.41 9.26a3.5 3.5 0 0 0-2.47-2.47C24.76 6.2 16 6.2 16 6.2s-8.76 0-10.94.59a3.5 3.5 0 0 0-2.47 2.47A36.13 36.13 0 0 0 2 16a36.13 36.13 0 0 0 .59 6.74 3.5 3.5 0 0 0 2.47 2.47c2.18.59 10.94.59 10.94.59s8.76 0 10.94-.59a3.5 3.5 0 0 0 2.47-2.47c.407-2.223.605-4.48.59-6.74a36.125 36.125 0 0 0-.59-6.74zM13.2 20.2v-8.4l7.27 4.2-7.27 4.2z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: YoutubeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-youtube-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29.41 9.26a3.5 3.5 0 0 0-2.47-2.47C24.76 6.2 16 6.2 16 6.2s-8.76 0-10.94.59a3.5 3.5 0 0 0-2.47 2.47A36.13 36.13 0 0 0 2 16a36.13 36.13 0 0 0 .59 6.74 3.5 3.5 0 0 0 2.47 2.47c2.18.59 10.94.59 10.94.59s8.76 0 10.94-.59a3.5 3.5 0 0 0 2.47-2.47c.407-2.223.605-4.48.59-6.74a36.125 36.125 0 0 0-.59-6.74zM13.2 20.2v-8.4l7.27 4.2-7.27 4.2z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ZipIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ZipIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ZipIconComponent, isStandalone: true, selector: "iui-zip-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 9h-6v14h2v-5h4a2 2 0 0 0 2-2v-5a2 2 0 0 0-2-2zm0 7h-4v-5h4v5zM12 9v2h3v10h-3v2h8v-2h-3V11h3V9h-8zM10 9H2v2h6L2 21v2h8v-2H4l6-10V9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ZipIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-zip-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M28 9h-6v14h2v-5h4a2 2 0 0 0 2-2v-5a2 2 0 0 0-2-2zm0 7h-4v-5h4v5zM12 9v2h3v10h-3v2h8v-2h-3V11h3V9h-8zM10 9H2v2h6L2 21v2h8v-2H4l6-10V9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ZoomInIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ZoomInIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ZoomInIconComponent, isStandalone: true, selector: "iui-zoom-in-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 12h-4V8h-2v4H8v2h4v4h2v-4h4v-2z" fill="currentColor"></path><path d="M21.448 20A10.856 10.856 0 0 0 24 13a11 11 0 1 0-11 11c2.561.002 5.04-.902 7-2.552L27.586 29 29 27.586 21.448 20zM13 22a9 9 0 1 1 9-9 9.01 9.01 0 0 1-9 9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ZoomInIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-zoom-in-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 12h-4V8h-2v4H8v2h4v4h2v-4h4v-2z" fill="currentColor"></path><path d="M21.448 20A10.856 10.856 0 0 0 24 13a11 11 0 1 0-11 11c2.561.002 5.04-.902 7-2.552L27.586 29 29 27.586 21.448 20zM13 22a9 9 0 1 1 9-9 9.01 9.01 0 0 1-9 9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class ZoomOutIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ZoomOutIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ZoomOutIconComponent, isStandalone: true, selector: "iui-zoom-out-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 12H8v2h10v-2z" fill="currentColor"></path><path d="M21.448 20A10.856 10.856 0 0 0 24 13a11 11 0 1 0-11 11c2.561.002 5.04-.902 7-2.552L27.586 29 29 27.586 21.448 20zM13 22a9 9 0 1 1 9-9 9.01 9.01 0 0 1-9 9z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ZoomOutIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-zoom-out-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M18 12H8v2h10v-2z" fill="currentColor"></path><path d="M21.448 20A10.856 10.856 0 0 0 24 13a11 11 0 1 0-11 11c2.561.002 5.04-.902 7-2.552L27.586 29 29 27.586 21.448 20zM13 22a9 9 0 1 1 9-9 9.01 9.01 0 0 1-9 9z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

class AiCrownIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AiCrownIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AiCrownIconComponent, isStandalone: true, selector: "iui-ai-crown-icon", host: { classAttribute: "iui-icon" }, ngImport: i0, template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29.7155 27.2397C29.7155 27.2397 29.5189 26.5355 29.7174 26.0901C30.1574 25.1031 31.4313 19.2273 31.0418 17.4702C30.5592 15.2932 27.1824 12.3903 25.9762 12.3344C24.7699 12.2785 22.3238 15.8391 21.4191 16.509C19.5336 17.6525 16.0255 16.968 15.6034 16.8003C15.1813 16.6326 17.4127 16.6326 18.0759 16.2981C18.7391 15.9631 16.6588 14.735 16.6588 14.735C16.6588 14.735 19.9756 16.2422 21.4229 15.4886C21.9258 15.4045 18.8695 15.0024 17.8949 14.121C16.086 12.4462 15.7244 11.6085 14.3371 12.3344C12.9502 13.0602 10.9111 16.8863 10.61 18.0584C10.3085 19.2306 11.5029 23.89 12.4681 25.7321C13.4328 27.5742 13.7949 27.1833 13.7344 27.8533C13.6739 28.5232 13.6139 28.5232 13.6139 28.5232C22.1083 29.724 20.1112 25.1881 29.7155 27.2397Z" fill="currentColor"></path><path d="M31.9999 31.9999L31.7183 29.7266C31.7183 29.7266 29.4651 27.7671 25.5216 28.1401C21.5781 28.5136 20.5458 29.8197 17.9167 30.1932C15.2877 30.5662 12.7528 29.3532 12.7528 29.3532C12.7528 29.3532 12.1894 30.0062 12.1894 30.5662V31.9999H31.9999Z" fill="currentColor"></path><path d="M6 6L6.0574 6.57183C6.34243 9.4116 8.5884 11.6576 11.4282 11.9426L12 12L11.4282 12.0574C8.5884 12.3424 6.34243 14.5884 6.0574 17.4282L6 18L5.9426 17.4282C5.65757 14.5884 3.4116 12.3424 0.571826 12.0574L0 12L0.571827 11.9426C3.4116 11.6576 5.65757 9.4116 5.9426 6.57183L6 6Z" fill="currentColor"></path><path d="M13 2C13.2123 4.11498 14.885 5.78771 17 6C14.885 6.21229 13.2123 7.88502 13 10C12.7877 7.88502 11.115 6.21229 9 6C11.115 5.78771 12.7877 4.11498 13 2Z" fill="currentColor"></path><path d="M6.5 0C6.63268 1.32186 7.67814 2.36732 9 2.5C7.67814 2.63268 6.63268 3.67814 6.5 5C6.36732 3.67814 5.32186 2.63268 4 2.5C5.32186 2.36732 6.36732 1.32186 6.5 0Z" fill="currentColor"></path></svg>`, isInline: true, styles: [":host{display:block}svg{vertical-align:middle}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AiCrownIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-ai-crown-icon', standalone: true, imports: [CommonModule], template: `<svg viewBox="0 0 32 32" fill="none" focusable="false" aria-hidden="true"><path d="M29.7155 27.2397C29.7155 27.2397 29.5189 26.5355 29.7174 26.0901C30.1574 25.1031 31.4313 19.2273 31.0418 17.4702C30.5592 15.2932 27.1824 12.3903 25.9762 12.3344C24.7699 12.2785 22.3238 15.8391 21.4191 16.509C19.5336 17.6525 16.0255 16.968 15.6034 16.8003C15.1813 16.6326 17.4127 16.6326 18.0759 16.2981C18.7391 15.9631 16.6588 14.735 16.6588 14.735C16.6588 14.735 19.9756 16.2422 21.4229 15.4886C21.9258 15.4045 18.8695 15.0024 17.8949 14.121C16.086 12.4462 15.7244 11.6085 14.3371 12.3344C12.9502 13.0602 10.9111 16.8863 10.61 18.0584C10.3085 19.2306 11.5029 23.89 12.4681 25.7321C13.4328 27.5742 13.7949 27.1833 13.7344 27.8533C13.6739 28.5232 13.6139 28.5232 13.6139 28.5232C22.1083 29.724 20.1112 25.1881 29.7155 27.2397Z" fill="currentColor"></path><path d="M31.9999 31.9999L31.7183 29.7266C31.7183 29.7266 29.4651 27.7671 25.5216 28.1401C21.5781 28.5136 20.5458 29.8197 17.9167 30.1932C15.2877 30.5662 12.7528 29.3532 12.7528 29.3532C12.7528 29.3532 12.1894 30.0062 12.1894 30.5662V31.9999H31.9999Z" fill="currentColor"></path><path d="M6 6L6.0574 6.57183C6.34243 9.4116 8.5884 11.6576 11.4282 11.9426L12 12L11.4282 12.0574C8.5884 12.3424 6.34243 14.5884 6.0574 17.4282L6 18L5.9426 17.4282C5.65757 14.5884 3.4116 12.3424 0.571826 12.0574L0 12L0.571827 11.9426C3.4116 11.6576 5.65757 9.4116 5.9426 6.57183L6 6Z" fill="currentColor"></path><path d="M13 2C13.2123 4.11498 14.885 5.78771 17 6C14.885 6.21229 13.2123 7.88502 13 10C12.7877 7.88502 11.115 6.21229 9 6C11.115 5.78771 12.7877 4.11498 13 2Z" fill="currentColor"></path><path d="M6.5 0C6.63268 1.32186 7.67814 2.36732 9 2.5C7.67814 2.63268 6.63268 3.67814 6.5 5C6.36732 3.67814 5.32186 2.63268 4 2.5C5.32186 2.36732 6.36732 1.32186 6.5 0Z" fill="currentColor"></path></svg>`, host: {
                        class: 'iui-icon',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}svg{vertical-align:middle}\n"] }]
        }] });

const ALL_ICONS = [
    AccountIconComponent,
    AddCommentIconComponent,
    AddEmptyIconComponent,
    AddFillIconComponent,
    AlarmAddIconComponent,
    AlarmIconComponent,
    AlarmSubtractIconComponent,
    AlignBoxBottomCenterIconComponent,
    AlignBoxBottomLeftIconComponent,
    AlignBoxBottomRightIconComponent,
    AlignBoxMiddleCenterIconComponent,
    AlignBoxMiddleLeftIconComponent,
    AlignBoxMiddleRightIconComponent,
    AlignBoxTopCenterIconComponent,
    AlignBoxTopLeftIconComponent,
    AlignBoxTopRightIconComponent,
    AlignHorizontalCenterIconComponent,
    AlignHorizontalLeftIconComponent,
    AlignHorizontalRightIconComponent,
    AlignVerticalBottomIconComponent,
    AlignVerticalCenterIconComponent,
    AlignVerticalTopIconComponent,
    ArchiveIconComponent,
    ArrowDownIconComponent,
    ArrowDownLeftIconComponent,
    ArrowDownRightIconComponent,
    ArrowLeftIconComponent,
    ArrowRightIconComponent,
    ArrowUpIconComponent,
    ArrowUpLeftIconComponent,
    ArrowUpRightIconComponent,
    AttachmentIconComponent,
    BadgeIconComponent,
    BarcodeIconComponent,
    BatteryChargingIconComponent,
    BatteryEmptyIconComponent,
    BatteryFullIconComponent,
    BatteryHalfIconComponent,
    BatteryLowIconComponent,
    BatteryQuarterIconComponent,
    BookIconComponent,
    BookmarkAddIconComponent,
    BookmarkFillIconComponent,
    BookmarkOutlineIconComponent,
    CalendarAddIconComponent,
    CalendarIconComponent,
    CalendarRemindIconComponent,
    CameraIconComponent,
    CaretBottomRightIconComponent,
    CaretDownIconComponent,
    CaretLeftIconComponent,
    CaretRightIconComponent,
    CaretUpIconComponent,
    CatalogIconComponent,
    CategoriesIconComponent,
    CdaIconComponent,
    CenterToFitIconComponent,
    CertificateCheckIconComponent,
    CertificateIconComponent,
    ChatIconComponent,
    ChatLaunchIconComponent,
    CheckmarkEmptyIconComponent,
    CheckmarkFillIconComponent,
    CheckmarkOutlineIconComponent,
    ChevronDownIconComponent,
    ChevronLeftIconComponent,
    ChevronRightIconComponent,
    ChevronUpIconComponent,
    CircleDashedIconComponent,
    CloseEmptyIconComponent,
    CloseFillIconComponent,
    CloudDownloadIconComponent,
    CloudOfflineIconComponent,
    CloudUploadIconComponent,
    CollaborateIconComponent,
    CommunityIconComponent,
    CompareIconComponent,
    CopyDocumentIconComponent,
    CopyIconComponent,
    CopyImageIconComponent,
    CopyLinkIconComponent,
    CredentialsIconComponent,
    CropIconComponent,
    CsvIconComponent,
    CutIconComponent,
    DashboardIconComponent,
    DeleteIconComponent,
    DeliveryAddIconComponent,
    DeliveryIconComponent,
    DeliveryParcelIconComponent,
    DesktopIconComponent,
    DevicesIconComponent,
    DiscordIconComponent,
    DistributeHorizontalCenterIconComponent,
    DistributeHorizontalLeftIconComponent,
    DistributeHorizontalRightIconComponent,
    DistributeVerticalBottomIconComponent,
    DistributeVerticalCenterIconComponent,
    DistributeVerticalTopIconComponent,
    DocIconComponent,
    DocumentAddIconComponent,
    DocumentAudioIconComponent,
    DocumentCheckIconComponent,
    DocumentDownloadIconComponent,
    DocumentExportIconComponent,
    DocumentIconComponent,
    DocumentImportIconComponent,
    DocumentLockedIconComponent,
    DocumentProtectedIconComponent,
    DocumentSignedIconComponent,
    DocumentSubtractIconComponent,
    DocumentUnlockIconComponent,
    DocumentVideoIconComponent,
    DocumentViewIconComponent,
    DownloadIconComponent,
    DragDropIconComponent,
    DragHorizontalIconComponent,
    DragVerticalIconComponent,
    DrawIconComponent,
    DvrIconComponent,
    EditIconComponent,
    EducationIconComponent,
    EmailIconComponent,
    EraseIconComponent,
    ErrorIconComponent,
    ExitIconComponent,
    ExportIconComponent,
    FaceDissatisfiedFillIconComponent,
    FaceDissatisfiedOutlineIconComponent,
    FaceDizzyFillIconComponent,
    FaceDizzyOutlineIconComponent,
    FaceIdIconComponent,
    FaceNeutralFillIconComponent,
    FaceNeutralOutlineIconComponent,
    FacePendingFillIconComponent,
    FacePendingOutlineIconComponent,
    FaceSatisfiedFillIconComponent,
    FaceSatisfiedOutlineIconComponent,
    FaceWideFillIconComponent,
    FaceWideOutlineIconComponent,
    FaceWinkFillIconComponent,
    FaceWinkOutlineIconComponent,
    FacebookIconComponent,
    FactoryIconComponent,
    FavoriteFillIconComponent,
    FavoriteHalfIconComponent,
    FavoriteOutlineIconComponent,
    FilterIconComponent,
    FitToHeightIconComponent,
    FitToScreenIconComponent,
    FitToWidthIconComponent,
    FlagFillIconComponent,
    FlagOutlineIconComponent,
    FlashFillIconComponent,
    FlashOffFillIconComponent,
    FlashOffOutlineIconComponent,
    FlashOutlineIconComponent,
    FolderAddIconComponent,
    FolderDetailIconComponent,
    FolderIconComponent,
    FolderMoveToIconComponent,
    FolderOffIconComponent,
    FolderOpenIconComponent,
    FolderSharedIconComponent,
    FoldersIconComponent,
    ForwardIconComponent,
    Forward10IconComponent,
    Forward30IconComponent,
    Forward5IconComponent,
    GalleryIconComponent,
    GenderFemaleIconComponent,
    GenderMaleIconComponent,
    GifIconComponent,
    GiftIconComponent,
    GithubIconComponent,
    GrowIconComponent,
    HelpFillIconComponent,
    HelpOutlineIconComponent,
    HomeIconComponent,
    HtmlIconComponent,
    IdentificationIconComponent,
    ImageDrawIconComponent,
    ImageIconComponent,
    InProgressIconComponent,
    IncompleteIconComponent,
    InformationIconComponent,
    InstagramIconComponent,
    IsoIconComponent,
    IteroScannerIconComponent,
    JpgIconComponent,
    JsonIconComponent,
    LanguageIconComponent,
    LaptopIconComponent,
    LightFillIconComponent,
    LightIconComponent,
    LinkIconComponent,
    LinkedinIconComponent,
    ListIconComponent,
    LocationStarFilledIconComponent,
    LocationStarOutlineIconComponent,
    LockedIconComponent,
    LoginIconComponent,
    LogoutIconComponent,
    MaximizeIconComponent,
    MediumIconComponent,
    MenuIconComponent,
    MicrophoneFillIconComponent,
    MicrophoneOffFillIconComponent,
    MicrophoneOffOutlineIconComponent,
    MicrophoneOutlineIconComponent,
    MinimizeIconComponent,
    MobileLandscapeIconComponent,
    MobilePortraitIconComponent,
    MoneyIconComponent,
    MoreHorizontalIconComponent,
    MoreVerticalIconComponent,
    MovIconComponent,
    MoveIconComponent,
    Mp3IconComponent,
    Mp4IconComponent,
    MpegIconComponent,
    Mpg2IconComponent,
    NewMessageIconComponent,
    NoImageIconComponent,
    NonCertifiedIconComponent,
    NotificationFillIconComponent,
    NotificationNewIconComponent,
    NotificationOffFillIconComponent,
    NotificationOffOutlineIconComponent,
    NotificationOutlineIconComponent,
    NumberFilled1IconComponent,
    NumberFilled2IconComponent,
    NumberFilled3IconComponent,
    NumberFilled4IconComponent,
    NumberFilled5IconComponent,
    NumberFilled6IconComponent,
    NumberFilled7IconComponent,
    NumberFilled8IconComponent,
    NumberFilled9IconComponent,
    NumberOutline1IconComponent,
    NumberOutline2IconComponent,
    NumberOutline3IconComponent,
    NumberOutline4IconComponent,
    NumberOutline5IconComponent,
    NumberOutline6IconComponent,
    NumberOutline7IconComponent,
    NumberOutline8IconComponent,
    NumberOutline9IconComponent,
    OpenBottomPanelFillIconComponent,
    OpenBottomPanelOutllineIconComponent,
    OpenLeftPanelFillIconComponent,
    OpenLeftPanelOutllineIconComponent,
    OpenRightPanelFillIconComponent,
    OpenRightPanelOutllineIconComponent,
    OpenTopPanelFillIconComponent,
    OpenTopPanelOutllineIconComponent,
    OrderHistoryIconComponent,
    PageFirstIconComponent,
    PageLastIconComponent,
    PauseFillIconComponent,
    PauseOutlineIconComponent,
    PdfIconComponent,
    PhoneBlockFillIconComponent,
    PhoneBlockOutlineIconComponent,
    PhoneFillIconComponent,
    PhoneIconComponent,
    PhoneIncomingFillIconComponent,
    PhoneIncomingOutlineIconComponent,
    PhoneOffFillIconComponent,
    PhoneOffOutlineIconComponent,
    PhoneOutgoingFillIconComponent,
    PhoneOutgoingOutlineIconComponent,
    PhoneVoiseFillIconComponent,
    PhoneVoiseOutlineIconComponent,
    PieChartIconComponent,
    PiggyBankIconComponent,
    PinFillIconComponent,
    PinOutlineIconComponent,
    PlanIconComponent,
    PlayFillIconComponent,
    PlayOutlineIconComponent,
    PngIconComponent,
    PptIconComponent,
    PrintIconComponent,
    ProtectionIconComponent,
    PurchaseIconComponent,
    QrCodeIconComponent,
    RawIconComponent,
    ReceiptIconComponent,
    RecordFillIconComponent,
    RecordOutlineIconComponent,
    RedoIconComponent,
    RefreshIconComponent,
    ReplyAllIconComponent,
    ReplyIconComponent,
    Rewind10IconComponent,
    Rewind30IconComponent,
    Rewind5IconComponent,
    RotateIconComponent,
    RxIconComponent,
    SaveIconComponent,
    SdkIconComponent,
    SearchIconComponent,
    SendFilledIconComponent,
    SendOutlineIconComponent,
    SettingsIconComponent,
    ShareIconComponent,
    ShoppingBagIconComponent,
    ShoppingCartAddIconComponent,
    ShoppingCartArrowDownIconComponent,
    ShoppingCartArrowUpIconComponent,
    ShoppingCartClearIconComponent,
    ShoppingCartErrorIconComponent,
    ShoppingCartIconComponent,
    ShoppingCartSubtractIconComponent,
    ShrinkScreenFillIconComponent,
    ShrinkScreenOutlineIconComponent,
    SkipBackFillIconComponent,
    SkipBackOutlineIconComponent,
    SkipForwardFillIconComponent,
    SkipForwardOutlineIconComponent,
    SkypeIconComponent,
    SlackIconComponent,
    SnapchatIconComponent,
    SortAscendingIconComponent,
    SortDescendingIconComponent,
    SqlIconComponent,
    StarFillIconComponent,
    StarHalfIconComponent,
    StarOutlineIconComponent,
    StopFillIconComponent,
    StopOutlineIconComponent,
    SubtractEmptyIconComponent,
    SubtractFillIconComponent,
    SubtractOutlineIconComponent,
    SvgIconComponent,
    TabletLandscapeIconComponent,
    TabletPortraitIconComponent,
    TextScaleIconComponent,
    ThumbsDownFillIconComponent,
    ThumbsDownOutlineIconComponent,
    ThumbsUpFillIconComponent,
    ThumbsUpOutlineIconComponent,
    TifIconComponent,
    TikTokIconComponent,
    TimeIconComponent,
    TimerIconComponent,
    TransgenderIconComponent,
    TrophyIconComponent,
    TsvIconComponent,
    TumblrIconComponent,
    TwitterIconComponent,
    TxtIconComponent,
    UndoIconComponent,
    UnlinkIconComponent,
    UnlockedIconComponent,
    UpToBottomIconComponent,
    UpToTopIconComponent,
    UploadIconComponent,
    UrrencyBahtIconComponent,
    UrrencyDollarIconComponent,
    UrrencyEuroIconComponent,
    UrrencyLiraIconComponent,
    UrrencyPoundIconComponent,
    UrrencyRubleIconComponent,
    UrrencyRupeeIconComponent,
    UrrencyShekelIconComponent,
    UrrencyWonIconComponent,
    UrrencyYenIconComponent,
    UserIconComponent,
    UsersIconComponent,
    VideoAddIconComponent,
    VideoFillIconComponent,
    VideoOffFillIconComponent,
    VideoOffOutlineIconComponent,
    VideoOutlineIconComponent,
    ViewOffIconComponent,
    ViewOnIconComponent,
    VolumeDownFillIconComponent,
    VolumeDownOutlineIconComponent,
    VolumeMuteFillIconComponent,
    VolumeMuteIconComponent,
    VolumeUpFillIconComponent,
    VolumeUpOutlineIconComponent,
    WalletIconComponent,
    WarningIconComponent,
    WatchIconComponent,
    WechatIconComponent,
    WmvIconComponent,
    XlsIconComponent,
    XmlIconComponent,
    YelpIconComponent,
    YoutubeIconComponent,
    ZipIconComponent,
    ZoomInIconComponent,
    ZoomOutIconComponent,
    AiCrownIconComponent,
];

/**
 * Generated bundle index. Do not edit.
 */

export { ALL_ICONS, AccountIconComponent, AddCommentIconComponent, AddEmptyIconComponent, AddFillIconComponent, AiCrownIconComponent, AlarmAddIconComponent, AlarmIconComponent, AlarmSubtractIconComponent, AlignBoxBottomCenterIconComponent, AlignBoxBottomLeftIconComponent, AlignBoxBottomRightIconComponent, AlignBoxMiddleCenterIconComponent, AlignBoxMiddleLeftIconComponent, AlignBoxMiddleRightIconComponent, AlignBoxTopCenterIconComponent, AlignBoxTopLeftIconComponent, AlignBoxTopRightIconComponent, AlignHorizontalCenterIconComponent, AlignHorizontalLeftIconComponent, AlignHorizontalRightIconComponent, AlignVerticalBottomIconComponent, AlignVerticalCenterIconComponent, AlignVerticalTopIconComponent, ArchiveIconComponent, ArrowDownIconComponent, ArrowDownLeftIconComponent, ArrowDownRightIconComponent, ArrowLeftIconComponent, ArrowRightIconComponent, ArrowUpIconComponent, ArrowUpLeftIconComponent, ArrowUpRightIconComponent, AttachmentIconComponent, BadgeIconComponent, BarcodeIconComponent, BatteryChargingIconComponent, BatteryEmptyIconComponent, BatteryFullIconComponent, BatteryHalfIconComponent, BatteryLowIconComponent, BatteryQuarterIconComponent, BookIconComponent, BookmarkAddIconComponent, BookmarkFillIconComponent, BookmarkOutlineIconComponent, CalendarAddIconComponent, CalendarIconComponent, CalendarRemindIconComponent, CameraIconComponent, CaretBottomRightIconComponent, CaretDownIconComponent, CaretLeftIconComponent, CaretRightIconComponent, CaretUpIconComponent, CatalogIconComponent, CategoriesIconComponent, CdaIconComponent, CenterToFitIconComponent, CertificateCheckIconComponent, CertificateIconComponent, ChatIconComponent, ChatLaunchIconComponent, CheckmarkEmptyIconComponent, CheckmarkFillIconComponent, CheckmarkOutlineIconComponent, ChevronDownIconComponent, ChevronLeftIconComponent, ChevronRightIconComponent, ChevronUpIconComponent, CircleDashedIconComponent, CloseEmptyIconComponent, CloseFillIconComponent, CloudDownloadIconComponent, CloudOfflineIconComponent, CloudUploadIconComponent, CollaborateIconComponent, CommunityIconComponent, CompareIconComponent, CopyDocumentIconComponent, CopyIconComponent, CopyImageIconComponent, CopyLinkIconComponent, CredentialsIconComponent, CropIconComponent, CsvIconComponent, CutIconComponent, DashboardIconComponent, DeleteIconComponent, DeliveryAddIconComponent, DeliveryIconComponent, DeliveryParcelIconComponent, DesktopIconComponent, DevicesIconComponent, DiscordIconComponent, DistributeHorizontalCenterIconComponent, DistributeHorizontalLeftIconComponent, DistributeHorizontalRightIconComponent, DistributeVerticalBottomIconComponent, DistributeVerticalCenterIconComponent, DistributeVerticalTopIconComponent, DocIconComponent, DocumentAddIconComponent, DocumentAudioIconComponent, DocumentCheckIconComponent, DocumentDownloadIconComponent, DocumentExportIconComponent, DocumentIconComponent, DocumentImportIconComponent, DocumentLockedIconComponent, DocumentProtectedIconComponent, DocumentSignedIconComponent, DocumentSubtractIconComponent, DocumentUnlockIconComponent, DocumentVideoIconComponent, DocumentViewIconComponent, DownloadIconComponent, DragDropIconComponent, DragHorizontalIconComponent, DragVerticalIconComponent, DrawIconComponent, DvrIconComponent, EditIconComponent, EducationIconComponent, EmailIconComponent, EraseIconComponent, ErrorIconComponent, ExitIconComponent, ExportIconComponent, FaceDissatisfiedFillIconComponent, FaceDissatisfiedOutlineIconComponent, FaceDizzyFillIconComponent, FaceDizzyOutlineIconComponent, FaceIdIconComponent, FaceNeutralFillIconComponent, FaceNeutralOutlineIconComponent, FacePendingFillIconComponent, FacePendingOutlineIconComponent, FaceSatisfiedFillIconComponent, FaceSatisfiedOutlineIconComponent, FaceWideFillIconComponent, FaceWideOutlineIconComponent, FaceWinkFillIconComponent, FaceWinkOutlineIconComponent, FacebookIconComponent, FactoryIconComponent, FavoriteFillIconComponent, FavoriteHalfIconComponent, FavoriteOutlineIconComponent, FilterIconComponent, FitToHeightIconComponent, FitToScreenIconComponent, FitToWidthIconComponent, FlagFillIconComponent, FlagOutlineIconComponent, FlashFillIconComponent, FlashOffFillIconComponent, FlashOffOutlineIconComponent, FlashOutlineIconComponent, FolderAddIconComponent, FolderDetailIconComponent, FolderIconComponent, FolderMoveToIconComponent, FolderOffIconComponent, FolderOpenIconComponent, FolderSharedIconComponent, FoldersIconComponent, Forward10IconComponent, Forward30IconComponent, Forward5IconComponent, ForwardIconComponent, GalleryIconComponent, GenderFemaleIconComponent, GenderMaleIconComponent, GifIconComponent, GiftIconComponent, GithubIconComponent, GrowIconComponent, HelpFillIconComponent, HelpOutlineIconComponent, HomeIconComponent, HtmlIconComponent, IdentificationIconComponent, ImageDrawIconComponent, ImageIconComponent, InProgressIconComponent, IncompleteIconComponent, InformationIconComponent, InstagramIconComponent, IsoIconComponent, IteroScannerIconComponent, JpgIconComponent, JsonIconComponent, LanguageIconComponent, LaptopIconComponent, LightFillIconComponent, LightIconComponent, LinkIconComponent, LinkedinIconComponent, ListIconComponent, LocationStarFilledIconComponent, LocationStarOutlineIconComponent, LockedIconComponent, LoginIconComponent, LogoutIconComponent, MaximizeIconComponent, MediumIconComponent, MenuIconComponent, MicrophoneFillIconComponent, MicrophoneOffFillIconComponent, MicrophoneOffOutlineIconComponent, MicrophoneOutlineIconComponent, MinimizeIconComponent, MobileLandscapeIconComponent, MobilePortraitIconComponent, MoneyIconComponent, MoreHorizontalIconComponent, MoreVerticalIconComponent, MovIconComponent, MoveIconComponent, Mp3IconComponent, Mp4IconComponent, MpegIconComponent, Mpg2IconComponent, NewMessageIconComponent, NoImageIconComponent, NonCertifiedIconComponent, NotificationFillIconComponent, NotificationNewIconComponent, NotificationOffFillIconComponent, NotificationOffOutlineIconComponent, NotificationOutlineIconComponent, NumberFilled1IconComponent, NumberFilled2IconComponent, NumberFilled3IconComponent, NumberFilled4IconComponent, NumberFilled5IconComponent, NumberFilled6IconComponent, NumberFilled7IconComponent, NumberFilled8IconComponent, NumberFilled9IconComponent, NumberOutline1IconComponent, NumberOutline2IconComponent, NumberOutline3IconComponent, NumberOutline4IconComponent, NumberOutline5IconComponent, NumberOutline6IconComponent, NumberOutline7IconComponent, NumberOutline8IconComponent, NumberOutline9IconComponent, OpenBottomPanelFillIconComponent, OpenBottomPanelOutllineIconComponent, OpenLeftPanelFillIconComponent, OpenLeftPanelOutllineIconComponent, OpenRightPanelFillIconComponent, OpenRightPanelOutllineIconComponent, OpenTopPanelFillIconComponent, OpenTopPanelOutllineIconComponent, OrderHistoryIconComponent, PageFirstIconComponent, PageLastIconComponent, PauseFillIconComponent, PauseOutlineIconComponent, PdfIconComponent, PhoneBlockFillIconComponent, PhoneBlockOutlineIconComponent, PhoneFillIconComponent, PhoneIconComponent, PhoneIncomingFillIconComponent, PhoneIncomingOutlineIconComponent, PhoneOffFillIconComponent, PhoneOffOutlineIconComponent, PhoneOutgoingFillIconComponent, PhoneOutgoingOutlineIconComponent, PhoneVoiseFillIconComponent, PhoneVoiseOutlineIconComponent, PieChartIconComponent, PiggyBankIconComponent, PinFillIconComponent, PinOutlineIconComponent, PlanIconComponent, PlayFillIconComponent, PlayOutlineIconComponent, PngIconComponent, PptIconComponent, PrintIconComponent, ProtectionIconComponent, PurchaseIconComponent, QrCodeIconComponent, RawIconComponent, ReceiptIconComponent, RecordFillIconComponent, RecordOutlineIconComponent, RedoIconComponent, RefreshIconComponent, ReplyAllIconComponent, ReplyIconComponent, Rewind10IconComponent, Rewind30IconComponent, Rewind5IconComponent, RotateIconComponent, RxIconComponent, SaveIconComponent, SdkIconComponent, SearchIconComponent, SendFilledIconComponent, SendOutlineIconComponent, SettingsIconComponent, ShareIconComponent, ShoppingBagIconComponent, ShoppingCartAddIconComponent, ShoppingCartArrowDownIconComponent, ShoppingCartArrowUpIconComponent, ShoppingCartClearIconComponent, ShoppingCartErrorIconComponent, ShoppingCartIconComponent, ShoppingCartSubtractIconComponent, ShrinkScreenFillIconComponent, ShrinkScreenOutlineIconComponent, SkipBackFillIconComponent, SkipBackOutlineIconComponent, SkipForwardFillIconComponent, SkipForwardOutlineIconComponent, SkypeIconComponent, SlackIconComponent, SnapchatIconComponent, SortAscendingIconComponent, SortDescendingIconComponent, SqlIconComponent, StarFillIconComponent, StarHalfIconComponent, StarOutlineIconComponent, StopFillIconComponent, StopOutlineIconComponent, SubtractEmptyIconComponent, SubtractFillIconComponent, SubtractOutlineIconComponent, SvgIconComponent, TabletLandscapeIconComponent, TabletPortraitIconComponent, TextScaleIconComponent, ThumbsDownFillIconComponent, ThumbsDownOutlineIconComponent, ThumbsUpFillIconComponent, ThumbsUpOutlineIconComponent, TifIconComponent, TikTokIconComponent, TimeIconComponent, TimerIconComponent, TransgenderIconComponent, TrophyIconComponent, TsvIconComponent, TumblrIconComponent, TwitterIconComponent, TxtIconComponent, UndoIconComponent, UnlinkIconComponent, UnlockedIconComponent, UpToBottomIconComponent, UpToTopIconComponent, UploadIconComponent, UrrencyBahtIconComponent, UrrencyDollarIconComponent, UrrencyEuroIconComponent, UrrencyLiraIconComponent, UrrencyPoundIconComponent, UrrencyRubleIconComponent, UrrencyRupeeIconComponent, UrrencyShekelIconComponent, UrrencyWonIconComponent, UrrencyYenIconComponent, UserIconComponent, UsersIconComponent, VideoAddIconComponent, VideoFillIconComponent, VideoOffFillIconComponent, VideoOffOutlineIconComponent, VideoOutlineIconComponent, ViewOffIconComponent, ViewOnIconComponent, VolumeDownFillIconComponent, VolumeDownOutlineIconComponent, VolumeMuteFillIconComponent, VolumeMuteIconComponent, VolumeUpFillIconComponent, VolumeUpOutlineIconComponent, WalletIconComponent, WarningIconComponent, WatchIconComponent, WechatIconComponent, WmvIconComponent, XlsIconComponent, XmlIconComponent, YelpIconComponent, YoutubeIconComponent, ZipIconComponent, ZoomInIconComponent, ZoomOutIconComponent };
//# sourceMappingURL=itero-ui-components-angular-icons.mjs.map
