import * as i0 from '@angular/core';
import { Input, ChangeDetectionStrategy, Component, createComponent, HostListener, Directive } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InformationIconComponent } from '@itero/ui-components-angular/icons';

class IuiTooltipComponent {
    constructor() {
        this.placement = 'bottom';
        this.alignment = 'start';
        this.showCaret = true;
        this.text = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTooltipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.12", type: IuiTooltipComponent, isStandalone: true, selector: "iui-tooltip", inputs: { placement: "placement", alignment: "alignment", showCaret: "showCaret", text: "text" }, ngImport: i0, template: "<div class=\"iui-tooltip__wrap\"\n     [class.iui-tooltip__wrap--bottom]=\"placement === 'bottom'\"\n     [class.iui-tooltip__wrap--top]=\"placement === 'top'\"\n     [class.iui-tooltip__wrap--left]=\"placement === 'left'\"\n     [class.iui-tooltip__wrap--right]=\"placement === 'right'\"\n     [class.iui-tooltip__wrap--align-start]=\"alignment === 'start'\"\n     [class.iui-tooltip__wrap--align-middle]=\"alignment === 'middle'\"\n     [class.iui-tooltip__wrap--align-end]=\"alignment === 'end'\"\n     role=\"tooltip\">\n  <!-- Caret at start (before body): bottom and right placements -->\n  @if (showCaret && (placement === 'bottom' || placement === 'right')) {\n    <div class=\"iui-tooltip__caret\"\n         [class.iui-tooltip__caret--up]=\"placement === 'bottom'\"\n         [class.iui-tooltip__caret--left]=\"placement === 'right'\">\n    </div>\n  }\n  <div class=\"iui-tooltip__body\">\n    <span class=\"iui-tooltip__text\">{{ text }}</span>\n    <ng-content></ng-content>\n  </div>\n  <!-- Caret at end (after body): top and left placements -->\n  @if (showCaret && (placement === 'top' || placement === 'left')) {\n    <div class=\"iui-tooltip__caret\"\n         [class.iui-tooltip__caret--down]=\"placement === 'top'\"\n         [class.iui-tooltip__caret--right]=\"placement === 'left'\">\n    </div>\n  }\n</div>\n", styles: [":host{display:inline-block;width:max-content;max-width:var(--iui-tooltip-max-width)}.iui-tooltip__wrap{display:inline-flex;align-items:flex-start;width:max-content;max-width:var(--iui-tooltip-max-width)}.iui-tooltip__wrap--bottom,.iui-tooltip__wrap--top{flex-direction:column}.iui-tooltip__wrap--left,.iui-tooltip__wrap--right{flex-direction:row}.iui-tooltip__wrap--align-start{align-items:flex-start}.iui-tooltip__wrap--align-middle{align-items:center}.iui-tooltip__wrap--align-end{align-items:flex-end}.iui-tooltip__wrap--bottom.iui-tooltip__wrap--align-start .iui-tooltip__caret,.iui-tooltip__wrap--top.iui-tooltip__wrap--align-start .iui-tooltip__caret{margin-left:var(--iui-tooltip-border-radius)}.iui-tooltip__wrap--bottom.iui-tooltip__wrap--align-end .iui-tooltip__caret,.iui-tooltip__wrap--top.iui-tooltip__wrap--align-end .iui-tooltip__caret{margin-right:var(--iui-tooltip-border-radius)}.iui-tooltip__wrap--left.iui-tooltip__wrap--align-start .iui-tooltip__caret,.iui-tooltip__wrap--right.iui-tooltip__wrap--align-start .iui-tooltip__caret{margin-top:var(--iui-tooltip-border-radius)}.iui-tooltip__wrap--left.iui-tooltip__wrap--align-end .iui-tooltip__caret,.iui-tooltip__wrap--right.iui-tooltip__wrap--align-end .iui-tooltip__caret{margin-bottom:var(--iui-tooltip-border-radius)}.iui-tooltip__body{background:var(--iui-tooltip-bg);color:var(--iui-tooltip-color);padding:var(--iui-tooltip-padding);border-radius:var(--iui-tooltip-border-radius);width:max-content;max-width:var(--iui-tooltip-max-width);min-width:var(--iui-tooltip-min-width);box-sizing:border-box}.iui-tooltip__text{font:var(--iui-tp-body-01-font);display:block;max-width:288px;min-width:28px}.iui-tooltip__caret{flex-shrink:0;width:0;height:0}.iui-tooltip__caret--up{border-left:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-right:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-bottom:var(--iui-tooltip-caret-size-short) solid var(--iui-tooltip-bg)}.iui-tooltip__caret--down{border-left:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-right:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-top:var(--iui-tooltip-caret-size-short) solid var(--iui-tooltip-bg)}.iui-tooltip__caret--left{border-top:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-bottom:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-right:var(--iui-tooltip-caret-size-short) solid var(--iui-tooltip-bg)}.iui-tooltip__caret--right{border-top:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-bottom:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-left:var(--iui-tooltip-caret-size-short) solid var(--iui-tooltip-bg)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTooltipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-tooltip', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"iui-tooltip__wrap\"\n     [class.iui-tooltip__wrap--bottom]=\"placement === 'bottom'\"\n     [class.iui-tooltip__wrap--top]=\"placement === 'top'\"\n     [class.iui-tooltip__wrap--left]=\"placement === 'left'\"\n     [class.iui-tooltip__wrap--right]=\"placement === 'right'\"\n     [class.iui-tooltip__wrap--align-start]=\"alignment === 'start'\"\n     [class.iui-tooltip__wrap--align-middle]=\"alignment === 'middle'\"\n     [class.iui-tooltip__wrap--align-end]=\"alignment === 'end'\"\n     role=\"tooltip\">\n  <!-- Caret at start (before body): bottom and right placements -->\n  @if (showCaret && (placement === 'bottom' || placement === 'right')) {\n    <div class=\"iui-tooltip__caret\"\n         [class.iui-tooltip__caret--up]=\"placement === 'bottom'\"\n         [class.iui-tooltip__caret--left]=\"placement === 'right'\">\n    </div>\n  }\n  <div class=\"iui-tooltip__body\">\n    <span class=\"iui-tooltip__text\">{{ text }}</span>\n    <ng-content></ng-content>\n  </div>\n  <!-- Caret at end (after body): top and left placements -->\n  @if (showCaret && (placement === 'top' || placement === 'left')) {\n    <div class=\"iui-tooltip__caret\"\n         [class.iui-tooltip__caret--down]=\"placement === 'top'\"\n         [class.iui-tooltip__caret--right]=\"placement === 'left'\">\n    </div>\n  }\n</div>\n", styles: [":host{display:inline-block;width:max-content;max-width:var(--iui-tooltip-max-width)}.iui-tooltip__wrap{display:inline-flex;align-items:flex-start;width:max-content;max-width:var(--iui-tooltip-max-width)}.iui-tooltip__wrap--bottom,.iui-tooltip__wrap--top{flex-direction:column}.iui-tooltip__wrap--left,.iui-tooltip__wrap--right{flex-direction:row}.iui-tooltip__wrap--align-start{align-items:flex-start}.iui-tooltip__wrap--align-middle{align-items:center}.iui-tooltip__wrap--align-end{align-items:flex-end}.iui-tooltip__wrap--bottom.iui-tooltip__wrap--align-start .iui-tooltip__caret,.iui-tooltip__wrap--top.iui-tooltip__wrap--align-start .iui-tooltip__caret{margin-left:var(--iui-tooltip-border-radius)}.iui-tooltip__wrap--bottom.iui-tooltip__wrap--align-end .iui-tooltip__caret,.iui-tooltip__wrap--top.iui-tooltip__wrap--align-end .iui-tooltip__caret{margin-right:var(--iui-tooltip-border-radius)}.iui-tooltip__wrap--left.iui-tooltip__wrap--align-start .iui-tooltip__caret,.iui-tooltip__wrap--right.iui-tooltip__wrap--align-start .iui-tooltip__caret{margin-top:var(--iui-tooltip-border-radius)}.iui-tooltip__wrap--left.iui-tooltip__wrap--align-end .iui-tooltip__caret,.iui-tooltip__wrap--right.iui-tooltip__wrap--align-end .iui-tooltip__caret{margin-bottom:var(--iui-tooltip-border-radius)}.iui-tooltip__body{background:var(--iui-tooltip-bg);color:var(--iui-tooltip-color);padding:var(--iui-tooltip-padding);border-radius:var(--iui-tooltip-border-radius);width:max-content;max-width:var(--iui-tooltip-max-width);min-width:var(--iui-tooltip-min-width);box-sizing:border-box}.iui-tooltip__text{font:var(--iui-tp-body-01-font);display:block;max-width:288px;min-width:28px}.iui-tooltip__caret{flex-shrink:0;width:0;height:0}.iui-tooltip__caret--up{border-left:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-right:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-bottom:var(--iui-tooltip-caret-size-short) solid var(--iui-tooltip-bg)}.iui-tooltip__caret--down{border-left:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-right:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-top:var(--iui-tooltip-caret-size-short) solid var(--iui-tooltip-bg)}.iui-tooltip__caret--left{border-top:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-bottom:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-right:var(--iui-tooltip-caret-size-short) solid var(--iui-tooltip-bg)}.iui-tooltip__caret--right{border-top:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-bottom:calc(var(--iui-tooltip-caret-size-long) / 2) solid transparent;border-left:var(--iui-tooltip-caret-size-short) solid var(--iui-tooltip-bg)}\n"] }]
        }], propDecorators: { placement: [{
                type: Input
            }], alignment: [{
                type: Input
            }], showCaret: [{
                type: Input
            }], text: [{
                type: Input
            }] } });

class IuiTooltipDirective {
    constructor(_el, _appRef, _injector) {
        this._el = _el;
        this._appRef = _appRef;
        this._injector = _injector;
        this.tooltipText = '';
        this.iuiTooltipPlacement = 'top';
        this.iuiTooltipAlignment = 'middle';
        this.iuiTooltipShowCaret = true;
        this.iuiTooltipDelay = 300;
        this._tooltipRef = null;
        this._showTimeout = null;
        this._hideTimeout = null;
        this._tooltipId = `iui-tooltip-${_nextId++}`;
    }
    show() {
        this._clearHideTimeout();
        if (this._tooltipRef)
            return;
        if (!this.tooltipText)
            return;
        this._showTimeout = setTimeout(() => {
            this._createTooltip();
        }, this.iuiTooltipDelay);
    }
    hide() {
        this._clearShowTimeout();
        this._hideTimeout = setTimeout(() => {
            this._destroyTooltip();
        }, 100);
    }
    onEscape() {
        this._clearShowTimeout();
        this._destroyTooltip();
    }
    _createTooltip() {
        if (this._tooltipRef)
            return;
        const ref = createComponent(IuiTooltipComponent, {
            environmentInjector: this._injector
        });
        ref.setInput('text', this.tooltipText);
        ref.setInput('placement', this.iuiTooltipPlacement);
        ref.setInput('alignment', this.iuiTooltipAlignment);
        ref.setInput('showCaret', this.iuiTooltipShowCaret);
        const el = ref.location.nativeElement;
        el.style.cssText = 'position:fixed;z-index:9999;pointer-events:none;';
        el.id = this._tooltipId;
        this._el.nativeElement.setAttribute('aria-describedby', this._tooltipId);
        this._appRef.attachView(ref.hostView);
        document.body.appendChild(el);
        this._tooltipRef = ref;
        ref.changeDetectorRef.detectChanges();
        this._positionTooltip();
    }
    _positionTooltip() {
        if (!this._tooltipRef)
            return;
        const hostRect = this._el.nativeElement.getBoundingClientRect();
        const tooltipEl = this._tooltipRef.location.nativeElement;
        const tooltipRect = tooltipEl.getBoundingClientRect();
        const offset = 4;
        let x = 0;
        let y = 0;
        switch (this.iuiTooltipPlacement) {
            case 'bottom':
                y = hostRect.bottom + offset;
                break;
            case 'top':
                y = hostRect.top - offset - tooltipRect.height;
                break;
            case 'right':
                x = hostRect.right + offset;
                break;
            case 'left':
                x = hostRect.left - offset - tooltipRect.width;
                break;
        }
        const isHorizontal = this.iuiTooltipPlacement === 'top' || this.iuiTooltipPlacement === 'bottom';
        if (isHorizontal) {
            switch (this.iuiTooltipAlignment) {
                case 'start':
                    x = hostRect.left;
                    break;
                case 'middle':
                    x = hostRect.left + hostRect.width / 2 - tooltipRect.width / 2;
                    break;
                case 'end':
                    x = hostRect.right - tooltipRect.width;
                    break;
            }
        }
        else {
            switch (this.iuiTooltipAlignment) {
                case 'start':
                    y = hostRect.top;
                    break;
                case 'middle':
                    y = hostRect.top + hostRect.height / 2 - tooltipRect.height / 2;
                    break;
                case 'end':
                    y = hostRect.bottom - tooltipRect.height;
                    break;
            }
        }
        tooltipEl.style.left = `${x}px`;
        tooltipEl.style.top = `${y}px`;
    }
    _destroyTooltip() {
        if (!this._tooltipRef)
            return;
        this._el.nativeElement.removeAttribute('aria-describedby');
        this._appRef.detachView(this._tooltipRef.hostView);
        this._tooltipRef.location.nativeElement.remove();
        this._tooltipRef.destroy();
        this._tooltipRef = null;
    }
    _clearShowTimeout() {
        if (this._showTimeout !== null) {
            clearTimeout(this._showTimeout);
            this._showTimeout = null;
        }
    }
    _clearHideTimeout() {
        if (this._hideTimeout !== null) {
            clearTimeout(this._hideTimeout);
            this._hideTimeout = null;
        }
    }
    ngOnDestroy() {
        this._clearShowTimeout();
        this._clearHideTimeout();
        this._destroyTooltip();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTooltipDirective, deps: [{ token: i0.ElementRef }, { token: i0.ApplicationRef }, { token: i0.EnvironmentInjector }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: IuiTooltipDirective, isStandalone: true, selector: "[iuiTooltip]", inputs: { tooltipText: ["iuiTooltip", "tooltipText"], iuiTooltipPlacement: "iuiTooltipPlacement", iuiTooltipAlignment: "iuiTooltipAlignment", iuiTooltipShowCaret: "iuiTooltipShowCaret", iuiTooltipDelay: "iuiTooltipDelay" }, host: { listeners: { "mouseenter": "show()", "focusin": "show()", "mouseleave": "hide()", "focusout": "hide()", "keydown.escape": "onEscape()" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[iuiTooltip]',
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ApplicationRef }, { type: i0.EnvironmentInjector }], propDecorators: { tooltipText: [{
                type: Input,
                args: ['iuiTooltip']
            }], iuiTooltipPlacement: [{
                type: Input
            }], iuiTooltipAlignment: [{
                type: Input
            }], iuiTooltipShowCaret: [{
                type: Input
            }], iuiTooltipDelay: [{
                type: Input
            }], show: [{
                type: HostListener,
                args: ['mouseenter']
            }, {
                type: HostListener,
                args: ['focusin']
            }], hide: [{
                type: HostListener,
                args: ['mouseleave']
            }, {
                type: HostListener,
                args: ['focusout']
            }], onEscape: [{
                type: HostListener,
                args: ['keydown.escape']
            }] } });
let _nextId = 0;

class IuiTooltipIconTriggerComponent {
    constructor() {
        this.text = '';
        this.placement = 'bottom';
        this.alignment = 'middle';
        this._visible = false;
    }
    _show() {
        this._visible = true;
    }
    _hide() {
        this._visible = false;
    }
    get _tooltipStyle() {
        return _getTooltipStyle(this.placement, this.alignment);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTooltipIconTriggerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.12", type: IuiTooltipIconTriggerComponent, isStandalone: true, selector: "iui-tooltip-icon-trigger", inputs: { text: "text", placement: "placement", alignment: "alignment" }, ngImport: i0, template: "<span class=\"iui-tooltip-icon-trigger__icon\"\n      tabindex=\"0\"\n      (mouseenter)=\"_show()\"\n      (mouseleave)=\"_hide()\"\n      (focusin)=\"_show()\"\n      (focusout)=\"_hide()\"\n      (keydown.escape)=\"_hide()\">\n  <iui-information-icon style=\"width:16px;height:16px;\"></iui-information-icon>\n</span>\n@if (_visible && text) {\n  <iui-tooltip\n    [text]=\"text\"\n    [placement]=\"placement\"\n    [alignment]=\"alignment\"\n    [showCaret]=\"true\"\n    [style]=\"_tooltipStyle\">\n  </iui-tooltip>\n}\n", styles: [":host{display:inline-flex;position:relative}.iui-tooltip-icon-trigger__icon{display:inline-flex;align-items:center;justify-content:center;cursor:pointer;width:16px;height:16px;color:var(--iui-text-secondary)}.iui-tooltip-icon-trigger__icon:focus-visible{outline:2px solid var(--iui-border-focus);outline-offset:2px;border-radius:2px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: IuiTooltipComponent, selector: "iui-tooltip", inputs: ["placement", "alignment", "showCaret", "text"] }, { kind: "component", type: InformationIconComponent, selector: "iui-information-icon" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTooltipIconTriggerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-tooltip-icon-trigger', standalone: true, imports: [CommonModule, IuiTooltipComponent, InformationIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<span class=\"iui-tooltip-icon-trigger__icon\"\n      tabindex=\"0\"\n      (mouseenter)=\"_show()\"\n      (mouseleave)=\"_hide()\"\n      (focusin)=\"_show()\"\n      (focusout)=\"_hide()\"\n      (keydown.escape)=\"_hide()\">\n  <iui-information-icon style=\"width:16px;height:16px;\"></iui-information-icon>\n</span>\n@if (_visible && text) {\n  <iui-tooltip\n    [text]=\"text\"\n    [placement]=\"placement\"\n    [alignment]=\"alignment\"\n    [showCaret]=\"true\"\n    [style]=\"_tooltipStyle\">\n  </iui-tooltip>\n}\n", styles: [":host{display:inline-flex;position:relative}.iui-tooltip-icon-trigger__icon{display:inline-flex;align-items:center;justify-content:center;cursor:pointer;width:16px;height:16px;color:var(--iui-text-secondary)}.iui-tooltip-icon-trigger__icon:focus-visible{outline:2px solid var(--iui-border-focus);outline-offset:2px;border-radius:2px}\n"] }]
        }], propDecorators: { text: [{
                type: Input
            }], placement: [{
                type: Input
            }], alignment: [{
                type: Input
            }] } });
function _getTooltipStyle(placement, alignment) {
    const offset = 'var(--iui-tooltip-offset)';
    const style = { position: 'absolute' };
    const isHorizontal = placement === 'top' || placement === 'bottom';
    if (placement === 'bottom')
        style['top'] = `calc(100% + ${offset})`;
    else if (placement === 'top')
        style['bottom'] = `calc(100% + ${offset})`;
    else if (placement === 'right')
        style['left'] = `calc(100% + ${offset})`;
    else if (placement === 'left')
        style['right'] = `calc(100% + ${offset})`;
    if (isHorizontal) {
        if (alignment === 'start')
            style['left'] = '0';
        else if (alignment === 'middle') {
            style['left'] = '50%';
            style['transform'] = 'translateX(-50%)';
        }
        else if (alignment === 'end')
            style['right'] = '0';
    }
    else {
        if (alignment === 'start')
            style['top'] = '0';
        else if (alignment === 'middle') {
            style['top'] = '50%';
            style['transform'] = 'translateY(-50%)';
        }
        else if (alignment === 'end')
            style['bottom'] = '0';
    }
    return style;
}

class IuiTooltipTextTriggerComponent {
    constructor() {
        this.text = '';
        this.triggerText = 'Definition tooltip';
        this.position = 'bottom';
        this.alignment = 'middle';
        this._visible = false;
    }
    _show() {
        this._visible = true;
    }
    _hide() {
        this._visible = false;
    }
    get _tooltipStyle() {
        return _getTooltipStyle(this.position, this.alignment);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTooltipTextTriggerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.12", type: IuiTooltipTextTriggerComponent, isStandalone: true, selector: "iui-tooltip-text-trigger", inputs: { text: "text", triggerText: "triggerText", position: "position", alignment: "alignment" }, ngImport: i0, template: "<span class=\"iui-tooltip-text-trigger__label\"\n      tabindex=\"0\"\n      (mouseenter)=\"_show()\"\n      (mouseleave)=\"_hide()\"\n      (focusin)=\"_show()\"\n      (focusout)=\"_hide()\"\n      (keydown.escape)=\"_hide()\">\n  {{ triggerText }}\n</span>\n@if (_visible && text) {\n  <iui-tooltip\n    [text]=\"text\"\n    [placement]=\"position\"\n    [alignment]=\"alignment\"\n    [showCaret]=\"true\"\n    [style]=\"_tooltipStyle\">\n  </iui-tooltip>\n}\n", styles: [":host{display:inline-flex;position:relative}.iui-tooltip-text-trigger__label{font:var(--iui-tp-body-01-font);color:var(--iui-text-primary);text-decoration:underline dotted;cursor:help}.iui-tooltip-text-trigger__label:focus-visible{outline:2px solid var(--iui-border-focus);outline-offset:2px;border-radius:2px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: IuiTooltipComponent, selector: "iui-tooltip", inputs: ["placement", "alignment", "showCaret", "text"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTooltipTextTriggerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-tooltip-text-trigger', standalone: true, imports: [CommonModule, IuiTooltipComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<span class=\"iui-tooltip-text-trigger__label\"\n      tabindex=\"0\"\n      (mouseenter)=\"_show()\"\n      (mouseleave)=\"_hide()\"\n      (focusin)=\"_show()\"\n      (focusout)=\"_hide()\"\n      (keydown.escape)=\"_hide()\">\n  {{ triggerText }}\n</span>\n@if (_visible && text) {\n  <iui-tooltip\n    [text]=\"text\"\n    [placement]=\"position\"\n    [alignment]=\"alignment\"\n    [showCaret]=\"true\"\n    [style]=\"_tooltipStyle\">\n  </iui-tooltip>\n}\n", styles: [":host{display:inline-flex;position:relative}.iui-tooltip-text-trigger__label{font:var(--iui-tp-body-01-font);color:var(--iui-text-primary);text-decoration:underline dotted;cursor:help}.iui-tooltip-text-trigger__label:focus-visible{outline:2px solid var(--iui-border-focus);outline-offset:2px;border-radius:2px}\n"] }]
        }], propDecorators: { text: [{
                type: Input
            }], triggerText: [{
                type: Input
            }], position: [{
                type: Input
            }], alignment: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiTooltipComponent, IuiTooltipDirective, IuiTooltipIconTriggerComponent, IuiTooltipTextTriggerComponent };
//# sourceMappingURL=itero-ui-components-angular-tooltip.mjs.map
