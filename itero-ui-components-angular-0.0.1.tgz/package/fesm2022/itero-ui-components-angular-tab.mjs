import * as i0 from '@angular/core';
import { TemplateRef, ViewChild, Input, Component, EventEmitter, Output, ContentChildren } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule, NgTemplateOutlet } from '@angular/common';

class IuiTabComponent {
    constructor() {
        this.label = '';
        this.disabled = false;
        this.showBadge = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTabComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiTabComponent, isStandalone: true, selector: "iui-tab", inputs: { label: "label", disabled: "disabled", showBadge: "showBadge" }, viewQueries: [{ propertyName: "content", first: true, predicate: TemplateRef, descendants: true, static: true }], ngImport: i0, template: '<ng-template><ng-content></ng-content></ng-template>', isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTabComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'iui-tab',
                    standalone: true,
                    template: '<ng-template><ng-content></ng-content></ng-template>',
                }]
        }], propDecorators: { label: [{
                type: Input
            }], disabled: [{
                type: Input
            }], showBadge: [{
                type: Input
            }], content: [{
                type: ViewChild,
                args: [TemplateRef, { static: true }]
            }] } });

class IuiTabGroupComponent {
    constructor(el) {
        this.el = el;
        this.selectedIndex = 0;
        this.scrollable = false;
        this.selectedIndexChange = new EventEmitter();
        this.tabChange = new EventEmitter();
        /** Tracks the DOM-focused tab index for keyboard navigation (may differ from selected). */
        this.focusedIndex = 0;
    }
    ngAfterContentInit() {
        this.tabsSubscription = this.tabs.changes.subscribe(() => {
            // Clamp selectedIndex if tabs shrink
            if (this.selectedIndex >= this.tabs.length) {
                this.selectedIndex = Math.max(0, this.tabs.length - 1);
            }
        });
    }
    ngOnChanges(changes) {
        if (changes['selectedIndex']) {
            this.focusedIndex = changes['selectedIndex'].currentValue;
        }
    }
    ngOnDestroy() {
        this.tabsSubscription?.unsubscribe();
    }
    selectTab(index) {
        const tab = this.tabs.get(index);
        if (!tab || tab.disabled)
            return;
        const previous = this.selectedIndex;
        this.selectedIndex = index;
        this.focusedIndex = index;
        this.selectedIndexChange.emit(index);
        this.tabChange.emit({ previousIndex: previous, index });
    }
    onKeyDown(event, currentIndex) {
        const tabsArray = this.tabs.toArray();
        const total = tabsArray.length;
        const findNextEnabled = (from, direction) => {
            let i = ((from + direction) % total + total) % total;
            let safety = 0;
            while (i !== from && safety < total) {
                if (!tabsArray[i].disabled)
                    return i;
                i = ((i + direction) % total + total) % total;
                safety++;
            }
            return from;
        };
        switch (event.key) {
            case 'ArrowRight':
                event.preventDefault();
                this.focusDomTab(findNextEnabled(currentIndex, 1));
                break;
            case 'ArrowLeft':
                event.preventDefault();
                this.focusDomTab(findNextEnabled(currentIndex, -1));
                break;
            case 'Home':
                event.preventDefault();
                this.focusDomTab(findNextEnabled(-1, 1));
                break;
            case 'End':
                event.preventDefault();
                this.focusDomTab(findNextEnabled(total, -1));
                break;
            case 'Enter':
            case ' ':
                event.preventDefault();
                this.selectTab(currentIndex);
                break;
        }
    }
    focusDomTab(index) {
        const buttons = this.el.nativeElement.querySelectorAll('[role="tab"]');
        buttons[index]?.focus();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTabGroupComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiTabGroupComponent, isStandalone: true, selector: "iui-tab-group", inputs: { selectedIndex: "selectedIndex", scrollable: "scrollable" }, outputs: { selectedIndexChange: "selectedIndexChange", tabChange: "tabChange" }, host: { properties: { "class.iui-tab-group--scrollable": "scrollable" } }, queries: [{ propertyName: "tabs", predicate: IuiTabComponent }], usesOnChanges: true, ngImport: i0, template: "<!-- Tab list -->\r\n<div\r\n  class=\"iui-tab-group__list\"\r\n  role=\"tablist\"\r\n  [class.iui-tab-group__list--scrollable]=\"scrollable\">\r\n  <button\r\n    *ngFor=\"let tab of tabs; let i = index\"\r\n    class=\"iui-tab-group__item\"\r\n    role=\"tab\"\r\n    [id]=\"'iui-tab-' + i\"\r\n    [attr.aria-selected]=\"i === selectedIndex\"\r\n    [attr.aria-controls]=\"'iui-panel-' + i\"\r\n    [attr.tabindex]=\"i === selectedIndex ? 0 : -1\"\r\n    [attr.aria-disabled]=\"tab.disabled ? true : null\"\r\n    [class.iui-tab-group__item--selected]=\"i === selectedIndex\"\r\n    [class.iui-tab-group__item--disabled]=\"tab.disabled\"\r\n    [disabled]=\"tab.disabled ? true : null\"\r\n    (click)=\"selectTab(i)\"\r\n    (keydown)=\"onKeyDown($event, i)\">\r\n    <span class=\"iui-tab-group__item-label\">{{ tab.label }}</span>\r\n    <span\r\n      *ngIf=\"tab.showBadge\"\r\n      class=\"iui-tab-group__item-badge\"\r\n      aria-hidden=\"true\"></span>\r\n  </button>\r\n</div>\r\n\r\n<!-- Content panels -->\r\n<div class=\"iui-tab-group__panel-container\">\r\n  <div\r\n    *ngFor=\"let tab of tabs; let i = index\"\r\n    class=\"iui-tab-group__panel\"\r\n    role=\"tabpanel\"\r\n    [id]=\"'iui-panel-' + i\"\r\n    [attr.aria-labelledby]=\"'iui-tab-' + i\"\r\n    [hidden]=\"i !== selectedIndex\">\r\n    <ng-container *ngTemplateOutlet=\"tab.content\"></ng-container>\r\n  </div>\r\n</div>\r\n", styles: [":host{display:flex;flex-direction:column}.iui-tab-group__list{display:flex;flex-direction:row;border-bottom:1px solid var(--iui-tab-list-border-color);overflow:hidden}.iui-tab-group__list--scrollable{overflow-x:auto;scrollbar-width:none}.iui-tab-group__list--scrollable::-webkit-scrollbar{display:none}.iui-tab-group__item{background:none;border:none;border-bottom:2px solid transparent;cursor:pointer;outline:none;padding:0;margin:0 0 -1px;display:inline-flex;align-items:flex-start;gap:0;padding-inline:var(--iui-tab-item-padding-x);padding-bottom:var(--iui-tab-item-padding-bottom)}.iui-tab-group__item .iui-tab-group__item-label{font:var(--iui-tp-body-01-font);color:var(--iui-tab-text-enabled);white-space:nowrap}.iui-tab-group__item:hover:not(.iui-tab-group__item--disabled):not(.iui-tab-group__item--selected) .iui-tab-group__item-label{color:var(--iui-tab-text-hovered)}.iui-tab-group__item:focus-visible{outline:1px solid var(--iui-tab-focus-border-color);outline-offset:-1px}.iui-tab-group__item:focus-visible .iui-tab-group__item-label{color:var(--iui-tab-text-focused)}.iui-tab-group__item--selected{border-bottom-color:var(--iui-tab-indicator-color)}.iui-tab-group__item--selected .iui-tab-group__item-label{font:var(--iui-tp-heading-01-font);color:var(--iui-tab-text-selected)}.iui-tab-group__item--disabled{cursor:not-allowed}.iui-tab-group__item--disabled .iui-tab-group__item-label{color:var(--iui-tab-text-disabled)}.iui-tab-group__item-badge{display:inline-block;width:6px;height:6px;border-radius:50%;background:var(--iui-tab-indicator-color);margin-left:4px;flex-shrink:0;align-self:center}.iui-tab-group__panel-container{flex:1}.iui-tab-group__panel[hidden]{display:none}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTabGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-tab-group', standalone: true, imports: [CommonModule, NgTemplateOutlet], host: {
                        '[class.iui-tab-group--scrollable]': 'scrollable',
                    }, template: "<!-- Tab list -->\r\n<div\r\n  class=\"iui-tab-group__list\"\r\n  role=\"tablist\"\r\n  [class.iui-tab-group__list--scrollable]=\"scrollable\">\r\n  <button\r\n    *ngFor=\"let tab of tabs; let i = index\"\r\n    class=\"iui-tab-group__item\"\r\n    role=\"tab\"\r\n    [id]=\"'iui-tab-' + i\"\r\n    [attr.aria-selected]=\"i === selectedIndex\"\r\n    [attr.aria-controls]=\"'iui-panel-' + i\"\r\n    [attr.tabindex]=\"i === selectedIndex ? 0 : -1\"\r\n    [attr.aria-disabled]=\"tab.disabled ? true : null\"\r\n    [class.iui-tab-group__item--selected]=\"i === selectedIndex\"\r\n    [class.iui-tab-group__item--disabled]=\"tab.disabled\"\r\n    [disabled]=\"tab.disabled ? true : null\"\r\n    (click)=\"selectTab(i)\"\r\n    (keydown)=\"onKeyDown($event, i)\">\r\n    <span class=\"iui-tab-group__item-label\">{{ tab.label }}</span>\r\n    <span\r\n      *ngIf=\"tab.showBadge\"\r\n      class=\"iui-tab-group__item-badge\"\r\n      aria-hidden=\"true\"></span>\r\n  </button>\r\n</div>\r\n\r\n<!-- Content panels -->\r\n<div class=\"iui-tab-group__panel-container\">\r\n  <div\r\n    *ngFor=\"let tab of tabs; let i = index\"\r\n    class=\"iui-tab-group__panel\"\r\n    role=\"tabpanel\"\r\n    [id]=\"'iui-panel-' + i\"\r\n    [attr.aria-labelledby]=\"'iui-tab-' + i\"\r\n    [hidden]=\"i !== selectedIndex\">\r\n    <ng-container *ngTemplateOutlet=\"tab.content\"></ng-container>\r\n  </div>\r\n</div>\r\n", styles: [":host{display:flex;flex-direction:column}.iui-tab-group__list{display:flex;flex-direction:row;border-bottom:1px solid var(--iui-tab-list-border-color);overflow:hidden}.iui-tab-group__list--scrollable{overflow-x:auto;scrollbar-width:none}.iui-tab-group__list--scrollable::-webkit-scrollbar{display:none}.iui-tab-group__item{background:none;border:none;border-bottom:2px solid transparent;cursor:pointer;outline:none;padding:0;margin:0 0 -1px;display:inline-flex;align-items:flex-start;gap:0;padding-inline:var(--iui-tab-item-padding-x);padding-bottom:var(--iui-tab-item-padding-bottom)}.iui-tab-group__item .iui-tab-group__item-label{font:var(--iui-tp-body-01-font);color:var(--iui-tab-text-enabled);white-space:nowrap}.iui-tab-group__item:hover:not(.iui-tab-group__item--disabled):not(.iui-tab-group__item--selected) .iui-tab-group__item-label{color:var(--iui-tab-text-hovered)}.iui-tab-group__item:focus-visible{outline:1px solid var(--iui-tab-focus-border-color);outline-offset:-1px}.iui-tab-group__item:focus-visible .iui-tab-group__item-label{color:var(--iui-tab-text-focused)}.iui-tab-group__item--selected{border-bottom-color:var(--iui-tab-indicator-color)}.iui-tab-group__item--selected .iui-tab-group__item-label{font:var(--iui-tp-heading-01-font);color:var(--iui-tab-text-selected)}.iui-tab-group__item--disabled{cursor:not-allowed}.iui-tab-group__item--disabled .iui-tab-group__item-label{color:var(--iui-tab-text-disabled)}.iui-tab-group__item-badge{display:inline-block;width:6px;height:6px;border-radius:50%;background:var(--iui-tab-indicator-color);margin-left:4px;flex-shrink:0;align-self:center}.iui-tab-group__panel-container{flex:1}.iui-tab-group__panel[hidden]{display:none}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { tabs: [{
                type: ContentChildren,
                args: [IuiTabComponent]
            }], selectedIndex: [{
                type: Input
            }], scrollable: [{
                type: Input
            }], selectedIndexChange: [{
                type: Output
            }], tabChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiTabComponent, IuiTabGroupComponent };
//# sourceMappingURL=itero-ui-components-angular-tab.mjs.map
