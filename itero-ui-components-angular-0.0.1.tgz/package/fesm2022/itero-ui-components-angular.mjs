/**
 * loads fonts from the static server. Extremely helpful for microfrontends, because they know their baseUrl only in runtime.
 * Invoke this function at the start of your application.
 * */
function loadFonts(baseUrl = '.', options = {}) {
    if (document.head.querySelector('.iui-fonts')) {
        return Promise.resolve();
    }
    const { iuiFontsFolder = 'iui-fonts' } = options;
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = `${baseUrl}/${iuiFontsFolder}/fonts.css`;
    link.crossOrigin = 'anonymous';
    link.classList.add('iui-fonts');
    link.type = 'text/css';
    document.head.appendChild(link);
    return new Promise((resolve, reject) => {
        const listeners = [
            (e) => {
                resolve(e);
                link.removeEventListener('load', listeners[0]);
                link.removeEventListener('error', listeners[1]);
            },
            (err) => {
                reject(err);
                document.head.removeChild(link);
                link.removeEventListener('load', listeners[0]);
                link.removeEventListener('error', listeners[1]);
            }
        ];
        link.addEventListener('load', listeners[0]);
        link.addEventListener('error', listeners[1]);
    });
}

/**
 * Generated bundle index. Do not edit.
 */

export { loadFonts };
//# sourceMappingURL=itero-ui-components-angular.mjs.map
