import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, ChangeDetectionStrategy, Component, InjectionToken, inject, forwardRef, ViewChild, Self } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule, DatePipe } from '@angular/common';
import { CaretDownIconComponent, ChevronLeftIconComponent, ChevronRightIconComponent, CalendarIconComponent } from '@itero/ui-components-angular/icons';
import * as i3 from '@angular/forms';
import { Validators, FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i4 from '@angular/cdk/overlay';
import { Overlay, OverlayModule, CdkConnectedOverlay } from '@angular/cdk/overlay';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { Subject } from 'rxjs';
import * as i1$1 from '@itero/ui-components-angular/core';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import { IuiDateInputComponent } from '@itero/ui-components-angular/date-input';

class IuiCalendarDayComponent {
    constructor() {
        this.date = new Date();
        this.state = 'enabled';
        this.isToday = false;
        this.rangePosition = 'none';
        this.dayClick = new EventEmitter();
        this.dayHover = new EventEmitter();
        this.dayLeave = new EventEmitter();
    }
    _handleClick() {
        if (this.state !== 'disabled') {
            this.dayClick.emit(this.date);
        }
    }
    _handleMouseEnter() {
        if (this.state !== 'disabled') {
            this.dayHover.emit(this.date);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCalendarDayComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.12", type: IuiCalendarDayComponent, isStandalone: true, selector: "iui-calendar-day", inputs: { date: "date", state: "state", isToday: "isToday", rangePosition: "rangePosition" }, outputs: { dayClick: "dayClick", dayHover: "dayHover", dayLeave: "dayLeave" }, host: { properties: { "class.iui-calendar-day_hovered": "state === \"hovered\"", "class.iui-calendar-day_pressed": "state === \"pressed\"", "class.iui-calendar-day_focused": "state === \"focused\"", "class.iui-calendar-day_selected": "state === \"selected\"", "class.iui-calendar-day_in-range": "state === \"in-range\"", "class.iui-calendar-day_disabled": "state === \"disabled\"", "class.iui-calendar-day_range-start": "rangePosition === \"start\"", "class.iui-calendar-day_range-middle": "rangePosition === \"middle\"", "class.iui-calendar-day_range-end": "rangePosition === \"end\"" }, classAttribute: "iui-calendar-day" }, ngImport: i0, template: "<div class=\"iui-calendar-day__range-left\"></div>\r\n<div\r\n\tclass=\"iui-calendar-day__picker\"\r\n\t[attr.tabindex]=\"state === 'disabled' ? -1 : 0\"\r\n\t(click)=\"_handleClick()\"\r\n\t(mouseenter)=\"_handleMouseEnter()\"\r\n\t(mouseleave)=\"dayLeave.emit()\"\r\n\t(keydown.enter)=\"_handleClick()\"\r\n\t(keydown.space)=\"_handleClick(); $event.preventDefault()\"\r\n\t[attr.aria-label]=\"date | date:'fullDate'\"\r\n\t[attr.aria-disabled]=\"state === 'disabled'\"\r\n\t[attr.aria-selected]=\"state === 'selected'\"\r\n>\r\n\t<span class=\"iui-calendar-day__label\">{{ date.getDate() }}</span>\r\n\t@if (isToday) {\r\n\t\t<span class=\"iui-calendar-day__today-indicator\"></span>\r\n\t}\r\n</div>\r\n<div class=\"iui-calendar-day__range-right\"></div>\r\n", styles: [":host{--iui-date-picker-day-selected-bg: var(--iui-background-interactive);--iui-date-picker-day-range-bg: var(--iui-background-layer-selected);--iui-date-picker-day-hover-bg: var(--iui-background-subtle-hover);--iui-date-picker-day-pressed-bg: var(--iui-background-subtle-active);--iui-date-picker-day-selected-color: var(--iui-text-on-color-primary);--iui-date-picker-today-indicator: var(--iui-border-interactive);--iui-date-picker-today-indicator-selected: var(--iui-border-on-color-strong);display:flex;align-items:flex-start;overflow:hidden;padding:4px 0;width:44px;flex-shrink:0}.iui-calendar-day__range-left,.iui-calendar-day__range-right{flex:1;min-width:0;height:36px}:host.iui-calendar-day_range-start .iui-calendar-day__range-right,:host.iui-calendar-day_in-range .iui-calendar-day__range-left,:host.iui-calendar-day_in-range .iui-calendar-day__range-right,:host.iui-calendar-day_range-end .iui-calendar-day__range-left,:host.iui-calendar-day_range-middle .iui-calendar-day__range-left,:host.iui-calendar-day_range-middle .iui-calendar-day__range-right{background:var(--iui-date-picker-day-range-bg)}.iui-calendar-day__picker{position:relative;width:36px;height:36px;border-radius:var(--iui-border-radius-medium);display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;outline:none;cursor:pointer}.iui-calendar-day__picker:focus-visible{outline:none}.iui-calendar-day__label{font:var(--iui-tp-body-01-font);color:var(--iui-text-primary);text-align:center;position:absolute;top:8px;left:0;right:0;pointer-events:none}:host.iui-calendar-day_hovered .iui-calendar-day__picker{background:var(--iui-date-picker-day-hover-bg)}:host.iui-calendar-day_pressed .iui-calendar-day__picker{background:var(--iui-date-picker-day-pressed-bg)}:host.iui-calendar-day_focused .iui-calendar-day__picker{border:1px solid var(--iui-date-picker-today-indicator)}:host.iui-calendar-day_focused .iui-calendar-day__label{top:7px;left:-1px;right:-1px}:host.iui-calendar-day_in-range .iui-calendar-day__picker,:host.iui-calendar-day_range-middle .iui-calendar-day__picker{background:var(--iui-date-picker-day-range-bg)}:host.iui-calendar-day_selected .iui-calendar-day__picker{background:var(--iui-date-picker-day-selected-bg)}:host.iui-calendar-day_selected .iui-calendar-day__label{color:var(--iui-date-picker-day-selected-color)}:host.iui-calendar-day_disabled .iui-calendar-day__picker{cursor:default;pointer-events:none}:host.iui-calendar-day_disabled .iui-calendar-day__label{color:var(--iui-text-disabled)}.iui-calendar-day__today-indicator{position:absolute;bottom:2px;left:50%;transform:translate(-50%);width:12px;height:2px;border-radius:9999px;background:var(--iui-date-picker-today-indicator);pointer-events:none}:host.iui-calendar-day_selected .iui-calendar-day__today-indicator{background:var(--iui-date-picker-today-indicator-selected)}:host.iui-calendar-day_focused .iui-calendar-day__today-indicator,:host.iui-calendar-day_in-range .iui-calendar-day__today-indicator{bottom:1px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "pipe", type: i1.DatePipe, name: "date" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCalendarDayComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-calendar-day', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'iui-calendar-day',
                        '[class.iui-calendar-day_hovered]': 'state === "hovered"',
                        '[class.iui-calendar-day_pressed]': 'state === "pressed"',
                        '[class.iui-calendar-day_focused]': 'state === "focused"',
                        '[class.iui-calendar-day_selected]': 'state === "selected"',
                        '[class.iui-calendar-day_in-range]': 'state === "in-range"',
                        '[class.iui-calendar-day_disabled]': 'state === "disabled"',
                        '[class.iui-calendar-day_range-start]': 'rangePosition === "start"',
                        '[class.iui-calendar-day_range-middle]': 'rangePosition === "middle"',
                        '[class.iui-calendar-day_range-end]': 'rangePosition === "end"'
                    }, template: "<div class=\"iui-calendar-day__range-left\"></div>\r\n<div\r\n\tclass=\"iui-calendar-day__picker\"\r\n\t[attr.tabindex]=\"state === 'disabled' ? -1 : 0\"\r\n\t(click)=\"_handleClick()\"\r\n\t(mouseenter)=\"_handleMouseEnter()\"\r\n\t(mouseleave)=\"dayLeave.emit()\"\r\n\t(keydown.enter)=\"_handleClick()\"\r\n\t(keydown.space)=\"_handleClick(); $event.preventDefault()\"\r\n\t[attr.aria-label]=\"date | date:'fullDate'\"\r\n\t[attr.aria-disabled]=\"state === 'disabled'\"\r\n\t[attr.aria-selected]=\"state === 'selected'\"\r\n>\r\n\t<span class=\"iui-calendar-day__label\">{{ date.getDate() }}</span>\r\n\t@if (isToday) {\r\n\t\t<span class=\"iui-calendar-day__today-indicator\"></span>\r\n\t}\r\n</div>\r\n<div class=\"iui-calendar-day__range-right\"></div>\r\n", styles: [":host{--iui-date-picker-day-selected-bg: var(--iui-background-interactive);--iui-date-picker-day-range-bg: var(--iui-background-layer-selected);--iui-date-picker-day-hover-bg: var(--iui-background-subtle-hover);--iui-date-picker-day-pressed-bg: var(--iui-background-subtle-active);--iui-date-picker-day-selected-color: var(--iui-text-on-color-primary);--iui-date-picker-today-indicator: var(--iui-border-interactive);--iui-date-picker-today-indicator-selected: var(--iui-border-on-color-strong);display:flex;align-items:flex-start;overflow:hidden;padding:4px 0;width:44px;flex-shrink:0}.iui-calendar-day__range-left,.iui-calendar-day__range-right{flex:1;min-width:0;height:36px}:host.iui-calendar-day_range-start .iui-calendar-day__range-right,:host.iui-calendar-day_in-range .iui-calendar-day__range-left,:host.iui-calendar-day_in-range .iui-calendar-day__range-right,:host.iui-calendar-day_range-end .iui-calendar-day__range-left,:host.iui-calendar-day_range-middle .iui-calendar-day__range-left,:host.iui-calendar-day_range-middle .iui-calendar-day__range-right{background:var(--iui-date-picker-day-range-bg)}.iui-calendar-day__picker{position:relative;width:36px;height:36px;border-radius:var(--iui-border-radius-medium);display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;outline:none;cursor:pointer}.iui-calendar-day__picker:focus-visible{outline:none}.iui-calendar-day__label{font:var(--iui-tp-body-01-font);color:var(--iui-text-primary);text-align:center;position:absolute;top:8px;left:0;right:0;pointer-events:none}:host.iui-calendar-day_hovered .iui-calendar-day__picker{background:var(--iui-date-picker-day-hover-bg)}:host.iui-calendar-day_pressed .iui-calendar-day__picker{background:var(--iui-date-picker-day-pressed-bg)}:host.iui-calendar-day_focused .iui-calendar-day__picker{border:1px solid var(--iui-date-picker-today-indicator)}:host.iui-calendar-day_focused .iui-calendar-day__label{top:7px;left:-1px;right:-1px}:host.iui-calendar-day_in-range .iui-calendar-day__picker,:host.iui-calendar-day_range-middle .iui-calendar-day__picker{background:var(--iui-date-picker-day-range-bg)}:host.iui-calendar-day_selected .iui-calendar-day__picker{background:var(--iui-date-picker-day-selected-bg)}:host.iui-calendar-day_selected .iui-calendar-day__label{color:var(--iui-date-picker-day-selected-color)}:host.iui-calendar-day_disabled .iui-calendar-day__picker{cursor:default;pointer-events:none}:host.iui-calendar-day_disabled .iui-calendar-day__label{color:var(--iui-text-disabled)}.iui-calendar-day__today-indicator{position:absolute;bottom:2px;left:50%;transform:translate(-50%);width:12px;height:2px;border-radius:9999px;background:var(--iui-date-picker-today-indicator);pointer-events:none}:host.iui-calendar-day_selected .iui-calendar-day__today-indicator{background:var(--iui-date-picker-today-indicator-selected)}:host.iui-calendar-day_focused .iui-calendar-day__today-indicator,:host.iui-calendar-day_in-range .iui-calendar-day__today-indicator{bottom:1px}\n"] }]
        }], propDecorators: { date: [{
                type: Input
            }], state: [{
                type: Input
            }], isToday: [{
                type: Input
            }], rangePosition: [{
                type: Input
            }], dayClick: [{
                type: Output
            }], dayHover: [{
                type: Output
            }], dayLeave: [{
                type: Output
            }] } });

const MONTH_NAMES = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
];
const MONTH_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
class IuiCalendarComponent {
    constructor() {
        this.type = 'single';
        this.currentView = 'day';
        this.displayMonth = new Date();
        this.selectedDate = null;
        this.selectedRange = null;
        this.hoverDate = null;
        this.minDate = null;
        this.maxDate = null;
        this.dateSelected = new EventEmitter();
        this.viewChange = new EventEmitter();
        this.displayMonthChange = new EventEmitter();
        this.dateHover = new EventEmitter();
        this.weekdays = WEEKDAYS;
        this._weeks = [];
        this._monthRows = [];
        this._yearRows = [];
        this._yearRangeStart = 0;
    }
    ngOnChanges(changes) {
        if (changes['displayMonth'] ||
            changes['selectedDate'] ||
            changes['selectedRange'] ||
            changes['hoverDate'] ||
            changes['minDate'] ||
            changes['maxDate'] ||
            changes['currentView']) {
            this._buildWeeks();
            this._buildMonthGrid();
            this._buildYearGrid();
        }
    }
    get _monthName() {
        return MONTH_NAMES[this.displayMonth.getMonth()];
    }
    get _year() {
        return this.displayMonth.getFullYear();
    }
    get _yearRangeLabel() {
        const start = this._yearRangeStart;
        return `${start} – ${start + 11}`;
    }
    _navigatePrevMonth() {
        const d = new Date(this.displayMonth);
        d.setMonth(d.getMonth() - 1);
        this.displayMonthChange.emit(d);
    }
    _navigateNextMonth() {
        const d = new Date(this.displayMonth);
        d.setMonth(d.getMonth() + 1);
        this.displayMonthChange.emit(d);
    }
    _switchToMonthView() {
        this.viewChange.emit('month');
    }
    _switchToYearView() {
        this.viewChange.emit('year');
    }
    _selectMonth(monthIndex) {
        const d = new Date(this.displayMonth);
        d.setMonth(monthIndex);
        this.displayMonthChange.emit(d);
        this.viewChange.emit('day');
    }
    _selectYear(year) {
        const d = new Date(this.displayMonth);
        d.setFullYear(year);
        this.displayMonthChange.emit(d);
        this.viewChange.emit('month');
    }
    _onDayClick(date) {
        this.dateSelected.emit(date);
    }
    _onDayHover(date) {
        this.dateHover.emit(date);
    }
    _onDayLeave() {
        this.dateHover.emit(null);
    }
    // Build week-row matrix for the current display month
    _buildWeeks() {
        const year = this.displayMonth.getFullYear();
        const month = this.displayMonth.getMonth();
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        // First day of month
        const firstDay = new Date(year, month, 1);
        const startDow = firstDay.getDay(); // 0=Sun
        // Total days in month
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const cells = [];
        // Leading nulls for days before month start
        for (let i = 0; i < startDow; i++) {
            cells.push(null);
        }
        for (let d = 1; d <= daysInMonth; d++) {
            const date = new Date(year, month, d);
            date.setHours(0, 0, 0, 0);
            const isToday = date.getTime() === today.getTime();
            const state = this._getDayState(date);
            const rangePosition = this._getRangePosition(date);
            cells.push({ date, state, isToday, rangePosition });
        }
        // Group into rows of 7
        const weeks = [];
        for (let i = 0; i < cells.length; i += 7) {
            const row = cells.slice(i, i + 7);
            // Pad last row to 7 items
            while (row.length < 7)
                row.push(null);
            weeks.push(row);
        }
        this._weeks = weeks;
    }
    _getDayState(date) {
        if (this.minDate && date < this.minDate)
            return 'disabled';
        if (this.maxDate && date > this.maxDate)
            return 'disabled';
        if (this.type === 'single') {
            if (this.selectedDate) {
                const sel = new Date(this.selectedDate);
                sel.setHours(0, 0, 0, 0);
                if (date.getTime() === sel.getTime())
                    return 'selected';
            }
        }
        else {
            // ranged mode
            const start = this.selectedRange?.start ? new Date(this.selectedRange.start) : null;
            const end = this.selectedRange?.end ? new Date(this.selectedRange.end) : null;
            if (start)
                start.setHours(0, 0, 0, 0);
            if (end)
                end.setHours(0, 0, 0, 0);
            if (start && date.getTime() === start.getTime())
                return 'selected';
            if (end && date.getTime() === end.getTime())
                return 'selected';
            if (start && end && date > start && date < end)
                return 'in-range';
            // Hover preview (when start is set, end is not yet)
            if (start && !end && this.hoverDate) {
                const hover = new Date(this.hoverDate);
                hover.setHours(0, 0, 0, 0);
                if (date > start && date < hover)
                    return 'in-range';
                if (date > hover && date < start)
                    return 'in-range';
            }
        }
        return 'enabled';
    }
    _getRangePosition(date) {
        if (this.type !== 'ranged')
            return 'none';
        const start = this.selectedRange?.start ? new Date(this.selectedRange.start) : null;
        const end = this.selectedRange?.end ? new Date(this.selectedRange.end) : null;
        if (start)
            start.setHours(0, 0, 0, 0);
        if (end)
            end.setHours(0, 0, 0, 0);
        if (start && end) {
            if (date.getTime() === start.getTime())
                return 'start';
            if (date.getTime() === end.getTime())
                return 'end';
            if (date > start && date < end)
                return 'middle';
        }
        // Hover preview
        if (start && !end && this.hoverDate) {
            const hover = new Date(this.hoverDate);
            hover.setHours(0, 0, 0, 0);
            const rangeStart = start < hover ? start : hover;
            const rangeEnd = start < hover ? hover : start;
            if (date.getTime() === rangeStart.getTime())
                return 'start';
            if (date.getTime() === rangeEnd.getTime())
                return 'end';
            if (date > rangeStart && date < rangeEnd)
                return 'middle';
        }
        return 'none';
    }
    _buildMonthGrid() {
        const selectedMonth = this.selectedDate?.getMonth() ?? -1;
        const selectedYear = this.selectedDate?.getFullYear() ?? -1;
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();
        const displayYear = this.displayMonth.getFullYear();
        const items = MONTH_SHORT.map((label, index) => ({
            label,
            index,
            isSelected: index === selectedMonth && displayYear === selectedYear,
            isCurrentMonth: index === currentMonth && displayYear === currentYear
        }));
        this._monthRows = [];
        for (let i = 0; i < 12; i += 4) {
            this._monthRows.push(items.slice(i, i + 4));
        }
    }
    _buildYearGrid() {
        const displayYear = this.displayMonth.getFullYear();
        // Show a grid starting at a multiple of 12
        this._yearRangeStart = Math.floor(displayYear / 12) * 12;
        const currentYear = new Date().getFullYear();
        const selectedYear = this.selectedDate?.getFullYear() ?? -1;
        const items = Array.from({ length: 12 }, (_, i) => ({
            value: this._yearRangeStart + i,
            isSelected: (this._yearRangeStart + i) === selectedYear ? 1 : 0,
            isCurrentYear: (this._yearRangeStart + i) === currentYear
        }));
        this._yearRows = [];
        for (let i = 0; i < 12; i += 4) {
            this._yearRows.push(items.slice(i, i + 4));
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCalendarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.12", type: IuiCalendarComponent, isStandalone: true, selector: "iui-calendar", inputs: { type: "type", currentView: "currentView", displayMonth: "displayMonth", selectedDate: "selectedDate", selectedRange: "selectedRange", hoverDate: "hoverDate", minDate: "minDate", maxDate: "maxDate" }, outputs: { dateSelected: "dateSelected", viewChange: "viewChange", displayMonthChange: "displayMonthChange", dateHover: "dateHover" }, usesOnChanges: true, ngImport: i0, template: "@if (currentView === 'day') {\r\n\t<!-- Day view header -->\r\n\t<div class=\"iui-calendar__header\">\r\n\t\t<button class=\"iui-calendar__nav-btn\" type=\"button\" (click)=\"_navigatePrevMonth()\" aria-label=\"Previous month\">\r\n\t\t\t<iui-chevron-left-icon></iui-chevron-left-icon>\r\n\t\t</button>\r\n\t\t<button class=\"iui-calendar__header-title\" type=\"button\" (click)=\"_switchToMonthView()\" aria-label=\"Select month and year\">\r\n\t\t\t<span>{{ _monthName }} {{ _year }}</span>\r\n\t\t\t<iui-caret-down-icon class=\"iui-calendar__header-caret\"></iui-caret-down-icon>\r\n\t\t</button>\r\n\t\t<button class=\"iui-calendar__nav-btn\" type=\"button\" (click)=\"_navigateNextMonth()\" aria-label=\"Next month\">\r\n\t\t\t<iui-chevron-right-icon></iui-chevron-right-icon>\r\n\t\t</button>\r\n\t</div>\r\n\r\n\t<!-- Weekday headers -->\r\n\t<div class=\"iui-calendar__day-grid\">\r\n\t\t<div class=\"iui-calendar__weekdays\">\r\n\t\t\t@for (day of weekdays; track day) {\r\n\t\t\t\t<div class=\"iui-calendar__weekday-header\">{{ day }}</div>\r\n\t\t\t}\r\n\t\t</div>\r\n\r\n\t\t<!-- Day rows -->\r\n\t\t@for (week of _weeks; track $index) {\r\n\t\t\t<div class=\"iui-calendar__week\">\r\n\t\t\t\t@for (cell of week; track $index) {\r\n\t\t\t\t\t@if (cell) {\r\n\t\t\t\t\t\t<iui-calendar-day\r\n\t\t\t\t\t\t\t[date]=\"cell.date\"\r\n\t\t\t\t\t\t\t[state]=\"cell.state\"\r\n\t\t\t\t\t\t\t[isToday]=\"cell.isToday\"\r\n\t\t\t\t\t\t\t[rangePosition]=\"cell.rangePosition\"\r\n\t\t\t\t\t\t\t(dayClick)=\"_onDayClick($event)\"\r\n\t\t\t\t\t\t\t(dayHover)=\"_onDayHover($event)\"\r\n\t\t\t\t\t\t\t(dayLeave)=\"_onDayLeave()\"\r\n\t\t\t\t\t\t></iui-calendar-day>\r\n\t\t\t\t\t} @else {\r\n\t\t\t\t\t\t<div class=\"iui-calendar__day-placeholder\"></div>\r\n\t\t\t\t\t}\r\n\t\t\t\t}\r\n\t\t\t</div>\r\n\t\t}\r\n\t</div>\r\n}\r\n\r\n@if (currentView === 'month') {\r\n\t<!-- Month view header -->\r\n\t<div class=\"iui-calendar__header\">\r\n\t\t<button class=\"iui-calendar__header-title iui-calendar__header-title_center\" type=\"button\" (click)=\"_switchToYearView()\" aria-label=\"Select year\">\r\n\t\t\t<span>{{ _year }}</span>\r\n\t\t</button>\r\n\t</div>\r\n\r\n\t<!-- Month grid -->\r\n\t<div class=\"iui-calendar__month-grid\">\r\n\t\t@for (row of _monthRows; track $index) {\r\n\t\t\t<div class=\"iui-calendar__month-row\">\r\n\t\t\t\t@for (month of row; track month.index) {\r\n\t\t\t\t\t<button\r\n\t\t\t\t\t\tclass=\"iui-calendar__month-cell\"\r\n\t\t\t\t\t\t[class.iui-calendar__month-cell_selected]=\"month.isSelected\"\r\n\t\t\t\t\t\t[class.iui-calendar__month-cell_today]=\"month.isCurrentMonth\"\r\n\t\t\t\t\t\ttype=\"button\"\r\n\t\t\t\t\t\t(click)=\"_selectMonth(month.index)\"\r\n\t\t\t\t\t>{{ month.label }}</button>\r\n\t\t\t\t}\r\n\t\t\t</div>\r\n\t\t}\r\n\t</div>\r\n}\r\n\r\n@if (currentView === 'year') {\r\n\t<!-- Year view header -->\r\n\t<div class=\"iui-calendar__header\">\r\n\t\t<span class=\"iui-calendar__header-title iui-calendar__header-title_center iui-calendar__header-title_label\">{{ _yearRangeLabel }}</span>\r\n\t</div>\r\n\r\n\t<!-- Year grid -->\r\n\t<div class=\"iui-calendar__year-grid\">\r\n\t\t@for (row of _yearRows; track $index) {\r\n\t\t\t<div class=\"iui-calendar__year-row\">\r\n\t\t\t\t@for (year of row; track year.value) {\r\n\t\t\t\t\t<button\r\n\t\t\t\t\t\tclass=\"iui-calendar__year-cell\"\r\n\t\t\t\t\t\t[class.iui-calendar__year-cell_selected]=\"year.isSelected\"\r\n\t\t\t\t\t\t[class.iui-calendar__year-cell_today]=\"year.isCurrentYear\"\r\n\t\t\t\t\t\ttype=\"button\"\r\n\t\t\t\t\t\t(click)=\"_selectYear(year.value)\"\r\n\t\t\t\t\t>{{ year.value }}</button>\r\n\t\t\t\t}\r\n\t\t\t</div>\r\n\t\t}\r\n\t</div>\r\n}\r\n", styles: [":host{--iui-date-picker-panel-bg: var(--iui-background-menu);--iui-date-picker-panel-shadow: var(--iui-box-shadow-m);--iui-date-picker-calendar-border: var(--iui-border-subtle);--iui-date-picker-header-color: var(--iui-text-primary);--iui-date-picker-weekday-color: var(--iui-text-tertiary);--iui-date-picker-day-hover-bg: var(--iui-background-subtle-hover);--iui-date-picker-day-selected-bg: var(--iui-background-interactive);--iui-date-picker-day-selected-color: var(--iui-text-on-color-primary);--iui-date-picker-today-indicator: var(--iui-border-interactive);display:block;width:324px;background:var(--iui-date-picker-panel-bg);box-shadow:var(--iui-date-picker-panel-shadow);border-radius:var(--iui-border-radius-medium);overflow:hidden}:host *,:host *:before,:host *:after{box-sizing:border-box}.iui-calendar__header{display:flex;align-items:center;padding:12px 16px;height:44px;border-bottom:1px solid var(--iui-date-picker-calendar-border);gap:8px}.iui-calendar__header-title{font:var(--iui-tp-heading-01-font);color:var(--iui-date-picker-header-color);flex:1;text-align:center;cursor:pointer;background:transparent;border:none;display:flex;align-items:center;justify-content:center;gap:4px;padding:0;font:inherit}.iui-calendar__header-title.iui-calendar__header-title_center{justify-content:center}.iui-calendar__header-title.iui-calendar__header-title_label{cursor:default}.iui-calendar__header-caret{width:16px;height:16px;flex-shrink:0}.iui-calendar__nav-btn{background:transparent;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--iui-date-picker-header-color);padding:0;width:20px;height:20px;flex-shrink:0}.iui-calendar__day-grid{padding:8px}.iui-calendar__weekdays{display:flex;margin-bottom:0}.iui-calendar__weekday-header{font:var(--iui-tp-body-01-font);color:var(--iui-date-picker-weekday-color);flex:1;text-align:center;padding:4px}.iui-calendar__week{display:flex}.iui-calendar__day-placeholder{width:44px;height:44px;flex-shrink:0}.iui-calendar__month-grid,.iui-calendar__year-grid{padding:8px}.iui-calendar__month-row,.iui-calendar__year-row{display:flex;gap:0}.iui-calendar__month-cell,.iui-calendar__year-cell{font:var(--iui-tp-body-01-font);flex:1;height:36px;border-radius:var(--iui-border-radius-medium);background:transparent;border:none;cursor:pointer;text-align:center;color:var(--iui-date-picker-header-color);margin:4px 2px;display:flex;align-items:center;justify-content:center}.iui-calendar__month-cell:hover,.iui-calendar__year-cell:hover{background:var(--iui-date-picker-day-hover-bg)}.iui-calendar__month-cell_selected,.iui-calendar__year-cell_selected{background:var(--iui-date-picker-day-selected-bg)!important;color:var(--iui-date-picker-day-selected-color)!important}.iui-calendar__month-cell_today,.iui-calendar__year-cell_today{position:relative}.iui-calendar__month-cell_today:after,.iui-calendar__year-cell_today:after{content:\"\";position:absolute;bottom:2px;left:50%;transform:translate(-50%);width:12px;height:2px;border-radius:9999px;background:var(--iui-date-picker-today-indicator)}.iui-calendar__month-cell_selected.iui-calendar__month-cell_today:after,.iui-calendar__year-cell_selected.iui-calendar__year-cell_today:after{background:var(--iui-date-picker-day-selected-color)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: CaretDownIconComponent, selector: "iui-caret-down-icon" }, { kind: "component", type: ChevronLeftIconComponent, selector: "iui-chevron-left-icon" }, { kind: "component", type: ChevronRightIconComponent, selector: "iui-chevron-right-icon" }, { kind: "component", type: IuiCalendarDayComponent, selector: "iui-calendar-day", inputs: ["date", "state", "isToday", "rangePosition"], outputs: ["dayClick", "dayHover", "dayLeave"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCalendarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-calendar', standalone: true, imports: [CommonModule, CalendarIconComponent, CaretDownIconComponent, ChevronLeftIconComponent, ChevronRightIconComponent, IuiCalendarDayComponent, DatePipe], changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (currentView === 'day') {\r\n\t<!-- Day view header -->\r\n\t<div class=\"iui-calendar__header\">\r\n\t\t<button class=\"iui-calendar__nav-btn\" type=\"button\" (click)=\"_navigatePrevMonth()\" aria-label=\"Previous month\">\r\n\t\t\t<iui-chevron-left-icon></iui-chevron-left-icon>\r\n\t\t</button>\r\n\t\t<button class=\"iui-calendar__header-title\" type=\"button\" (click)=\"_switchToMonthView()\" aria-label=\"Select month and year\">\r\n\t\t\t<span>{{ _monthName }} {{ _year }}</span>\r\n\t\t\t<iui-caret-down-icon class=\"iui-calendar__header-caret\"></iui-caret-down-icon>\r\n\t\t</button>\r\n\t\t<button class=\"iui-calendar__nav-btn\" type=\"button\" (click)=\"_navigateNextMonth()\" aria-label=\"Next month\">\r\n\t\t\t<iui-chevron-right-icon></iui-chevron-right-icon>\r\n\t\t</button>\r\n\t</div>\r\n\r\n\t<!-- Weekday headers -->\r\n\t<div class=\"iui-calendar__day-grid\">\r\n\t\t<div class=\"iui-calendar__weekdays\">\r\n\t\t\t@for (day of weekdays; track day) {\r\n\t\t\t\t<div class=\"iui-calendar__weekday-header\">{{ day }}</div>\r\n\t\t\t}\r\n\t\t</div>\r\n\r\n\t\t<!-- Day rows -->\r\n\t\t@for (week of _weeks; track $index) {\r\n\t\t\t<div class=\"iui-calendar__week\">\r\n\t\t\t\t@for (cell of week; track $index) {\r\n\t\t\t\t\t@if (cell) {\r\n\t\t\t\t\t\t<iui-calendar-day\r\n\t\t\t\t\t\t\t[date]=\"cell.date\"\r\n\t\t\t\t\t\t\t[state]=\"cell.state\"\r\n\t\t\t\t\t\t\t[isToday]=\"cell.isToday\"\r\n\t\t\t\t\t\t\t[rangePosition]=\"cell.rangePosition\"\r\n\t\t\t\t\t\t\t(dayClick)=\"_onDayClick($event)\"\r\n\t\t\t\t\t\t\t(dayHover)=\"_onDayHover($event)\"\r\n\t\t\t\t\t\t\t(dayLeave)=\"_onDayLeave()\"\r\n\t\t\t\t\t\t></iui-calendar-day>\r\n\t\t\t\t\t} @else {\r\n\t\t\t\t\t\t<div class=\"iui-calendar__day-placeholder\"></div>\r\n\t\t\t\t\t}\r\n\t\t\t\t}\r\n\t\t\t</div>\r\n\t\t}\r\n\t</div>\r\n}\r\n\r\n@if (currentView === 'month') {\r\n\t<!-- Month view header -->\r\n\t<div class=\"iui-calendar__header\">\r\n\t\t<button class=\"iui-calendar__header-title iui-calendar__header-title_center\" type=\"button\" (click)=\"_switchToYearView()\" aria-label=\"Select year\">\r\n\t\t\t<span>{{ _year }}</span>\r\n\t\t</button>\r\n\t</div>\r\n\r\n\t<!-- Month grid -->\r\n\t<div class=\"iui-calendar__month-grid\">\r\n\t\t@for (row of _monthRows; track $index) {\r\n\t\t\t<div class=\"iui-calendar__month-row\">\r\n\t\t\t\t@for (month of row; track month.index) {\r\n\t\t\t\t\t<button\r\n\t\t\t\t\t\tclass=\"iui-calendar__month-cell\"\r\n\t\t\t\t\t\t[class.iui-calendar__month-cell_selected]=\"month.isSelected\"\r\n\t\t\t\t\t\t[class.iui-calendar__month-cell_today]=\"month.isCurrentMonth\"\r\n\t\t\t\t\t\ttype=\"button\"\r\n\t\t\t\t\t\t(click)=\"_selectMonth(month.index)\"\r\n\t\t\t\t\t>{{ month.label }}</button>\r\n\t\t\t\t}\r\n\t\t\t</div>\r\n\t\t}\r\n\t</div>\r\n}\r\n\r\n@if (currentView === 'year') {\r\n\t<!-- Year view header -->\r\n\t<div class=\"iui-calendar__header\">\r\n\t\t<span class=\"iui-calendar__header-title iui-calendar__header-title_center iui-calendar__header-title_label\">{{ _yearRangeLabel }}</span>\r\n\t</div>\r\n\r\n\t<!-- Year grid -->\r\n\t<div class=\"iui-calendar__year-grid\">\r\n\t\t@for (row of _yearRows; track $index) {\r\n\t\t\t<div class=\"iui-calendar__year-row\">\r\n\t\t\t\t@for (year of row; track year.value) {\r\n\t\t\t\t\t<button\r\n\t\t\t\t\t\tclass=\"iui-calendar__year-cell\"\r\n\t\t\t\t\t\t[class.iui-calendar__year-cell_selected]=\"year.isSelected\"\r\n\t\t\t\t\t\t[class.iui-calendar__year-cell_today]=\"year.isCurrentYear\"\r\n\t\t\t\t\t\ttype=\"button\"\r\n\t\t\t\t\t\t(click)=\"_selectYear(year.value)\"\r\n\t\t\t\t\t>{{ year.value }}</button>\r\n\t\t\t\t}\r\n\t\t\t</div>\r\n\t\t}\r\n\t</div>\r\n}\r\n", styles: [":host{--iui-date-picker-panel-bg: var(--iui-background-menu);--iui-date-picker-panel-shadow: var(--iui-box-shadow-m);--iui-date-picker-calendar-border: var(--iui-border-subtle);--iui-date-picker-header-color: var(--iui-text-primary);--iui-date-picker-weekday-color: var(--iui-text-tertiary);--iui-date-picker-day-hover-bg: var(--iui-background-subtle-hover);--iui-date-picker-day-selected-bg: var(--iui-background-interactive);--iui-date-picker-day-selected-color: var(--iui-text-on-color-primary);--iui-date-picker-today-indicator: var(--iui-border-interactive);display:block;width:324px;background:var(--iui-date-picker-panel-bg);box-shadow:var(--iui-date-picker-panel-shadow);border-radius:var(--iui-border-radius-medium);overflow:hidden}:host *,:host *:before,:host *:after{box-sizing:border-box}.iui-calendar__header{display:flex;align-items:center;padding:12px 16px;height:44px;border-bottom:1px solid var(--iui-date-picker-calendar-border);gap:8px}.iui-calendar__header-title{font:var(--iui-tp-heading-01-font);color:var(--iui-date-picker-header-color);flex:1;text-align:center;cursor:pointer;background:transparent;border:none;display:flex;align-items:center;justify-content:center;gap:4px;padding:0;font:inherit}.iui-calendar__header-title.iui-calendar__header-title_center{justify-content:center}.iui-calendar__header-title.iui-calendar__header-title_label{cursor:default}.iui-calendar__header-caret{width:16px;height:16px;flex-shrink:0}.iui-calendar__nav-btn{background:transparent;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--iui-date-picker-header-color);padding:0;width:20px;height:20px;flex-shrink:0}.iui-calendar__day-grid{padding:8px}.iui-calendar__weekdays{display:flex;margin-bottom:0}.iui-calendar__weekday-header{font:var(--iui-tp-body-01-font);color:var(--iui-date-picker-weekday-color);flex:1;text-align:center;padding:4px}.iui-calendar__week{display:flex}.iui-calendar__day-placeholder{width:44px;height:44px;flex-shrink:0}.iui-calendar__month-grid,.iui-calendar__year-grid{padding:8px}.iui-calendar__month-row,.iui-calendar__year-row{display:flex;gap:0}.iui-calendar__month-cell,.iui-calendar__year-cell{font:var(--iui-tp-body-01-font);flex:1;height:36px;border-radius:var(--iui-border-radius-medium);background:transparent;border:none;cursor:pointer;text-align:center;color:var(--iui-date-picker-header-color);margin:4px 2px;display:flex;align-items:center;justify-content:center}.iui-calendar__month-cell:hover,.iui-calendar__year-cell:hover{background:var(--iui-date-picker-day-hover-bg)}.iui-calendar__month-cell_selected,.iui-calendar__year-cell_selected{background:var(--iui-date-picker-day-selected-bg)!important;color:var(--iui-date-picker-day-selected-color)!important}.iui-calendar__month-cell_today,.iui-calendar__year-cell_today{position:relative}.iui-calendar__month-cell_today:after,.iui-calendar__year-cell_today:after{content:\"\";position:absolute;bottom:2px;left:50%;transform:translate(-50%);width:12px;height:2px;border-radius:9999px;background:var(--iui-date-picker-today-indicator)}.iui-calendar__month-cell_selected.iui-calendar__month-cell_today:after,.iui-calendar__year-cell_selected.iui-calendar__year-cell_today:after{background:var(--iui-date-picker-day-selected-color)}\n"] }]
        }], propDecorators: { type: [{
                type: Input
            }], currentView: [{
                type: Input
            }], displayMonth: [{
                type: Input
            }], selectedDate: [{
                type: Input
            }], selectedRange: [{
                type: Input
            }], hoverDate: [{
                type: Input
            }], minDate: [{
                type: Input
            }], maxDate: [{
                type: Input
            }], dateSelected: [{
                type: Output
            }], viewChange: [{
                type: Output
            }], displayMonthChange: [{
                type: Output
            }], dateHover: [{
                type: Output
            }] } });

let nextUniqueId = 0;
/** Scroll strategy token — block scrolling while calendar is open. */
const IUI_DATE_PICKER_SCROLL_STRATEGY = new InjectionToken('iui-date-picker-scroll-strategy', {
    providedIn: 'root',
    factory: () => {
        const overlay = inject(Overlay);
        return () => overlay.scrollStrategies.block();
    }
});
const DATE_PICKER_POSITIONS = [
    { originX: 'end', originY: 'bottom', overlayX: 'end', overlayY: 'top', offsetY: 4 },
    { originX: 'end', originY: 'top', overlayX: 'end', overlayY: 'bottom', offsetY: -4 },
    { originX: 'start', originY: 'bottom', overlayX: 'start', overlayY: 'top', offsetY: 4 },
    { originX: 'start', originY: 'top', overlayX: 'start', overlayY: 'bottom', offsetY: -4 }
];
class IuiDatePickerComponent {
    set id(value) { this._id = value; }
    get id() { return this._id; }
    get required() {
        return this._required ?? this.ngControlDirective.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    constructor(_cdr, _elementRef, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._cdr = _cdr;
        this._elementRef = _elementRef;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        this.type = 'single';
        this.layerSet = 'set-01';
        this.label = '';
        this.placeholder = 'mm.dd.yyyy';
        this.placeholderEnd = 'mm.dd.yyyy';
        this.dateFormat = 'MM/dd/yyyy';
        this.name = '';
        this.showLabel = true;
        this.showHelper = true;
        this.showExplainer = false; // reserved, no-op
        this.skeleton = false;
        this.minDate = null;
        this.maxDate = null;
        this.valueChange = new EventEmitter();
        this.calendarOpen = new EventEmitter();
        this.calendarClose = new EventEmitter();
        // Internal state
        this._panelOpen = false;
        this._focused = false;
        this._hovered = false;
        this._singleValue = null;
        this._rangeValue = null;
        this._selectingEnd = false; // ranged: true after start is set, waiting for end
        this._hoverDate = null;
        this._calendarView = 'day';
        this._displayMonth = new Date();
        this._displayValue = '';
        this._displayStartValue = '';
        this._displayEndValue = '';
        this._positions = DATE_PICKER_POSITIONS;
        this._id = `iui-date-picker-${nextUniqueId++}`;
        this._onChange = () => { };
        this._onTouched = () => { };
        this._destroy = new Subject();
        const factory = inject(IUI_DATE_PICKER_SCROLL_STRATEGY);
        this._scrollStrategy = factory();
        this._datePipe = new DatePipe('en-US');
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get _empty() {
        if (this.type === 'single')
            return this._singleValue == null;
        return this._rangeValue == null || (this._rangeValue.start == null && this._rangeValue.end == null);
    }
    // ── Calendar open / close ────────────────────────────────────────────────
    open() {
        if (this.disabled || this._panelOpen)
            return;
        this._panelOpen = true;
        this._calendarView = 'day';
        // Set display month to currently selected date
        if (this.type === 'single' && this._singleValue) {
            this._displayMonth = new Date(this._singleValue);
        }
        else if (this.type === 'ranged' && this._rangeValue?.start) {
            this._displayMonth = new Date(this._rangeValue.start);
        }
        else {
            this._displayMonth = new Date();
        }
        this._displayMonth.setDate(1);
        this.calendarOpen.emit();
        this._cdr.markForCheck();
    }
    close() {
        if (!this._panelOpen)
            return;
        this._panelOpen = false;
        this._selectingEnd = false;
        this._hoverDate = null;
        this._onTouched();
        this.calendarClose.emit();
        this._cdr.markForCheck();
        // Return focus to host element
        this._elementRef.nativeElement.focus();
    }
    toggle() {
        if (this._panelOpen)
            this.close();
        else
            this.open();
    }
    // ── Calendar events ──────────────────────────────────────────────────────
    _onDateSelected(date) {
        if (this.type === 'single') {
            this._singleValue = date;
            this._displayValue = this._formatDate(date);
            this._onChange(date);
            this.valueChange.emit(date);
            this.close();
        }
        else {
            // Ranged mode
            if (!this._selectingEnd || this._rangeValue?.start == null) {
                // Setting start date
                const d = new Date(date);
                d.setHours(0, 0, 0, 0);
                this._rangeValue = { start: d, end: null };
                this._displayStartValue = this._formatDate(d);
                this._displayEndValue = '';
                this._selectingEnd = true;
                this._hoverDate = null;
            }
            else {
                // Setting end date
                const d = new Date(date);
                d.setHours(0, 0, 0, 0);
                const start = this._rangeValue.start;
                if (d < start) {
                    // New date is before start — swap
                    this._rangeValue = { start: d, end: start };
                    this._displayStartValue = this._formatDate(d);
                    this._displayEndValue = this._formatDate(start);
                }
                else {
                    this._rangeValue = { start, end: d };
                    this._displayStartValue = this._formatDate(start);
                    this._displayEndValue = this._formatDate(d);
                }
                this._onChange(this._rangeValue);
                this.valueChange.emit(this._rangeValue);
                this.close();
            }
        }
        this._cdr.markForCheck();
    }
    _onViewChange(view) {
        this._calendarView = view;
        this._cdr.markForCheck();
    }
    _onDisplayMonthChange(month) {
        this._displayMonth = month;
        this._cdr.markForCheck();
    }
    _onDateHover(date) {
        this._hoverDate = date;
        this._cdr.markForCheck();
    }
    // ── Trigger field events ─────────────────────────────────────────────────
    _onFocus() {
        this._focused = true;
        this._cdr.markForCheck();
    }
    _onBlur() {
        this._focused = false;
        this._cdr.markForCheck();
    }
    _onMouseEnter() {
        this._hovered = true;
        this._cdr.markForCheck();
    }
    _onMouseLeave() {
        this._hovered = false;
        this._cdr.markForCheck();
    }
    _onStartFocus() {
        this._focused = true;
        this._selectingEnd = false;
        this._cdr.markForCheck();
    }
    _onEndFocus() {
        this._focused = true;
        this._selectingEnd = true;
        this._cdr.markForCheck();
    }
    _onTextInput(value) {
        if (!value) {
            this._singleValue = null;
            this._onChange(null);
            this.valueChange.emit(null);
        }
        else {
            const parsed = this._parseDate(value);
            if (parsed) {
                this._singleValue = parsed;
                this._onChange(parsed);
                this.valueChange.emit(parsed);
            }
        }
        this._cdr.markForCheck();
    }
    _onStartTextInput(event) {
        const value = event.target.value;
        const parsed = value ? this._parseDate(value) : null;
        if (!this._rangeValue)
            this._rangeValue = { start: null, end: null };
        this._rangeValue = { ...this._rangeValue, start: parsed };
        this._emitRangeIfComplete();
        this._cdr.markForCheck();
    }
    _onEndTextInput(event) {
        const value = event.target.value;
        const parsed = value ? this._parseDate(value) : null;
        if (!this._rangeValue)
            this._rangeValue = { start: null, end: null };
        this._rangeValue = { ...this._rangeValue, end: parsed };
        this._emitRangeIfComplete();
        this._cdr.markForCheck();
    }
    _emitRangeIfComplete() {
        if (this._rangeValue?.start && this._rangeValue?.end) {
            this._onChange(this._rangeValue);
            this.valueChange.emit(this._rangeValue);
        }
        else if (!this._rangeValue?.start && !this._rangeValue?.end) {
            this._onChange(null);
            this.valueChange.emit(null);
        }
    }
    _handleKeydown(event) {
        if (event.key === 'Escape') {
            this.close();
        }
        else if (!this._panelOpen && (event.key === 'Enter' || event.key === ' ' || event.key === 'ArrowDown')) {
            this.open();
            event.preventDefault();
        }
    }
    // ── Date formatting / parsing ────────────────────────────────────────────
    _formatDate(date) {
        return this._datePipe.transform(date, this.dateFormat) ?? '';
    }
    _parseDate(text) {
        if (!text)
            return null;
        // Simple parser: supports MM/dd/yyyy and MM.dd.yyyy and yyyy-MM-dd
        const cleaned = text.replace(/\./g, '/').replace(/-/g, '/');
        const parts = cleaned.split('/');
        if (parts.length === 3) {
            const [a, b, c] = parts.map(Number);
            // Determine format based on dateFormat
            let month, day, year;
            if (this.dateFormat.startsWith('yyyy')) {
                year = a;
                month = b - 1;
                day = c;
            }
            else {
                month = a - 1;
                day = b;
                year = c;
            }
            if (!isNaN(month) && !isNaN(day) && !isNaN(year) && year > 1000) {
                const d = new Date(year, month, day);
                if (d.getFullYear() === year && d.getMonth() === month && d.getDate() === day) {
                    return d;
                }
            }
        }
        return null;
    }
    // ── ControlValueAccessor ─────────────────────────────────────────────────
    writeValue(value) {
        if (this.type === 'single') {
            if (value instanceof Date) {
                this._singleValue = value;
                this._displayValue = this._formatDate(value);
            }
            else if (typeof value === 'string') {
                const parsed = this._parseDate(value);
                this._singleValue = parsed;
                this._displayValue = parsed ? this._formatDate(parsed) : '';
            }
            else {
                this._singleValue = null;
                this._displayValue = '';
            }
        }
        else {
            const range = value;
            this._rangeValue = range ?? null;
            this._displayStartValue = range?.start ? this._formatDate(range.start) : '';
            this._displayEndValue = range?.end ? this._formatDate(range.end) : '';
        }
        this._cdr.markForCheck();
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._cdr.markForCheck();
    }
    ngOnDestroy() {
        this._destroy.next();
        this._destroy.complete();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiDatePickerComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i0.ElementRef }, { token: i1$1.NgControlDirective, self: true }, { token: i1$1.IuiErrorStateMatcherDirective, self: true }, { token: i1$1.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.12", type: IuiDatePickerComponent, isStandalone: true, selector: "iui-date-picker", inputs: { id: "id", type: "type", layerSet: "layerSet", label: "label", placeholder: "placeholder", placeholderEnd: "placeholderEnd", dateFormat: "dateFormat", name: "name", showLabel: "showLabel", showHelper: "showHelper", showExplainer: "showExplainer", skeleton: "skeleton", minDate: "minDate", maxDate: "maxDate", required: "required" }, outputs: { valueChange: "valueChange", calendarOpen: "calendarOpen", calendarClose: "calendarClose" }, host: { properties: { "class.iui-date-picker_type_ranged": "type === \"ranged\"", "class.iui-date-picker_layer-set-02": "layerSet === \"set-02\"", "class.iui-date-picker_open": "_panelOpen", "class.iui-date-picker_focused": "_focused", "class.iui-date-picker_hovered": "_hovered", "class.iui-date-picker_selected": "!_empty", "class.iui-date-picker_disabled": "disabled", "class.iui-date-picker_invalid": "_errorState", "class.iui-date-picker_skeleton": "skeleton", "class.iui-date-picker_required": "required", "attr.id": "id", "attr.data-testid": "id" }, classAttribute: "iui-date-picker" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiDatePickerComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "_overlayDir", first: true, predicate: CdkConnectedOverlay, descendants: true }], hostDirectives: [{ directive: i1$1.NgControlDirective }, { directive: i1$1.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i1$1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "@if (skeleton) {\r\n\t<div class=\"iui-date-picker__skeleton-label\" *ngIf=\"showLabel\"></div>\r\n\t<div class=\"iui-date-picker__skeleton-field\"></div>\r\n\t<div class=\"iui-date-picker__skeleton-helper\" *ngIf=\"showHelper\"></div>\r\n} @else {\r\n\t<!-- Label row (optional) -->\r\n\t@if (showLabel && label) {\r\n\t\t<div class=\"iui-date-picker__label-row\">\r\n\t\t\t<label class=\"iui-date-picker__label\">\r\n\t\t\t\t{{ label }}<span class=\"iui-date-picker__required\" *ngIf=\"required\">*</span>\r\n\t\t\t</label>\r\n\t\t</div>\r\n\t}\r\n\r\n\t<!-- Trigger field wrapper (overlay origin) -->\r\n\t<div\r\n\t\tclass=\"iui-date-picker__field-wrap\"\r\n\t\tcdk-overlay-origin\r\n\t\t#overlayOrigin=\"cdkOverlayOrigin\"\r\n\t\t(click)=\"open()\"\r\n\t\t(mouseenter)=\"_onMouseEnter()\"\r\n\t\t(mouseleave)=\"_onMouseLeave()\"\r\n\t\t(keydown)=\"_handleKeydown($event)\"\r\n\t>\r\n\t\t@if (type === 'single') {\r\n\t\t\t<!-- Single mode: use iui-date-input with calendar icon suffix -->\r\n\t\t\t<iui-date-input\r\n\t\t\t\tclass=\"iui-date-picker__date-input\"\r\n\t\t\t\t[showLabel]=\"false\"\r\n\t\t\t\t[showHelper]=\"false\"\r\n\t\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t\t[isDisabled]=\"disabled\"\r\n\t\t\t\t[ngModel]=\"_displayValue\"\r\n\t\t\t\t(ngModelChange)=\"_onTextInput($event)\"\r\n\t\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t>\r\n\t\t\t\t<button\r\n\t\t\t\t\tiuiSuffix\r\n\t\t\t\t\tclass=\"iui-date-picker__calendar-btn\"\r\n\t\t\t\t\ttype=\"button\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\taria-label=\"Open calendar\"\r\n\t\t\t\t\t(click)=\"toggle(); $event.stopPropagation()\"\r\n\t\t\t\t>\r\n\t\t\t\t\t<iui-calendar-icon></iui-calendar-icon>\r\n\t\t\t\t</button>\r\n\t\t\t</iui-date-input>\r\n\t\t}\r\n\r\n\t\t@if (type === 'ranged') {\r\n\t\t\t<!-- Ranged mode: custom dual-input field -->\r\n\t\t\t<div class=\"iui-date-picker__range-field\">\r\n\t\t\t\t<input\r\n\t\t\t\t\tclass=\"iui-date-picker__range-input\"\r\n\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\t[value]=\"_displayStartValue\"\r\n\t\t\t\t\taria-label=\"Start date\"\r\n\t\t\t\t\t(input)=\"_onStartTextInput($event)\"\r\n\t\t\t\t\t(focus)=\"_onStartFocus()\"\r\n\t\t\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t\t\t(click)=\"open()\"\r\n\t\t\t\t/>\r\n\t\t\t\t<span class=\"iui-date-picker__range-divider\" aria-hidden=\"true\">\u2192</span>\r\n\t\t\t\t<input\r\n\t\t\t\t\tclass=\"iui-date-picker__range-input\"\r\n\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t[placeholder]=\"placeholderEnd\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\t[value]=\"_displayEndValue\"\r\n\t\t\t\t\taria-label=\"End date\"\r\n\t\t\t\t\t(input)=\"_onEndTextInput($event)\"\r\n\t\t\t\t\t(focus)=\"_onEndFocus()\"\r\n\t\t\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t\t\t(click)=\"open()\"\r\n\t\t\t\t/>\r\n\t\t\t\t<button\r\n\t\t\t\t\tclass=\"iui-date-picker__calendar-btn\"\r\n\t\t\t\t\ttype=\"button\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\taria-label=\"Open calendar\"\r\n\t\t\t\t\t(click)=\"toggle(); $event.stopPropagation()\"\r\n\t\t\t\t>\r\n\t\t\t\t\t<iui-calendar-icon></iui-calendar-icon>\r\n\t\t\t\t</button>\r\n\t\t\t</div>\r\n\t\t}\r\n\t</div>\r\n\r\n\t<!-- CDK overlay for calendar panel -->\r\n\t<ng-template\r\n\t\tcdk-connected-overlay\r\n\t\tcdkConnectedOverlayHasBackdrop\r\n\t\tcdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\r\n\t\t[cdkConnectedOverlayOrigin]=\"overlayOrigin\"\r\n\t\t[cdkConnectedOverlayOpen]=\"_panelOpen\"\r\n\t\t[cdkConnectedOverlayPositions]=\"_positions\"\r\n\t\t[cdkConnectedOverlayScrollStrategy]=\"_scrollStrategy\"\r\n\t\t[cdkConnectedOverlayWidth]=\"324\"\r\n\t\t(backdropClick)=\"close()\"\r\n\t\t(detach)=\"close()\"\r\n\t>\r\n\t\t<iui-calendar\r\n\t\t\t[type]=\"type\"\r\n\t\t\t[currentView]=\"_calendarView\"\r\n\t\t\t[displayMonth]=\"_displayMonth\"\r\n\t\t\t[selectedDate]=\"type === 'single' ? _singleValue : null\"\r\n\t\t\t[selectedRange]=\"type === 'ranged' ? _rangeValue : null\"\r\n\t\t\t[hoverDate]=\"_hoverDate\"\r\n\t\t\t[minDate]=\"minDate\"\r\n\t\t\t[maxDate]=\"maxDate\"\r\n\t\t\t(dateSelected)=\"_onDateSelected($event)\"\r\n\t\t\t(viewChange)=\"_onViewChange($event)\"\r\n\t\t\t(displayMonthChange)=\"_onDisplayMonthChange($event)\"\r\n\t\t\t(dateHover)=\"_onDateHover($event)\"\r\n\t\t></iui-calendar>\r\n\t</ng-template>\r\n\r\n\t<!-- Helper / Error row (optional) -->\r\n\t@if (showHelper) {\r\n\t\t<div class=\"iui-date-picker__helper-row\">\r\n\t\t\t@if (_errorState) {\r\n\t\t\t\t<span class=\"iui-date-picker__error\">\r\n\t\t\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t\t\t</span>\r\n\t\t\t} @else {\r\n\t\t\t\t<span class=\"iui-date-picker__helper\">\r\n\t\t\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t\t\t</span>\r\n\t\t\t}\r\n\t\t</div>\r\n\t}\r\n}\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{--iui-date-picker-field-bg: var(--iui-background-subtle-01);--iui-date-picker-field-bg-02: var(--iui-background-subtle-02);--iui-date-picker-field-hover-bg: var(--iui-background-subtle-hover);--iui-date-picker-label-color: var(--iui-text-secondary);--iui-date-picker-value-color: var(--iui-text-primary);--iui-date-picker-placeholder-color: var(--iui-text-tertiary);--iui-date-picker-helper-color: var(--iui-text-secondary);--iui-date-picker-error-color: var(--iui-text-error);--iui-date-picker-disabled-color: var(--iui-text-disabled);--iui-date-picker-focus-border: var(--iui-border-focus);--iui-date-picker-error-border: var(--iui-border-error);--iui-date-picker-divider-color: var(--iui-text-tertiary);--iui-date-picker-required-color: var(--iui-text-error);--iui-date-picker-skeleton-bg: var(--iui-background-highlight-gray);display:flex;flex-direction:column;min-width:200px;max-width:100%}:host.iui-date-picker_layer-set-02{--iui-date-picker-field-bg: var(--iui-date-picker-field-bg-02)}.iui-date-picker__label-row{display:flex;align-items:flex-start;padding-bottom:8px}.iui-date-picker__label{font:var(--iui-tp-label-01-font);color:var(--iui-date-picker-label-color);flex:1;min-width:0}.iui-date-picker__required{color:var(--iui-date-picker-required-color);margin-left:4px}:host.iui-date-picker_disabled .iui-date-picker__label{color:var(--iui-date-picker-disabled-color)}.iui-date-picker__field-wrap{position:relative;width:100%}:host:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input{width:100%}:host:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input ::ng-deep .iui-date-input__field{background:var(--iui-date-picker-field-bg);cursor:pointer}:host:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input:hover ::ng-deep .iui-date-input__field{background:linear-gradient(var(--iui-date-picker-field-hover-bg),var(--iui-date-picker-field-hover-bg)),var(--iui-date-picker-field-bg)}:host.iui-date-picker_open:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input ::ng-deep .iui-date-input__field{border-color:var(--iui-date-picker-focus-border)}:host.iui-date-picker_invalid:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input ::ng-deep .iui-date-input__field{border-color:var(--iui-date-picker-error-border)}:host.iui-date-picker_disabled .iui-date-picker__field-wrap{pointer-events:none}.iui-date-picker__range-field{display:flex;align-items:center;gap:8px;height:44px;padding:12px 16px;background:var(--iui-date-picker-field-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:pointer}:host.iui-date-picker_type_ranged:hover .iui-date-picker__range-field:not(.iui-date-picker_open .iui-date-picker__range-field){background:linear-gradient(var(--iui-date-picker-field-hover-bg),var(--iui-date-picker-field-hover-bg)),var(--iui-date-picker-field-bg)}:host.iui-date-picker_open.iui-date-picker_type_ranged .iui-date-picker__range-field,:host.iui-date-picker_focused.iui-date-picker_type_ranged .iui-date-picker__range-field{border-color:var(--iui-date-picker-focus-border)}:host.iui-date-picker_invalid.iui-date-picker_type_ranged .iui-date-picker__range-field{border-color:var(--iui-date-picker-error-border)}.iui-date-picker__range-input{font:var(--iui-tp-body-01-font);background:transparent;border:none;outline:none;color:var(--iui-date-picker-value-color);flex:1;min-width:0;padding:0;cursor:pointer}.iui-date-picker__range-input::placeholder{color:var(--iui-date-picker-placeholder-color)}.iui-date-picker__range-input:disabled{color:var(--iui-date-picker-disabled-color);cursor:default}.iui-date-picker__range-divider{font:var(--iui-tp-body-01-font);color:var(--iui-date-picker-divider-color);flex-shrink:0;-webkit-user-select:none;user-select:none}.iui-date-picker__calendar-btn{background:transparent;border:none;padding:0;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:var(--iui-date-picker-value-color);outline:none}.iui-date-picker__calendar-btn:disabled{cursor:default;color:var(--iui-date-picker-disabled-color)}.iui-date-picker__helper-row{padding-top:8px}.iui-date-picker__helper{font:var(--iui-tp-label-01-font);color:var(--iui-date-picker-helper-color)}.iui-date-picker__error{font:var(--iui-tp-label-01-font);color:var(--iui-date-picker-error-color)}:host.iui-date-picker_disabled .iui-date-picker__helper{color:var(--iui-date-picker-disabled-color)}.iui-date-picker__skeleton-label{width:80px;height:8px;background:var(--iui-date-picker-skeleton-bg);border-radius:2px;margin-bottom:8px}.iui-date-picker__skeleton-field{width:100%;height:44px;background:var(--iui-date-picker-skeleton-bg);border-radius:var(--iui-border-radius-medium)}.iui-date-picker__skeleton-helper{width:120px;height:8px;background:var(--iui-date-picker-skeleton-bg);border-radius:2px;margin-top:8px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i4.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: i4.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "component", type: IuiDateInputComponent, selector: "iui-date-input", inputs: ["id", "size", "layerSet", "label", "placeholder", "name", "showLabel", "showHelper", "showExplainer", "skeleton", "required"], outputs: ["valueChange"] }, { kind: "component", type: IuiCalendarComponent, selector: "iui-calendar", inputs: ["type", "currentView", "displayMonth", "selectedDate", "selectedRange", "hoverDate", "minDate", "maxDate"], outputs: ["dateSelected", "viewChange", "displayMonthChange", "dateHover"] }, { kind: "component", type: CalendarIconComponent, selector: "iui-calendar-icon" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiDatePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-date-picker', standalone: true, imports: [
                        CommonModule,
                        FormsModule,
                        OverlayModule,
                        IuiDateInputComponent,
                        IuiCalendarComponent,
                        CalendarIconComponent,
                        DatePipe
                    ], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiDatePickerComponent),
                            multi: true
                        }
                    ], hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], host: {
                        class: 'iui-date-picker',
                        '[class.iui-date-picker_type_ranged]': 'type === "ranged"',
                        '[class.iui-date-picker_layer-set-02]': 'layerSet === "set-02"',
                        '[class.iui-date-picker_open]': '_panelOpen',
                        '[class.iui-date-picker_focused]': '_focused',
                        '[class.iui-date-picker_hovered]': '_hovered',
                        '[class.iui-date-picker_selected]': '!_empty',
                        '[class.iui-date-picker_disabled]': 'disabled',
                        '[class.iui-date-picker_invalid]': '_errorState',
                        '[class.iui-date-picker_skeleton]': 'skeleton',
                        '[class.iui-date-picker_required]': 'required',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "@if (skeleton) {\r\n\t<div class=\"iui-date-picker__skeleton-label\" *ngIf=\"showLabel\"></div>\r\n\t<div class=\"iui-date-picker__skeleton-field\"></div>\r\n\t<div class=\"iui-date-picker__skeleton-helper\" *ngIf=\"showHelper\"></div>\r\n} @else {\r\n\t<!-- Label row (optional) -->\r\n\t@if (showLabel && label) {\r\n\t\t<div class=\"iui-date-picker__label-row\">\r\n\t\t\t<label class=\"iui-date-picker__label\">\r\n\t\t\t\t{{ label }}<span class=\"iui-date-picker__required\" *ngIf=\"required\">*</span>\r\n\t\t\t</label>\r\n\t\t</div>\r\n\t}\r\n\r\n\t<!-- Trigger field wrapper (overlay origin) -->\r\n\t<div\r\n\t\tclass=\"iui-date-picker__field-wrap\"\r\n\t\tcdk-overlay-origin\r\n\t\t#overlayOrigin=\"cdkOverlayOrigin\"\r\n\t\t(click)=\"open()\"\r\n\t\t(mouseenter)=\"_onMouseEnter()\"\r\n\t\t(mouseleave)=\"_onMouseLeave()\"\r\n\t\t(keydown)=\"_handleKeydown($event)\"\r\n\t>\r\n\t\t@if (type === 'single') {\r\n\t\t\t<!-- Single mode: use iui-date-input with calendar icon suffix -->\r\n\t\t\t<iui-date-input\r\n\t\t\t\tclass=\"iui-date-picker__date-input\"\r\n\t\t\t\t[showLabel]=\"false\"\r\n\t\t\t\t[showHelper]=\"false\"\r\n\t\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t\t[isDisabled]=\"disabled\"\r\n\t\t\t\t[ngModel]=\"_displayValue\"\r\n\t\t\t\t(ngModelChange)=\"_onTextInput($event)\"\r\n\t\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t>\r\n\t\t\t\t<button\r\n\t\t\t\t\tiuiSuffix\r\n\t\t\t\t\tclass=\"iui-date-picker__calendar-btn\"\r\n\t\t\t\t\ttype=\"button\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\taria-label=\"Open calendar\"\r\n\t\t\t\t\t(click)=\"toggle(); $event.stopPropagation()\"\r\n\t\t\t\t>\r\n\t\t\t\t\t<iui-calendar-icon></iui-calendar-icon>\r\n\t\t\t\t</button>\r\n\t\t\t</iui-date-input>\r\n\t\t}\r\n\r\n\t\t@if (type === 'ranged') {\r\n\t\t\t<!-- Ranged mode: custom dual-input field -->\r\n\t\t\t<div class=\"iui-date-picker__range-field\">\r\n\t\t\t\t<input\r\n\t\t\t\t\tclass=\"iui-date-picker__range-input\"\r\n\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\t[value]=\"_displayStartValue\"\r\n\t\t\t\t\taria-label=\"Start date\"\r\n\t\t\t\t\t(input)=\"_onStartTextInput($event)\"\r\n\t\t\t\t\t(focus)=\"_onStartFocus()\"\r\n\t\t\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t\t\t(click)=\"open()\"\r\n\t\t\t\t/>\r\n\t\t\t\t<span class=\"iui-date-picker__range-divider\" aria-hidden=\"true\">\u2192</span>\r\n\t\t\t\t<input\r\n\t\t\t\t\tclass=\"iui-date-picker__range-input\"\r\n\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t[placeholder]=\"placeholderEnd\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\t[value]=\"_displayEndValue\"\r\n\t\t\t\t\taria-label=\"End date\"\r\n\t\t\t\t\t(input)=\"_onEndTextInput($event)\"\r\n\t\t\t\t\t(focus)=\"_onEndFocus()\"\r\n\t\t\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t\t\t(click)=\"open()\"\r\n\t\t\t\t/>\r\n\t\t\t\t<button\r\n\t\t\t\t\tclass=\"iui-date-picker__calendar-btn\"\r\n\t\t\t\t\ttype=\"button\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\taria-label=\"Open calendar\"\r\n\t\t\t\t\t(click)=\"toggle(); $event.stopPropagation()\"\r\n\t\t\t\t>\r\n\t\t\t\t\t<iui-calendar-icon></iui-calendar-icon>\r\n\t\t\t\t</button>\r\n\t\t\t</div>\r\n\t\t}\r\n\t</div>\r\n\r\n\t<!-- CDK overlay for calendar panel -->\r\n\t<ng-template\r\n\t\tcdk-connected-overlay\r\n\t\tcdkConnectedOverlayHasBackdrop\r\n\t\tcdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\r\n\t\t[cdkConnectedOverlayOrigin]=\"overlayOrigin\"\r\n\t\t[cdkConnectedOverlayOpen]=\"_panelOpen\"\r\n\t\t[cdkConnectedOverlayPositions]=\"_positions\"\r\n\t\t[cdkConnectedOverlayScrollStrategy]=\"_scrollStrategy\"\r\n\t\t[cdkConnectedOverlayWidth]=\"324\"\r\n\t\t(backdropClick)=\"close()\"\r\n\t\t(detach)=\"close()\"\r\n\t>\r\n\t\t<iui-calendar\r\n\t\t\t[type]=\"type\"\r\n\t\t\t[currentView]=\"_calendarView\"\r\n\t\t\t[displayMonth]=\"_displayMonth\"\r\n\t\t\t[selectedDate]=\"type === 'single' ? _singleValue : null\"\r\n\t\t\t[selectedRange]=\"type === 'ranged' ? _rangeValue : null\"\r\n\t\t\t[hoverDate]=\"_hoverDate\"\r\n\t\t\t[minDate]=\"minDate\"\r\n\t\t\t[maxDate]=\"maxDate\"\r\n\t\t\t(dateSelected)=\"_onDateSelected($event)\"\r\n\t\t\t(viewChange)=\"_onViewChange($event)\"\r\n\t\t\t(displayMonthChange)=\"_onDisplayMonthChange($event)\"\r\n\t\t\t(dateHover)=\"_onDateHover($event)\"\r\n\t\t></iui-calendar>\r\n\t</ng-template>\r\n\r\n\t<!-- Helper / Error row (optional) -->\r\n\t@if (showHelper) {\r\n\t\t<div class=\"iui-date-picker__helper-row\">\r\n\t\t\t@if (_errorState) {\r\n\t\t\t\t<span class=\"iui-date-picker__error\">\r\n\t\t\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t\t\t</span>\r\n\t\t\t} @else {\r\n\t\t\t\t<span class=\"iui-date-picker__helper\">\r\n\t\t\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t\t\t</span>\r\n\t\t\t}\r\n\t\t</div>\r\n\t}\r\n}\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{--iui-date-picker-field-bg: var(--iui-background-subtle-01);--iui-date-picker-field-bg-02: var(--iui-background-subtle-02);--iui-date-picker-field-hover-bg: var(--iui-background-subtle-hover);--iui-date-picker-label-color: var(--iui-text-secondary);--iui-date-picker-value-color: var(--iui-text-primary);--iui-date-picker-placeholder-color: var(--iui-text-tertiary);--iui-date-picker-helper-color: var(--iui-text-secondary);--iui-date-picker-error-color: var(--iui-text-error);--iui-date-picker-disabled-color: var(--iui-text-disabled);--iui-date-picker-focus-border: var(--iui-border-focus);--iui-date-picker-error-border: var(--iui-border-error);--iui-date-picker-divider-color: var(--iui-text-tertiary);--iui-date-picker-required-color: var(--iui-text-error);--iui-date-picker-skeleton-bg: var(--iui-background-highlight-gray);display:flex;flex-direction:column;min-width:200px;max-width:100%}:host.iui-date-picker_layer-set-02{--iui-date-picker-field-bg: var(--iui-date-picker-field-bg-02)}.iui-date-picker__label-row{display:flex;align-items:flex-start;padding-bottom:8px}.iui-date-picker__label{font:var(--iui-tp-label-01-font);color:var(--iui-date-picker-label-color);flex:1;min-width:0}.iui-date-picker__required{color:var(--iui-date-picker-required-color);margin-left:4px}:host.iui-date-picker_disabled .iui-date-picker__label{color:var(--iui-date-picker-disabled-color)}.iui-date-picker__field-wrap{position:relative;width:100%}:host:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input{width:100%}:host:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input ::ng-deep .iui-date-input__field{background:var(--iui-date-picker-field-bg);cursor:pointer}:host:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input:hover ::ng-deep .iui-date-input__field{background:linear-gradient(var(--iui-date-picker-field-hover-bg),var(--iui-date-picker-field-hover-bg)),var(--iui-date-picker-field-bg)}:host.iui-date-picker_open:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input ::ng-deep .iui-date-input__field{border-color:var(--iui-date-picker-focus-border)}:host.iui-date-picker_invalid:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input ::ng-deep .iui-date-input__field{border-color:var(--iui-date-picker-error-border)}:host.iui-date-picker_disabled .iui-date-picker__field-wrap{pointer-events:none}.iui-date-picker__range-field{display:flex;align-items:center;gap:8px;height:44px;padding:12px 16px;background:var(--iui-date-picker-field-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:pointer}:host.iui-date-picker_type_ranged:hover .iui-date-picker__range-field:not(.iui-date-picker_open .iui-date-picker__range-field){background:linear-gradient(var(--iui-date-picker-field-hover-bg),var(--iui-date-picker-field-hover-bg)),var(--iui-date-picker-field-bg)}:host.iui-date-picker_open.iui-date-picker_type_ranged .iui-date-picker__range-field,:host.iui-date-picker_focused.iui-date-picker_type_ranged .iui-date-picker__range-field{border-color:var(--iui-date-picker-focus-border)}:host.iui-date-picker_invalid.iui-date-picker_type_ranged .iui-date-picker__range-field{border-color:var(--iui-date-picker-error-border)}.iui-date-picker__range-input{font:var(--iui-tp-body-01-font);background:transparent;border:none;outline:none;color:var(--iui-date-picker-value-color);flex:1;min-width:0;padding:0;cursor:pointer}.iui-date-picker__range-input::placeholder{color:var(--iui-date-picker-placeholder-color)}.iui-date-picker__range-input:disabled{color:var(--iui-date-picker-disabled-color);cursor:default}.iui-date-picker__range-divider{font:var(--iui-tp-body-01-font);color:var(--iui-date-picker-divider-color);flex-shrink:0;-webkit-user-select:none;user-select:none}.iui-date-picker__calendar-btn{background:transparent;border:none;padding:0;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:var(--iui-date-picker-value-color);outline:none}.iui-date-picker__calendar-btn:disabled{cursor:default;color:var(--iui-date-picker-disabled-color)}.iui-date-picker__helper-row{padding-top:8px}.iui-date-picker__helper{font:var(--iui-tp-label-01-font);color:var(--iui-date-picker-helper-color)}.iui-date-picker__error{font:var(--iui-tp-label-01-font);color:var(--iui-date-picker-error-color)}:host.iui-date-picker_disabled .iui-date-picker__helper{color:var(--iui-date-picker-disabled-color)}.iui-date-picker__skeleton-label{width:80px;height:8px;background:var(--iui-date-picker-skeleton-bg);border-radius:2px;margin-bottom:8px}.iui-date-picker__skeleton-field{width:100%;height:44px;background:var(--iui-date-picker-skeleton-bg);border-radius:var(--iui-border-radius-medium)}.iui-date-picker__skeleton-helper{width:120px;height:8px;background:var(--iui-date-picker-skeleton-bg);border-radius:2px;margin-top:8px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i0.ElementRef }, { type: i1$1.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i1$1.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i1$1.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { _overlayDir: [{
                type: ViewChild,
                args: [CdkConnectedOverlay]
            }], id: [{
                type: Input
            }], type: [{
                type: Input
            }], layerSet: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], placeholderEnd: [{
                type: Input
            }], dateFormat: [{
                type: Input
            }], name: [{
                type: Input
            }], showLabel: [{
                type: Input
            }], showHelper: [{
                type: Input
            }], showExplainer: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], minDate: [{
                type: Input
            }], maxDate: [{
                type: Input
            }], required: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], calendarOpen: [{
                type: Output
            }], calendarClose: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IUI_DATE_PICKER_SCROLL_STRATEGY, IuiCalendarComponent, IuiCalendarDayComponent, IuiDatePickerComponent };
//# sourceMappingURL=itero-ui-components-angular-date-picker.mjs.map
