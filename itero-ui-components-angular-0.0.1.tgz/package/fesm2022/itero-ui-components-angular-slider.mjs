import * as i0 from '@angular/core';
import { EventEmitter, forwardRef, Output, Input, Self, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i1 from '@itero/ui-components-angular/core';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import { InformationIconComponent, SubtractEmptyIconComponent } from '@itero/ui-components-angular/icons';
import { IuiTooltipDirective } from '@itero/ui-components-angular/tooltip';

let nextUniqueId = 0;
class IuiSliderComponent {
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    constructor(_cdr, _isDisabledDirective) {
        this._cdr = _cdr;
        this._isDisabledDirective = _isDisabledDirective;
        this._id = `iui-slider-${nextUniqueId++}`;
        this.label = '';
        this.explainerText = '';
        this.layerSet = 'set-01';
        this.ranged = false;
        this.editable = false;
        this.showValue = true;
        this.showTooltip = false;
        this.min = 0;
        this.max = 100;
        this.step = 1;
        this.stepMultiplier = 10;
        this.skeleton = false;
        // Single mode output
        this.valueChange = new EventEmitter();
        // Ranged mode outputs
        this.startValueChange = new EventEmitter();
        this.endValueChange = new EventEmitter();
        this._singleValue = 0;
        this._startValue = 0;
        this._endValue = 100;
        this._focused = false;
        this._activeThumb = null;
        this._onChange = () => { };
        this._onTouched = () => { };
    }
    get disabled() {
        return this._isDisabledDirective.isDisabled;
    }
    // ── Computed fill percentages ─────────────────────────────────────────────
    get _fillPct() {
        return this._clampPct((this._singleValue - this.min) / (this.max - this.min) * 100);
    }
    get _startFillPct() {
        return this._clampPct((this._startValue - this.min) / (this.max - this.min) * 100);
    }
    get _endFillPct() {
        return this._clampPct((this._endValue - this.min) / (this.max - this.min) * 100);
    }
    _clampPct(pct) {
        return Math.min(100, Math.max(0, pct));
    }
    // ── Event handlers ────────────────────────────────────────────────────────
    _onSingleInput(event) {
        this._singleValue = Number(event.target.value);
        this._onChange(this._singleValue);
        this.valueChange.emit(this._singleValue);
        this._cdr.markForCheck();
    }
    _onStartInput(event) {
        const raw = Number(event.target.value);
        this._startValue = Math.min(raw, this._endValue - this.step);
        this._onChange([this._startValue, this._endValue]);
        this.startValueChange.emit(this._startValue);
        this._cdr.markForCheck();
    }
    _onEndInput(event) {
        const raw = Number(event.target.value);
        this._endValue = Math.max(raw, this._startValue + this.step);
        this._onChange([this._startValue, this._endValue]);
        this.endValueChange.emit(this._endValue);
        this._cdr.markForCheck();
    }
    _onNumberInputChange(event) {
        const raw = Number(event.target.value);
        this._singleValue = Math.min(this.max, Math.max(this.min, raw));
        this._onChange(this._singleValue);
        this.valueChange.emit(this._singleValue);
        this._cdr.markForCheck();
    }
    _onStartNumberInputChange(event) {
        const raw = Number(event.target.value);
        this._startValue = Math.min(Math.max(raw, this.min), this._endValue - this.step);
        this._onChange([this._startValue, this._endValue]);
        this.startValueChange.emit(this._startValue);
        this._cdr.markForCheck();
    }
    _onEndNumberInputChange(event) {
        const raw = Number(event.target.value);
        this._endValue = Math.max(Math.min(raw, this.max), this._startValue + this.step);
        this._onChange([this._startValue, this._endValue]);
        this.endValueChange.emit(this._endValue);
        this._cdr.markForCheck();
    }
    _onFocus(thumb) {
        this._focused = true;
        this._activeThumb = thumb;
        this._cdr.markForCheck();
    }
    _onBlur() {
        this._focused = false;
        this._activeThumb = null;
        this._onTouched();
        this._cdr.markForCheck();
    }
    _onPointerDown(thumb) {
        this._activeThumb = thumb;
        this._cdr.markForCheck();
    }
    _onPointerUp() {
        this._activeThumb = null;
        this._cdr.markForCheck();
    }
    _onKeyDown(event, thumb) {
        if (!event.shiftKey) {
            return;
        }
        const isIncrease = event.key === 'ArrowRight' || event.key === 'ArrowUp';
        const isDecrease = event.key === 'ArrowLeft' || event.key === 'ArrowDown';
        if (!isIncrease && !isDecrease) {
            return;
        }
        event.preventDefault();
        const delta = (isIncrease ? 1 : -1) * this.step * this.stepMultiplier;
        if (thumb === 'single') {
            this._singleValue = Math.min(this.max, Math.max(this.min, this._singleValue + delta));
            this._onChange(this._singleValue);
            this.valueChange.emit(this._singleValue);
        }
        else if (thumb === 'start') {
            this._startValue = Math.min(this._endValue - this.step, Math.max(this.min, this._startValue + delta));
            this._onChange([this._startValue, this._endValue]);
            this.startValueChange.emit(this._startValue);
        }
        else {
            this._endValue = Math.max(this._startValue + this.step, Math.min(this.max, this._endValue + delta));
            this._onChange([this._startValue, this._endValue]);
            this.endValueChange.emit(this._endValue);
        }
        this._cdr.markForCheck();
    }
    // ── ControlValueAccessor ─────────────────────────────────────────────────
    writeValue(value) {
        if (this.ranged) {
            if (Array.isArray(value)) {
                this._startValue = value[0] ?? this.min;
                this._endValue = value[1] ?? this.max;
            }
            else {
                this._startValue = this.min;
                this._endValue = this.max;
            }
        }
        else {
            this._singleValue = typeof value === 'number' ? value : this.min;
        }
        this._cdr.markForCheck();
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this._isDisabledDirective.isDisabled = isDisabled;
        this._cdr.markForCheck();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiSliderComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiSliderComponent, isStandalone: true, selector: "iui-slider", inputs: { id: "id", label: "label", explainerText: "explainerText", layerSet: "layerSet", ranged: "ranged", editable: "editable", showValue: "showValue", showTooltip: "showTooltip", min: "min", max: "max", step: "step", stepMultiplier: "stepMultiplier", skeleton: "skeleton" }, outputs: { valueChange: "valueChange", startValueChange: "startValueChange", endValueChange: "endValueChange" }, host: { properties: { "class.iui-slider_layer-set-02": "layerSet === \"set-02\"", "class.iui-slider_ranged": "ranged", "class.iui-slider_editable": "editable", "class.iui-slider_disabled": "disabled", "class.iui-slider_skeleton": "skeleton", "class.iui-slider_focused": "_focused", "attr.id": "id", "attr.data-testid": "id" }, classAttribute: "iui-slider" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiSliderComponent),
                multi: true
            }
        ], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<!-- Skeleton branch -->\r\n<ng-container *ngIf=\"skeleton\">\r\n  <div class=\"iui-slider__skeleton-label\"></div>\r\n  <div class=\"iui-slider__skeleton-track\"></div>\r\n</ng-container>\r\n\r\n<!-- Normal branch -->\r\n<ng-container *ngIf=\"!skeleton\">\r\n\r\n  <!-- Label row -->\r\n  <div *ngIf=\"label\" class=\"iui-slider__label-row\">\r\n    <span class=\"iui-slider__label\">{{ label }}</span>\r\n    <span *ngIf=\"explainerText\"\r\n          class=\"iui-slider__explainer\"\r\n          [iuiTooltip]=\"explainerText\"\r\n          [iuiTooltipPlacement]=\"'top'\">\r\n      <iui-information-icon aria-hidden=\"true\"></iui-information-icon>\r\n    </span>\r\n  </div>\r\n\r\n  <!-- Editable inputs: single mode -->\r\n  <div *ngIf=\"editable && !ranged\" class=\"iui-slider__inputs\">\r\n    <input type=\"number\" class=\"iui-slider__number-input\"\r\n           [value]=\"_singleValue\"\r\n           [min]=\"min\" [max]=\"max\" [step]=\"step\"\r\n           [disabled]=\"disabled\"\r\n           (change)=\"_onNumberInputChange($event)\" />\r\n  </div>\r\n\r\n  <!-- Editable inputs: ranged mode -->\r\n  <div *ngIf=\"editable && ranged\" class=\"iui-slider__inputs iui-slider__inputs_ranged\">\r\n    <input type=\"number\" class=\"iui-slider__number-input\"\r\n           [value]=\"_startValue\"\r\n           [min]=\"min\" [max]=\"_endValue - step\" [step]=\"step\"\r\n           [disabled]=\"disabled\"\r\n           (change)=\"_onStartNumberInputChange($event)\" />\r\n    <iui-subtract-empty-icon class=\"iui-slider__inputs-separator\" aria-hidden=\"true\"></iui-subtract-empty-icon>\r\n    <input type=\"number\" class=\"iui-slider__number-input\"\r\n           [value]=\"_endValue\"\r\n           [min]=\"_startValue + step\" [max]=\"max\" [step]=\"step\"\r\n           [disabled]=\"disabled\"\r\n           (change)=\"_onEndNumberInputChange($event)\" />\r\n  </div>\r\n\r\n  <!-- Track area -->\r\n  <div class=\"iui-slider__track-wrapper\">\r\n\r\n    <!-- Custom track gradient: single mode -->\r\n    <div *ngIf=\"!ranged\"\r\n         class=\"iui-slider__track iui-slider__track_single\"\r\n         [style.--slider-pct]=\"_fillPct + '%'\">\r\n    </div>\r\n\r\n    <!-- Custom track gradient: ranged mode -->\r\n    <div *ngIf=\"ranged\"\r\n         class=\"iui-slider__track iui-slider__track_ranged\"\r\n         [style.--slider-start-pct]=\"_startFillPct + '%'\"\r\n         [style.--slider-end-pct]=\"_endFillPct + '%'\">\r\n    </div>\r\n\r\n    <!-- Single thumb input -->\r\n    <input *ngIf=\"!ranged\"\r\n           #singleInput\r\n           type=\"range\"\r\n           class=\"iui-slider__input\"\r\n           [min]=\"min\" [max]=\"max\" [step]=\"step\"\r\n           [value]=\"_singleValue\"\r\n           [disabled]=\"disabled\"\r\n           [attr.aria-label]=\"label || null\"\r\n           [attr.aria-valuenow]=\"_singleValue\"\r\n           [attr.aria-valuemin]=\"min\"\r\n           [attr.aria-valuemax]=\"max\"\r\n           (input)=\"_onSingleInput($event)\"\r\n           (keydown)=\"_onKeyDown($event, 'single')\"\r\n           (focus)=\"_onFocus('single')\"\r\n           (blur)=\"_onBlur()\"\r\n           (pointerdown)=\"_onPointerDown('single')\"\r\n           (pointerup)=\"_onPointerUp()\" />\r\n\r\n    <!-- Ranged: start thumb -->\r\n    <input *ngIf=\"ranged\"\r\n           #startInput\r\n           type=\"range\"\r\n           class=\"iui-slider__input iui-slider__input_start\"\r\n           [min]=\"min\" [max]=\"max\" [step]=\"step\"\r\n           [value]=\"_startValue\"\r\n           [disabled]=\"disabled\"\r\n           [attr.aria-label]=\"(label ? label + ' ' : '') + 'start'\"\r\n           [attr.aria-valuenow]=\"_startValue\"\r\n           [attr.aria-valuemin]=\"min\"\r\n           [attr.aria-valuemax]=\"max\"\r\n           (input)=\"_onStartInput($event)\"\r\n           (keydown)=\"_onKeyDown($event, 'start')\"\r\n           (focus)=\"_onFocus('start')\"\r\n           (blur)=\"_onBlur()\"\r\n           (pointerdown)=\"_onPointerDown('start')\"\r\n           (pointerup)=\"_onPointerUp()\" />\r\n\r\n    <!-- Ranged: end thumb -->\r\n    <input *ngIf=\"ranged\"\r\n           #endInput\r\n           type=\"range\"\r\n           class=\"iui-slider__input iui-slider__input_end\"\r\n           [min]=\"min\" [max]=\"max\" [step]=\"step\"\r\n           [value]=\"_endValue\"\r\n           [disabled]=\"disabled\"\r\n           [attr.aria-label]=\"(label ? label + ' ' : '') + 'end'\"\r\n           [attr.aria-valuenow]=\"_endValue\"\r\n           [attr.aria-valuemin]=\"min\"\r\n           [attr.aria-valuemax]=\"max\"\r\n           (input)=\"_onEndInput($event)\"\r\n           (keydown)=\"_onKeyDown($event, 'end')\"\r\n           (focus)=\"_onFocus('end')\"\r\n           (blur)=\"_onBlur()\"\r\n           (pointerdown)=\"_onPointerDown('end')\"\r\n           (pointerup)=\"_onPointerUp()\" />\r\n\r\n    <!-- Value tooltip \u2014 shown only when showTooltip=true; hidden via CSS when disabled/skeleton -->\r\n\r\n    <!-- Single mode tooltip -->\r\n    <div *ngIf=\"showTooltip && !ranged\"\r\n         class=\"iui-slider__tooltip\"\r\n         [class.iui-slider__tooltip_active]=\"_activeThumb === 'single'\"\r\n         [style.--tooltip-pct]=\"_fillPct + '%'\"\r\n         aria-hidden=\"true\">\r\n      <div class=\"iui-slider__tooltip-bubble\">{{ _singleValue }}</div>\r\n      <div class=\"iui-slider__tooltip-caret\"></div>\r\n    </div>\r\n\r\n    <!-- Ranged: start tooltip -->\r\n    <div *ngIf=\"showTooltip && ranged\"\r\n         class=\"iui-slider__tooltip\"\r\n         [class.iui-slider__tooltip_active]=\"_activeThumb === 'start'\"\r\n         [style.--tooltip-pct]=\"_startFillPct + '%'\"\r\n         aria-hidden=\"true\">\r\n      <div class=\"iui-slider__tooltip-bubble\">{{ _startValue }}</div>\r\n      <div class=\"iui-slider__tooltip-caret\"></div>\r\n    </div>\r\n\r\n    <!-- Ranged: end tooltip -->\r\n    <div *ngIf=\"showTooltip && ranged\"\r\n         class=\"iui-slider__tooltip\"\r\n         [class.iui-slider__tooltip_active]=\"_activeThumb === 'end'\"\r\n         [style.--tooltip-pct]=\"_endFillPct + '%'\"\r\n         aria-hidden=\"true\">\r\n      <div class=\"iui-slider__tooltip-bubble\">{{ _endValue }}</div>\r\n      <div class=\"iui-slider__tooltip-caret\"></div>\r\n    </div>\r\n\r\n  </div><!-- end track-wrapper -->\r\n\r\n  <!-- Value labels row -->\r\n  <div *ngIf=\"showValue\" class=\"iui-slider__values\">\r\n    <span class=\"iui-slider__value-start\">{{ min }}</span>\r\n    <span class=\"iui-slider__value-end\">{{ max }}</span>\r\n  </div>\r\n\r\n</ng-container>\r\n", styles: [":host{--iui-slider-track-active: var(--iui-border-interactive);--iui-slider-track-inactive: var(--iui-border-subtle);--iui-slider-track-disabled: var(--iui-border-disabled);--iui-slider-thumb-bg: var(--iui-background-layer-01);--iui-slider-thumb-border: var(--iui-border-interactive);--iui-slider-thumb-border-disabled: var(--iui-border-disabled);--iui-slider-thumb-focus-ring: var(--iui-border-focus);--iui-slider-thumb-shadow: var(--iui-box-shadow-s);--iui-slider-label-color: var(--iui-text-secondary);--iui-slider-label-disabled: var(--iui-text-disabled);--iui-slider-value-color: var(--iui-text-primary);--iui-slider-value-disabled: var(--iui-text-disabled);--iui-slider-input-bg: var(--iui-background-layer-01);--iui-slider-skeleton-bg: var(--iui-background-highlight-gray);--iui-slider-tooltip-bg: var(--iui-background-inverse);--iui-slider-tooltip-text: var(--iui-text-inverse-primary);display:flex;flex-direction:column;align-items:stretch;width:100%;position:relative}:host.iui-slider_layer-set-02{--iui-slider-input-bg: var(--iui-background-layer-02)}:host.iui-slider_disabled{--iui-slider-track-active: var(--iui-slider-track-disabled);--iui-slider-track-inactive: var(--iui-slider-track-disabled);--iui-slider-thumb-border: var(--iui-slider-thumb-border-disabled);--iui-slider-label-color: var(--iui-slider-label-disabled);--iui-slider-value-color: var(--iui-slider-value-disabled);pointer-events:none}:host.iui-slider_disabled .iui-slider__tooltip{display:none}:host.iui-slider_skeleton .iui-slider__tooltip{display:none}.iui-slider__label-row{display:flex;align-items:center;gap:4px;margin-bottom:8px}.iui-slider__label{font-size:12px;line-height:16px;font-weight:400;color:var(--iui-slider-label-color)}.iui-slider__explainer{display:flex;align-items:center;cursor:default;color:var(--iui-icon-secondary)}.iui-slider__explainer iui-information-icon{width:16px;height:16px}.iui-slider__inputs{width:100%;margin-bottom:8px}.iui-slider__inputs_ranged{display:flex;align-items:center;gap:8px}.iui-slider__inputs_ranged .iui-slider__number-input{flex:1;min-width:0}.iui-slider__number-input{display:block;width:100%;height:44px;padding:8px 8px 8px 16px;border-radius:8px;border:1px solid var(--iui-border-subtle);background:var(--iui-slider-input-bg);font-size:14px;line-height:20px;color:var(--iui-text-primary);box-sizing:border-box;outline:none;transition:border-color .15s}.iui-slider__number-input::-webkit-inner-spin-button,.iui-slider__number-input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.iui-slider__number-input[type=number]{-moz-appearance:textfield}.iui-slider__number-input:focus{border-color:var(--iui-border-interactive);box-shadow:0 0 0 2px var(--iui-border-focus)}.iui-slider__number-input:disabled{background:var(--iui-slider-input-bg);color:var(--iui-text-disabled);border-color:var(--iui-border-disabled);cursor:not-allowed}.iui-slider__inputs-separator{flex-shrink:0;width:16px;height:16px;color:var(--iui-icon-secondary)}.iui-slider__track-wrapper{position:relative;height:20px;display:flex;align-items:center}.iui-slider__track_single{position:absolute;left:0;right:0;height:4px;border-radius:4px;background:linear-gradient(to right,var(--iui-slider-track-active) 0%,var(--iui-slider-track-active) var(--slider-pct, 50%),var(--iui-slider-track-inactive) var(--slider-pct, 50%),var(--iui-slider-track-inactive) 100%);pointer-events:none}.iui-slider__track_ranged{position:absolute;left:0;right:0;height:4px;border-radius:4px;background:linear-gradient(to right,var(--iui-slider-track-inactive) 0%,var(--iui-slider-track-inactive) var(--slider-start-pct, 25%),var(--iui-slider-track-active) var(--slider-start-pct, 25%),var(--iui-slider-track-active) var(--slider-end-pct, 75%),var(--iui-slider-track-inactive) var(--slider-end-pct, 75%),var(--iui-slider-track-inactive) 100%);pointer-events:none}.iui-slider__input{-webkit-appearance:none;appearance:none;position:absolute;left:0;width:100%;height:20px;background:transparent;margin:0;cursor:pointer;pointer-events:none}.iui-slider__input::-webkit-slider-thumb{-webkit-appearance:none;pointer-events:all;width:20px;height:20px;border-radius:50%;background:var(--iui-slider-thumb-bg);border:1.5px solid var(--iui-slider-thumb-border);box-shadow:var(--iui-slider-thumb-shadow);cursor:grab;transition:box-shadow .15s;box-sizing:border-box}.iui-slider__input::-moz-range-thumb{pointer-events:all;width:20px;height:20px;border-radius:50%;background:var(--iui-slider-thumb-bg);border:1.5px solid var(--iui-slider-thumb-border);box-shadow:var(--iui-slider-thumb-shadow);cursor:grab;transition:box-shadow .15s;box-sizing:border-box}.iui-slider__input:focus-visible::-webkit-slider-thumb{outline:2px solid var(--iui-slider-thumb-focus-ring);outline-offset:2px}.iui-slider__input:focus-visible::-moz-range-thumb{outline:2px solid var(--iui-slider-thumb-focus-ring);outline-offset:2px}.iui-slider__input:active::-webkit-slider-thumb{cursor:grabbing;box-shadow:var(--iui-slider-thumb-shadow),0 0 0 4px #009ace33}.iui-slider__input:active::-moz-range-thumb{cursor:grabbing;box-shadow:var(--iui-slider-thumb-shadow),0 0 0 4px #009ace33}.iui-slider__input::-webkit-slider-runnable-track{background:transparent}.iui-slider__input::-moz-range-track{background:transparent}.iui-slider__input_start{z-index:3}.iui-slider__input_end{z-index:4}.iui-slider__tooltip{position:absolute;bottom:calc(100% + 4px);left:var(--tooltip-pct, 50%);transform:translate(-50%);display:flex;flex-direction:column;align-items:center;pointer-events:none;z-index:10;transition:transform .1s ease}.iui-slider__tooltip.iui-slider__tooltip_active{transform:translate(-50%) scale(1.05)}.iui-slider__tooltip-bubble{background:var(--iui-slider-tooltip-bg);color:var(--iui-slider-tooltip-text);font-size:14px;line-height:20px;padding:4px 8px;border-radius:8px;min-width:32px;text-align:center;white-space:nowrap;order:1}.iui-slider__tooltip-caret{width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-top:6px solid var(--iui-slider-tooltip-bg);order:2}.iui-slider__values{display:flex;justify-content:space-between;margin-top:4px;font-size:12px;line-height:16px;color:var(--iui-slider-value-color)}.iui-slider__skeleton-label{height:12px;width:80px;background:var(--iui-slider-skeleton-bg);border-radius:4px;margin-bottom:8px}.iui-slider__skeleton-track{height:4px;width:100%;background:var(--iui-slider-skeleton-bg);border-radius:4px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: InformationIconComponent, selector: "iui-information-icon" }, { kind: "component", type: SubtractEmptyIconComponent, selector: "iui-subtract-empty-icon" }, { kind: "directive", type: IuiTooltipDirective, selector: "[iuiTooltip]", inputs: ["iuiTooltip", "iuiTooltipPlacement", "iuiTooltipAlignment", "iuiTooltipShowCaret", "iuiTooltipDelay"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiSliderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-slider', standalone: true, imports: [
                        CommonModule,
                        InformationIconComponent,
                        SubtractEmptyIconComponent,
                        IuiTooltipDirective
                    ], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiSliderComponent),
                            multi: true
                        }
                    ], host: {
                        class: 'iui-slider',
                        '[class.iui-slider_layer-set-02]': 'layerSet === "set-02"',
                        '[class.iui-slider_ranged]': 'ranged',
                        '[class.iui-slider_editable]': 'editable',
                        '[class.iui-slider_disabled]': 'disabled',
                        '[class.iui-slider_skeleton]': 'skeleton',
                        '[class.iui-slider_focused]': '_focused',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<!-- Skeleton branch -->\r\n<ng-container *ngIf=\"skeleton\">\r\n  <div class=\"iui-slider__skeleton-label\"></div>\r\n  <div class=\"iui-slider__skeleton-track\"></div>\r\n</ng-container>\r\n\r\n<!-- Normal branch -->\r\n<ng-container *ngIf=\"!skeleton\">\r\n\r\n  <!-- Label row -->\r\n  <div *ngIf=\"label\" class=\"iui-slider__label-row\">\r\n    <span class=\"iui-slider__label\">{{ label }}</span>\r\n    <span *ngIf=\"explainerText\"\r\n          class=\"iui-slider__explainer\"\r\n          [iuiTooltip]=\"explainerText\"\r\n          [iuiTooltipPlacement]=\"'top'\">\r\n      <iui-information-icon aria-hidden=\"true\"></iui-information-icon>\r\n    </span>\r\n  </div>\r\n\r\n  <!-- Editable inputs: single mode -->\r\n  <div *ngIf=\"editable && !ranged\" class=\"iui-slider__inputs\">\r\n    <input type=\"number\" class=\"iui-slider__number-input\"\r\n           [value]=\"_singleValue\"\r\n           [min]=\"min\" [max]=\"max\" [step]=\"step\"\r\n           [disabled]=\"disabled\"\r\n           (change)=\"_onNumberInputChange($event)\" />\r\n  </div>\r\n\r\n  <!-- Editable inputs: ranged mode -->\r\n  <div *ngIf=\"editable && ranged\" class=\"iui-slider__inputs iui-slider__inputs_ranged\">\r\n    <input type=\"number\" class=\"iui-slider__number-input\"\r\n           [value]=\"_startValue\"\r\n           [min]=\"min\" [max]=\"_endValue - step\" [step]=\"step\"\r\n           [disabled]=\"disabled\"\r\n           (change)=\"_onStartNumberInputChange($event)\" />\r\n    <iui-subtract-empty-icon class=\"iui-slider__inputs-separator\" aria-hidden=\"true\"></iui-subtract-empty-icon>\r\n    <input type=\"number\" class=\"iui-slider__number-input\"\r\n           [value]=\"_endValue\"\r\n           [min]=\"_startValue + step\" [max]=\"max\" [step]=\"step\"\r\n           [disabled]=\"disabled\"\r\n           (change)=\"_onEndNumberInputChange($event)\" />\r\n  </div>\r\n\r\n  <!-- Track area -->\r\n  <div class=\"iui-slider__track-wrapper\">\r\n\r\n    <!-- Custom track gradient: single mode -->\r\n    <div *ngIf=\"!ranged\"\r\n         class=\"iui-slider__track iui-slider__track_single\"\r\n         [style.--slider-pct]=\"_fillPct + '%'\">\r\n    </div>\r\n\r\n    <!-- Custom track gradient: ranged mode -->\r\n    <div *ngIf=\"ranged\"\r\n         class=\"iui-slider__track iui-slider__track_ranged\"\r\n         [style.--slider-start-pct]=\"_startFillPct + '%'\"\r\n         [style.--slider-end-pct]=\"_endFillPct + '%'\">\r\n    </div>\r\n\r\n    <!-- Single thumb input -->\r\n    <input *ngIf=\"!ranged\"\r\n           #singleInput\r\n           type=\"range\"\r\n           class=\"iui-slider__input\"\r\n           [min]=\"min\" [max]=\"max\" [step]=\"step\"\r\n           [value]=\"_singleValue\"\r\n           [disabled]=\"disabled\"\r\n           [attr.aria-label]=\"label || null\"\r\n           [attr.aria-valuenow]=\"_singleValue\"\r\n           [attr.aria-valuemin]=\"min\"\r\n           [attr.aria-valuemax]=\"max\"\r\n           (input)=\"_onSingleInput($event)\"\r\n           (keydown)=\"_onKeyDown($event, 'single')\"\r\n           (focus)=\"_onFocus('single')\"\r\n           (blur)=\"_onBlur()\"\r\n           (pointerdown)=\"_onPointerDown('single')\"\r\n           (pointerup)=\"_onPointerUp()\" />\r\n\r\n    <!-- Ranged: start thumb -->\r\n    <input *ngIf=\"ranged\"\r\n           #startInput\r\n           type=\"range\"\r\n           class=\"iui-slider__input iui-slider__input_start\"\r\n           [min]=\"min\" [max]=\"max\" [step]=\"step\"\r\n           [value]=\"_startValue\"\r\n           [disabled]=\"disabled\"\r\n           [attr.aria-label]=\"(label ? label + ' ' : '') + 'start'\"\r\n           [attr.aria-valuenow]=\"_startValue\"\r\n           [attr.aria-valuemin]=\"min\"\r\n           [attr.aria-valuemax]=\"max\"\r\n           (input)=\"_onStartInput($event)\"\r\n           (keydown)=\"_onKeyDown($event, 'start')\"\r\n           (focus)=\"_onFocus('start')\"\r\n           (blur)=\"_onBlur()\"\r\n           (pointerdown)=\"_onPointerDown('start')\"\r\n           (pointerup)=\"_onPointerUp()\" />\r\n\r\n    <!-- Ranged: end thumb -->\r\n    <input *ngIf=\"ranged\"\r\n           #endInput\r\n           type=\"range\"\r\n           class=\"iui-slider__input iui-slider__input_end\"\r\n           [min]=\"min\" [max]=\"max\" [step]=\"step\"\r\n           [value]=\"_endValue\"\r\n           [disabled]=\"disabled\"\r\n           [attr.aria-label]=\"(label ? label + ' ' : '') + 'end'\"\r\n           [attr.aria-valuenow]=\"_endValue\"\r\n           [attr.aria-valuemin]=\"min\"\r\n           [attr.aria-valuemax]=\"max\"\r\n           (input)=\"_onEndInput($event)\"\r\n           (keydown)=\"_onKeyDown($event, 'end')\"\r\n           (focus)=\"_onFocus('end')\"\r\n           (blur)=\"_onBlur()\"\r\n           (pointerdown)=\"_onPointerDown('end')\"\r\n           (pointerup)=\"_onPointerUp()\" />\r\n\r\n    <!-- Value tooltip \u2014 shown only when showTooltip=true; hidden via CSS when disabled/skeleton -->\r\n\r\n    <!-- Single mode tooltip -->\r\n    <div *ngIf=\"showTooltip && !ranged\"\r\n         class=\"iui-slider__tooltip\"\r\n         [class.iui-slider__tooltip_active]=\"_activeThumb === 'single'\"\r\n         [style.--tooltip-pct]=\"_fillPct + '%'\"\r\n         aria-hidden=\"true\">\r\n      <div class=\"iui-slider__tooltip-bubble\">{{ _singleValue }}</div>\r\n      <div class=\"iui-slider__tooltip-caret\"></div>\r\n    </div>\r\n\r\n    <!-- Ranged: start tooltip -->\r\n    <div *ngIf=\"showTooltip && ranged\"\r\n         class=\"iui-slider__tooltip\"\r\n         [class.iui-slider__tooltip_active]=\"_activeThumb === 'start'\"\r\n         [style.--tooltip-pct]=\"_startFillPct + '%'\"\r\n         aria-hidden=\"true\">\r\n      <div class=\"iui-slider__tooltip-bubble\">{{ _startValue }}</div>\r\n      <div class=\"iui-slider__tooltip-caret\"></div>\r\n    </div>\r\n\r\n    <!-- Ranged: end tooltip -->\r\n    <div *ngIf=\"showTooltip && ranged\"\r\n         class=\"iui-slider__tooltip\"\r\n         [class.iui-slider__tooltip_active]=\"_activeThumb === 'end'\"\r\n         [style.--tooltip-pct]=\"_endFillPct + '%'\"\r\n         aria-hidden=\"true\">\r\n      <div class=\"iui-slider__tooltip-bubble\">{{ _endValue }}</div>\r\n      <div class=\"iui-slider__tooltip-caret\"></div>\r\n    </div>\r\n\r\n  </div><!-- end track-wrapper -->\r\n\r\n  <!-- Value labels row -->\r\n  <div *ngIf=\"showValue\" class=\"iui-slider__values\">\r\n    <span class=\"iui-slider__value-start\">{{ min }}</span>\r\n    <span class=\"iui-slider__value-end\">{{ max }}</span>\r\n  </div>\r\n\r\n</ng-container>\r\n", styles: [":host{--iui-slider-track-active: var(--iui-border-interactive);--iui-slider-track-inactive: var(--iui-border-subtle);--iui-slider-track-disabled: var(--iui-border-disabled);--iui-slider-thumb-bg: var(--iui-background-layer-01);--iui-slider-thumb-border: var(--iui-border-interactive);--iui-slider-thumb-border-disabled: var(--iui-border-disabled);--iui-slider-thumb-focus-ring: var(--iui-border-focus);--iui-slider-thumb-shadow: var(--iui-box-shadow-s);--iui-slider-label-color: var(--iui-text-secondary);--iui-slider-label-disabled: var(--iui-text-disabled);--iui-slider-value-color: var(--iui-text-primary);--iui-slider-value-disabled: var(--iui-text-disabled);--iui-slider-input-bg: var(--iui-background-layer-01);--iui-slider-skeleton-bg: var(--iui-background-highlight-gray);--iui-slider-tooltip-bg: var(--iui-background-inverse);--iui-slider-tooltip-text: var(--iui-text-inverse-primary);display:flex;flex-direction:column;align-items:stretch;width:100%;position:relative}:host.iui-slider_layer-set-02{--iui-slider-input-bg: var(--iui-background-layer-02)}:host.iui-slider_disabled{--iui-slider-track-active: var(--iui-slider-track-disabled);--iui-slider-track-inactive: var(--iui-slider-track-disabled);--iui-slider-thumb-border: var(--iui-slider-thumb-border-disabled);--iui-slider-label-color: var(--iui-slider-label-disabled);--iui-slider-value-color: var(--iui-slider-value-disabled);pointer-events:none}:host.iui-slider_disabled .iui-slider__tooltip{display:none}:host.iui-slider_skeleton .iui-slider__tooltip{display:none}.iui-slider__label-row{display:flex;align-items:center;gap:4px;margin-bottom:8px}.iui-slider__label{font-size:12px;line-height:16px;font-weight:400;color:var(--iui-slider-label-color)}.iui-slider__explainer{display:flex;align-items:center;cursor:default;color:var(--iui-icon-secondary)}.iui-slider__explainer iui-information-icon{width:16px;height:16px}.iui-slider__inputs{width:100%;margin-bottom:8px}.iui-slider__inputs_ranged{display:flex;align-items:center;gap:8px}.iui-slider__inputs_ranged .iui-slider__number-input{flex:1;min-width:0}.iui-slider__number-input{display:block;width:100%;height:44px;padding:8px 8px 8px 16px;border-radius:8px;border:1px solid var(--iui-border-subtle);background:var(--iui-slider-input-bg);font-size:14px;line-height:20px;color:var(--iui-text-primary);box-sizing:border-box;outline:none;transition:border-color .15s}.iui-slider__number-input::-webkit-inner-spin-button,.iui-slider__number-input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.iui-slider__number-input[type=number]{-moz-appearance:textfield}.iui-slider__number-input:focus{border-color:var(--iui-border-interactive);box-shadow:0 0 0 2px var(--iui-border-focus)}.iui-slider__number-input:disabled{background:var(--iui-slider-input-bg);color:var(--iui-text-disabled);border-color:var(--iui-border-disabled);cursor:not-allowed}.iui-slider__inputs-separator{flex-shrink:0;width:16px;height:16px;color:var(--iui-icon-secondary)}.iui-slider__track-wrapper{position:relative;height:20px;display:flex;align-items:center}.iui-slider__track_single{position:absolute;left:0;right:0;height:4px;border-radius:4px;background:linear-gradient(to right,var(--iui-slider-track-active) 0%,var(--iui-slider-track-active) var(--slider-pct, 50%),var(--iui-slider-track-inactive) var(--slider-pct, 50%),var(--iui-slider-track-inactive) 100%);pointer-events:none}.iui-slider__track_ranged{position:absolute;left:0;right:0;height:4px;border-radius:4px;background:linear-gradient(to right,var(--iui-slider-track-inactive) 0%,var(--iui-slider-track-inactive) var(--slider-start-pct, 25%),var(--iui-slider-track-active) var(--slider-start-pct, 25%),var(--iui-slider-track-active) var(--slider-end-pct, 75%),var(--iui-slider-track-inactive) var(--slider-end-pct, 75%),var(--iui-slider-track-inactive) 100%);pointer-events:none}.iui-slider__input{-webkit-appearance:none;appearance:none;position:absolute;left:0;width:100%;height:20px;background:transparent;margin:0;cursor:pointer;pointer-events:none}.iui-slider__input::-webkit-slider-thumb{-webkit-appearance:none;pointer-events:all;width:20px;height:20px;border-radius:50%;background:var(--iui-slider-thumb-bg);border:1.5px solid var(--iui-slider-thumb-border);box-shadow:var(--iui-slider-thumb-shadow);cursor:grab;transition:box-shadow .15s;box-sizing:border-box}.iui-slider__input::-moz-range-thumb{pointer-events:all;width:20px;height:20px;border-radius:50%;background:var(--iui-slider-thumb-bg);border:1.5px solid var(--iui-slider-thumb-border);box-shadow:var(--iui-slider-thumb-shadow);cursor:grab;transition:box-shadow .15s;box-sizing:border-box}.iui-slider__input:focus-visible::-webkit-slider-thumb{outline:2px solid var(--iui-slider-thumb-focus-ring);outline-offset:2px}.iui-slider__input:focus-visible::-moz-range-thumb{outline:2px solid var(--iui-slider-thumb-focus-ring);outline-offset:2px}.iui-slider__input:active::-webkit-slider-thumb{cursor:grabbing;box-shadow:var(--iui-slider-thumb-shadow),0 0 0 4px #009ace33}.iui-slider__input:active::-moz-range-thumb{cursor:grabbing;box-shadow:var(--iui-slider-thumb-shadow),0 0 0 4px #009ace33}.iui-slider__input::-webkit-slider-runnable-track{background:transparent}.iui-slider__input::-moz-range-track{background:transparent}.iui-slider__input_start{z-index:3}.iui-slider__input_end{z-index:4}.iui-slider__tooltip{position:absolute;bottom:calc(100% + 4px);left:var(--tooltip-pct, 50%);transform:translate(-50%);display:flex;flex-direction:column;align-items:center;pointer-events:none;z-index:10;transition:transform .1s ease}.iui-slider__tooltip.iui-slider__tooltip_active{transform:translate(-50%) scale(1.05)}.iui-slider__tooltip-bubble{background:var(--iui-slider-tooltip-bg);color:var(--iui-slider-tooltip-text);font-size:14px;line-height:20px;padding:4px 8px;border-radius:8px;min-width:32px;text-align:center;white-space:nowrap;order:1}.iui-slider__tooltip-caret{width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-top:6px solid var(--iui-slider-tooltip-bg);order:2}.iui-slider__values{display:flex;justify-content:space-between;margin-top:4px;font-size:12px;line-height:16px;color:var(--iui-slider-value-color)}.iui-slider__skeleton-label{height:12px;width:80px;background:var(--iui-slider-skeleton-bg);border-radius:4px;margin-bottom:8px}.iui-slider__skeleton-track{height:4px;width:100%;background:var(--iui-slider-skeleton-bg);border-radius:4px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { id: [{
                type: Input
            }], label: [{
                type: Input
            }], explainerText: [{
                type: Input
            }], layerSet: [{
                type: Input
            }], ranged: [{
                type: Input
            }], editable: [{
                type: Input
            }], showValue: [{
                type: Input
            }], showTooltip: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], step: [{
                type: Input
            }], stepMultiplier: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], startValueChange: [{
                type: Output
            }], endValueChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiSliderComponent };
//# sourceMappingURL=itero-ui-components-angular-slider.mjs.map
