import * as i0 from '@angular/core';
import { forwardRef, Input, ViewChild, Self, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import { Validators, NG_VALUE_ACCESSOR } from '@angular/forms';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i1 from '@itero/ui-components-angular/core';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import { SubtractEmptyIconComponent, AddEmptyIconComponent } from '@itero/ui-components-angular/icons';

let nextUniqueId = 0;
class IuiNumberInputComponent {
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    get required() {
        return this._required ?? this.ngControlDirective.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get _focused() {
        return this.__focused;
    }
    get _inputId() {
        return this.id + '-input';
    }
    get _isAtMin() {
        return this.__value != null && this.__value <= this.min;
    }
    get _isAtMax() {
        return this.__value != null && this.__value >= this.max;
    }
    get _ariaValueMin() {
        return isFinite(this.min) ? this.min : null;
    }
    get _ariaValueMax() {
        return isFinite(this.max) ? this.max : null;
    }
    get _displayValue() {
        if (this._rawInput != null) {
            return this._rawInput;
        }
        return this.__value != null ? String(this.__value) : '';
    }
    get _value() {
        return this.__value;
    }
    constructor(_changeDetectorRef, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._changeDetectorRef = _changeDetectorRef;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        this._id = `iui-number-input-${nextUniqueId++}`;
        this.label = '';
        this.helperText = '';
        this.name = '';
        this.size = 'l';
        this.layerSet = 'set-01';
        this.min = -Infinity;
        this.max = Infinity;
        this.step = 1;
        this.showControls = true;
        this.showLabel = true;
        this.showHelper = true;
        // showExplainer is deferred — no-op until tooltip integration is available
        this.showExplainer = false;
        this.skeleton = false;
        this.__value = null;
        this.__focused = false;
        this._rawInput = null;
        this._onChange = () => { };
        this._onTouched = () => { };
    }
    _increment() {
        const current = this.__value ?? 0;
        const newValue = Math.min(current + this.step, this.max);
        this._setValue(newValue);
    }
    _decrement() {
        const current = this.__value ?? 0;
        const newValue = Math.max(current - this.step, this.min);
        this._setValue(newValue);
    }
    _onKeydown(event) {
        if (event.key === 'ArrowUp') {
            event.preventDefault();
            this._increment();
        }
        else if (event.key === 'ArrowDown') {
            event.preventDefault();
            this._decrement();
        }
    }
    _onInputChange(event) {
        const raw = event.target.value;
        this._rawInput = raw;
        if (raw === '') {
            this._assignValue(null);
            return;
        }
        if (raw === '-') {
            return;
        }
        const parsed = Number(raw);
        if (!isNaN(parsed)) {
            this._setValue(this._clamp(parsed));
        }
    }
    _onFocus() {
        if (!this.disabled) {
            this.__focused = true;
            this._rawInput = this._displayValue;
        }
    }
    _onBlur() {
        this.__focused = false;
        this._rawInput = null;
        if (this.__value == null) {
            const resolved = isFinite(this.min) ? this.min : 0;
            this._setValue(resolved);
        }
        else {
            this._setValue(this._clamp(this.__value));
        }
        if (!this.disabled) {
            this._onTouched();
            this._changeDetectorRef.markForCheck();
        }
    }
    writeValue(value) {
        this._assignValue(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._changeDetectorRef.markForCheck();
    }
    _setValue(value) {
        const hasAssigned = this._assignValue(value);
        if (hasAssigned) {
            this._onChange(value);
        }
    }
    _assignValue(newValue) {
        if (newValue !== this.__value) {
            this.__value = newValue;
            this._changeDetectorRef.markForCheck();
            return true;
        }
        return false;
    }
    _clamp(value) {
        if (isFinite(this.min) && value < this.min) {
            return this.min;
        }
        if (isFinite(this.max) && value > this.max) {
            return this.max;
        }
        return value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiNumberInputComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.NgControlDirective, self: true }, { token: i1.IuiErrorStateMatcherDirective, self: true }, { token: i1.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiNumberInputComponent, isStandalone: true, selector: "iui-number-input", inputs: { id: "id", label: "label", helperText: "helperText", name: "name", size: "size", layerSet: "layerSet", min: "min", max: "max", step: "step", showControls: "showControls", showLabel: "showLabel", showHelper: "showHelper", showExplainer: "showExplainer", skeleton: "skeleton", required: "required" }, host: { properties: { "class.iui-number-input_size_l": "size === \"l\"", "class.iui-number-input_size_m": "size === \"m\"", "class.iui-number-input_size_s": "size === \"s\"", "class.iui-number-input_layer-set-02": "layerSet === \"set-02\"", "class.iui-number-input_focused": "_focused", "class.iui-number-input_disabled": "disabled", "class.iui-number-input_invalid": "_errorState", "class.iui-number-input_skeleton": "skeleton", "attr.id": "id" }, classAttribute: "iui-number-input" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiNumberInputComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true }], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\r\n\t<div class=\"iui-number-input__skeleton-label\" *ngIf=\"showLabel\"></div>\r\n\t<div class=\"iui-number-input__skeleton-field\"></div>\r\n\t<div class=\"iui-number-input__skeleton-helper\"></div>\r\n</ng-container>\r\n\r\n<ng-template #normalTemplate>\r\n\t<div class=\"iui-number-input__label-row\" *ngIf=\"showLabel && label\">\r\n\t\t<label class=\"iui-number-input__label\" [attr.for]=\"_inputId\">\r\n\t\t\t{{ label }}\r\n\t\t</label>\r\n\t</div>\r\n\r\n\t<div class=\"iui-number-input__field\">\r\n\t\t<input\r\n\t\t\t#inputElement\r\n\t\t\ttype=\"text\"\r\n\t\t\tinputmode=\"numeric\"\r\n\t\t\tclass=\"iui-number-input__input\"\r\n\t\t\trole=\"spinbutton\"\r\n\t\t\t[attr.id]=\"_inputId\"\r\n\t\t\t[attr.name]=\"name || null\"\r\n\t\t\t[attr.aria-label]=\"label || null\"\r\n\t\t\t[attr.aria-valuemin]=\"_ariaValueMin\"\r\n\t\t\t[attr.aria-valuemax]=\"_ariaValueMax\"\r\n\t\t\t[attr.aria-valuenow]=\"_value\"\r\n\t\t\t[disabled]=\"disabled\"\r\n\t\t\t[value]=\"_displayValue\"\r\n\t\t\t(input)=\"_onInputChange($event)\"\r\n\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t(keydown)=\"_onKeydown($event)\"\r\n\t\t/>\r\n\r\n\t\t<div class=\"iui-number-input__controls\" *ngIf=\"showControls\">\r\n\t\t\t<button\r\n\t\t\t\ttype=\"button\"\r\n\t\t\t\tclass=\"iui-number-input__control-btn\"\r\n\t\t\t\t[disabled]=\"disabled || _isAtMin\"\r\n\t\t\t\t(click)=\"_decrement()\"\r\n\t\t\t\ttabindex=\"-1\"\r\n\t\t\t\taria-label=\"Decrease value\"\r\n\t\t\t>\r\n\t\t\t\t<iui-subtract-empty-icon class=\"iui-icon iui-icon_size_s\"></iui-subtract-empty-icon>\r\n\t\t\t</button>\r\n\r\n\t\t\t<span class=\"iui-number-input__divider\" aria-hidden=\"true\"></span>\r\n\r\n\t\t\t<button\r\n\t\t\t\ttype=\"button\"\r\n\t\t\t\tclass=\"iui-number-input__control-btn\"\r\n\t\t\t\t[disabled]=\"disabled || _isAtMax\"\r\n\t\t\t\t(click)=\"_increment()\"\r\n\t\t\t\ttabindex=\"-1\"\r\n\t\t\t\taria-label=\"Increase value\"\r\n\t\t\t>\r\n\t\t\t\t<iui-add-empty-icon class=\"iui-icon iui-icon_size_s\"></iui-add-empty-icon>\r\n\t\t\t</button>\r\n\t\t</div>\r\n\t</div>\r\n\r\n\t<div class=\"iui-number-input__helper-row\" *ngIf=\"showHelper\">\r\n\t\t<span *ngIf=\"_errorState\" class=\"iui-number-input__error\">\r\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t</span>\r\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-number-input__helper\">\r\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t</span>\r\n\t</div>\r\n</ng-template>\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;width:100%}.iui-number-input__label-row{padding-bottom:var(--spacing-02, 8px)}.iui-number-input__label{font:var(--iui-tp-label-01-font);color:var(--iui-number-input-label-color);display:block}:host.iui-number-input_disabled .iui-number-input__label{color:var(--iui-number-input-disabled-color)}.iui-number-input__field{display:flex;align-items:center;gap:var(--spacing-02, 8px);overflow:hidden;background:var(--iui-number-input-bg);border:1px solid transparent;border-radius:var(--medium, 8px);transition:border-color .1s ease-out}:host.iui-number-input_size_l .iui-number-input__field{height:44px;padding:var(--spacing-02, 8px) var(--spacing-02, 8px) var(--spacing-02, 8px) var(--spacing-04, 16px)}:host.iui-number-input_size_m .iui-number-input__field{height:36px;padding:var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-03, 12px)}:host.iui-number-input_size_s .iui-number-input__field{height:28px;border-radius:var(--small, 4px);padding:var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-02, 8px)}:host.iui-number-input_layer-set-02 .iui-number-input__field{background:var(--iui-number-input-bg-layer-02)}:host.iui-number-input_focused .iui-number-input__field{border-color:var(--iui-number-input-focus-border)}:host.iui-number-input_invalid .iui-number-input__field{border-color:var(--iui-number-input-error-border)}.iui-number-input__input{flex:1 0 0;min-width:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border:none;outline:none;background:transparent;font:var(--iui-tp-body-01-font);color:var(--iui-number-input-color);padding:0}.iui-number-input__input:disabled{color:var(--iui-number-input-disabled-color)}.iui-number-input__controls{display:flex;align-items:center;gap:var(--spacing-01, 4px);flex-shrink:0}.iui-number-input__control-btn{display:flex;align-items:center;justify-content:center;padding:var(--spacing-01, 4px);background:transparent;border:none;border-radius:var(--small, 4px);cursor:pointer;color:var(--iui-number-input-color)}.iui-number-input__control-btn:hover:not(:disabled){background:var(--iui-background-interactive-hover)}.iui-number-input__control-btn:active:not(:disabled){background:var(--iui-background-interactive-active)}.iui-number-input__control-btn:focus-visible{outline:1px solid var(--iui-number-input-focus-border);outline-offset:-1px}.iui-number-input__control-btn:disabled{color:var(--iui-number-input-disabled-color);cursor:default}.iui-number-input__divider{display:block;width:1px;height:16px;background:var(--iui-number-input-divider-color);flex-shrink:0}.iui-number-input__helper-row{padding-top:var(--spacing-02, 8px)}.iui-number-input__helper{font:var(--iui-tp-label-01-font);color:var(--iui-number-input-helper-color)}:host.iui-number-input_disabled .iui-number-input__helper{color:var(--iui-number-input-disabled-color)}.iui-number-input__error{font:var(--iui-tp-label-01-font);color:var(--iui-number-input-error-color)}.iui-number-input__skeleton-label{width:40px;height:8px;background:var(--iui-number-input-skeleton-bg);border-radius:2px;margin-bottom:var(--spacing-02, 8px)}.iui-number-input__skeleton-field{width:100%;background:var(--iui-number-input-skeleton-bg)}:host.iui-number-input_size_l .iui-number-input__skeleton-field{height:44px;border-radius:var(--medium, 8px)}:host.iui-number-input_size_m .iui-number-input__skeleton-field{height:36px;border-radius:var(--medium, 8px)}:host.iui-number-input_size_s .iui-number-input__skeleton-field{height:28px;border-radius:var(--small, 4px)}:host:not(.iui-number-input_size_m):not(.iui-number-input_size_s) .iui-number-input__skeleton-field{height:44px;border-radius:var(--medium, 8px)}.iui-number-input__skeleton-helper{width:40px;height:8px;background:var(--iui-number-input-skeleton-bg);border-radius:2px;margin-top:var(--spacing-02, 8px)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SubtractEmptyIconComponent, selector: "iui-subtract-empty-icon" }, { kind: "component", type: AddEmptyIconComponent, selector: "iui-add-empty-icon" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiNumberInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-input', standalone: true, imports: [CommonModule, SubtractEmptyIconComponent, AddEmptyIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiNumberInputComponent),
                            multi: true
                        }
                    ], host: {
                        class: 'iui-number-input',
                        '[class.iui-number-input_size_l]': 'size === "l"',
                        '[class.iui-number-input_size_m]': 'size === "m"',
                        '[class.iui-number-input_size_s]': 'size === "s"',
                        '[class.iui-number-input_layer-set-02]': 'layerSet === "set-02"',
                        '[class.iui-number-input_focused]': '_focused',
                        '[class.iui-number-input_disabled]': 'disabled',
                        '[class.iui-number-input_invalid]': '_errorState',
                        '[class.iui-number-input_skeleton]': 'skeleton',
                        '[attr.id]': 'id'
                    }, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\r\n\t<div class=\"iui-number-input__skeleton-label\" *ngIf=\"showLabel\"></div>\r\n\t<div class=\"iui-number-input__skeleton-field\"></div>\r\n\t<div class=\"iui-number-input__skeleton-helper\"></div>\r\n</ng-container>\r\n\r\n<ng-template #normalTemplate>\r\n\t<div class=\"iui-number-input__label-row\" *ngIf=\"showLabel && label\">\r\n\t\t<label class=\"iui-number-input__label\" [attr.for]=\"_inputId\">\r\n\t\t\t{{ label }}\r\n\t\t</label>\r\n\t</div>\r\n\r\n\t<div class=\"iui-number-input__field\">\r\n\t\t<input\r\n\t\t\t#inputElement\r\n\t\t\ttype=\"text\"\r\n\t\t\tinputmode=\"numeric\"\r\n\t\t\tclass=\"iui-number-input__input\"\r\n\t\t\trole=\"spinbutton\"\r\n\t\t\t[attr.id]=\"_inputId\"\r\n\t\t\t[attr.name]=\"name || null\"\r\n\t\t\t[attr.aria-label]=\"label || null\"\r\n\t\t\t[attr.aria-valuemin]=\"_ariaValueMin\"\r\n\t\t\t[attr.aria-valuemax]=\"_ariaValueMax\"\r\n\t\t\t[attr.aria-valuenow]=\"_value\"\r\n\t\t\t[disabled]=\"disabled\"\r\n\t\t\t[value]=\"_displayValue\"\r\n\t\t\t(input)=\"_onInputChange($event)\"\r\n\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t(keydown)=\"_onKeydown($event)\"\r\n\t\t/>\r\n\r\n\t\t<div class=\"iui-number-input__controls\" *ngIf=\"showControls\">\r\n\t\t\t<button\r\n\t\t\t\ttype=\"button\"\r\n\t\t\t\tclass=\"iui-number-input__control-btn\"\r\n\t\t\t\t[disabled]=\"disabled || _isAtMin\"\r\n\t\t\t\t(click)=\"_decrement()\"\r\n\t\t\t\ttabindex=\"-1\"\r\n\t\t\t\taria-label=\"Decrease value\"\r\n\t\t\t>\r\n\t\t\t\t<iui-subtract-empty-icon class=\"iui-icon iui-icon_size_s\"></iui-subtract-empty-icon>\r\n\t\t\t</button>\r\n\r\n\t\t\t<span class=\"iui-number-input__divider\" aria-hidden=\"true\"></span>\r\n\r\n\t\t\t<button\r\n\t\t\t\ttype=\"button\"\r\n\t\t\t\tclass=\"iui-number-input__control-btn\"\r\n\t\t\t\t[disabled]=\"disabled || _isAtMax\"\r\n\t\t\t\t(click)=\"_increment()\"\r\n\t\t\t\ttabindex=\"-1\"\r\n\t\t\t\taria-label=\"Increase value\"\r\n\t\t\t>\r\n\t\t\t\t<iui-add-empty-icon class=\"iui-icon iui-icon_size_s\"></iui-add-empty-icon>\r\n\t\t\t</button>\r\n\t\t</div>\r\n\t</div>\r\n\r\n\t<div class=\"iui-number-input__helper-row\" *ngIf=\"showHelper\">\r\n\t\t<span *ngIf=\"_errorState\" class=\"iui-number-input__error\">\r\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t</span>\r\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-number-input__helper\">\r\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t</span>\r\n\t</div>\r\n</ng-template>\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;width:100%}.iui-number-input__label-row{padding-bottom:var(--spacing-02, 8px)}.iui-number-input__label{font:var(--iui-tp-label-01-font);color:var(--iui-number-input-label-color);display:block}:host.iui-number-input_disabled .iui-number-input__label{color:var(--iui-number-input-disabled-color)}.iui-number-input__field{display:flex;align-items:center;gap:var(--spacing-02, 8px);overflow:hidden;background:var(--iui-number-input-bg);border:1px solid transparent;border-radius:var(--medium, 8px);transition:border-color .1s ease-out}:host.iui-number-input_size_l .iui-number-input__field{height:44px;padding:var(--spacing-02, 8px) var(--spacing-02, 8px) var(--spacing-02, 8px) var(--spacing-04, 16px)}:host.iui-number-input_size_m .iui-number-input__field{height:36px;padding:var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-03, 12px)}:host.iui-number-input_size_s .iui-number-input__field{height:28px;border-radius:var(--small, 4px);padding:var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-02, 8px)}:host.iui-number-input_layer-set-02 .iui-number-input__field{background:var(--iui-number-input-bg-layer-02)}:host.iui-number-input_focused .iui-number-input__field{border-color:var(--iui-number-input-focus-border)}:host.iui-number-input_invalid .iui-number-input__field{border-color:var(--iui-number-input-error-border)}.iui-number-input__input{flex:1 0 0;min-width:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border:none;outline:none;background:transparent;font:var(--iui-tp-body-01-font);color:var(--iui-number-input-color);padding:0}.iui-number-input__input:disabled{color:var(--iui-number-input-disabled-color)}.iui-number-input__controls{display:flex;align-items:center;gap:var(--spacing-01, 4px);flex-shrink:0}.iui-number-input__control-btn{display:flex;align-items:center;justify-content:center;padding:var(--spacing-01, 4px);background:transparent;border:none;border-radius:var(--small, 4px);cursor:pointer;color:var(--iui-number-input-color)}.iui-number-input__control-btn:hover:not(:disabled){background:var(--iui-background-interactive-hover)}.iui-number-input__control-btn:active:not(:disabled){background:var(--iui-background-interactive-active)}.iui-number-input__control-btn:focus-visible{outline:1px solid var(--iui-number-input-focus-border);outline-offset:-1px}.iui-number-input__control-btn:disabled{color:var(--iui-number-input-disabled-color);cursor:default}.iui-number-input__divider{display:block;width:1px;height:16px;background:var(--iui-number-input-divider-color);flex-shrink:0}.iui-number-input__helper-row{padding-top:var(--spacing-02, 8px)}.iui-number-input__helper{font:var(--iui-tp-label-01-font);color:var(--iui-number-input-helper-color)}:host.iui-number-input_disabled .iui-number-input__helper{color:var(--iui-number-input-disabled-color)}.iui-number-input__error{font:var(--iui-tp-label-01-font);color:var(--iui-number-input-error-color)}.iui-number-input__skeleton-label{width:40px;height:8px;background:var(--iui-number-input-skeleton-bg);border-radius:2px;margin-bottom:var(--spacing-02, 8px)}.iui-number-input__skeleton-field{width:100%;background:var(--iui-number-input-skeleton-bg)}:host.iui-number-input_size_l .iui-number-input__skeleton-field{height:44px;border-radius:var(--medium, 8px)}:host.iui-number-input_size_m .iui-number-input__skeleton-field{height:36px;border-radius:var(--medium, 8px)}:host.iui-number-input_size_s .iui-number-input__skeleton-field{height:28px;border-radius:var(--small, 4px)}:host:not(.iui-number-input_size_m):not(.iui-number-input_size_s) .iui-number-input__skeleton-field{height:44px;border-radius:var(--medium, 8px)}.iui-number-input__skeleton-helper{width:40px;height:8px;background:var(--iui-number-input-skeleton-bg);border-radius:2px;margin-top:var(--spacing-02, 8px)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { inputElement: [{
                type: ViewChild,
                args: ['inputElement']
            }], id: [{
                type: Input
            }], label: [{
                type: Input
            }], helperText: [{
                type: Input
            }], name: [{
                type: Input
            }], size: [{
                type: Input
            }], layerSet: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], step: [{
                type: Input
            }], showControls: [{
                type: Input
            }], showLabel: [{
                type: Input
            }], showHelper: [{
                type: Input
            }], showExplainer: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], required: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiNumberInputComponent };
//# sourceMappingURL=itero-ui-components-angular-number-input.mjs.map
