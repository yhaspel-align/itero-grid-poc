import * as i0 from '@angular/core';
import { Input, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

class IuiLinkComponent {
    constructor() {
        /** Color variant */
        this.type = 'primary';
        /** Link size */
        this.size = 'm';
        /** Disabled state */
        this.disabled = false;
        /** Adds external-link arrow icon after text */
        this.external = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiLinkComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiLinkComponent, isStandalone: true, selector: "a[iuiLink]", inputs: { type: "type", size: "size", disabled: "disabled", external: "external" }, host: { properties: { "class.iui-link": "true", "class.iui-link_type_primary": "type === \"primary\"", "class.iui-link_type_secondary": "type === \"secondary\"", "class.iui-link_type_inversed": "type === \"inversed\"", "class.iui-link_type_on-color": "type === \"on-color\"", "class.iui-link_size_m": "size === \"m\"", "class.iui-link_size_s": "size === \"s\"", "class.iui-link_disabled": "disabled", "class.iui-link_external": "external", "attr.aria-disabled": "disabled ? \"true\" : null", "attr.tabindex": "disabled ? -1 : null" } }, ngImport: i0, template: "<ng-content></ng-content>\n<svg *ngIf=\"external\"\n     class=\"iui-link__icon\"\n     xmlns=\"http://www.w3.org/2000/svg\"\n     viewBox=\"0 0 20 20\"\n     fill=\"none\"\n     focusable=\"false\"\n     aria-hidden=\"true\">\n  <path d=\"M5 3.75V5H13.4425L3.75 14.6925L4.8075 15.75L14.5 6.0575V14.5H15.75V3.75H5Z\" fill=\"currentColor\"/>\n</svg>\n", styles: [":host{display:inline-flex;align-items:center;text-decoration:none;cursor:pointer;padding:0}:host:not(.iui-link_disabled):focus-visible{outline-width:1px;outline-style:solid;outline-offset:2px;border-radius:4px}:host.iui-link_size_m{font:var(--iui-tp-link-02-font);text-decoration:underline;text-decoration:none;gap:var(--iui-spacing-02, 8px)}:host.iui-link_size_m .iui-link__icon{width:20px;height:20px}:host.iui-link_size_s{font:var(--iui-tp-link-01-font);text-decoration:underline;text-decoration:none;gap:var(--iui-spacing-01, 4px)}:host.iui-link_size_s .iui-link__icon{width:16px;height:16px}:host.iui-link_type_primary{color:var(--iui-link-primary-color)}:host.iui-link_type_primary:not(.iui-link_disabled):hover{color:var(--iui-link-primary-hover-color);text-decoration:underline;text-underline-offset:2px}:host.iui-link_type_primary:not(.iui-link_disabled):focus-visible{outline-color:var(--iui-link-primary-focus-border)}:host.iui-link_type_primary.iui-link_disabled{color:var(--iui-link-primary-disabled-color)}:host.iui-link_type_secondary{color:var(--iui-link-secondary-color)}:host.iui-link_type_secondary:not(.iui-link_disabled):hover{color:var(--iui-link-secondary-hover-color);text-decoration:underline;text-underline-offset:2px}:host.iui-link_type_secondary:not(.iui-link_disabled):focus-visible{outline-color:var(--iui-link-secondary-focus-border)}:host.iui-link_type_secondary.iui-link_disabled{color:var(--iui-link-secondary-disabled-color)}:host.iui-link_type_inversed{color:var(--iui-link-inversed-color)}:host.iui-link_type_inversed:not(.iui-link_disabled):hover{color:var(--iui-link-inversed-hover-color);text-decoration:underline;text-underline-offset:2px}:host.iui-link_type_inversed:not(.iui-link_disabled):focus-visible{outline-color:var(--iui-link-inversed-focus-border)}:host.iui-link_type_inversed.iui-link_disabled{color:var(--iui-link-inversed-disabled-color)}:host.iui-link_type_on-color{color:var(--iui-link-on-color-color)}:host.iui-link_type_on-color:not(.iui-link_disabled):hover{color:var(--iui-link-on-color-hover-color);text-decoration:underline;text-underline-offset:2px}:host.iui-link_type_on-color:not(.iui-link_disabled):focus-visible{outline-color:var(--iui-link-on-color-focus-border)}:host.iui-link_type_on-color.iui-link_disabled{color:var(--iui-link-on-color-disabled-color)}:host.iui-link_disabled{cursor:not-allowed;pointer-events:none;text-decoration:none}:host .iui-link__icon{flex-shrink:0;color:currentColor}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiLinkComponent, decorators: [{
            type: Component,
            args: [{ selector: 'a[iuiLink]', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        '[class.iui-link]': 'true',
                        '[class.iui-link_type_primary]': 'type === "primary"',
                        '[class.iui-link_type_secondary]': 'type === "secondary"',
                        '[class.iui-link_type_inversed]': 'type === "inversed"',
                        '[class.iui-link_type_on-color]': 'type === "on-color"',
                        '[class.iui-link_size_m]': 'size === "m"',
                        '[class.iui-link_size_s]': 'size === "s"',
                        '[class.iui-link_disabled]': 'disabled',
                        '[class.iui-link_external]': 'external',
                        '[attr.aria-disabled]': 'disabled ? "true" : null',
                        '[attr.tabindex]': 'disabled ? -1 : null',
                    }, template: "<ng-content></ng-content>\n<svg *ngIf=\"external\"\n     class=\"iui-link__icon\"\n     xmlns=\"http://www.w3.org/2000/svg\"\n     viewBox=\"0 0 20 20\"\n     fill=\"none\"\n     focusable=\"false\"\n     aria-hidden=\"true\">\n  <path d=\"M5 3.75V5H13.4425L3.75 14.6925L4.8075 15.75L14.5 6.0575V14.5H15.75V3.75H5Z\" fill=\"currentColor\"/>\n</svg>\n", styles: [":host{display:inline-flex;align-items:center;text-decoration:none;cursor:pointer;padding:0}:host:not(.iui-link_disabled):focus-visible{outline-width:1px;outline-style:solid;outline-offset:2px;border-radius:4px}:host.iui-link_size_m{font:var(--iui-tp-link-02-font);text-decoration:underline;text-decoration:none;gap:var(--iui-spacing-02, 8px)}:host.iui-link_size_m .iui-link__icon{width:20px;height:20px}:host.iui-link_size_s{font:var(--iui-tp-link-01-font);text-decoration:underline;text-decoration:none;gap:var(--iui-spacing-01, 4px)}:host.iui-link_size_s .iui-link__icon{width:16px;height:16px}:host.iui-link_type_primary{color:var(--iui-link-primary-color)}:host.iui-link_type_primary:not(.iui-link_disabled):hover{color:var(--iui-link-primary-hover-color);text-decoration:underline;text-underline-offset:2px}:host.iui-link_type_primary:not(.iui-link_disabled):focus-visible{outline-color:var(--iui-link-primary-focus-border)}:host.iui-link_type_primary.iui-link_disabled{color:var(--iui-link-primary-disabled-color)}:host.iui-link_type_secondary{color:var(--iui-link-secondary-color)}:host.iui-link_type_secondary:not(.iui-link_disabled):hover{color:var(--iui-link-secondary-hover-color);text-decoration:underline;text-underline-offset:2px}:host.iui-link_type_secondary:not(.iui-link_disabled):focus-visible{outline-color:var(--iui-link-secondary-focus-border)}:host.iui-link_type_secondary.iui-link_disabled{color:var(--iui-link-secondary-disabled-color)}:host.iui-link_type_inversed{color:var(--iui-link-inversed-color)}:host.iui-link_type_inversed:not(.iui-link_disabled):hover{color:var(--iui-link-inversed-hover-color);text-decoration:underline;text-underline-offset:2px}:host.iui-link_type_inversed:not(.iui-link_disabled):focus-visible{outline-color:var(--iui-link-inversed-focus-border)}:host.iui-link_type_inversed.iui-link_disabled{color:var(--iui-link-inversed-disabled-color)}:host.iui-link_type_on-color{color:var(--iui-link-on-color-color)}:host.iui-link_type_on-color:not(.iui-link_disabled):hover{color:var(--iui-link-on-color-hover-color);text-decoration:underline;text-underline-offset:2px}:host.iui-link_type_on-color:not(.iui-link_disabled):focus-visible{outline-color:var(--iui-link-on-color-focus-border)}:host.iui-link_type_on-color.iui-link_disabled{color:var(--iui-link-on-color-disabled-color)}:host.iui-link_disabled{cursor:not-allowed;pointer-events:none;text-decoration:none}:host .iui-link__icon{flex-shrink:0;color:currentColor}\n"] }]
        }], propDecorators: { type: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], external: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiLinkComponent };
//# sourceMappingURL=itero-ui-components-angular-link.mjs.map
