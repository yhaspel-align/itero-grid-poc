import * as i0 from '@angular/core';
import { InjectionToken, inject, TemplateRef, forwardRef, Directive, ViewContainerRef, EventEmitter, Output, ContentChild, Input, Optional, Inject, SkipSelf, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import { Subject, distinctUntilChanged, startWith, filter, takeUntil } from 'rxjs';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i3 from '@angular/cdk/portal';
import { TemplatePortal, PortalModule } from '@angular/cdk/portal';
import * as i4 from '@angular/cdk/accordion';
import { CdkAccordionItem } from '@angular/cdk/accordion';
import * as i1 from '@angular/cdk/collections';
import { trigger, state, style, transition, animate } from '@angular/animations';

const ACCORDION_ANIMATION_TIMING = '225ms cubic-bezier(0.4,0.0,0.2,1)';
const iuiAccordionAnimations = {
    indicatorRotate: trigger('indicatorRotate', [
        state('collapsed, void', style({ transform: 'rotate(0deg)' })),
        state('expanded', style({ transform: 'rotate(180deg)' })),
        transition('expanded <=> collapsed, void => collapsed', animate(ACCORDION_ANIMATION_TIMING))
    ]),
    bodyExpansion: trigger('bodyExpansion', [
        state('collapsed, void', style({ height: '0px', visibility: 'hidden' })),
        state('expanded', style({ height: '*', visibility: 'visible' })),
        transition('expanded <=> collapsed, void => collapsed', animate(ACCORDION_ANIMATION_TIMING))
    ])
};

let nextId = 0;
const IUI_ACCORDION_CONTENT = new InjectionToken('iui_accordion_content');
const IUI_ACCORDION_ITEM = new InjectionToken('iui_accordion_item');
const IUI_ACCORDION = new InjectionToken('iui_accordion');
class IuiAccordionContentDirective {
    constructor() {
        this.templateRef = inject(TemplateRef);
        this._accordion = inject(IUI_ACCORDION_ITEM);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiAccordionContentDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: IuiAccordionContentDirective, isStandalone: true, selector: "[iuiAccordionContent]", providers: [
            {
                provide: IUI_ACCORDION_CONTENT,
                useExisting: forwardRef(() => IuiAccordionContentDirective)
            }
        ], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiAccordionContentDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[iuiAccordionContent]',
                    standalone: true,
                    providers: [
                        {
                            provide: IUI_ACCORDION_CONTENT,
                            useExisting: forwardRef(() => IuiAccordionContentDirective)
                        }
                    ]
                }]
        }] });
class IuiAccordionComponent extends CdkAccordionItem {
    set skeleton(value) {
        this._skeleton = coerceBooleanProperty(value);
    }
    get skeleton() {
        return this._skeleton;
    }
    set removeWhenCollapsed(value) {
        this._removeWhenCollapsed = coerceBooleanProperty(value);
    }
    get removeWhenCollapsed() {
        return this._removeWhenCollapsed;
    }
    constructor(accordion, _changeDetectorRef, _uniqueSelectionDispatcher) {
        super(accordion, _changeDetectorRef, _uniqueSelectionDispatcher);
        this.vcr = inject(ViewContainerRef);
        this.style = 'background-01';
        this.title = '';
        this._skeleton = false;
        this.id = `iui-accordion-${nextId++}`;
        this._removeWhenCollapsed = true;
        this._destroy = new Subject();
        this.afterExpand = new EventEmitter();
        this.afterCollapse = new EventEmitter();
        this._bodyAnimationDone = new Subject();
        this._bodyAnimationDone
            .pipe(distinctUntilChanged((x, y) => {
            return x.fromState === y.fromState && x.toState === y.toState;
        }))
            .subscribe(event => {
            if (event.fromState !== 'void') {
                if (event.toState === 'expanded') {
                    this.afterExpand.emit();
                }
                else if (event.toState === 'collapsed') {
                    this.afterCollapse.emit();
                }
            }
        });
    }
    _getExpandedState() {
        return this.expanded ? 'expanded' : 'collapsed';
    }
    _toggle() {
        if (!this.disabled && !this.skeleton) {
            this.toggle();
        }
    }
    ngAfterContentInit() {
        if (this._content && this._content._accordion === this) {
            this.opened
                .pipe(startWith(null), filter(() => this.expanded && !this._portal), takeUntil(this._destroy))
                .subscribe(() => {
                if (this._content?.templateRef === undefined) {
                    throw new Error('iui-accordion requires iuiAccordionContent directive to be used inside it');
                }
                this._portal = new TemplatePortal(this._content.templateRef, this.vcr);
            });
            this.afterCollapse.pipe(takeUntil(this._destroy)).subscribe(() => {
                if (this._removeWhenCollapsed && this._portal) {
                    this._portal.detach();
                    this._portal = undefined;
                }
            });
        }
    }
    ngOnDestroy() {
        super.ngOnDestroy();
        this._bodyAnimationDone.complete();
        this._destroy.next();
        this._destroy.complete();
        if (this._portal) {
            if (this._portal.isAttached) {
                this._portal.detach();
            }
            this._portal = undefined;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiAccordionComponent, deps: [{ token: IUI_ACCORDION, optional: true, skipSelf: true }, { token: i0.ChangeDetectorRef }, { token: i1.UniqueSelectionDispatcher }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiAccordionComponent, isStandalone: true, selector: "iui-accordion", inputs: { style: "style", title: "title", skeleton: "skeleton", id: "id", removeWhenCollapsed: "removeWhenCollapsed" }, outputs: { afterExpand: "afterExpand", afterCollapse: "afterCollapse" }, host: { properties: { "class.iui-accordion--background-01": "style === \"background-01\"", "class.iui-accordion--background-02": "style === \"background-02\"", "class.iui-accordion--border": "style === \"border\"", "class.iui-accordion--line": "style === \"line\"", "class.iui-accordion--expanded": "expanded", "class.iui-accordion--disabled": "disabled", "class.iui-accordion--skeleton": "skeleton" }, classAttribute: "iui-accordion" }, providers: [
            { provide: IUI_ACCORDION, useValue: undefined },
            {
                provide: IUI_ACCORDION_ITEM,
                useExisting: forwardRef(() => IuiAccordionComponent)
            }
        ], queries: [{ propertyName: "_content", first: true, predicate: IUI_ACCORDION_CONTENT, descendants: true }], usesInheritance: true, ngImport: i0, template: "<div class=\"iui-accordion__header\"\n\t (click)=\"_toggle()\"\n\t (keydown.enter)=\"_toggle()\"\n\t (keydown.space)=\"_toggle(); $event.preventDefault()\"\n\t [attr.tabindex]=\"disabled || skeleton ? -1 : 0\"\n\t role=\"button\"\n\t [attr.aria-expanded]=\"expanded\"\n\t [attr.aria-disabled]=\"disabled || skeleton\">\n\n\t<span class=\"iui-accordion__title\" *ngIf=\"!skeleton\">{{ title }}</span>\n\t<span class=\"iui-accordion__title-skeleton\" *ngIf=\"skeleton\"></span>\n\n\t<span class=\"iui-accordion__chevron-wrapper\">\n\t\t<span class=\"iui-accordion__chevron\"\n\t\t\t  [@indicatorRotate]=\"_getExpandedState()\">\n\t\t</span>\n\t</span>\n</div>\n\n<div class=\"iui-accordion__body\"\n\t [@bodyExpansion]=\"_getExpandedState()\"\n\t (@bodyExpansion.done)=\"_bodyAnimationDone.next($event)\">\n\n\t<div class=\"iui-accordion__content\" *ngIf=\"!skeleton\">\n\t\t<ng-template [cdkPortalOutlet]=\"_portal ?? ''\" />\n\t</div>\n\n\t<div class=\"iui-accordion__content-skeleton\" *ngIf=\"skeleton\">\n\t\t<div class=\"iui-accordion__skeleton-bar\"></div>\n\t\t<div class=\"iui-accordion__skeleton-bar\"></div>\n\t\t<div class=\"iui-accordion__skeleton-bar\"></div>\n\t\t<div class=\"iui-accordion__skeleton-bar\"></div>\n\t\t<div class=\"iui-accordion__skeleton-bar\"></div>\n\t\t<div class=\"iui-accordion__skeleton-bar iui-accordion__skeleton-bar--short\"></div>\n\t</div>\n</div>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:block;overflow:hidden}:host(.iui-accordion--background-01){background-color:var(--iui-accordion-bg-01);border-radius:var(--iui-accordion-radius)}:host(.iui-accordion--background-02){background-color:var(--iui-accordion-bg-02);border-radius:var(--iui-accordion-radius)}:host(.iui-accordion--border){border:1px solid var(--iui-accordion-border);border-radius:var(--iui-accordion-radius)}:host(.iui-accordion--line){border-bottom:1px solid var(--iui-accordion-border)}:host(.iui-accordion--disabled.iui-accordion--line),:host(.iui-accordion--skeleton.iui-accordion--line){border-bottom-color:var(--iui-accordion-border-disabled)}.iui-accordion__header:focus-visible{outline:none}:host(.iui-accordion--background-01):has(.iui-accordion__header:focus-visible),:host(.iui-accordion--background-02):has(.iui-accordion__header:focus-visible){outline:1px solid var(--iui-accordion-border-focus);outline-offset:-1px}:host(.iui-accordion--border):has(.iui-accordion__header:focus-visible){border-color:var(--iui-accordion-border-focus)}:host(.iui-accordion--line):has(.iui-accordion__header:focus-visible){border:1px solid var(--iui-accordion-border-focus);border-radius:0}.iui-accordion__header{display:flex;align-items:flex-start;gap:8px;cursor:pointer;width:100%}:host(.iui-accordion--line) .iui-accordion__header{padding:16px 0}:host(:not(.iui-accordion--line)) .iui-accordion__header{padding:16px}:host(.iui-accordion--disabled) .iui-accordion__header,:host(.iui-accordion--skeleton) .iui-accordion__header{cursor:default;pointer-events:none}.iui-accordion__title{flex:1 0 0;min-width:0;font:var(--iui-tp-heading-01-font);color:var(--iui-accordion-title-color)}:host.iui-accordion--disabled ::ng-deep .iui-accordion__title{color:var(--iui-accordion-title-disabled-color)}.iui-accordion__title-skeleton{width:72px;height:8px;background-color:var(--iui-accordion-skeleton-bg);flex-shrink:0}.iui-accordion__chevron-wrapper{display:flex;align-items:center;align-self:stretch;flex-shrink:0}.iui-accordion__chevron{width:20px;height:20px;display:flex;align-items:center;justify-content:center}.iui-accordion__chevron:before{content:\"\";display:block;border-left:2px solid var(--iui-accordion-chevron-color);border-bottom:2px solid var(--iui-accordion-chevron-color);width:8px;height:8px;transform:rotate(-45deg);margin-top:-3px}:host.iui-accordion--disabled ::ng-deep .iui-accordion__chevron:before{border-color:var(--iui-accordion-chevron-disabled-color)}:host.iui-accordion--skeleton ::ng-deep .iui-accordion__chevron:before{border-color:var(--iui-accordion-chevron-disabled-color)}.iui-accordion__body{display:flex;flex-direction:column;overflow:hidden}.iui-accordion__body[style*=\"visibility: hidden\"] *{visibility:hidden!important}.iui-accordion__content{display:flex;flex-direction:column;gap:16px;width:100%}:host(.iui-accordion--line) .iui-accordion__content{padding:0 0 16px}:host(:not(.iui-accordion--line)) .iui-accordion__content{padding:0 16px 16px}.iui-accordion__content-skeleton{display:flex;flex-direction:column;gap:8px;width:100%}:host(.iui-accordion--line) .iui-accordion__content-skeleton{padding:0 0 16px}:host(:not(.iui-accordion--line)) .iui-accordion__content-skeleton{padding:0 16px 16px}.iui-accordion__skeleton-bar{width:100%;height:8px;background-color:var(--iui-accordion-skeleton-bg)}.iui-accordion__skeleton-bar--short{width:96px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: PortalModule }, { kind: "directive", type: i3.CdkPortalOutlet, selector: "[cdkPortalOutlet]", inputs: ["cdkPortalOutlet"], outputs: ["attached"], exportAs: ["cdkPortalOutlet"] }], animations: [iuiAccordionAnimations.bodyExpansion, iuiAccordionAnimations.indicatorRotate], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiAccordionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-accordion', standalone: true, imports: [CommonModule, PortalModule], animations: [iuiAccordionAnimations.bodyExpansion, iuiAccordionAnimations.indicatorRotate], providers: [
                        { provide: IUI_ACCORDION, useValue: undefined },
                        {
                            provide: IUI_ACCORDION_ITEM,
                            useExisting: forwardRef(() => IuiAccordionComponent)
                        }
                    ], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'iui-accordion',
                        '[class.iui-accordion--background-01]': 'style === "background-01"',
                        '[class.iui-accordion--background-02]': 'style === "background-02"',
                        '[class.iui-accordion--border]': 'style === "border"',
                        '[class.iui-accordion--line]': 'style === "line"',
                        '[class.iui-accordion--expanded]': 'expanded',
                        '[class.iui-accordion--disabled]': 'disabled',
                        '[class.iui-accordion--skeleton]': 'skeleton'
                    }, template: "<div class=\"iui-accordion__header\"\n\t (click)=\"_toggle()\"\n\t (keydown.enter)=\"_toggle()\"\n\t (keydown.space)=\"_toggle(); $event.preventDefault()\"\n\t [attr.tabindex]=\"disabled || skeleton ? -1 : 0\"\n\t role=\"button\"\n\t [attr.aria-expanded]=\"expanded\"\n\t [attr.aria-disabled]=\"disabled || skeleton\">\n\n\t<span class=\"iui-accordion__title\" *ngIf=\"!skeleton\">{{ title }}</span>\n\t<span class=\"iui-accordion__title-skeleton\" *ngIf=\"skeleton\"></span>\n\n\t<span class=\"iui-accordion__chevron-wrapper\">\n\t\t<span class=\"iui-accordion__chevron\"\n\t\t\t  [@indicatorRotate]=\"_getExpandedState()\">\n\t\t</span>\n\t</span>\n</div>\n\n<div class=\"iui-accordion__body\"\n\t [@bodyExpansion]=\"_getExpandedState()\"\n\t (@bodyExpansion.done)=\"_bodyAnimationDone.next($event)\">\n\n\t<div class=\"iui-accordion__content\" *ngIf=\"!skeleton\">\n\t\t<ng-template [cdkPortalOutlet]=\"_portal ?? ''\" />\n\t</div>\n\n\t<div class=\"iui-accordion__content-skeleton\" *ngIf=\"skeleton\">\n\t\t<div class=\"iui-accordion__skeleton-bar\"></div>\n\t\t<div class=\"iui-accordion__skeleton-bar\"></div>\n\t\t<div class=\"iui-accordion__skeleton-bar\"></div>\n\t\t<div class=\"iui-accordion__skeleton-bar\"></div>\n\t\t<div class=\"iui-accordion__skeleton-bar\"></div>\n\t\t<div class=\"iui-accordion__skeleton-bar iui-accordion__skeleton-bar--short\"></div>\n\t</div>\n</div>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:block;overflow:hidden}:host(.iui-accordion--background-01){background-color:var(--iui-accordion-bg-01);border-radius:var(--iui-accordion-radius)}:host(.iui-accordion--background-02){background-color:var(--iui-accordion-bg-02);border-radius:var(--iui-accordion-radius)}:host(.iui-accordion--border){border:1px solid var(--iui-accordion-border);border-radius:var(--iui-accordion-radius)}:host(.iui-accordion--line){border-bottom:1px solid var(--iui-accordion-border)}:host(.iui-accordion--disabled.iui-accordion--line),:host(.iui-accordion--skeleton.iui-accordion--line){border-bottom-color:var(--iui-accordion-border-disabled)}.iui-accordion__header:focus-visible{outline:none}:host(.iui-accordion--background-01):has(.iui-accordion__header:focus-visible),:host(.iui-accordion--background-02):has(.iui-accordion__header:focus-visible){outline:1px solid var(--iui-accordion-border-focus);outline-offset:-1px}:host(.iui-accordion--border):has(.iui-accordion__header:focus-visible){border-color:var(--iui-accordion-border-focus)}:host(.iui-accordion--line):has(.iui-accordion__header:focus-visible){border:1px solid var(--iui-accordion-border-focus);border-radius:0}.iui-accordion__header{display:flex;align-items:flex-start;gap:8px;cursor:pointer;width:100%}:host(.iui-accordion--line) .iui-accordion__header{padding:16px 0}:host(:not(.iui-accordion--line)) .iui-accordion__header{padding:16px}:host(.iui-accordion--disabled) .iui-accordion__header,:host(.iui-accordion--skeleton) .iui-accordion__header{cursor:default;pointer-events:none}.iui-accordion__title{flex:1 0 0;min-width:0;font:var(--iui-tp-heading-01-font);color:var(--iui-accordion-title-color)}:host.iui-accordion--disabled ::ng-deep .iui-accordion__title{color:var(--iui-accordion-title-disabled-color)}.iui-accordion__title-skeleton{width:72px;height:8px;background-color:var(--iui-accordion-skeleton-bg);flex-shrink:0}.iui-accordion__chevron-wrapper{display:flex;align-items:center;align-self:stretch;flex-shrink:0}.iui-accordion__chevron{width:20px;height:20px;display:flex;align-items:center;justify-content:center}.iui-accordion__chevron:before{content:\"\";display:block;border-left:2px solid var(--iui-accordion-chevron-color);border-bottom:2px solid var(--iui-accordion-chevron-color);width:8px;height:8px;transform:rotate(-45deg);margin-top:-3px}:host.iui-accordion--disabled ::ng-deep .iui-accordion__chevron:before{border-color:var(--iui-accordion-chevron-disabled-color)}:host.iui-accordion--skeleton ::ng-deep .iui-accordion__chevron:before{border-color:var(--iui-accordion-chevron-disabled-color)}.iui-accordion__body{display:flex;flex-direction:column;overflow:hidden}.iui-accordion__body[style*=\"visibility: hidden\"] *{visibility:hidden!important}.iui-accordion__content{display:flex;flex-direction:column;gap:16px;width:100%}:host(.iui-accordion--line) .iui-accordion__content{padding:0 0 16px}:host(:not(.iui-accordion--line)) .iui-accordion__content{padding:0 16px 16px}.iui-accordion__content-skeleton{display:flex;flex-direction:column;gap:8px;width:100%}:host(.iui-accordion--line) .iui-accordion__content-skeleton{padding:0 0 16px}:host(:not(.iui-accordion--line)) .iui-accordion__content-skeleton{padding:0 16px 16px}.iui-accordion__skeleton-bar{width:100%;height:8px;background-color:var(--iui-accordion-skeleton-bg)}.iui-accordion__skeleton-bar--short{width:96px}\n"] }]
        }], ctorParameters: () => [{ type: i4.CdkAccordion, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [IUI_ACCORDION]
                }, {
                    type: SkipSelf
                }] }, { type: i0.ChangeDetectorRef }, { type: i1.UniqueSelectionDispatcher }], propDecorators: { style: [{
                type: Input
            }], title: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], id: [{
                type: Input
            }], removeWhenCollapsed: [{
                type: Input
            }], _content: [{
                type: ContentChild,
                args: [IUI_ACCORDION_CONTENT]
            }], afterExpand: [{
                type: Output
            }], afterCollapse: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ACCORDION_ANIMATION_TIMING, IUI_ACCORDION, IUI_ACCORDION_CONTENT, IUI_ACCORDION_ITEM, IuiAccordionComponent, IuiAccordionContentDirective, iuiAccordionAnimations };
//# sourceMappingURL=itero-ui-components-angular-accordion.mjs.map
