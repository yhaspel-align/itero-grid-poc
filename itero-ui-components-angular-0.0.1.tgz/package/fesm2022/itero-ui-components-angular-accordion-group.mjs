import * as i0 from '@angular/core';
import { Input, Component } from '@angular/core';
import { CdkAccordion } from '@angular/cdk/accordion';
import { IUI_ACCORDION } from '@itero/ui-components-angular/accordion';

class IuiAccordionGroupComponent extends CdkAccordion {
    constructor() {
        super(...arguments);
        this.style = 'background-01';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiAccordionGroupComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiAccordionGroupComponent, isStandalone: true, selector: "iui-accordion-group", inputs: { style: "style" }, host: { properties: { "class.iui-accordion-group--background-01": "style === \"background-01\"", "class.iui-accordion-group--background-02": "style === \"background-02\"", "class.iui-accordion-group--border": "style === \"border\"", "class.iui-accordion-group--line": "style === \"line\"" }, classAttribute: "iui-accordion-group" }, providers: [{ provide: IUI_ACCORDION, useExisting: IuiAccordionGroupComponent }], usesInheritance: true, ngImport: i0, template: "<ng-content></ng-content>\n", styles: [":host{display:flex;flex-direction:column;align-items:stretch}:host(.iui-accordion-group--background-01),:host(.iui-accordion-group--background-02),:host(.iui-accordion-group--border){gap:8px}:host(.iui-accordion-group--line){gap:0}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiAccordionGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-accordion-group', standalone: true, providers: [{ provide: IUI_ACCORDION, useExisting: IuiAccordionGroupComponent }], host: {
                        'class': 'iui-accordion-group',
                        '[class.iui-accordion-group--background-01]': 'style === "background-01"',
                        '[class.iui-accordion-group--background-02]': 'style === "background-02"',
                        '[class.iui-accordion-group--border]': 'style === "border"',
                        '[class.iui-accordion-group--line]': 'style === "line"'
                    }, template: "<ng-content></ng-content>\n", styles: [":host{display:flex;flex-direction:column;align-items:stretch}:host(.iui-accordion-group--background-01),:host(.iui-accordion-group--background-02),:host(.iui-accordion-group--border){gap:8px}:host(.iui-accordion-group--line){gap:0}\n"] }]
        }], propDecorators: { style: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiAccordionGroupComponent };
//# sourceMappingURL=itero-ui-components-angular-accordion-group.mjs.map
