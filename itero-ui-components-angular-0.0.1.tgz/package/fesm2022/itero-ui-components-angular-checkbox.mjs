import * as i0 from '@angular/core';
import { inject, EventEmitter, forwardRef, Output, Input, Component } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i1 from '@itero/ui-components-angular/core';
import { IuiIsDisabledDirective, NgControlDirective } from '@itero/ui-components-angular/core';
import { IuiCheckboxMarkComponent } from '@itero/ui-components-angular/checkbox-mark';

let nextUniqueId = 0;
class IuiCheckboxComponent {
    constructor() {
        /** The unique id of the element */
        this.id = `iui-checkbox-${nextUniqueId++}`;
        this.showValue = true;
        this.skeleton = false;
        /**
         * @prop
         * @ignore
         */
        this._touched = false;
        /**
         * @prop
         * @ignore
         */
        this._checked = false;
        /**
         * @prop
         * @ignore
         */
        this._indeterminate = false;
        /**
         * @prop
         * @ignore
         */
        this.isDisabledDirective = inject(IuiIsDisabledDirective, { self: true });
        this.changeEvent = new EventEmitter();
        this.indeterminateChanged = new EventEmitter();
        /**
         * @prop
         * @ignore
         */
        this.propagateChange = () => undefined;
        /**
         * @prop
         * @ignore
         */
        this.propagateTouched = () => undefined;
    }
    /**
     * @prop
     * @ignore
     */
    get _markId() {
        return this.id + '-mark';
    }
    /**
     * @prop
     * @ignore
     */
    get _labelId() {
        return this.id + '-label';
    }
    /**
     * input where you can pass desirable state of checkbox "true" or "false".
     * Can be helpful when you don't use formControl, otherwise you can patchValue of formControl
     * */
    set checked(value) {
        this._checked = value;
        this.indeterminate = false;
    }
    get checked() {
        return this._checked;
    }
    set indeterminate(value) {
        const updateCheckedState = (newIndeterminateState) => {
            if (newIndeterminateState) {
                this._checked = false;
            }
        };
        this.setIndeterminateInternal(value, updateCheckedState);
    }
    get indeterminate() {
        return this._indeterminate;
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled || this.skeleton;
    }
    /**
     * @method
     * @ignore
     */
    _blurHandler() {
        if (this.disabled) {
            return;
        }
        this.markAsTouched();
    }
    /**
     * @method
     * @ignore
     */
    setIndeterminateInternal(value, cb) {
        const changed = value !== this._indeterminate;
        this._indeterminate = value;
        if (changed) {
            if (cb) {
                cb(this._indeterminate);
            }
            this.indeterminateChanged.emit(this._indeterminate);
        }
    }
    /**
     * @method
     * @ignore
     */
    markAsTouched() {
        if (!this._touched) {
            this.propagateTouched();
            this._touched = true;
        }
    }
    /**
     * @method
     * @ignore
     */
    _changeHandler(event) {
        if (this.disabled) {
            return;
        }
        this._checked = !this.checked;
        this.setIndeterminateInternal(false);
        this.markAsTouched();
        this.propagateChange(this._checked);
        this.changeEvent.emit({
            event,
            checked: this._checked
        });
    }
    writeValue(val) {
        this._checked = val;
        this.setIndeterminateInternal(false);
    }
    registerOnChange(fn) {
        this.propagateChange = fn;
    }
    registerOnTouched(fn) {
        this.propagateTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiCheckboxComponent, isStandalone: true, selector: "iui-checkbox", inputs: { id: "id", showValue: "showValue", skeleton: "skeleton", checked: "checked", indeterminate: "indeterminate" }, outputs: { changeEvent: "changeEvent", indeterminateChanged: "indeterminateChanged" }, host: { properties: { "class.iui-checkbox_checked": "checked", "class.iui-checkbox_indeterminate": "indeterminate", "class.iui-checkbox_disabled": "disabled", "class.iui-checkbox_skeleton": "skeleton", "class.iui-checkbox_hide-value": "!showValue", "attr.id": "id", "attr.data-testid": "id" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiCheckboxComponent),
                multi: true
            }
        ], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<label class=\"iui-checkbox__container\"\n\t[attr.data-testid]=\"_labelId\"\n\t[attr.id]=\"_labelId\">\n\t<iui-checkbox-mark\n\t\tclass=\"iui-checkbox__trigger\"\n\t\t[id]=\"_markId\"\n\t\t[isDisabled]=\"disabled\"\n\t\t[skeleton]=\"skeleton\"\n\t\t(change)=\"_changeHandler($event)\"\n\t\t(blurEvent)=\"_blurHandler()\"\n\t\t[checked]=\"checked\"\n\t\t[indeterminate]=\"indeterminate\"\n\t></iui-checkbox-mark>\n\n\t<div class=\"iui-checkbox__label-text\" *ngIf=\"showValue && !skeleton\">\n\t\t<ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container>\n\t</div>\n\n\t<div class=\"iui-checkbox__skeleton-box\" *ngIf=\"skeleton\"></div>\n</label>\n\n<ng-template #contentTpl>\n\t<div>\n\t\t<ng-content></ng-content>\n\t</div>\n\t<div class=\"iui-checkbox__label-desc\">\n\t\t<ng-content select=\"[description]\"></ng-content>\n\t</div>\n</ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:block}.iui-checkbox__container{display:flex;align-items:flex-start;gap:8px;cursor:pointer;padding:0}:host(.iui-checkbox_disabled) .iui-checkbox__container{pointer-events:none;cursor:default}:host(.iui-checkbox_skeleton) .iui-checkbox__container{align-items:center;pointer-events:none;cursor:default}.iui-checkbox__trigger{flex-shrink:0;margin:0}.iui-checkbox__label-text{font:var(--iui-tp-body-01-font);color:var(--iui-checkbox-label-color)}:host(.iui-checkbox_disabled) .iui-checkbox__label-text{color:var(--iui-checkbox-label-disabled-color)}.iui-checkbox__label-desc{font:var(--iui-tp-label-01-font);color:var(--iui-checkbox-label-color)}:host(.iui-checkbox_disabled) .iui-checkbox__label-desc{color:var(--iui-checkbox-label-disabled-color)}.iui-checkbox__skeleton-box{width:40px;height:8px;background-color:var(--iui-checkbox-skeleton-bg);flex-shrink:0}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: IuiCheckboxMarkComponent, selector: "iui-checkbox-mark", inputs: ["id", "skeleton", "checked", "indeterminate"], outputs: ["blurEvent", "changeEvent", "indeterminateChanged"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-checkbox', standalone: true, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiCheckboxComponent),
                            multi: true
                        }
                    ], imports: [CommonModule, IuiCheckboxMarkComponent], hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiIsDisabledDirective,
                            // eslint-disable-next-line @angular-eslint/no-inputs-metadata-property
                            inputs: ['isDisabled'],
                            // eslint-disable-next-line @angular-eslint/no-outputs-metadata-property
                            outputs: ['disableChangeEvent']
                        }
                    ], host: {
                        '[class.iui-checkbox_checked]': 'checked',
                        '[class.iui-checkbox_indeterminate]': 'indeterminate',
                        '[class.iui-checkbox_disabled]': 'disabled',
                        '[class.iui-checkbox_skeleton]': 'skeleton',
                        '[class.iui-checkbox_hide-value]': '!showValue',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<label class=\"iui-checkbox__container\"\n\t[attr.data-testid]=\"_labelId\"\n\t[attr.id]=\"_labelId\">\n\t<iui-checkbox-mark\n\t\tclass=\"iui-checkbox__trigger\"\n\t\t[id]=\"_markId\"\n\t\t[isDisabled]=\"disabled\"\n\t\t[skeleton]=\"skeleton\"\n\t\t(change)=\"_changeHandler($event)\"\n\t\t(blurEvent)=\"_blurHandler()\"\n\t\t[checked]=\"checked\"\n\t\t[indeterminate]=\"indeterminate\"\n\t></iui-checkbox-mark>\n\n\t<div class=\"iui-checkbox__label-text\" *ngIf=\"showValue && !skeleton\">\n\t\t<ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container>\n\t</div>\n\n\t<div class=\"iui-checkbox__skeleton-box\" *ngIf=\"skeleton\"></div>\n</label>\n\n<ng-template #contentTpl>\n\t<div>\n\t\t<ng-content></ng-content>\n\t</div>\n\t<div class=\"iui-checkbox__label-desc\">\n\t\t<ng-content select=\"[description]\"></ng-content>\n\t</div>\n</ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:block}.iui-checkbox__container{display:flex;align-items:flex-start;gap:8px;cursor:pointer;padding:0}:host(.iui-checkbox_disabled) .iui-checkbox__container{pointer-events:none;cursor:default}:host(.iui-checkbox_skeleton) .iui-checkbox__container{align-items:center;pointer-events:none;cursor:default}.iui-checkbox__trigger{flex-shrink:0;margin:0}.iui-checkbox__label-text{font:var(--iui-tp-body-01-font);color:var(--iui-checkbox-label-color)}:host(.iui-checkbox_disabled) .iui-checkbox__label-text{color:var(--iui-checkbox-label-disabled-color)}.iui-checkbox__label-desc{font:var(--iui-tp-label-01-font);color:var(--iui-checkbox-label-color)}:host(.iui-checkbox_disabled) .iui-checkbox__label-desc{color:var(--iui-checkbox-label-disabled-color)}.iui-checkbox__skeleton-box{width:40px;height:8px;background-color:var(--iui-checkbox-skeleton-bg);flex-shrink:0}\n"] }]
        }], propDecorators: { id: [{
                type: Input
            }], showValue: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], checked: [{
                type: Input
            }], indeterminate: [{
                type: Input
            }], changeEvent: [{
                type: Output
            }], indeterminateChanged: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiCheckboxComponent };
//# sourceMappingURL=itero-ui-components-angular-checkbox.mjs.map
