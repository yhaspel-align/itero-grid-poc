import { NgControl, NgModel, FormControlDirective, FormControlName, ControlContainer, FormGroupDirective, NgForm } from '@angular/forms';
import * as i0 from '@angular/core';
import { inject, Injector, Directive, EventEmitter, Output, Input, Injectable, ChangeDetectorRef, Pipe } from '@angular/core';
import { coerceBooleanProperty } from '@angular/cdk/coercion';

class NgControlDirective {
    constructor() {
        this.injector = inject(Injector);
    }
    ngOnInit() {
        const ngControl = this.injector.get(NgControl, null, {
            optional: true,
            self: true
        });
        if (ngControl instanceof NgModel) {
            this.control = ngControl.control;
        }
        else if (ngControl instanceof FormControlDirective) {
            this.control = ngControl.control;
        }
        else if (ngControl instanceof FormControlName) {
            const container = this.injector.get(ControlContainer).control;
            if (ngControl.name == null || container == null) {
                return;
            }
            const name = ngControl.name;
            this.control = container.get(typeof name === 'number' ? [name] : name);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NgControlDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: NgControlDirective, isStandalone: true, selector: "[iuiNgControl]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NgControlDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[iuiNgControl]',
                    standalone: true
                }]
        }] });

class IuiIsDisabledDirective {
    constructor() {
        this._isDisabled = false;
        this.ngControlDirective = inject((NgControlDirective), {
            self: true,
            optional: true
        });
        this.disableChangeEvent = new EventEmitter();
    }
    /**
     * whether the control is disabled.
     * [part of IuiIsDisabledDirective]
     * By assigning this input to truthy value, it makes associated formControl disabled.
     * The name "isDisabled" differs to traditional naming "disabled" because it clashes with attribute "disabled" of the formControl
     * */
    set isDisabled(value) {
        value = coerceBooleanProperty(value);
        if (this._isDisabled !== value) {
            this._isDisabled = value;
            this.handleDisabled(this._isDisabled);
        }
    }
    get isDisabled() {
        return this._isDisabled;
    }
    get control() {
        return this.ngControlDirective?.control;
    }
    ngOnInit() {
        this.handleDisabled(this.isDisabled);
    }
    /*
     *
     * @docs-private: returns true, when value was changed, otherwise - false
     * */
    handleDisabled(value) {
        if (this.control && this.control.disabled === value) {
            return false;
        }
        if (value) {
            this.control?.disable?.({ emitEvent: false });
            this.disableChangeEvent.emit(true);
        }
        else {
            this.control?.enable?.({ emitEvent: false });
            this.disableChangeEvent.emit(false);
        }
        return true;
    }
    // part of CVA handle when user disable control programmatically
    setDisabledState(isDisabled) {
        if (isDisabled !== this._isDisabled) {
            this._isDisabled = isDisabled;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiIsDisabledDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: IuiIsDisabledDirective, isStandalone: true, selector: "[isDisabled]", inputs: { isDisabled: "isDisabled" }, outputs: { disableChangeEvent: "disableChangeEvent" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiIsDisabledDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[isDisabled]',
                    standalone: true
                }]
        }], propDecorators: { isDisabled: [{
                type: Input
            }], disableChangeEvent: [{
                type: Output
            }] } });

/** Error state matcher that matches when a control is invalid and dirty. */
class ShowOnDirtyErrorStateMatcher {
    isErrorState(control, form) {
        return !!(control && control.invalid && (control.dirty || (form && form.submitted)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShowOnDirtyErrorStateMatcher, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShowOnDirtyErrorStateMatcher }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShowOnDirtyErrorStateMatcher, decorators: [{
            type: Injectable
        }] });
class IuiInstantErrorStateMatcher {
    isErrorState(control, form) {
        return !!control && control.invalid;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiInstantErrorStateMatcher, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiInstantErrorStateMatcher }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiInstantErrorStateMatcher, decorators: [{
            type: Injectable
        }] });
/** Provider that defines how form controls behave with regards to displaying error messages. */
class IuiErrorStateMatcher {
    isErrorState(control, form) {
        return !!(control && control.invalid && (control.touched || (form && form.submitted)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiErrorStateMatcher, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiErrorStateMatcher, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiErrorStateMatcher, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
class IuiErrorStateMatcherDirective {
    constructor() {
        /** Whether the component is in an error state. */
        this.errorState = false;
        this.defaultErrorStateMatcher = inject(IuiErrorStateMatcher);
        this.cdr = inject(ChangeDetectorRef);
        this.injector = inject(Injector);
    }
    ngOnInit() {
        this._parentFormGroup = this.injector.get(FormGroupDirective, null, {
            optional: true
        });
        this._parentForm = this.injector.get(NgForm, null, { optional: true });
        this._ngControl = this.injector.get(NgControl, null, { optional: true });
    }
    /** returns true if errorState has changed */
    updateErrorState() {
        const oldState = this.errorState;
        const parent = this._parentFormGroup || this._parentForm;
        const matcher = this.errorStateMatcher ?? this.defaultErrorStateMatcher;
        const control = this._ngControl ? this._ngControl.control : null;
        const newState = matcher.isErrorState(control, parent ?? null);
        if (newState !== oldState) {
            this.errorState = newState;
            return true;
        }
        return false;
    }
    ngDoCheck() {
        if (this.updateErrorState()) {
            this.cdr.detectChanges();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiErrorStateMatcherDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: IuiErrorStateMatcherDirective, isStandalone: true, inputs: { errorStateMatcher: "errorStateMatcher" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiErrorStateMatcherDirective, decorators: [{
            type: Directive,
            args: [{ standalone: true }]
        }], propDecorators: { errorStateMatcher: [{
                type: Input
            }] } });

class MapperPipe {
    transform(value, callBack, ...args) {
        return callBack(value, ...args);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MapperPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.12", ngImport: i0, type: MapperPipe, isStandalone: true, name: "mapper" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MapperPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'mapper',
                    standalone: true
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiErrorStateMatcher, IuiErrorStateMatcherDirective, IuiInstantErrorStateMatcher, IuiIsDisabledDirective, MapperPipe, NgControlDirective, ShowOnDirtyErrorStateMatcher };
//# sourceMappingURL=itero-ui-components-angular-core.mjs.map
