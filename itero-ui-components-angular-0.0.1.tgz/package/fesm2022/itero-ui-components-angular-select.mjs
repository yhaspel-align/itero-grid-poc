import * as i0 from '@angular/core';
import { InjectionToken, inject, EventEmitter, isDevMode, forwardRef, Input, ViewChild, Output, ViewChildren, Self, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i1 from '@angular/cdk/overlay';
import { Overlay, OverlayModule, CdkConnectedOverlay } from '@angular/cdk/overlay';
import { Subject, takeUntil, take } from 'rxjs';
import { CdkListbox, CdkOption } from '@angular/cdk/listbox';
import { Validators, NG_VALUE_ACCESSOR } from '@angular/forms';
import { coerceBooleanProperty, coerceNumberProperty } from '@angular/cdk/coercion';
import { ENTER, SPACE } from '@angular/cdk/keycodes';
import { CaretDownIconComponent, CloseEmptyIconComponent } from '@itero/ui-components-angular/icons';
import * as i2 from '@itero/ui-components-angular/core';
import { MapperPipe, NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import { IuiButtonComponent } from '@itero/ui-components-angular/button';

const ALIGNED_LEFT_POSITIONS = [
    {
        originX: 'start', // left corner of the trigger
        originY: 'bottom', // bottom corner of the trigger
        overlayX: 'start', // left corner of the overlay to the origin
        overlayY: 'top' // top corner of the overlay to the origin,
    },
    {
        originX: 'start', // left corner of the trigger
        originY: 'top', // top corner of the trigger
        overlayX: 'start', // left corner of the overlay to the origin
        overlayY: 'bottom' // bottom corner of the overlay to the origin
    },
    {
        originX: 'start',
        originY: 'top', // top corner of the trigger
        overlayX: 'start',
        overlayY: 'top'
    },
    {
        originX: 'start',
        originY: 'bottom', // bottom corner of the trigger
        overlayX: 'start',
        overlayY: 'bottom'
    },
    {
        originX: 'start',
        originY: 'center', // center of the origin
        overlayX: 'start',
        overlayY: 'center' // center of the overlay
    }
];
const ALIGNED_RIGHT_POSITIONS = [
    {
        originX: 'end', // right corner of the trigger
        originY: 'bottom', // bottom corner of the trigger
        overlayX: 'end', // right corner of the overlay to the origin
        overlayY: 'top' // top corner of the overlay to the origin
    },
    {
        originX: 'end', // right corner of the button
        originY: 'top', // top corner of the button
        overlayX: 'end', // right corner of the overlay to the origin
        overlayY: 'bottom' // top corner of the overlay to the origin
    },
    {
        originX: 'end',
        originY: 'top',
        overlayX: 'end',
        overlayY: 'top'
    },
    {
        originX: 'end',
        originY: 'bottom',
        overlayX: 'end',
        overlayY: 'bottom'
    },
    {
        originX: 'end',
        originY: 'center', // center of the origin
        overlayX: 'end',
        overlayY: 'center' // center of the overlay
    }
];

let nextUniqueId = 0;
/** Injection token that determines the scroll handling while a select is open. */
const IUI_SELECT_SCROLL_STRATEGY = new InjectionToken('iui-select-scroll-strategy', {
    providedIn: 'root',
    factory: () => {
        const overlay = inject(Overlay);
        return () => overlay.scrollStrategies.reposition();
    }
});
function hasModifierKey(event, ...modifiers) {
    if (modifiers.length) {
        return modifiers.some(modifier => event[modifier]);
    }
    return event.altKey || event.shiftKey || event.ctrlKey || event.metaKey;
}
class IuiSelectComponent {
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    get _valueId() {
        return this.id + '-value';
    }
    get _labelId() {
        return this.id + '-label';
    }
    get _panelId() {
        return this.id + '-panel';
    }
    get _comboboxId() {
        return this.id + '-combobox';
    }
    get _cancelButtonId() {
        return this.id + '-cancel-selection';
    }
    get autoClose() {
        return this._autoClose;
    }
    set autoClose(value) {
        this._autoCloseExplicitlySet = true;
        this._autoClose = coerceBooleanProperty(value);
    }
    constructor(_elementRef, _changeDetectorRef, _viewportRuler, overlay, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._elementRef = _elementRef;
        this._changeDetectorRef = _changeDetectorRef;
        this._viewportRuler = _viewportRuler;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        this._overlayPanelClass = '';
        this.dropDownOpened = false;
        this._id = `iui-select-${nextUniqueId++}`;
        this.label = '';
        this.placeholder = '';
        this.panelWidth = 'auto';
        this.options = [];
        this.panelStyle = {};
        this.panelClass = '';
        this.hintText = '';
        this.requiredText = '';
        this.cancelSelectionText = '';
        this.flexibleDimensions = false;
        // ADS 1.0.0 inputs
        this.size = 'l';
        this.layerSet = 'set-01';
        this.selectType = 'single';
        this.skeleton = false;
        this._autoClose = true;
        this._autoCloseExplicitlySet = false;
        this._positions = ALIGNED_LEFT_POSITIONS;
        this.openEvent = new EventEmitter();
        this.closeEvent = new EventEmitter();
        this.selectionChange = new EventEmitter();
        this.cancelSelectionEvent = new EventEmitter();
        this._destroy = new Subject();
        this._tabIndex = 0;
        this.__focused = false;
        this.__panelOpen = false;
        this.compareWith = (v1, v2) => v1 === v2;
        this.getOptionId = (index, currentOption) => {
            return `${this._panelId}__option_index_${String(index)}`;
        };
        this.getOptionName = (currentOption) => String(currentOption);
        this.getOptionStyle = () => null;
        this.getOptionClassName = () => '';
        this._onChange = () => { };
        this._onTouched = () => { };
        this._scrollStrategy = overlay.scrollStrategies.reposition();
    }
    get tabIndex() {
        return this._tabIndex;
    }
    set tabIndex(v) {
        this._tabIndex = v == null ? 0 : coerceNumberProperty(v);
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _value() {
        return this.__value;
    }
    set _value(newValue) {
        const hasAssigned = this._assignValue(newValue);
        if (hasAssigned) {
            this._onChange(newValue);
        }
    }
    get required() {
        return this._required ?? this.ngControlDirective.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    get empty() {
        if (this.selectType === 'multi') {
            return !Array.isArray(this.__value) || this.__value.length === 0;
        }
        return this.__value == null;
    }
    get _isMultiple() {
        return this.selectType === 'multi';
    }
    get _multiValue() {
        return Array.isArray(this.__value) ? this.__value : [];
    }
    set dropdownPositions(value) {
        if (typeof value === 'string') {
            this._positions = value === 'right' ? ALIGNED_RIGHT_POSITIONS : ALIGNED_LEFT_POSITIONS;
        }
        else {
            this._positions = value;
        }
    }
    get isDropdownOpened() {
        return this.dropDownOpened;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get requiredError() {
        return !!this.ngControlDirective.control?.errors?.['required'];
    }
    get _focused() {
        return this.__focused || this._panelOpen;
    }
    get _isCancelButtonDisabled() {
        return !!this.cancelSelectionText && this.empty;
    }
    get _effectiveAutoClose() {
        return this.selectType === 'multi' && !this._autoCloseExplicitlySet ? false : this._autoClose;
    }
    get _panelOpen() {
        return this.__panelOpen;
    }
    _valueOrPlaceholder(value) {
        if (value != null && !Array.isArray(value)) {
            return this.getOptionName(value);
        }
        return this.placeholder || null;
    }
    ngOnChanges(changes) {
        const options = changes['options'];
        if (options && options.currentValue != options.previousValue) {
            if (this.selectType === 'multi' && Array.isArray(this.__unmodifiedValue)) {
                this.__value = this.__unmodifiedValue
                    .map(v => this.correspondedValueOrNull(v))
                    .filter((v) => v != null);
                if (this.__value.length === 0) {
                    this.__value = null;
                }
            }
            else {
                this.__value = this.correspondedValueOrNull(this.__unmodifiedValue);
            }
        }
    }
    ngOnInit() {
        this._viewportRuler
            .change()
            .pipe(takeUntil(this._destroy))
            .subscribe(() => {
            if (this._panelOpen) {
                this._overlayWidth = this._getOverlayWidth();
                this._changeDetectorRef.detectChanges();
            }
        });
    }
    ngAfterViewInit() { }
    ngOnDestroy() {
        this._destroy.next();
        this._destroy.complete();
    }
    _handleCancelSelection(event) {
        this.cancelSelectionEvent.emit(event);
        this._value = null;
        if (this._effectiveAutoClose) {
            this.close();
            this._focus();
        }
    }
    _removeTag(option, event) {
        event.stopPropagation();
        if (this.selectType === 'multi' && Array.isArray(this.__value)) {
            const newValue = this.__value.filter(v => !this.compareWith(v, option));
            this._assignValue(newValue.length ? newValue : null);
            this._onChange(this.__value);
        }
    }
    _handleKeydown(event) {
        if (!this.disabled) {
            this._panelOpen ? this._handleOpenKeydown(event) : this._handleClosedKeydown(event);
        }
    }
    _onFocus() {
        if (!this.disabled) {
            this.__focused = true;
        }
    }
    _onBlur() {
        this.__focused = false;
        if (!this.disabled && !this._panelOpen) {
            this._onTouched();
            this._changeDetectorRef.markForCheck();
        }
    }
    _canOpen() {
        return !this._panelOpen && !this.disabled && this.options?.length > 0;
    }
    open() {
        if (!this._canOpen()) {
            return;
        }
        this._overlayWidth = this._getOverlayWidth();
        this.__panelOpen = true;
        this._highlightCorrectOption();
        this._changeDetectorRef.markForCheck();
    }
    close() {
        if (this.__panelOpen) {
            this.__panelOpen = false;
            this._changeDetectorRef.markForCheck();
            this.closeEvent.emit();
            this.dropDownOpened = !this.dropDownOpened;
            this._onTouched();
        }
    }
    _focus(options) {
        this.combobox.nativeElement.focus(options);
    }
    _onAttached() {
        this.openEvent.emit();
        this.dropDownOpened = !this.dropDownOpened;
        const bd = document.querySelector('.iui-select-backdrop');
        bd?.setAttribute('data-testid', 'iui-select-backdrop');
        this._overlayDir.positionChange.pipe(take(1)).subscribe(() => {
            this._changeDetectorRef.detectChanges();
            this._positioningSettled();
        });
    }
    writeValue(value) {
        this._assignValue(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._changeDetectorRef.markForCheck();
    }
    _listBoxValueChange(event) {
        if (this.selectType === 'multi') {
            const newValue = [...event.value];
            this._assignValue(newValue.length ? newValue : null);
            this._onChange(this.__value);
            this._emitSelectionChange(event);
            if (this._effectiveAutoClose && this._panelOpen) {
                this.close();
                this._focus();
            }
        }
        else {
            if (event.value.length) {
                const v = [...event.value]?.[0] ?? null;
                this._assignValue(v);
                this._onChange(v);
                this._emitSelectionChange(event);
                if (this._effectiveAutoClose && this._panelOpen) {
                    this.close();
                    this._focus();
                }
            }
        }
    }
    _onOptionClick(option) {
        if (this.selectType !== 'multi') {
            this._value = option;
            this.close();
        }
    }
    _cdkListBoxValue(value) {
        if (Array.isArray(value)) {
            return value;
        }
        return value != null ? [value] : [];
    }
    _optionClassName(index) {
        return `iui-dropdown-panel__option_index_${String(index)}`;
    }
    _handleOpenKeydown(event) { }
    _handleClosedKeydown(event) {
        const keyCode = event.keyCode;
        const isOpenKey = keyCode === ENTER || keyCode === SPACE;
        if (isOpenKey && !hasModifierKey(event)) {
            event.preventDefault();
            this.open();
        }
    }
    _highlightCorrectOption() {
        this.optionElements.changes.pipe(take(1), takeUntil(this._destroy)).subscribe(() => {
            this.listBox.focus();
            this._changeDetectorRef.detectChanges();
        });
    }
    _positioningSettled() { }
    _getOverlayWidth() {
        if (this.panelWidth == null || this.panelWidth === 'auto') {
            return this._elementRef.nativeElement.getBoundingClientRect().width;
        }
        return this.panelWidth === null ? '' : this.panelWidth;
    }
    _assignValue(newValue) {
        if (this.selectType === 'multi') {
            if (Array.isArray(newValue)) {
                this.__unmodifiedValue = newValue;
                this.__value = newValue;
                this._changeDetectorRef.markForCheck();
                return true;
            }
            else if (newValue == null) {
                this.__unmodifiedValue = null;
                this.__value = null;
                this._changeDetectorRef.markForCheck();
                return true;
            }
            return false;
        }
        const singleValue = newValue;
        if (singleValue !== this.__value) {
            this.__unmodifiedValue = singleValue;
            this.__value = this.correspondedValueOrNull(singleValue);
            this._changeDetectorRef.markForCheck();
            return true;
        }
        return false;
    }
    _emitSelectionChange(event) {
        this.selectionChange.emit(event);
    }
    correspondedValueOrNull(newValue) {
        if (newValue == null) {
            return null;
        }
        if (!this.options || this.options.length === 0) {
            return newValue;
        }
        const index = this.options.findIndex(opt => {
            try {
                return opt != null && this.compareWith(opt, newValue);
            }
            catch (error) {
                if (isDevMode()) {
                    console.warn(error);
                }
                return false;
            }
        });
        return index >= 0 ? this.options[index] : null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiSelectComponent, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i1.ViewportRuler }, { token: i1.Overlay }, { token: i2.NgControlDirective, self: true }, { token: i2.IuiErrorStateMatcherDirective, self: true }, { token: i2.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiSelectComponent, isStandalone: true, selector: "iui-select", inputs: { id: "id", label: "label", placeholder: "placeholder", panelWidth: "panelWidth", options: "options", panelStyle: "panelStyle", panelClass: "panelClass", hintText: "hintText", requiredText: "requiredText", cancelSelectionText: "cancelSelectionText", flexibleDimensions: "flexibleDimensions", size: "size", layerSet: "layerSet", selectType: "selectType", skeleton: "skeleton", autoClose: "autoClose", tabIndex: "tabIndex", required: "required", dropdownPositions: "dropdownPositions", compareWith: "compareWith", getOptionId: "getOptionId", getOptionName: "getOptionName", getOptionStyle: "getOptionStyle", getOptionClassName: "getOptionClassName" }, outputs: { openEvent: "openEvent", closeEvent: "closeEvent", selectionChange: "selectionChange", cancelSelectionEvent: "cancelSelectionEvent" }, host: { properties: { "class.iui-select_size_l": "size === \"l\"", "class.iui-select_size_m": "size === \"m\"", "class.iui-select_size_s": "size === \"s\"", "class.iui-select_layer-set-02": "layerSet === \"set-02\"", "class.iui-select_type_multi": "selectType === \"multi\"", "class.iui-select_required": "required", "class.iui-select_disabled": "disabled", "class.iui-select_focused": "_focused", "class.iui-select_invalid": "_errorState", "class.iui-select_filled": "!empty", "class.iui-select_skeleton": "skeleton", "attr.id": "id", "attr.data-testid": "id" }, classAttribute: "iui-select" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiSelectComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "combobox", first: true, predicate: ["combobox"], descendants: true }, { propertyName: "panel", first: true, predicate: ["panel"], descendants: true }, { propertyName: "listBox", first: true, predicate: CdkListbox, descendants: true }, { propertyName: "_overlayDir", first: true, predicate: CdkConnectedOverlay, descendants: true }, { propertyName: "optionElements", predicate: CdkOption, descendants: true }], usesOnChanges: true, hostDirectives: [{ directive: i2.NgControlDirective }, { directive: i2.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i2.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\n\t<div class=\"iui-select__skeleton-label\"></div>\n\t<div class=\"iui-select__skeleton-field\"></div>\n\t<div class=\"iui-select__skeleton-helper\"></div>\n</ng-container>\n\n<ng-template #normalTemplate>\n\t<div class=\"iui-select__label-row\" *ngIf=\"label\">\n\t\t<label class=\"iui-select__label\" [attr.for]=\"_comboboxId\" [id]=\"_labelId\">\n\t\t\t{{ label }}<span class=\"iui-select__required\" *ngIf=\"required\">*</span>\n\t\t</label>\n\t</div>\n\n\t<div\n\t\t#combobox\n\t\tcdk-overlay-origin\n\t\t#fallbackOverlayOrigin=\"cdkOverlayOrigin\"\n\t\tclass=\"iui-select__field\"\n\t\t[attr.id]=\"_comboboxId\"\n\t\t[attr.aria-owns]=\"_panelOpen ? _panelId : null\"\n\t\trole=\"combobox\"\n\t\taria-autocomplete=\"none\"\n\t\taria-haspopup=\"listbox\"\n\t\t[attr.aria-expanded]=\"_panelOpen\"\n\t\t[attr.aria-required]=\"required.toString()\"\n\t\t[attr.aria-disabled]=\"disabled.toString()\"\n\t\t[attr.aria-invalid]=\"_errorState\"\n\t\t[attr.tabindex]=\"disabled ? -1 : tabIndex\"\n\t\t(keydown)=\"_handleKeydown($event)\"\n\t\t(focus)=\"_onFocus()\"\n\t\t(blur)=\"_onBlur()\"\n\t\t(click)=\"open()\"\n\t>\n\t\t<span class=\"iui-select__prefix\"><ng-content select=\"[iui-prefix]\"></ng-content></span>\n\n\t\t<ng-container *ngIf=\"selectType === 'single'\">\n\t\t\t<span\n\t\t\t\t*ngIf=\"placeholder || !empty\"\n\t\t\t\tclass=\"iui-select__value\"\n\t\t\t\t[attr.id]=\"_valueId\"\n\t\t\t\t[attr.data-testid]=\"_valueId\"\n\t\t\t>\n\t\t\t\t{{ _value | mapper: _valueOrPlaceholder.bind(this) }}\n\t\t\t</span>\n\t\t</ng-container>\n\n\t\t<ng-container *ngIf=\"selectType === 'multi'\">\n\t\t\t<div class=\"iui-select__tags\" *ngIf=\"!empty; else multiPlaceholder\">\n\t\t\t\t<span class=\"iui-select__tag\" *ngFor=\"let tag of _multiValue; trackBy: getOptionId\">\n\t\t\t\t\t<span class=\"iui-select__tag-text\">{{ tag | mapper: getOptionName.bind(this) }}</span>\n\t\t\t\t\t<iui-close-empty-icon\n\t\t\t\t\t\tclass=\"iui-select__tag-remove\"\n\t\t\t\t\t\t(click)=\"_removeTag(tag, $event)\"\n\t\t\t\t\t></iui-close-empty-icon>\n\t\t\t\t</span>\n\t\t\t</div>\n\t\t\t<ng-template #multiPlaceholder>\n\t\t\t\t<span class=\"iui-select__value\" *ngIf=\"placeholder\">{{ placeholder }}</span>\n\t\t\t</ng-template>\n\t\t</ng-container>\n\n\t\t<span class=\"iui-select__chevron\">\n\t\t\t<span class=\"iui-select__suffix\"><ng-content select=\"[iui-suffix]\"></ng-content></span>\n\t\t\t<iui-caret-down-icon\n\t\t\t\tclass=\"iui-select__arrow default-caret\"\n\t\t\t\t[class.iui-select__arrow_opened]=\"isDropdownOpened\">\n\t\t\t</iui-caret-down-icon>\n\t\t</span>\n\t</div>\n\n\t<div class=\"iui-select__helper-row\">\n\t\t<span *ngIf=\"_errorState\" class=\"iui-select__error\">\n\t\t\t<ng-container *ngIf=\"requiredError && requiredText\">{{ requiredText }}</ng-container>\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\n\t\t</span>\n\t\t<span *ngIf=\"!_errorState && hintText\" class=\"iui-select__helper\">\n\t\t\t{{ hintText }}\n\t\t</span>\n\t</div>\n\n\t<ng-template\n\tcdk-connected-overlay\n\tcdkConnectedOverlayLockPosition\n\tcdkConnectedOverlayHasBackdrop\n\t[cdkConnectedOverlayBackdropClass]=\"['cdk-overlay-transparent-backdrop', 'iui-select-backdrop']\"\n\t[cdkConnectedOverlayPanelClass]=\"_overlayPanelClass\"\n\t[cdkConnectedOverlayScrollStrategy]=\"_scrollStrategy\"\n\t[cdkConnectedOverlayOrigin]=\"fallbackOverlayOrigin\"\n\t[cdkConnectedOverlayOpen]=\"_panelOpen\"\n\t[cdkConnectedOverlayPositions]=\"_positions\"\n\t[cdkConnectedOverlayMinWidth]=\"_overlayWidth\"\n\t[cdkConnectedOverlayFlexibleDimensions]=\"flexibleDimensions\"\n\t(backdropClick)=\"close()\"\n\t(attach)=\"_onAttached()\"\n\t(detach)=\"close()\"\n>\n\t<div\n\t\t#panel\n\t\tclass=\"iui-dropdown-panel\"\n\t\t[attr.id]=\"_panelId\"\n\t\t[attr.data-testid]=\"_panelId\"\n\t\t[attr.aria-labelledby]=\"_labelId\"\n\t\t[ngStyle]=\"panelStyle\"\n\t\t[ngClass]=\"panelClass\"\n\t>\n\t\t<ul\n\t\t\tclass=\"iui-dropdown-panel__listbox\"\n\t\t\tcdkListbox\n\t\t\t[cdkListboxValue]=\"_value | mapper : _cdkListBoxValue\"\n\t\t\t(cdkListboxValueChange)=\"_listBoxValueChange($event)\"\n\t\t\t[cdkListboxDisabled]=\"disabled\"\n\t\t\t[cdkListboxCompareWith]=\"compareWith\"\n\t\t\t[cdkListboxMultiple]=\"_isMultiple\"\n\t\t>\n\t\t\t<li\n\t\t\t\tclass=\"iui-dropdown-panel__option\"\n\t\t\t\t[id]=\"index | mapper: getOptionId.bind(this) : option\"\n\t\t\t\t[class]=\"_optionClassName(index)\"\n\t\t\t\t[ngStyle]=\"index | mapper: getOptionStyle.bind(this) : option\"\n\t\t\t\t[ngClass]=\"index | mapper: getOptionClassName.bind(this) : option\"\n\t\t\t\t[cdkOption]=\"option\"\n\t\t\t\t(click)=\"_onOptionClick(option)\"\n\t\t\t\t*ngFor=\"let option of options; let index = index; trackBy: getOptionId\"\n\t\t\t>\n\t\t\t\t{{ option | mapper: getOptionName.bind(this) }}\n\t\t\t</li>\n\t\t</ul>\n\n\t\t<footer class=\"iui-dropdown-panel__footer\" *ngIf=\"cancelSelectionText\">\n\t\t\t<button\n\t\t\t\tiuiButton\n\t\t\t\tsize=\"s\"\n\t\t\t\temphasis=\"secondary\"\n\t\t\t\tclass=\"iui-dropdown-panel__cancel-button\"\n\t\t\t\t[attr.id]=\"_cancelButtonId\"\n\t\t\t\t[disabled]=\"_isCancelButtonDisabled\"\n\t\t\t\t(click)=\"_handleCancelSelection($event)\"\n\t\t\t>\n\t\t\t\t{{ cancelSelectionText }}\n\t\t\t</button>\n\t\t</footer>\n\t</div>\n\t</ng-template>\n</ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;min-width:206px;max-width:100%}.iui-select__label-row{display:flex;align-items:flex-start;padding-bottom:8px}.iui-select__label{font:var(--iui-tp-label-01-font);color:var(--iui-select-label-color);flex:1;min-width:1px}.iui-select__required{color:var(--iui-select-error-color);margin-left:4px}.iui-select__field{display:flex;align-items:center;gap:8px;overflow:hidden;background:var(--iui-select-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:pointer;outline:none}:host.iui-select_size_l .iui-select__field{padding:12px 16px;border-radius:var(--iui-border-radius-medium)}:host.iui-select_size_m .iui-select__field{padding:8px 12px;border-radius:var(--iui-border-radius-medium)}:host.iui-select_size_s .iui-select__field{padding:4px 8px;gap:4px;border-radius:var(--iui-border-radius)}.iui-select__value{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-select-color);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:20px}.iui-select__chevron{display:inline-flex;align-items:center;flex-shrink:0;margin-left:auto;color:var(--iui-select-color)}.iui-select__chevron .default-caret{width:20px;height:20px}.iui-select__prefix{display:none;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:inherit}.iui-select__prefix:not(:empty){display:inline-flex}:host ::ng-deep .iui-select__prefix [iui-prefix]{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;color:inherit}:host ::ng-deep .iui-select__prefix [iui-prefix] svg{display:block;width:100%;height:100%}.iui-select__suffix{display:none;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:inherit}.iui-select__suffix:not(:empty){display:inline-flex}.iui-select__suffix:not(:empty)+.default-caret{display:none}:host ::ng-deep .iui-select__suffix [iui-suffix]{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;color:inherit}:host ::ng-deep .iui-select__suffix [iui-suffix] svg{display:block;width:100%;height:100%}.iui-select__arrow{display:block;transition:transform .3s ease;width:100%;height:100%}.iui-select__arrow_opened{transform:rotate(180deg)}.iui-select__tags{display:flex;flex-wrap:wrap;gap:8px;flex:1;min-width:0;align-items:center}.iui-select__tag{display:inline-flex;align-items:center;gap:4px;min-width:24px;padding:4px 4px 4px 8px;border:1px solid var(--iui-select-tag-border);border-radius:4px;overflow:hidden}.iui-select__tag-text{font:var(--iui-tp-body-01-font);color:var(--iui-select-color);flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:20px}.iui-select__tag-remove{flex-shrink:0;width:20px;height:20px;cursor:pointer;color:inherit}:host.iui-select_type_multi .iui-select__field{align-items:flex-start}:host.iui-select_type_multi.iui-select_size_l .iui-select__field{padding:8px 16px 8px 8px}:host.iui-select_type_multi.iui-select_size_m .iui-select__field{padding:4px 16px 4px 4px}:host.iui-select_type_multi.iui-select_size_s .iui-select__field{padding:4px 8px 4px 4px}:host.iui-select_type_multi .iui-select__chevron{padding-top:4px}:host.iui-select_type_multi.iui-select_size_s .iui-select__chevron{padding-top:0}:host.iui-select_type_multi.iui-select_size_s .iui-select__tags{gap:4px}.iui-select__helper-row{padding-top:8px}.iui-select__helper{font:var(--iui-tp-label-01-font);color:var(--iui-select-helper-color)}.iui-select__error{font:var(--iui-tp-label-01-font);color:var(--iui-select-error-color)}:host.iui-select_focused .iui-select__field{border-color:var(--iui-select-focus-border)}:host.iui-select_invalid .iui-select__field{border-color:var(--iui-select-error-border)}:host.iui-select_disabled .iui-select__field{cursor:default;pointer-events:none}:host.iui-select_disabled .iui-select__value,:host.iui-select_disabled .iui-select__chevron{color:var(--iui-select-disabled-color)}:host.iui-select_disabled .iui-select__label{color:var(--iui-select-disabled-color)}:host.iui-select_disabled .iui-select__helper{color:var(--iui-select-disabled-color)}:host.iui-select_disabled .iui-select__tag{color:var(--iui-select-disabled-color);border-color:var(--iui-select-disabled-color)}:host.iui-select_layer-set-02 .iui-select__field{background:var(--iui-select-bg-layer-02)}.iui-select__skeleton-label{width:40px;height:8px;background:var(--iui-select-skeleton-bg);margin-bottom:8px}.iui-select__skeleton-field{height:44px;border-radius:var(--iui-border-radius-medium);background:var(--iui-select-skeleton-bg)}.iui-select__skeleton-helper{margin-top:8px;width:40px;height:8px;background:var(--iui-select-skeleton-bg)}:host.iui-select_size_m .iui-select__skeleton-field{height:36px}:host.iui-select_size_s .iui-select__skeleton-field{height:28px;border-radius:var(--iui-border-radius)}\n", ".iui-dropdown-panel{display:flex;flex-direction:column;overflow:auto;font:var(--iui-tp-body-01-font);color:var(--iui-select-color);max-height:var(--iui-dropdown-panel-max-height);min-width:fit-content;width:100%;max-width:var(--iui-dropdown-panel-max-width);background-color:var(--iui-select-panel-bg);box-shadow:0 2px 8px #0003,0 1px 2px #00000024;border-radius:var(--iui-border-radius)}ul{overflow:auto;margin:0;margin-block-start:0;margin-block-end:0;margin-inline-start:0;margin-inline-end:0;padding-inline-start:0;padding-inline-end:0;list-style:none}li{line-height:var(--iui-dropdown-option-height);padding:0 calc(4 * var(--iui-main-unit));list-style-type:none;margin:0;cursor:pointer;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}li:hover{background-color:var(--iui-select-option-hover)}li.cdk-option-active{outline:none;background-color:var(--iui-select-option-hover)}li[aria-selected=true]{background-color:var(--iui-select-option-selected)}li[aria-selected=true]:hover,li[aria-selected=true].cdk-option-active{background-color:var(--iui-select-option-selected-hover)}li_hidden{display:none}footer{border-top:1px solid var(--iui-select-footer-border);padding:calc(2 * var(--iui-main-unit)) calc(4 * var(--iui-main-unit));border-bottom-right-radius:var(--iui-border-radius);border-bottom-left-radius:var(--iui-border-radius);display:flex;justify-content:space-between;align-items:center}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i1.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: i1.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "directive", type: CdkListbox, selector: "[cdkListbox]", inputs: ["id", "tabindex", "cdkListboxValue", "cdkListboxMultiple", "cdkListboxDisabled", "cdkListboxUseActiveDescendant", "cdkListboxOrientation", "cdkListboxCompareWith", "cdkListboxNavigationWrapDisabled", "cdkListboxNavigatesDisabledOptions"], outputs: ["cdkListboxValueChange"], exportAs: ["cdkListbox"] }, { kind: "directive", type: CdkOption, selector: "[cdkOption]", inputs: ["id", "cdkOption", "cdkOptionTypeaheadLabel", "cdkOptionDisabled", "tabindex"], exportAs: ["cdkOption"] }, { kind: "component", type: CaretDownIconComponent, selector: "iui-caret-down-icon" }, { kind: "component", type: CloseEmptyIconComponent, selector: "iui-close-empty-icon" }, { kind: "component", type: IuiButtonComponent, selector: "button[iuiButton]", inputs: ["type", "emphasis", "size", "disabled", "loading", "menu"] }, { kind: "pipe", type: MapperPipe, name: "mapper" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-select', standalone: true, imports: [CommonModule, OverlayModule, CdkListbox, CdkOption, CaretDownIconComponent, CloseEmptyIconComponent, IuiButtonComponent, MapperPipe], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiSelectComponent),
                            multi: true
                        }
                    ], host: {
                        class: 'iui-select',
                        '[class.iui-select_size_l]': 'size === "l"',
                        '[class.iui-select_size_m]': 'size === "m"',
                        '[class.iui-select_size_s]': 'size === "s"',
                        '[class.iui-select_layer-set-02]': 'layerSet === "set-02"',
                        '[class.iui-select_type_multi]': 'selectType === "multi"',
                        '[class.iui-select_required]': 'required',
                        '[class.iui-select_disabled]': 'disabled',
                        '[class.iui-select_focused]': '_focused',
                        '[class.iui-select_invalid]': '_errorState',
                        '[class.iui-select_filled]': '!empty',
                        '[class.iui-select_skeleton]': 'skeleton',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\n\t<div class=\"iui-select__skeleton-label\"></div>\n\t<div class=\"iui-select__skeleton-field\"></div>\n\t<div class=\"iui-select__skeleton-helper\"></div>\n</ng-container>\n\n<ng-template #normalTemplate>\n\t<div class=\"iui-select__label-row\" *ngIf=\"label\">\n\t\t<label class=\"iui-select__label\" [attr.for]=\"_comboboxId\" [id]=\"_labelId\">\n\t\t\t{{ label }}<span class=\"iui-select__required\" *ngIf=\"required\">*</span>\n\t\t</label>\n\t</div>\n\n\t<div\n\t\t#combobox\n\t\tcdk-overlay-origin\n\t\t#fallbackOverlayOrigin=\"cdkOverlayOrigin\"\n\t\tclass=\"iui-select__field\"\n\t\t[attr.id]=\"_comboboxId\"\n\t\t[attr.aria-owns]=\"_panelOpen ? _panelId : null\"\n\t\trole=\"combobox\"\n\t\taria-autocomplete=\"none\"\n\t\taria-haspopup=\"listbox\"\n\t\t[attr.aria-expanded]=\"_panelOpen\"\n\t\t[attr.aria-required]=\"required.toString()\"\n\t\t[attr.aria-disabled]=\"disabled.toString()\"\n\t\t[attr.aria-invalid]=\"_errorState\"\n\t\t[attr.tabindex]=\"disabled ? -1 : tabIndex\"\n\t\t(keydown)=\"_handleKeydown($event)\"\n\t\t(focus)=\"_onFocus()\"\n\t\t(blur)=\"_onBlur()\"\n\t\t(click)=\"open()\"\n\t>\n\t\t<span class=\"iui-select__prefix\"><ng-content select=\"[iui-prefix]\"></ng-content></span>\n\n\t\t<ng-container *ngIf=\"selectType === 'single'\">\n\t\t\t<span\n\t\t\t\t*ngIf=\"placeholder || !empty\"\n\t\t\t\tclass=\"iui-select__value\"\n\t\t\t\t[attr.id]=\"_valueId\"\n\t\t\t\t[attr.data-testid]=\"_valueId\"\n\t\t\t>\n\t\t\t\t{{ _value | mapper: _valueOrPlaceholder.bind(this) }}\n\t\t\t</span>\n\t\t</ng-container>\n\n\t\t<ng-container *ngIf=\"selectType === 'multi'\">\n\t\t\t<div class=\"iui-select__tags\" *ngIf=\"!empty; else multiPlaceholder\">\n\t\t\t\t<span class=\"iui-select__tag\" *ngFor=\"let tag of _multiValue; trackBy: getOptionId\">\n\t\t\t\t\t<span class=\"iui-select__tag-text\">{{ tag | mapper: getOptionName.bind(this) }}</span>\n\t\t\t\t\t<iui-close-empty-icon\n\t\t\t\t\t\tclass=\"iui-select__tag-remove\"\n\t\t\t\t\t\t(click)=\"_removeTag(tag, $event)\"\n\t\t\t\t\t></iui-close-empty-icon>\n\t\t\t\t</span>\n\t\t\t</div>\n\t\t\t<ng-template #multiPlaceholder>\n\t\t\t\t<span class=\"iui-select__value\" *ngIf=\"placeholder\">{{ placeholder }}</span>\n\t\t\t</ng-template>\n\t\t</ng-container>\n\n\t\t<span class=\"iui-select__chevron\">\n\t\t\t<span class=\"iui-select__suffix\"><ng-content select=\"[iui-suffix]\"></ng-content></span>\n\t\t\t<iui-caret-down-icon\n\t\t\t\tclass=\"iui-select__arrow default-caret\"\n\t\t\t\t[class.iui-select__arrow_opened]=\"isDropdownOpened\">\n\t\t\t</iui-caret-down-icon>\n\t\t</span>\n\t</div>\n\n\t<div class=\"iui-select__helper-row\">\n\t\t<span *ngIf=\"_errorState\" class=\"iui-select__error\">\n\t\t\t<ng-container *ngIf=\"requiredError && requiredText\">{{ requiredText }}</ng-container>\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\n\t\t</span>\n\t\t<span *ngIf=\"!_errorState && hintText\" class=\"iui-select__helper\">\n\t\t\t{{ hintText }}\n\t\t</span>\n\t</div>\n\n\t<ng-template\n\tcdk-connected-overlay\n\tcdkConnectedOverlayLockPosition\n\tcdkConnectedOverlayHasBackdrop\n\t[cdkConnectedOverlayBackdropClass]=\"['cdk-overlay-transparent-backdrop', 'iui-select-backdrop']\"\n\t[cdkConnectedOverlayPanelClass]=\"_overlayPanelClass\"\n\t[cdkConnectedOverlayScrollStrategy]=\"_scrollStrategy\"\n\t[cdkConnectedOverlayOrigin]=\"fallbackOverlayOrigin\"\n\t[cdkConnectedOverlayOpen]=\"_panelOpen\"\n\t[cdkConnectedOverlayPositions]=\"_positions\"\n\t[cdkConnectedOverlayMinWidth]=\"_overlayWidth\"\n\t[cdkConnectedOverlayFlexibleDimensions]=\"flexibleDimensions\"\n\t(backdropClick)=\"close()\"\n\t(attach)=\"_onAttached()\"\n\t(detach)=\"close()\"\n>\n\t<div\n\t\t#panel\n\t\tclass=\"iui-dropdown-panel\"\n\t\t[attr.id]=\"_panelId\"\n\t\t[attr.data-testid]=\"_panelId\"\n\t\t[attr.aria-labelledby]=\"_labelId\"\n\t\t[ngStyle]=\"panelStyle\"\n\t\t[ngClass]=\"panelClass\"\n\t>\n\t\t<ul\n\t\t\tclass=\"iui-dropdown-panel__listbox\"\n\t\t\tcdkListbox\n\t\t\t[cdkListboxValue]=\"_value | mapper : _cdkListBoxValue\"\n\t\t\t(cdkListboxValueChange)=\"_listBoxValueChange($event)\"\n\t\t\t[cdkListboxDisabled]=\"disabled\"\n\t\t\t[cdkListboxCompareWith]=\"compareWith\"\n\t\t\t[cdkListboxMultiple]=\"_isMultiple\"\n\t\t>\n\t\t\t<li\n\t\t\t\tclass=\"iui-dropdown-panel__option\"\n\t\t\t\t[id]=\"index | mapper: getOptionId.bind(this) : option\"\n\t\t\t\t[class]=\"_optionClassName(index)\"\n\t\t\t\t[ngStyle]=\"index | mapper: getOptionStyle.bind(this) : option\"\n\t\t\t\t[ngClass]=\"index | mapper: getOptionClassName.bind(this) : option\"\n\t\t\t\t[cdkOption]=\"option\"\n\t\t\t\t(click)=\"_onOptionClick(option)\"\n\t\t\t\t*ngFor=\"let option of options; let index = index; trackBy: getOptionId\"\n\t\t\t>\n\t\t\t\t{{ option | mapper: getOptionName.bind(this) }}\n\t\t\t</li>\n\t\t</ul>\n\n\t\t<footer class=\"iui-dropdown-panel__footer\" *ngIf=\"cancelSelectionText\">\n\t\t\t<button\n\t\t\t\tiuiButton\n\t\t\t\tsize=\"s\"\n\t\t\t\temphasis=\"secondary\"\n\t\t\t\tclass=\"iui-dropdown-panel__cancel-button\"\n\t\t\t\t[attr.id]=\"_cancelButtonId\"\n\t\t\t\t[disabled]=\"_isCancelButtonDisabled\"\n\t\t\t\t(click)=\"_handleCancelSelection($event)\"\n\t\t\t>\n\t\t\t\t{{ cancelSelectionText }}\n\t\t\t</button>\n\t\t</footer>\n\t</div>\n\t</ng-template>\n</ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;min-width:206px;max-width:100%}.iui-select__label-row{display:flex;align-items:flex-start;padding-bottom:8px}.iui-select__label{font:var(--iui-tp-label-01-font);color:var(--iui-select-label-color);flex:1;min-width:1px}.iui-select__required{color:var(--iui-select-error-color);margin-left:4px}.iui-select__field{display:flex;align-items:center;gap:8px;overflow:hidden;background:var(--iui-select-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:pointer;outline:none}:host.iui-select_size_l .iui-select__field{padding:12px 16px;border-radius:var(--iui-border-radius-medium)}:host.iui-select_size_m .iui-select__field{padding:8px 12px;border-radius:var(--iui-border-radius-medium)}:host.iui-select_size_s .iui-select__field{padding:4px 8px;gap:4px;border-radius:var(--iui-border-radius)}.iui-select__value{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-select-color);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:20px}.iui-select__chevron{display:inline-flex;align-items:center;flex-shrink:0;margin-left:auto;color:var(--iui-select-color)}.iui-select__chevron .default-caret{width:20px;height:20px}.iui-select__prefix{display:none;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:inherit}.iui-select__prefix:not(:empty){display:inline-flex}:host ::ng-deep .iui-select__prefix [iui-prefix]{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;color:inherit}:host ::ng-deep .iui-select__prefix [iui-prefix] svg{display:block;width:100%;height:100%}.iui-select__suffix{display:none;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:inherit}.iui-select__suffix:not(:empty){display:inline-flex}.iui-select__suffix:not(:empty)+.default-caret{display:none}:host ::ng-deep .iui-select__suffix [iui-suffix]{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;color:inherit}:host ::ng-deep .iui-select__suffix [iui-suffix] svg{display:block;width:100%;height:100%}.iui-select__arrow{display:block;transition:transform .3s ease;width:100%;height:100%}.iui-select__arrow_opened{transform:rotate(180deg)}.iui-select__tags{display:flex;flex-wrap:wrap;gap:8px;flex:1;min-width:0;align-items:center}.iui-select__tag{display:inline-flex;align-items:center;gap:4px;min-width:24px;padding:4px 4px 4px 8px;border:1px solid var(--iui-select-tag-border);border-radius:4px;overflow:hidden}.iui-select__tag-text{font:var(--iui-tp-body-01-font);color:var(--iui-select-color);flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:20px}.iui-select__tag-remove{flex-shrink:0;width:20px;height:20px;cursor:pointer;color:inherit}:host.iui-select_type_multi .iui-select__field{align-items:flex-start}:host.iui-select_type_multi.iui-select_size_l .iui-select__field{padding:8px 16px 8px 8px}:host.iui-select_type_multi.iui-select_size_m .iui-select__field{padding:4px 16px 4px 4px}:host.iui-select_type_multi.iui-select_size_s .iui-select__field{padding:4px 8px 4px 4px}:host.iui-select_type_multi .iui-select__chevron{padding-top:4px}:host.iui-select_type_multi.iui-select_size_s .iui-select__chevron{padding-top:0}:host.iui-select_type_multi.iui-select_size_s .iui-select__tags{gap:4px}.iui-select__helper-row{padding-top:8px}.iui-select__helper{font:var(--iui-tp-label-01-font);color:var(--iui-select-helper-color)}.iui-select__error{font:var(--iui-tp-label-01-font);color:var(--iui-select-error-color)}:host.iui-select_focused .iui-select__field{border-color:var(--iui-select-focus-border)}:host.iui-select_invalid .iui-select__field{border-color:var(--iui-select-error-border)}:host.iui-select_disabled .iui-select__field{cursor:default;pointer-events:none}:host.iui-select_disabled .iui-select__value,:host.iui-select_disabled .iui-select__chevron{color:var(--iui-select-disabled-color)}:host.iui-select_disabled .iui-select__label{color:var(--iui-select-disabled-color)}:host.iui-select_disabled .iui-select__helper{color:var(--iui-select-disabled-color)}:host.iui-select_disabled .iui-select__tag{color:var(--iui-select-disabled-color);border-color:var(--iui-select-disabled-color)}:host.iui-select_layer-set-02 .iui-select__field{background:var(--iui-select-bg-layer-02)}.iui-select__skeleton-label{width:40px;height:8px;background:var(--iui-select-skeleton-bg);margin-bottom:8px}.iui-select__skeleton-field{height:44px;border-radius:var(--iui-border-radius-medium);background:var(--iui-select-skeleton-bg)}.iui-select__skeleton-helper{margin-top:8px;width:40px;height:8px;background:var(--iui-select-skeleton-bg)}:host.iui-select_size_m .iui-select__skeleton-field{height:36px}:host.iui-select_size_s .iui-select__skeleton-field{height:28px;border-radius:var(--iui-border-radius)}\n", ".iui-dropdown-panel{display:flex;flex-direction:column;overflow:auto;font:var(--iui-tp-body-01-font);color:var(--iui-select-color);max-height:var(--iui-dropdown-panel-max-height);min-width:fit-content;width:100%;max-width:var(--iui-dropdown-panel-max-width);background-color:var(--iui-select-panel-bg);box-shadow:0 2px 8px #0003,0 1px 2px #00000024;border-radius:var(--iui-border-radius)}ul{overflow:auto;margin:0;margin-block-start:0;margin-block-end:0;margin-inline-start:0;margin-inline-end:0;padding-inline-start:0;padding-inline-end:0;list-style:none}li{line-height:var(--iui-dropdown-option-height);padding:0 calc(4 * var(--iui-main-unit));list-style-type:none;margin:0;cursor:pointer;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}li:hover{background-color:var(--iui-select-option-hover)}li.cdk-option-active{outline:none;background-color:var(--iui-select-option-hover)}li[aria-selected=true]{background-color:var(--iui-select-option-selected)}li[aria-selected=true]:hover,li[aria-selected=true].cdk-option-active{background-color:var(--iui-select-option-selected-hover)}li_hidden{display:none}footer{border-top:1px solid var(--iui-select-footer-border);padding:calc(2 * var(--iui-main-unit)) calc(4 * var(--iui-main-unit));border-bottom-right-radius:var(--iui-border-radius);border-bottom-left-radius:var(--iui-border-radius);display:flex;justify-content:space-between;align-items:center}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i1.ViewportRuler }, { type: i1.Overlay }, { type: i2.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i2.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i2.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { combobox: [{
                type: ViewChild,
                args: ['combobox']
            }], panel: [{
                type: ViewChild,
                args: ['panel']
            }], listBox: [{
                type: ViewChild,
                args: [CdkListbox]
            }], optionElements: [{
                type: ViewChildren,
                args: [CdkOption]
            }], id: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], panelWidth: [{
                type: Input
            }], options: [{
                type: Input
            }], panelStyle: [{
                type: Input
            }], panelClass: [{
                type: Input
            }], hintText: [{
                type: Input
            }], requiredText: [{
                type: Input
            }], cancelSelectionText: [{
                type: Input
            }], flexibleDimensions: [{
                type: Input
            }], size: [{
                type: Input
            }], layerSet: [{
                type: Input
            }], selectType: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], autoClose: [{
                type: Input
            }], openEvent: [{
                type: Output
            }], closeEvent: [{
                type: Output
            }], selectionChange: [{
                type: Output
            }], cancelSelectionEvent: [{
                type: Output
            }], _overlayDir: [{
                type: ViewChild,
                args: [CdkConnectedOverlay]
            }], tabIndex: [{
                type: Input
            }], required: [{
                type: Input
            }], dropdownPositions: [{
                type: Input
            }], compareWith: [{
                type: Input
            }], getOptionId: [{
                type: Input
            }], getOptionName: [{
                type: Input
            }], getOptionStyle: [{
                type: Input
            }], getOptionClassName: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ALIGNED_LEFT_POSITIONS, ALIGNED_RIGHT_POSITIONS, IUI_SELECT_SCROLL_STRATEGY, IuiSelectComponent, hasModifierKey };
//# sourceMappingURL=itero-ui-components-angular-select.mjs.map
