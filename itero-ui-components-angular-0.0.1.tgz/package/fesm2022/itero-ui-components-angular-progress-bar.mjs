import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { CheckmarkFillIconComponent, ErrorIconComponent } from '@itero/ui-components-angular/icons';

class IuiProgressBarComponent {
    constructor() {
        /** Completion percentage. Values outside 0..100 are clamped. */
        this.value = 0;
        /** Current progress status. Success and error render a full-width status bar. */
        this.status = 'in-progress';
        /** Textual description of the task being completed. */
        this.label = 'Label';
        /** Assistive text shown below non-error progress states. */
        this.helperText = 'Optional helper text';
        /** Error message shown below the bar when status is error. */
        this.errorText = 'Error text message';
        /** Text for the retry action shown in the error state. */
        this.retryLabel = 'Try again';
        /** Accessible name used when the visible label is hidden or unavailable. */
        this.ariaLabel = '';
        this.retry = new EventEmitter();
        this._showLabel = true;
        this._showHelperText = true;
    }
    get showLabel() {
        return this._showLabel;
    }
    set showLabel(value) {
        this._showLabel = coerceBooleanProperty(value);
    }
    get showHelperText() {
        return this._showHelperText;
    }
    set showHelperText(value) {
        this._showHelperText = coerceBooleanProperty(value);
    }
    get normalizedValue() {
        const value = Number(this.value);
        if (!Number.isFinite(value)) {
            return 0;
        }
        return Math.min(100, Math.max(0, value));
    }
    get visualValue() {
        return this.status === 'success' || this.status === 'error' ? 100 : this.normalizedValue;
    }
    get progressStyle() {
        return { width: `${this.visualValue}%` };
    }
    get computedAriaLabel() {
        if (this.ariaLabel) {
            return this.ariaLabel;
        }
        if (this.showLabel && this.label) {
            return this.label;
        }
        return 'Progress';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiProgressBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiProgressBarComponent, isStandalone: true, selector: "iui-progress-bar", inputs: { value: "value", status: "status", label: "label", showLabel: "showLabel", helperText: "helperText", showHelperText: "showHelperText", errorText: "errorText", retryLabel: "retryLabel", ariaLabel: "ariaLabel" }, outputs: { retry: "retry" }, host: { attributes: { "role": "progressbar" }, properties: { "attr.aria-valuemin": "0", "attr.aria-valuemax": "100", "attr.aria-valuenow": "status === \"error\" ? null : visualValue", "attr.aria-invalid": "status === \"error\" ? \"true\" : null", "attr.aria-label": "computedAriaLabel", "class.iui-progress-bar_success": "status === \"success\"", "class.iui-progress-bar_error": "status === \"error\"" }, classAttribute: "iui-progress-bar" }, ngImport: i0, template: "<div class=\"iui-progress-bar__label-row\" *ngIf=\"showLabel && label\">\n\t<span class=\"iui-progress-bar__label\">{{ label }}</span>\n\n\t<span class=\"iui-progress-bar__status\" *ngIf=\"status === 'success'\">\n\t\t<iui-checkmark-fill-icon class=\"iui-progress-bar__icon iui-progress-bar__icon_success iui-icon_size_xs\" aria-hidden=\"true\"></iui-checkmark-fill-icon>\n\t</span>\n\n\t<span class=\"iui-progress-bar__status iui-progress-bar__status_error\" *ngIf=\"status === 'error'\">\n\t\t<button class=\"iui-progress-bar__retry\" type=\"button\" (click)=\"retry.emit()\">\n\t\t\t{{ retryLabel }}\n\t\t</button>\n\t\t<iui-error-icon class=\"iui-progress-bar__icon iui-progress-bar__icon_error iui-icon_size_xs\" aria-hidden=\"true\"></iui-error-icon>\n\t</span>\n</div>\n\n<div class=\"iui-progress-bar__track\">\n\t<div class=\"iui-progress-bar__fill\" [ngStyle]=\"progressStyle\"></div>\n</div>\n\n<div class=\"iui-progress-bar__helper-row\" *ngIf=\"showHelperText\">\n\t<span class=\"iui-progress-bar__error\" *ngIf=\"status === 'error'; else helperTemplate\">\n\t\t{{ errorText }}\n\t</span>\n\n\t<ng-template #helperTemplate>\n\t\t<span class=\"iui-progress-bar__helper\">{{ helperText }}</span>\n\t</ng-template>\n</div>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;width:100%;max-width:100%}.iui-progress-bar__label-row{display:flex;align-items:flex-start;gap:16px;justify-content:flex-end;width:100%;padding-bottom:8px}.iui-progress-bar__label{flex:1 0 0;min-width:1px;color:var(--iui-progress-bar-label-color)}.iui-progress-bar__label,.iui-progress-bar__helper,.iui-progress-bar__error,.iui-progress-bar__retry{font:var(--iui-tp-label-01-font)}.iui-progress-bar__status{display:inline-flex;align-items:center;flex-shrink:0}.iui-progress-bar__status_error{gap:8px}.iui-progress-bar__track{position:relative;width:100%;height:4px;overflow:hidden;border-radius:var(--iui-border-radius);background:var(--iui-progress-bar-track)}.iui-progress-bar__fill{height:100%;border-radius:inherit;background:var(--iui-progress-bar-fill)}:host.iui-progress-bar_success .iui-progress-bar__fill{background:var(--iui-progress-bar-success-fill)}:host.iui-progress-bar_error .iui-progress-bar__fill{background:var(--iui-progress-bar-error-fill)}.iui-progress-bar__helper-row{display:flex;align-items:center;width:100%;padding-top:8px}.iui-progress-bar__helper{flex:1 0 0;min-width:1px;color:var(--iui-progress-bar-helper-color)}.iui-progress-bar__error{flex:1 0 0;min-width:1px;color:var(--iui-progress-bar-error-color)}.iui-progress-bar__retry{display:inline-flex;align-items:center;gap:4px;padding:0;margin:0;color:var(--iui-progress-bar-link-color);background:transparent;border:none;cursor:pointer}.iui-progress-bar__retry:focus-visible{outline:1px solid var(--iui-border-focus);outline-offset:2px}.iui-progress-bar__icon{display:inline-flex;width:var(--iui-icon-size-xs);height:var(--iui-icon-size-xs);flex-shrink:0}.iui-progress-bar__icon_success{color:var(--iui-progress-bar-success-icon)}.iui-progress-bar__icon_error{color:var(--iui-progress-bar-error-icon)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: CheckmarkFillIconComponent, selector: "iui-checkmark-fill-icon" }, { kind: "component", type: ErrorIconComponent, selector: "iui-error-icon" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiProgressBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-progress-bar', standalone: true, imports: [CommonModule, CheckmarkFillIconComponent, ErrorIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'iui-progress-bar',
                        role: 'progressbar',
                        '[attr.aria-valuemin]': '0',
                        '[attr.aria-valuemax]': '100',
                        '[attr.aria-valuenow]': 'status === "error" ? null : visualValue',
                        '[attr.aria-invalid]': 'status === "error" ? "true" : null',
                        '[attr.aria-label]': 'computedAriaLabel',
                        '[class.iui-progress-bar_success]': 'status === "success"',
                        '[class.iui-progress-bar_error]': 'status === "error"'
                    }, template: "<div class=\"iui-progress-bar__label-row\" *ngIf=\"showLabel && label\">\n\t<span class=\"iui-progress-bar__label\">{{ label }}</span>\n\n\t<span class=\"iui-progress-bar__status\" *ngIf=\"status === 'success'\">\n\t\t<iui-checkmark-fill-icon class=\"iui-progress-bar__icon iui-progress-bar__icon_success iui-icon_size_xs\" aria-hidden=\"true\"></iui-checkmark-fill-icon>\n\t</span>\n\n\t<span class=\"iui-progress-bar__status iui-progress-bar__status_error\" *ngIf=\"status === 'error'\">\n\t\t<button class=\"iui-progress-bar__retry\" type=\"button\" (click)=\"retry.emit()\">\n\t\t\t{{ retryLabel }}\n\t\t</button>\n\t\t<iui-error-icon class=\"iui-progress-bar__icon iui-progress-bar__icon_error iui-icon_size_xs\" aria-hidden=\"true\"></iui-error-icon>\n\t</span>\n</div>\n\n<div class=\"iui-progress-bar__track\">\n\t<div class=\"iui-progress-bar__fill\" [ngStyle]=\"progressStyle\"></div>\n</div>\n\n<div class=\"iui-progress-bar__helper-row\" *ngIf=\"showHelperText\">\n\t<span class=\"iui-progress-bar__error\" *ngIf=\"status === 'error'; else helperTemplate\">\n\t\t{{ errorText }}\n\t</span>\n\n\t<ng-template #helperTemplate>\n\t\t<span class=\"iui-progress-bar__helper\">{{ helperText }}</span>\n\t</ng-template>\n</div>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;width:100%;max-width:100%}.iui-progress-bar__label-row{display:flex;align-items:flex-start;gap:16px;justify-content:flex-end;width:100%;padding-bottom:8px}.iui-progress-bar__label{flex:1 0 0;min-width:1px;color:var(--iui-progress-bar-label-color)}.iui-progress-bar__label,.iui-progress-bar__helper,.iui-progress-bar__error,.iui-progress-bar__retry{font:var(--iui-tp-label-01-font)}.iui-progress-bar__status{display:inline-flex;align-items:center;flex-shrink:0}.iui-progress-bar__status_error{gap:8px}.iui-progress-bar__track{position:relative;width:100%;height:4px;overflow:hidden;border-radius:var(--iui-border-radius);background:var(--iui-progress-bar-track)}.iui-progress-bar__fill{height:100%;border-radius:inherit;background:var(--iui-progress-bar-fill)}:host.iui-progress-bar_success .iui-progress-bar__fill{background:var(--iui-progress-bar-success-fill)}:host.iui-progress-bar_error .iui-progress-bar__fill{background:var(--iui-progress-bar-error-fill)}.iui-progress-bar__helper-row{display:flex;align-items:center;width:100%;padding-top:8px}.iui-progress-bar__helper{flex:1 0 0;min-width:1px;color:var(--iui-progress-bar-helper-color)}.iui-progress-bar__error{flex:1 0 0;min-width:1px;color:var(--iui-progress-bar-error-color)}.iui-progress-bar__retry{display:inline-flex;align-items:center;gap:4px;padding:0;margin:0;color:var(--iui-progress-bar-link-color);background:transparent;border:none;cursor:pointer}.iui-progress-bar__retry:focus-visible{outline:1px solid var(--iui-border-focus);outline-offset:2px}.iui-progress-bar__icon{display:inline-flex;width:var(--iui-icon-size-xs);height:var(--iui-icon-size-xs);flex-shrink:0}.iui-progress-bar__icon_success{color:var(--iui-progress-bar-success-icon)}.iui-progress-bar__icon_error{color:var(--iui-progress-bar-error-icon)}\n"] }]
        }], propDecorators: { value: [{
                type: Input
            }], status: [{
                type: Input
            }], label: [{
                type: Input
            }], showLabel: [{
                type: Input
            }], helperText: [{
                type: Input
            }], showHelperText: [{
                type: Input
            }], errorText: [{
                type: Input
            }], retryLabel: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], retry: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiProgressBarComponent };
//# sourceMappingURL=itero-ui-components-angular-progress-bar.mjs.map
