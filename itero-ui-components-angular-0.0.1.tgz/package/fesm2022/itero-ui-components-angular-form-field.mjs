import * as i0 from '@angular/core';
import { Input, Optional, SkipSelf, Component } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import { Subject } from 'rxjs';
import { trigger, transition, animate, state, style } from '@angular/animations';
import { Validators } from '@angular/forms';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i1 from '@itero/ui-components-angular/core';

let nextUniqueId = 0;
const labelScale = 0.7777;
const labelAboveAnimation = trigger('labelAbove', [
    transition('false <=> true', animate('150ms cubic-bezier(0.4, 0, 0.2, 1)')),
    state('true', style({
        left: 0,
        transform: `translateY(-10.75px) scale(${labelScale})`,
        'max-width': `calc((100%  - 32px) / ${labelScale})`,
        cursor: 'auto'
    }))
]);
const transformPanelAnimation = trigger('transformPanel', [
    state('void', style({
        opacity: 0,
        transform: 'scale(1, 0.8)'
    })),
    transition('void => showing', animate('120ms cubic-bezier(0, 0, 0.2, 1)', style({
        opacity: 1,
        transform: 'scale(1, 1)'
    }))),
    transition('* => void', animate('100ms linear', style({ opacity: 0 })))
]);
const transitionMessages = trigger('transitionMessages', [
    // TODO(mmalerba): Use angular animations for label animation as well.
    state('enter', style({ opacity: 1, transform: 'translateY(0%)', position: 'static' })),
    transition('void => enter', [style({ opacity: 0, transform: 'translateY(-5px)' }), animate('200ms cubic-bezier(0.55, 0, 0.55, 0.2)')])
]);
class IuiFormFieldComponent {
    /** Id for label inside */
    set labelId(value) {
        this._labelId = value;
    }
    get labelId() {
        return this._labelId;
    }
    /** Unique id of the element */
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    constructor(ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        this._id = `iui-form-field-${nextUniqueId++}`;
        /** Label of select component, default is '', strongly recommended to be filled */
        this.label = '';
        this._labelId = this.id + '-label';
        /** "for" Attribute assigned to label, as a value you should provide Id of your input/combobox component */
        this.labelFor = '';
        this._underlineAnimationState = '';
        this._hovered = false;
        /** Emits whenever the component is destroyed. */
        this._destroy = new Subject();
        /** flag that controls moving label up, when it is clicked, focused, etc. */
        this.labelAbove = false;
        this.focused = false;
    }
    /** Whether the select is disabled. */
    get disabled() {
        return !!this.isDisabledDirective?.isDisabled;
    }
    /** Whether the component is required. */
    get required() {
        return this._required ?? this.ngControlDirective?.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    get _labelAbove() {
        return this.labelAbove;
    }
    get _errorState() {
        return !!this.errorStateMatcherDirective?.errorState;
    }
    ngAfterViewInit() {
        // Enable animations now. This ensures we don't animate on initial render.
        this._underlineAnimationState = 'enter';
    }
    ngOnDestroy() {
        this._destroy.next();
        this._destroy.complete();
    }
    _handleTransitionMessagesStart(event) {
        const el = event.element;
        if (el.parentElement) {
            el.parentElement.style.height = String(el.offsetHeight) + 'px';
        }
    }
    _handleTransitionMessagesDone(event) {
        const el = event.element;
        if (el.parentElement) {
            el.parentElement.style.height = '';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiFormFieldComponent, deps: [{ token: i1.NgControlDirective, optional: true, skipSelf: true }, { token: i1.IuiErrorStateMatcherDirective, optional: true, skipSelf: true }, { token: i1.IuiIsDisabledDirective, optional: true, skipSelf: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiFormFieldComponent, isStandalone: true, selector: "iui-form-field", inputs: { labelId: "labelId", id: "id", label: "label", labelFor: "labelFor", labelAbove: "labelAbove", focused: "focused", required: "required" }, host: { properties: { "class.iui-form-field_focused": "focused", "class.iui-form-field_required": "required", "class.iui-form-field_disabled": "disabled", "class.iui-form-field_invalid": "_errorState", "attr.id": "id", "attr.data-testid": "id" }, classAttribute: "iui-form-field" }, ngImport: i0, template: "<!--\n Note that the select trigger element specifies `aria-owns` pointing to the listbox overlay.\n While aria-owns is not required for the ARIA 1.2 `role=\"combobox\"` interaction pattern,\n it fixes an issue with VoiceOver when the select appears inside of an `aria-model=\"true\"`\n element (e.g. a dialog). Without this `aria-owns`, the `aria-modal` on a dialog prevents\n VoiceOver from \"seeing\" the select's listbox overlay for aria-activedescendant.\n Using `aria-owns` re-parents the select overlay so that it works again.\n See https://github.com/angular/components/issues/20694\n-->\n<div\n\t(mouseenter)=\"_hovered = true\"\n\t(mouseleave)=\"_hovered = false\"\n\tclass=\"iui-form-field__container\"\n\t[ngClass]=\"{ 'iui-form-field__container_hovered': _hovered }\"\n>\n\t<ng-content></ng-content>\n\t<label\n\t\tclass=\"iui-form-field__label-container\"\n\t\t[@labelAbove]=\"_labelAbove\"\n\t\t[attr.id]=\"labelId\"\n\t\t[attr.data-testid]=\"labelId\"\n\t\t[attr.for]=\"labelFor\"\n\t>\n\t\t<span class=\"iui-form-field__label\" [class.iui-form-field__label_above]=\"_labelAbove\">{{ label }}</span>\n\t\t<span class=\"iui-form-field__asterisk\" *ngIf=\"required && !disabled\">*</span>\n\t</label>\n\t\n</div>\n<div class=\"iui-form-field__underline\">\n\t<span class=\"iui-form-field__underline-content\"></span>\n</div>\n<div class=\"iui-form-field__underline-container\">\n\t<span\n\t\t*ngIf=\"_errorState\"\n\t\t(@transitionMessages.start)=\"_handleTransitionMessagesStart($event)\"\n\t\t(@transitionMessages.done)=\"_handleTransitionMessagesDone($event)\"\n\t\t[@transitionMessages]=\"_underlineAnimationState\"\n\t\tclass=\"iui-form-field__error\"\n\t><ng-content select=\"[iui-error]\"></ng-content></span>\n\t<span\n\t\t*ngIf=\"!_errorState\"\n\t\tclass=\"iui-form-field__hint\"\n\t><ng-content select=\"[iui-hint]\"></ng-content></span>\n</div>\n\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:block;color:var(--iui-form-field-color);min-width:206px;max-width:100%;transition:color .2s ease-out}:host:focus-visible{outline:none}:host.iui-form-field_disabled{transition:color .2s ease-in;color:var(--iui-form-field-disabled-color)}:host.iui-form-field_invalid{transition:color .2s ease-in}.iui-form-field__container{display:flex;align-items:center;position:relative;cursor:pointer;font:var(--iui-tp-body-01-font);box-sizing:border-box;border-top-left-radius:var(--iui-border-radius);border-top-right-radius:var(--iui-border-radius);height:52px;padding:0;transition:background-color .2s ease-out;will-change:background-color}.iui-form-field__container_hovered{transition:background-color .2s ease-in;background-color:var(--iui-form-field-hover-bg)}:host.iui-form-field_focused ::ng-deep .iui-form-field__container{transition:background-color .2s ease-in;outline:none}:host.iui-form-field_disabled ::ng-deep .iui-form-field__container{border-bottom-color:var(--iui-form-field-underline);cursor:default;pointer-events:none}.iui-form-field__underline{position:relative;height:2px;width:100%;background-color:var(--iui-form-field-underline);background-clip:content-box;padding-bottom:1px;will-change:background-color;transition:background-color .2s ease-out}:host.iui-form-field_invalid ::ng-deep .iui-form-field__underline{background-color:var(--iui-form-field-error-color);transition:background-color .2s ease-in}.iui-form-field__underline-content{display:block;position:absolute;top:0;width:100%;height:1px;opacity:0;transform:scaleY(1);overflow:hidden;background-color:var(--iui-form-field-underline-focused);will-change:background-color,transform,opacity;transition:transform .2s ease-out,opacity .2s ease-out,background-color .2s ease-out}:host.iui-form-field_focused ::ng-deep .iui-form-field__underline-content{opacity:1;transform:scaleY(2);transition:transform .2s ease-in,opacity .2s ease-in,background-color .2s ease-in}:host.iui-form-field_invalid ::ng-deep .iui-form-field__underline-content{background-color:var(--iui-form-field-error-color)}.iui-form-field__label-container{font:var(--iui-tp-body-02-font);position:absolute;display:flex;cursor:pointer;align-self:center;transform-origin:left top;left:0;right:auto;font-weight:400;margin:0;will-change:transform;max-width:calc(100% - 32px)}.iui-form-field__label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host.iui-form-field_invalid ::ng-deep .iui-form-field__label.iui-form-field__label_above{color:var(--iui-form-field-error-color)}.iui-form-field__asterisk{margin-left:8px;color:var(--iui-form-field-error-color)}.iui-form-field__underline-container{position:relative;font:var(--iui-tp-label-01-font)}.iui-form-field__error{position:absolute;color:var(--iui-form-field-error-color);line-height:21px}.iui-form-field__hint{line-height:21px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], animations: [transformPanelAnimation, transitionMessages, labelAboveAnimation] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiFormFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-form-field', standalone: true, imports: [CommonModule], animations: [transformPanelAnimation, transitionMessages, labelAboveAnimation], host: {
                        class: 'iui-form-field',
                        '[class.iui-form-field_focused]': 'focused',
                        '[class.iui-form-field_required]': 'required',
                        '[class.iui-form-field_disabled]': 'disabled',
                        '[class.iui-form-field_invalid]': '_errorState',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<!--\n Note that the select trigger element specifies `aria-owns` pointing to the listbox overlay.\n While aria-owns is not required for the ARIA 1.2 `role=\"combobox\"` interaction pattern,\n it fixes an issue with VoiceOver when the select appears inside of an `aria-model=\"true\"`\n element (e.g. a dialog). Without this `aria-owns`, the `aria-modal` on a dialog prevents\n VoiceOver from \"seeing\" the select's listbox overlay for aria-activedescendant.\n Using `aria-owns` re-parents the select overlay so that it works again.\n See https://github.com/angular/components/issues/20694\n-->\n<div\n\t(mouseenter)=\"_hovered = true\"\n\t(mouseleave)=\"_hovered = false\"\n\tclass=\"iui-form-field__container\"\n\t[ngClass]=\"{ 'iui-form-field__container_hovered': _hovered }\"\n>\n\t<ng-content></ng-content>\n\t<label\n\t\tclass=\"iui-form-field__label-container\"\n\t\t[@labelAbove]=\"_labelAbove\"\n\t\t[attr.id]=\"labelId\"\n\t\t[attr.data-testid]=\"labelId\"\n\t\t[attr.for]=\"labelFor\"\n\t>\n\t\t<span class=\"iui-form-field__label\" [class.iui-form-field__label_above]=\"_labelAbove\">{{ label }}</span>\n\t\t<span class=\"iui-form-field__asterisk\" *ngIf=\"required && !disabled\">*</span>\n\t</label>\n\t\n</div>\n<div class=\"iui-form-field__underline\">\n\t<span class=\"iui-form-field__underline-content\"></span>\n</div>\n<div class=\"iui-form-field__underline-container\">\n\t<span\n\t\t*ngIf=\"_errorState\"\n\t\t(@transitionMessages.start)=\"_handleTransitionMessagesStart($event)\"\n\t\t(@transitionMessages.done)=\"_handleTransitionMessagesDone($event)\"\n\t\t[@transitionMessages]=\"_underlineAnimationState\"\n\t\tclass=\"iui-form-field__error\"\n\t><ng-content select=\"[iui-error]\"></ng-content></span>\n\t<span\n\t\t*ngIf=\"!_errorState\"\n\t\tclass=\"iui-form-field__hint\"\n\t><ng-content select=\"[iui-hint]\"></ng-content></span>\n</div>\n\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:block;color:var(--iui-form-field-color);min-width:206px;max-width:100%;transition:color .2s ease-out}:host:focus-visible{outline:none}:host.iui-form-field_disabled{transition:color .2s ease-in;color:var(--iui-form-field-disabled-color)}:host.iui-form-field_invalid{transition:color .2s ease-in}.iui-form-field__container{display:flex;align-items:center;position:relative;cursor:pointer;font:var(--iui-tp-body-01-font);box-sizing:border-box;border-top-left-radius:var(--iui-border-radius);border-top-right-radius:var(--iui-border-radius);height:52px;padding:0;transition:background-color .2s ease-out;will-change:background-color}.iui-form-field__container_hovered{transition:background-color .2s ease-in;background-color:var(--iui-form-field-hover-bg)}:host.iui-form-field_focused ::ng-deep .iui-form-field__container{transition:background-color .2s ease-in;outline:none}:host.iui-form-field_disabled ::ng-deep .iui-form-field__container{border-bottom-color:var(--iui-form-field-underline);cursor:default;pointer-events:none}.iui-form-field__underline{position:relative;height:2px;width:100%;background-color:var(--iui-form-field-underline);background-clip:content-box;padding-bottom:1px;will-change:background-color;transition:background-color .2s ease-out}:host.iui-form-field_invalid ::ng-deep .iui-form-field__underline{background-color:var(--iui-form-field-error-color);transition:background-color .2s ease-in}.iui-form-field__underline-content{display:block;position:absolute;top:0;width:100%;height:1px;opacity:0;transform:scaleY(1);overflow:hidden;background-color:var(--iui-form-field-underline-focused);will-change:background-color,transform,opacity;transition:transform .2s ease-out,opacity .2s ease-out,background-color .2s ease-out}:host.iui-form-field_focused ::ng-deep .iui-form-field__underline-content{opacity:1;transform:scaleY(2);transition:transform .2s ease-in,opacity .2s ease-in,background-color .2s ease-in}:host.iui-form-field_invalid ::ng-deep .iui-form-field__underline-content{background-color:var(--iui-form-field-error-color)}.iui-form-field__label-container{font:var(--iui-tp-body-02-font);position:absolute;display:flex;cursor:pointer;align-self:center;transform-origin:left top;left:0;right:auto;font-weight:400;margin:0;will-change:transform;max-width:calc(100% - 32px)}.iui-form-field__label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}:host.iui-form-field_invalid ::ng-deep .iui-form-field__label.iui-form-field__label_above{color:var(--iui-form-field-error-color)}.iui-form-field__asterisk{margin-left:8px;color:var(--iui-form-field-error-color)}.iui-form-field__underline-container{position:relative;font:var(--iui-tp-label-01-font)}.iui-form-field__error{position:absolute;color:var(--iui-form-field-error-color);line-height:21px}.iui-form-field__hint{line-height:21px}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControlDirective, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.IuiErrorStateMatcherDirective, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.IuiIsDisabledDirective, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }], propDecorators: { labelId: [{
                type: Input
            }], id: [{
                type: Input
            }], label: [{
                type: Input
            }], labelFor: [{
                type: Input
            }], labelAbove: [{
                type: Input
            }], focused: [{
                type: Input
            }], required: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiFormFieldComponent };
//# sourceMappingURL=itero-ui-components-angular-form-field.mjs.map
