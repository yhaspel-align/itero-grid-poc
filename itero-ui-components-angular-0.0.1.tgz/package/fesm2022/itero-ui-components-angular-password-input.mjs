import * as i0 from '@angular/core';
import { forwardRef, Input, ViewChild, Self, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i3 from '@angular/forms';
import { Validators, FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i1 from '@itero/ui-components-angular/core';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';

let nextUniqueId = 0;
class IuiPasswordInputComponent {
    /** Unique id of the element */
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    /** Whether the component is required. */
    get required() {
        return this._required ?? this.ngControlDirective.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    get _labelId() {
        return this.id + '-label';
    }
    get _inputId() {
        return this.id + '-input';
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get empty() {
        return this._value == null || this._value === '';
    }
    /** Current input type: 'password' when hidden, 'text' when visible */
    get _inputType() {
        return this._passwordVisible ? 'text' : 'password';
    }
    constructor(_changeDetectorRef, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._changeDetectorRef = _changeDetectorRef;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        /** Label text. Non-empty value shows the label row. */
        this.label = '';
        /** Placeholder for the native input */
        this.placeholder = '';
        /** Name attribute on native input */
        this.name = '';
        /** autocomplete attribute (e.g. 'current-password') */
        this.autocomplete = null;
        /** Background layer variant: 'set-01' (white) or 'set-02' (gray) */
        this.layerSet = 'set-01';
        /** Whether to show the skeleton loading state */
        this.skeleton = false;
        this.__focused = false;
        this._id = `iui-password-input-${nextUniqueId++}`;
        /** Whether the password is shown as plain text */
        this._passwordVisible = false;
        /** View -> model callback called when value changes */
        this._onChange = () => { };
        /** View -> model callback called when touched */
        this._onTouched = () => { };
    }
    get _value() {
        return this.__value;
    }
    set _value(newValue) {
        const hasAssigned = this._assignValue(newValue);
        if (hasAssigned) {
            this._onChange(newValue);
        }
    }
    get _focused() {
        return this.__focused;
    }
    _onFocus() {
        if (!this.disabled) {
            this.__focused = true;
        }
    }
    _onBlur() {
        this.__focused = false;
        if (!this.disabled) {
            this._onTouched();
            this._changeDetectorRef.markForCheck();
        }
    }
    _focusInput() {
        if (!this.disabled) {
            this.inputElement?.nativeElement.focus();
        }
    }
    _toggleVisibility(event) {
        event.stopPropagation();
        this._passwordVisible = !this._passwordVisible;
        this._changeDetectorRef.markForCheck();
    }
    writeValue(value) {
        this._assignValue(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._changeDetectorRef.markForCheck();
    }
    modelChangeHandler(value) {
        this._assignValue(value);
        this._onChange(value);
    }
    _assignValue(newValue) {
        if (newValue !== this.__value) {
            this.__value = newValue;
            this._changeDetectorRef.markForCheck();
            return true;
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiPasswordInputComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.NgControlDirective, self: true }, { token: i1.IuiErrorStateMatcherDirective, self: true }, { token: i1.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiPasswordInputComponent, isStandalone: true, selector: "iui-password-input", inputs: { id: "id", label: "label", placeholder: "placeholder", name: "name", autocomplete: "autocomplete", layerSet: "layerSet", skeleton: "skeleton", required: "required" }, host: { properties: { "class.iui-password-input_layer-set-02": "layerSet === \"set-02\"", "class.iui-password-input_required": "required", "class.iui-password-input_disabled": "disabled", "class.iui-password-input_invalid": "_errorState", "class.iui-password-input_focused": "_focused", "class.iui-password-input_filled": "!empty", "class.iui-password-input_skeleton": "skeleton", "class.iui-password-input_visible": "_passwordVisible", "attr.id": "id", "attr.data-testid": "id" }, classAttribute: "iui-password-input" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiPasswordInputComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true }], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\r\n\t<div class=\"iui-password-input__skeleton-field\"></div>\r\n\t<div class=\"iui-password-input__skeleton-helper\"></div>\r\n</ng-container>\r\n\r\n<ng-template #normalTemplate>\r\n\t<!-- Label row (shown when label is non-empty) -->\r\n\t<div class=\"iui-password-input__label-row\" *ngIf=\"label\">\r\n\t\t<label class=\"iui-password-input__label\" [attr.for]=\"_inputId\" [id]=\"_labelId\">\r\n\t\t\t{{ label }}<span class=\"iui-password-input__required\" *ngIf=\"required\">*</span>\r\n\t\t</label>\r\n\t\t<span class=\"iui-password-input__explainer\">\r\n\t\t\t<ng-content select=\"[iui-explainer]\"></ng-content>\r\n\t\t</span>\r\n\t\t<span class=\"iui-password-input__link\">\r\n\t\t\t<ng-content select=\"[iui-link]\"></ng-content>\r\n\t\t</span>\r\n\t</div>\r\n\r\n\t<!-- Field container -->\r\n\t<div class=\"iui-password-input__field\" (click)=\"_focusInput()\">\r\n\t\t<input\r\n\t\t\t#inputElement\r\n\t\t\tclass=\"iui-password-input__input\"\r\n\t\t\t[type]=\"_inputType\"\r\n\t\t\t[required]=\"required\"\r\n\t\t\t[disabled]=\"disabled\"\r\n\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t[name]=\"name\"\r\n\t\t\t[attr.name]=\"name\"\r\n\t\t\t[attr.autocomplete]=\"autocomplete\"\r\n\t\t\t[attr.aria-invalid]=\"_errorState\"\r\n\t\t\t[attr.aria-disabled]=\"disabled.toString()\"\r\n\t\t\t[attr.aria-labelledby]=\"label ? _labelId : null\"\r\n\t\t\t[id]=\"_inputId\"\r\n\t\t\t[ngModel]=\"_value\"\r\n\t\t\t(ngModelChange)=\"modelChangeHandler($event)\"\r\n\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t(blur)=\"_onBlur()\"\r\n\t\t/>\r\n\r\n\t\t<!-- Interactive visibility toggle (shown when filled and not disabled) -->\r\n\t\t<button\r\n\t\t\t*ngIf=\"!empty && !disabled\"\r\n\t\t\ttype=\"button\"\r\n\t\t\tclass=\"iui-password-input__visibility-btn\"\r\n\t\t\t[attr.aria-label]=\"_passwordVisible ? 'Hide password' : 'Show password'\"\r\n\t\t\t(click)=\"_toggleVisibility($event)\"\r\n\t\t\ttabindex=\"-1\"\r\n\t\t>\r\n\t\t\t<!-- Eye-open icon: shown when password is currently visible -->\r\n\t\t\t<!-- TODO: replace with <iui-eye-icon> once published in @itero/ui-components-angular/icons -->\r\n\t\t\t<svg *ngIf=\"_passwordVisible\" width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\">\r\n\t\t\t\t<path d=\"M1.5 10s3-6 8.5-6 8.5 6 8.5 6-3 6-8.5 6-8.5-6-8.5-6z\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linejoin=\"round\"/>\r\n\t\t\t\t<circle cx=\"10\" cy=\"10\" r=\"2.5\" stroke=\"currentColor\" stroke-width=\"1.5\"/>\r\n\t\t\t</svg>\r\n\t\t\t<!-- Eye-slash icon: shown when password is masked -->\r\n\t\t\t<!-- TODO: replace with <iui-eye-slash-icon> once published in @itero/ui-components-angular/icons -->\r\n\t\t\t<svg *ngIf=\"!_passwordVisible\" width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\">\r\n\t\t\t\t<path d=\"M3 3l14 14M8.5 8.5a2.5 2.5 0 0 0 3 3M5 5.2C3 6.6 1.5 8.8 1.5 10s3 6 8.5 6c1.7 0 3.2-.5 4.5-1.2M9 4.1C9.3 4 9.6 4 10 4c5.5 0 8.5 6 8.5 6s-.7 1.4-2 2.7\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n\t\t\t</svg>\r\n\t\t</button>\r\n\r\n\t\t<!-- Static decorative eye-slash icon in disabled+filled state -->\r\n\t\t<span *ngIf=\"!empty && disabled\" class=\"iui-password-input__visibility-icon\" aria-hidden=\"true\">\r\n\t\t\t<!-- TODO: replace with <iui-eye-slash-icon> once published in @itero/ui-components-angular/icons -->\r\n\t\t\t<svg width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\">\r\n\t\t\t\t<path d=\"M3 3l14 14M8.5 8.5a2.5 2.5 0 0 0 3 3M5 5.2C3 6.6 1.5 8.8 1.5 10s3 6 8.5 6c1.7 0 3.2-.5 4.5-1.2M9 4.1C9.3 4 9.6 4 10 4c5.5 0 8.5 6 8.5 6s-.7 1.4-2 2.7\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n\t\t\t</svg>\r\n\t\t</span>\r\n\t</div>\r\n\r\n\t<!-- Helper / Error row -->\r\n\t<div class=\"iui-password-input__helper-row\">\r\n\t\t<span *ngIf=\"_errorState\" class=\"iui-password-input__error\">\r\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t</span>\r\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-password-input__helper\">\r\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t</span>\r\n\t</div>\r\n</ng-template>\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;min-width:206px;max-width:100%}.iui-password-input__label-row{display:flex;align-items:flex-start;justify-content:space-between;padding-bottom:8px}.iui-password-input__label{font:var(--iui-tp-label-01-font);color:var(--iui-password-input-label-color);flex:1;min-width:1px}.iui-password-input__required{color:var(--iui-password-input-error-color);margin-left:4px}.iui-password-input__explainer{display:inline-flex;align-items:center;flex-shrink:0;margin-left:4px}.iui-password-input__explainer:empty{display:none}.iui-password-input__link{display:inline-flex;align-items:center;flex-shrink:0;margin-left:auto;padding-left:8px;font:var(--iui-tp-label-01-font)}.iui-password-input__link:empty{display:none}.iui-password-input__field{display:flex;align-items:center;gap:8px;overflow:hidden;background:var(--iui-password-input-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);padding:12px 16px;cursor:text;transition:border-color .2s ease-out}.iui-password-input__input{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-password-input-color);background:transparent;border:none;outline:none;padding:0;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.iui-password-input__input::placeholder{color:var(--iui-password-input-placeholder-color)}.iui-password-input__input:disabled{color:var(--iui-password-input-disabled-color)}.iui-password-input__input:disabled::placeholder{color:var(--iui-password-input-disabled-color)}.iui-password-input__visibility-btn{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;padding:0;margin:0;background:transparent;border:none;outline:none;cursor:pointer;color:var(--iui-password-input-icon-color)}.iui-password-input__visibility-btn:focus-visible{outline:2px solid var(--iui-password-input-focus-border);border-radius:2px}.iui-password-input__visibility-icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:var(--iui-password-input-icon-disabled-color)}.iui-password-input__helper-row{padding-top:8px}.iui-password-input__helper{font:var(--iui-tp-label-01-font);color:var(--iui-password-input-helper-color)}.iui-password-input__error{font:var(--iui-tp-label-01-font);color:var(--iui-password-input-error-color)}:host.iui-password-input_focused .iui-password-input__field{border-color:var(--iui-password-input-focus-border)}:host.iui-password-input_invalid .iui-password-input__field{border-color:var(--iui-password-input-error-border)}:host.iui-password-input_disabled .iui-password-input__field{cursor:default;pointer-events:none}:host.iui-password-input_disabled .iui-password-input__label{color:var(--iui-password-input-disabled-color)}:host.iui-password-input_disabled .iui-password-input__helper{color:var(--iui-password-input-disabled-color)}:host.iui-password-input_layer-set-02 .iui-password-input__field{background:var(--iui-password-input-bg-layer-02)}.iui-password-input__skeleton-field{height:44px;border-radius:var(--iui-border-radius-medium);background:var(--iui-password-input-skeleton-bg)}.iui-password-input__skeleton-helper{margin-top:8px;width:40px;height:8px;background:var(--iui-password-input-skeleton-bg)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiPasswordInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-password-input', standalone: true, imports: [CommonModule, FormsModule], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiPasswordInputComponent),
                            multi: true
                        }
                    ], host: {
                        class: 'iui-password-input',
                        '[class.iui-password-input_layer-set-02]': 'layerSet === "set-02"',
                        '[class.iui-password-input_required]': 'required',
                        '[class.iui-password-input_disabled]': 'disabled',
                        '[class.iui-password-input_invalid]': '_errorState',
                        '[class.iui-password-input_focused]': '_focused',
                        '[class.iui-password-input_filled]': '!empty',
                        '[class.iui-password-input_skeleton]': 'skeleton',
                        '[class.iui-password-input_visible]': '_passwordVisible',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\r\n\t<div class=\"iui-password-input__skeleton-field\"></div>\r\n\t<div class=\"iui-password-input__skeleton-helper\"></div>\r\n</ng-container>\r\n\r\n<ng-template #normalTemplate>\r\n\t<!-- Label row (shown when label is non-empty) -->\r\n\t<div class=\"iui-password-input__label-row\" *ngIf=\"label\">\r\n\t\t<label class=\"iui-password-input__label\" [attr.for]=\"_inputId\" [id]=\"_labelId\">\r\n\t\t\t{{ label }}<span class=\"iui-password-input__required\" *ngIf=\"required\">*</span>\r\n\t\t</label>\r\n\t\t<span class=\"iui-password-input__explainer\">\r\n\t\t\t<ng-content select=\"[iui-explainer]\"></ng-content>\r\n\t\t</span>\r\n\t\t<span class=\"iui-password-input__link\">\r\n\t\t\t<ng-content select=\"[iui-link]\"></ng-content>\r\n\t\t</span>\r\n\t</div>\r\n\r\n\t<!-- Field container -->\r\n\t<div class=\"iui-password-input__field\" (click)=\"_focusInput()\">\r\n\t\t<input\r\n\t\t\t#inputElement\r\n\t\t\tclass=\"iui-password-input__input\"\r\n\t\t\t[type]=\"_inputType\"\r\n\t\t\t[required]=\"required\"\r\n\t\t\t[disabled]=\"disabled\"\r\n\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t[name]=\"name\"\r\n\t\t\t[attr.name]=\"name\"\r\n\t\t\t[attr.autocomplete]=\"autocomplete\"\r\n\t\t\t[attr.aria-invalid]=\"_errorState\"\r\n\t\t\t[attr.aria-disabled]=\"disabled.toString()\"\r\n\t\t\t[attr.aria-labelledby]=\"label ? _labelId : null\"\r\n\t\t\t[id]=\"_inputId\"\r\n\t\t\t[ngModel]=\"_value\"\r\n\t\t\t(ngModelChange)=\"modelChangeHandler($event)\"\r\n\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t(blur)=\"_onBlur()\"\r\n\t\t/>\r\n\r\n\t\t<!-- Interactive visibility toggle (shown when filled and not disabled) -->\r\n\t\t<button\r\n\t\t\t*ngIf=\"!empty && !disabled\"\r\n\t\t\ttype=\"button\"\r\n\t\t\tclass=\"iui-password-input__visibility-btn\"\r\n\t\t\t[attr.aria-label]=\"_passwordVisible ? 'Hide password' : 'Show password'\"\r\n\t\t\t(click)=\"_toggleVisibility($event)\"\r\n\t\t\ttabindex=\"-1\"\r\n\t\t>\r\n\t\t\t<!-- Eye-open icon: shown when password is currently visible -->\r\n\t\t\t<!-- TODO: replace with <iui-eye-icon> once published in @itero/ui-components-angular/icons -->\r\n\t\t\t<svg *ngIf=\"_passwordVisible\" width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\">\r\n\t\t\t\t<path d=\"M1.5 10s3-6 8.5-6 8.5 6 8.5 6-3 6-8.5 6-8.5-6-8.5-6z\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linejoin=\"round\"/>\r\n\t\t\t\t<circle cx=\"10\" cy=\"10\" r=\"2.5\" stroke=\"currentColor\" stroke-width=\"1.5\"/>\r\n\t\t\t</svg>\r\n\t\t\t<!-- Eye-slash icon: shown when password is masked -->\r\n\t\t\t<!-- TODO: replace with <iui-eye-slash-icon> once published in @itero/ui-components-angular/icons -->\r\n\t\t\t<svg *ngIf=\"!_passwordVisible\" width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\">\r\n\t\t\t\t<path d=\"M3 3l14 14M8.5 8.5a2.5 2.5 0 0 0 3 3M5 5.2C3 6.6 1.5 8.8 1.5 10s3 6 8.5 6c1.7 0 3.2-.5 4.5-1.2M9 4.1C9.3 4 9.6 4 10 4c5.5 0 8.5 6 8.5 6s-.7 1.4-2 2.7\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n\t\t\t</svg>\r\n\t\t</button>\r\n\r\n\t\t<!-- Static decorative eye-slash icon in disabled+filled state -->\r\n\t\t<span *ngIf=\"!empty && disabled\" class=\"iui-password-input__visibility-icon\" aria-hidden=\"true\">\r\n\t\t\t<!-- TODO: replace with <iui-eye-slash-icon> once published in @itero/ui-components-angular/icons -->\r\n\t\t\t<svg width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\">\r\n\t\t\t\t<path d=\"M3 3l14 14M8.5 8.5a2.5 2.5 0 0 0 3 3M5 5.2C3 6.6 1.5 8.8 1.5 10s3 6 8.5 6c1.7 0 3.2-.5 4.5-1.2M9 4.1C9.3 4 9.6 4 10 4c5.5 0 8.5 6 8.5 6s-.7 1.4-2 2.7\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n\t\t\t</svg>\r\n\t\t</span>\r\n\t</div>\r\n\r\n\t<!-- Helper / Error row -->\r\n\t<div class=\"iui-password-input__helper-row\">\r\n\t\t<span *ngIf=\"_errorState\" class=\"iui-password-input__error\">\r\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t</span>\r\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-password-input__helper\">\r\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t</span>\r\n\t</div>\r\n</ng-template>\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;min-width:206px;max-width:100%}.iui-password-input__label-row{display:flex;align-items:flex-start;justify-content:space-between;padding-bottom:8px}.iui-password-input__label{font:var(--iui-tp-label-01-font);color:var(--iui-password-input-label-color);flex:1;min-width:1px}.iui-password-input__required{color:var(--iui-password-input-error-color);margin-left:4px}.iui-password-input__explainer{display:inline-flex;align-items:center;flex-shrink:0;margin-left:4px}.iui-password-input__explainer:empty{display:none}.iui-password-input__link{display:inline-flex;align-items:center;flex-shrink:0;margin-left:auto;padding-left:8px;font:var(--iui-tp-label-01-font)}.iui-password-input__link:empty{display:none}.iui-password-input__field{display:flex;align-items:center;gap:8px;overflow:hidden;background:var(--iui-password-input-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);padding:12px 16px;cursor:text;transition:border-color .2s ease-out}.iui-password-input__input{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-password-input-color);background:transparent;border:none;outline:none;padding:0;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.iui-password-input__input::placeholder{color:var(--iui-password-input-placeholder-color)}.iui-password-input__input:disabled{color:var(--iui-password-input-disabled-color)}.iui-password-input__input:disabled::placeholder{color:var(--iui-password-input-disabled-color)}.iui-password-input__visibility-btn{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;padding:0;margin:0;background:transparent;border:none;outline:none;cursor:pointer;color:var(--iui-password-input-icon-color)}.iui-password-input__visibility-btn:focus-visible{outline:2px solid var(--iui-password-input-focus-border);border-radius:2px}.iui-password-input__visibility-icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:var(--iui-password-input-icon-disabled-color)}.iui-password-input__helper-row{padding-top:8px}.iui-password-input__helper{font:var(--iui-tp-label-01-font);color:var(--iui-password-input-helper-color)}.iui-password-input__error{font:var(--iui-tp-label-01-font);color:var(--iui-password-input-error-color)}:host.iui-password-input_focused .iui-password-input__field{border-color:var(--iui-password-input-focus-border)}:host.iui-password-input_invalid .iui-password-input__field{border-color:var(--iui-password-input-error-border)}:host.iui-password-input_disabled .iui-password-input__field{cursor:default;pointer-events:none}:host.iui-password-input_disabled .iui-password-input__label{color:var(--iui-password-input-disabled-color)}:host.iui-password-input_disabled .iui-password-input__helper{color:var(--iui-password-input-disabled-color)}:host.iui-password-input_layer-set-02 .iui-password-input__field{background:var(--iui-password-input-bg-layer-02)}.iui-password-input__skeleton-field{height:44px;border-radius:var(--iui-border-radius-medium);background:var(--iui-password-input-skeleton-bg)}.iui-password-input__skeleton-helper{margin-top:8px;width:40px;height:8px;background:var(--iui-password-input-skeleton-bg)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { inputElement: [{
                type: ViewChild,
                args: ['inputElement']
            }], id: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], name: [{
                type: Input
            }], autocomplete: [{
                type: Input
            }], layerSet: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], required: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiPasswordInputComponent };
//# sourceMappingURL=itero-ui-components-angular-password-input.mjs.map
