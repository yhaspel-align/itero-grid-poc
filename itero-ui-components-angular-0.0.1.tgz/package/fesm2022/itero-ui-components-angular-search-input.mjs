import * as i0 from '@angular/core';
import { EventEmitter, forwardRef, Output, Input, ViewChild, Self, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i3 from '@angular/forms';
import { FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i1 from '@itero/ui-components-angular/core';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import { SearchIconComponent, CloseEmptyIconComponent } from '@itero/ui-components-angular/icons';

let nextUniqueId = 0;
class IuiSearchInputComponent {
    /** Unique id of the component */
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    get _inputId() {
        return this._id + '-input';
    }
    get empty() {
        return this._value == null || this._value === '';
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get _focused() {
        return this.__focused;
    }
    get _value() {
        return this.__value;
    }
    set _value(newValue) {
        if (newValue !== this.__value) {
            this.__value = newValue;
            this._onChange(newValue);
            this._changeDetectorRef.markForCheck();
        }
    }
    constructor(_changeDetectorRef, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._changeDetectorRef = _changeDetectorRef;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        /** Size of the search field: large (default), medium, small */
        this.size = 'l';
        /** Layer set: set-01 (white bg, default) or set-02 (gray bg) */
        this.layerSet = 'set-01';
        /** Placeholder text shown when the field is empty */
        this.placeholder = 'Search';
        /** Name attribute for the native input */
        this.name = '';
        /** When true, the suggestions dropdown panel (ng-content) is shown */
        this.showMenu = false;
        /** Whether to show the skeleton loading state */
        this.skeleton = false;
        /** Emitted when the input value changes */
        this.valueChange = new EventEmitter();
        /** Emitted when the clear (×) button is clicked */
        this.clearClick = new EventEmitter();
        /** Emitted when the user presses Enter */
        this.searchSubmit = new EventEmitter();
        this._id = `iui-search-input-${nextUniqueId++}`;
        this.__focused = false;
        this._onChange = () => { };
        this._onTouched = () => { };
    }
    _onModelChange(value) {
        this.__value = value;
        this._onChange(value);
        this.valueChange.emit(value);
        this._changeDetectorRef.markForCheck();
    }
    _onFocus() {
        if (!this.disabled) {
            this.__focused = true;
            this._changeDetectorRef.markForCheck();
        }
    }
    _onBlur() {
        this.__focused = false;
        if (!this.disabled) {
            this._onTouched();
            this._changeDetectorRef.markForCheck();
        }
    }
    _onEnter() {
        if (!this.disabled && this._value != null && this._value !== '') {
            this.searchSubmit.emit(this._value);
        }
    }
    _onClear(event) {
        event.stopPropagation();
        if (!this.disabled) {
            this._value = '';
            this.valueChange.emit('');
            this.clearClick.emit();
            this._focusInput();
        }
    }
    _focusInput() {
        if (!this.disabled) {
            this.inputElement?.nativeElement.focus();
        }
    }
    writeValue(value) {
        if (value !== this.__value) {
            this.__value = value;
            this._changeDetectorRef.markForCheck();
        }
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._changeDetectorRef.markForCheck();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiSearchInputComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.NgControlDirective, self: true }, { token: i1.IuiErrorStateMatcherDirective, self: true }, { token: i1.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiSearchInputComponent, isStandalone: true, selector: "iui-search-input", inputs: { id: "id", size: "size", layerSet: "layerSet", placeholder: "placeholder", name: "name", showMenu: "showMenu", skeleton: "skeleton" }, outputs: { valueChange: "valueChange", clearClick: "clearClick", searchSubmit: "searchSubmit" }, host: { properties: { "class.iui-search-input_size_l": "size === \"l\"", "class.iui-search-input_size_m": "size === \"m\"", "class.iui-search-input_size_s": "size === \"s\"", "class.iui-search-input_layer-set-02": "layerSet === \"set-02\"", "class.iui-search-input_filled": "!empty", "class.iui-search-input_focused": "_focused", "class.iui-search-input_disabled": "disabled", "class.iui-search-input_skeleton": "skeleton", "class.iui-search-input_menu-open": "showMenu", "attr.id": "id", "attr.data-testid": "id" }, classAttribute: "iui-search-input" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiSearchInputComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true }], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\r\n\t<div class=\"iui-search-input__skeleton\"></div>\r\n</ng-container>\r\n\r\n<ng-template #normalTemplate>\r\n\t<div class=\"iui-search-input__field\" (click)=\"_focusInput()\">\r\n\t\t<!-- Scroll mask hides overflowing text on the left when filled -->\r\n\t\t<div *ngIf=\"!empty\" class=\"iui-search-input__scroll-mask\"></div>\r\n\r\n\t\t<iui-search-icon\r\n\t\t\tclass=\"iui-search-input__search-icon iui-icon iui-icon_size_s\"\r\n\t\t\taria-hidden=\"true\"\r\n\t\t></iui-search-icon>\r\n\r\n\t\t<input\r\n\t\t\t#inputElement\r\n\t\t\tclass=\"iui-search-input__input\"\r\n\t\t\t[id]=\"_inputId\"\r\n\t\t\t[name]=\"name\"\r\n\t\t\t[attr.name]=\"name\"\r\n\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t[disabled]=\"disabled\"\r\n\t\t\t[attr.aria-disabled]=\"disabled.toString()\"\r\n\t\t\t[attr.aria-invalid]=\"_errorState\"\r\n\t\t\t[ngModel]=\"_value\"\r\n\t\t\t(ngModelChange)=\"_onModelChange($event)\"\r\n\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t(keydown.enter)=\"_onEnter()\"\r\n\t\t\ttype=\"text\"\r\n\t\t\tautocomplete=\"off\"\r\n\t\t/>\r\n\r\n\t\t<button\r\n\t\t\t*ngIf=\"!empty && !disabled\"\r\n\t\t\ttype=\"button\"\r\n\t\t\tclass=\"iui-search-input__clear-btn\"\r\n\t\t\t[attr.aria-label]=\"'Clear'\"\r\n\t\t\t(click)=\"_onClear($event)\"\r\n\t\t>\r\n\t\t\t<iui-close-empty-icon\r\n\t\t\t\tclass=\"iui-icon iui-icon_size_s\"\r\n\t\t\t\taria-hidden=\"true\"\r\n\t\t\t></iui-close-empty-icon>\r\n\t\t</button>\r\n\t</div>\r\n\r\n\t<div *ngIf=\"showMenu\" class=\"iui-search-input__menu\">\r\n\t\t<ng-content></ng-content>\r\n\t</div>\r\n</ng-template>\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{--iui-search-input-bg: var(--iui-background-layer-01);--iui-search-input-bg-layer-02: var(--iui-background-subtle-01);--iui-search-input-text: var(--iui-text-primary);--iui-search-input-placeholder: var(--iui-text-tertiary);--iui-search-input-icon: var(--iui-icon-secondary);--iui-search-input-icon-filled: var(--iui-icon-primary);--iui-search-input-clear-icon: var(--iui-icon-secondary);--iui-search-input-focus-border: var(--iui-border-focus);--iui-search-input-disabled-text: var(--iui-text-disabled);--iui-search-input-disabled-icon: var(--iui-icon-disabled);--iui-search-input-skeleton-bg: var(--iui-background-subtle-01);--iui-search-input-menu-bg: var(--iui-background-menu);--iui-search-input-menu-shadow: var(--iui-box-shadow-s);--iui-search-input-height: 44px;--iui-search-input-py: 12px;--iui-search-input-px: 12px;--iui-search-input-gap: 8px;--iui-search-input-icon-size: 20px;--iui-search-input-mask-width: 48px;display:block;position:relative;min-width:180px;max-width:100%}:host.iui-search-input_size_m{--iui-search-input-height: 36px;--iui-search-input-py: 8px;--iui-search-input-px: 12px;--iui-search-input-gap: 8px;--iui-search-input-icon-size: 16px;--iui-search-input-mask-width: 40px}:host.iui-search-input_size_s{--iui-search-input-height: 28px;--iui-search-input-py: 4px;--iui-search-input-px: 8px;--iui-search-input-gap: 4px;--iui-search-input-icon-size: 16px;--iui-search-input-mask-width: 32px}:host.iui-search-input_layer-set-02 .iui-search-input__field{background:var(--iui-search-input-bg-layer-02)}.iui-search-input__field{position:relative;display:flex;align-items:center;gap:var(--iui-search-input-gap);height:var(--iui-search-input-height);padding:var(--iui-search-input-py) var(--iui-search-input-px);background:var(--iui-search-input-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);overflow:hidden;cursor:text;transition:border-color .2s ease-out}:host.iui-search-input_focused .iui-search-input__field{border-color:var(--iui-search-input-focus-border)}:host.iui-search-input_menu-open .iui-search-input__field{border-radius:var(--iui-border-radius-medium) var(--iui-border-radius-medium) 0 0}:host.iui-search-input_disabled .iui-search-input__field{pointer-events:none;cursor:default}.iui-search-input__scroll-mask{position:absolute;left:0;top:0;bottom:0;width:var(--iui-search-input-mask-width);background:inherit;border-radius:var(--iui-border-radius-medium) 0 0 var(--iui-border-radius-medium);z-index:1;pointer-events:none}.iui-search-input__search-icon{flex-shrink:0;color:var(--iui-search-input-icon);width:var(--iui-search-input-icon-size);height:var(--iui-search-input-icon-size);z-index:2}:host.iui-search-input_filled .iui-search-input__search-icon{color:var(--iui-search-input-icon-filled)}:host.iui-search-input_disabled .iui-search-input__search-icon{color:var(--iui-search-input-disabled-icon)}.iui-search-input__input{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-search-input-text);background:transparent;border:none;outline:none;padding:0;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.iui-search-input__input::placeholder{color:var(--iui-search-input-placeholder)}.iui-search-input__input:disabled{color:var(--iui-search-input-disabled-text)}.iui-search-input__input:disabled::placeholder{color:var(--iui-search-input-disabled-text)}.iui-search-input__clear-btn{flex-shrink:0;display:flex;align-items:center;justify-content:center;background:transparent;border:none;padding:0;cursor:pointer;color:var(--iui-search-input-clear-icon);z-index:2}.iui-search-input__clear-btn:focus{outline:none}:host.iui-search-input_disabled .iui-search-input__clear-btn{display:none}.iui-search-input__menu{position:absolute;top:100%;left:0;right:0;background:var(--iui-search-input-menu-bg);box-shadow:var(--iui-search-input-menu-shadow);border-radius:0 0 var(--iui-border-radius-medium) var(--iui-border-radius-medium);padding:4px 0;z-index:100}.iui-search-input__skeleton{height:var(--iui-search-input-height);border-radius:var(--iui-border-radius-medium);background:var(--iui-search-input-skeleton-bg)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: SearchIconComponent, selector: "iui-search-icon" }, { kind: "component", type: CloseEmptyIconComponent, selector: "iui-close-empty-icon" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiSearchInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-search-input', standalone: true, imports: [CommonModule, FormsModule, SearchIconComponent, CloseEmptyIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiSearchInputComponent),
                            multi: true
                        }
                    ], host: {
                        class: 'iui-search-input',
                        '[class.iui-search-input_size_l]': 'size === "l"',
                        '[class.iui-search-input_size_m]': 'size === "m"',
                        '[class.iui-search-input_size_s]': 'size === "s"',
                        '[class.iui-search-input_layer-set-02]': 'layerSet === "set-02"',
                        '[class.iui-search-input_filled]': '!empty',
                        '[class.iui-search-input_focused]': '_focused',
                        '[class.iui-search-input_disabled]': 'disabled',
                        '[class.iui-search-input_skeleton]': 'skeleton',
                        '[class.iui-search-input_menu-open]': 'showMenu',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\r\n\t<div class=\"iui-search-input__skeleton\"></div>\r\n</ng-container>\r\n\r\n<ng-template #normalTemplate>\r\n\t<div class=\"iui-search-input__field\" (click)=\"_focusInput()\">\r\n\t\t<!-- Scroll mask hides overflowing text on the left when filled -->\r\n\t\t<div *ngIf=\"!empty\" class=\"iui-search-input__scroll-mask\"></div>\r\n\r\n\t\t<iui-search-icon\r\n\t\t\tclass=\"iui-search-input__search-icon iui-icon iui-icon_size_s\"\r\n\t\t\taria-hidden=\"true\"\r\n\t\t></iui-search-icon>\r\n\r\n\t\t<input\r\n\t\t\t#inputElement\r\n\t\t\tclass=\"iui-search-input__input\"\r\n\t\t\t[id]=\"_inputId\"\r\n\t\t\t[name]=\"name\"\r\n\t\t\t[attr.name]=\"name\"\r\n\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t[disabled]=\"disabled\"\r\n\t\t\t[attr.aria-disabled]=\"disabled.toString()\"\r\n\t\t\t[attr.aria-invalid]=\"_errorState\"\r\n\t\t\t[ngModel]=\"_value\"\r\n\t\t\t(ngModelChange)=\"_onModelChange($event)\"\r\n\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t(keydown.enter)=\"_onEnter()\"\r\n\t\t\ttype=\"text\"\r\n\t\t\tautocomplete=\"off\"\r\n\t\t/>\r\n\r\n\t\t<button\r\n\t\t\t*ngIf=\"!empty && !disabled\"\r\n\t\t\ttype=\"button\"\r\n\t\t\tclass=\"iui-search-input__clear-btn\"\r\n\t\t\t[attr.aria-label]=\"'Clear'\"\r\n\t\t\t(click)=\"_onClear($event)\"\r\n\t\t>\r\n\t\t\t<iui-close-empty-icon\r\n\t\t\t\tclass=\"iui-icon iui-icon_size_s\"\r\n\t\t\t\taria-hidden=\"true\"\r\n\t\t\t></iui-close-empty-icon>\r\n\t\t</button>\r\n\t</div>\r\n\r\n\t<div *ngIf=\"showMenu\" class=\"iui-search-input__menu\">\r\n\t\t<ng-content></ng-content>\r\n\t</div>\r\n</ng-template>\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{--iui-search-input-bg: var(--iui-background-layer-01);--iui-search-input-bg-layer-02: var(--iui-background-subtle-01);--iui-search-input-text: var(--iui-text-primary);--iui-search-input-placeholder: var(--iui-text-tertiary);--iui-search-input-icon: var(--iui-icon-secondary);--iui-search-input-icon-filled: var(--iui-icon-primary);--iui-search-input-clear-icon: var(--iui-icon-secondary);--iui-search-input-focus-border: var(--iui-border-focus);--iui-search-input-disabled-text: var(--iui-text-disabled);--iui-search-input-disabled-icon: var(--iui-icon-disabled);--iui-search-input-skeleton-bg: var(--iui-background-subtle-01);--iui-search-input-menu-bg: var(--iui-background-menu);--iui-search-input-menu-shadow: var(--iui-box-shadow-s);--iui-search-input-height: 44px;--iui-search-input-py: 12px;--iui-search-input-px: 12px;--iui-search-input-gap: 8px;--iui-search-input-icon-size: 20px;--iui-search-input-mask-width: 48px;display:block;position:relative;min-width:180px;max-width:100%}:host.iui-search-input_size_m{--iui-search-input-height: 36px;--iui-search-input-py: 8px;--iui-search-input-px: 12px;--iui-search-input-gap: 8px;--iui-search-input-icon-size: 16px;--iui-search-input-mask-width: 40px}:host.iui-search-input_size_s{--iui-search-input-height: 28px;--iui-search-input-py: 4px;--iui-search-input-px: 8px;--iui-search-input-gap: 4px;--iui-search-input-icon-size: 16px;--iui-search-input-mask-width: 32px}:host.iui-search-input_layer-set-02 .iui-search-input__field{background:var(--iui-search-input-bg-layer-02)}.iui-search-input__field{position:relative;display:flex;align-items:center;gap:var(--iui-search-input-gap);height:var(--iui-search-input-height);padding:var(--iui-search-input-py) var(--iui-search-input-px);background:var(--iui-search-input-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);overflow:hidden;cursor:text;transition:border-color .2s ease-out}:host.iui-search-input_focused .iui-search-input__field{border-color:var(--iui-search-input-focus-border)}:host.iui-search-input_menu-open .iui-search-input__field{border-radius:var(--iui-border-radius-medium) var(--iui-border-radius-medium) 0 0}:host.iui-search-input_disabled .iui-search-input__field{pointer-events:none;cursor:default}.iui-search-input__scroll-mask{position:absolute;left:0;top:0;bottom:0;width:var(--iui-search-input-mask-width);background:inherit;border-radius:var(--iui-border-radius-medium) 0 0 var(--iui-border-radius-medium);z-index:1;pointer-events:none}.iui-search-input__search-icon{flex-shrink:0;color:var(--iui-search-input-icon);width:var(--iui-search-input-icon-size);height:var(--iui-search-input-icon-size);z-index:2}:host.iui-search-input_filled .iui-search-input__search-icon{color:var(--iui-search-input-icon-filled)}:host.iui-search-input_disabled .iui-search-input__search-icon{color:var(--iui-search-input-disabled-icon)}.iui-search-input__input{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-search-input-text);background:transparent;border:none;outline:none;padding:0;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.iui-search-input__input::placeholder{color:var(--iui-search-input-placeholder)}.iui-search-input__input:disabled{color:var(--iui-search-input-disabled-text)}.iui-search-input__input:disabled::placeholder{color:var(--iui-search-input-disabled-text)}.iui-search-input__clear-btn{flex-shrink:0;display:flex;align-items:center;justify-content:center;background:transparent;border:none;padding:0;cursor:pointer;color:var(--iui-search-input-clear-icon);z-index:2}.iui-search-input__clear-btn:focus{outline:none}:host.iui-search-input_disabled .iui-search-input__clear-btn{display:none}.iui-search-input__menu{position:absolute;top:100%;left:0;right:0;background:var(--iui-search-input-menu-bg);box-shadow:var(--iui-search-input-menu-shadow);border-radius:0 0 var(--iui-border-radius-medium) var(--iui-border-radius-medium);padding:4px 0;z-index:100}.iui-search-input__skeleton{height:var(--iui-search-input-height);border-radius:var(--iui-border-radius-medium);background:var(--iui-search-input-skeleton-bg)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { inputElement: [{
                type: ViewChild,
                args: ['inputElement']
            }], id: [{
                type: Input
            }], size: [{
                type: Input
            }], layerSet: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], name: [{
                type: Input
            }], showMenu: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], clearClick: [{
                type: Output
            }], searchSubmit: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiSearchInputComponent };
//# sourceMappingURL=itero-ui-components-angular-search-input.mjs.map
