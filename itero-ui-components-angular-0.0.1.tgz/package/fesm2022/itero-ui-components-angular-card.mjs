import * as i0 from '@angular/core';
import { Input, Component } from '@angular/core';

class IuiCardComponent {
    set padding(value) {
        this._padding = value + 'px';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiCardComponent, isStandalone: true, selector: "iui-card", inputs: { padding: "padding" }, host: { properties: { "style.--iui-card-padding-local": "_padding" }, classAttribute: "iui-card" }, ngImport: i0, template: "<ng-content></ng-content>\n", styles: [":host{--iui-card-padding-local: var(--iui-card-padding);display:flex;flex-direction:column;box-sizing:border-box;background:var(--iui-card-bg);border-radius:var(--iui-card-border-radius);border:var(--iui-border-width) solid var(--iui-card-border);overflow:hidden}:host ::ng-deep [iuiCardHeader]{display:block;box-sizing:border-box;padding:var(--iui-card-padding-local) var(--iui-card-padding-local) calc(var(--iui-card-padding-local) / 2) var(--iui-card-padding-local);font:var(--iui-tp-heading-04-font)}:host ::ng-deep [iuiCardContent]{display:block;box-sizing:border-box;font:var(--iui-tp-body-02-font);padding:calc(var(--iui-card-padding-local) / 2) var(--iui-card-padding-local)}:host ::ng-deep [iuiCardContent]:first-child{padding-top:var(--iui-card-padding-local)}:host ::ng-deep [iuiCardContent]:last-child{padding-bottom:var(--iui-card-padding-local)}:host ::ng-deep [iuiCardContent]>:last-child{margin-bottom:0}:host ::ng-deep [iuiCardFooter]{display:block;margin-top:auto;box-sizing:border-box;padding:calc(var(--iui-card-padding-local) / 2) var(--iui-card-padding-local) var(--iui-card-padding-local) var(--iui-card-padding-local)}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-card', standalone: true, host: {
                        'class': 'iui-card',
                        '[style.--iui-card-padding-local]': '_padding'
                    }, template: "<ng-content></ng-content>\n", styles: [":host{--iui-card-padding-local: var(--iui-card-padding);display:flex;flex-direction:column;box-sizing:border-box;background:var(--iui-card-bg);border-radius:var(--iui-card-border-radius);border:var(--iui-border-width) solid var(--iui-card-border);overflow:hidden}:host ::ng-deep [iuiCardHeader]{display:block;box-sizing:border-box;padding:var(--iui-card-padding-local) var(--iui-card-padding-local) calc(var(--iui-card-padding-local) / 2) var(--iui-card-padding-local);font:var(--iui-tp-heading-04-font)}:host ::ng-deep [iuiCardContent]{display:block;box-sizing:border-box;font:var(--iui-tp-body-02-font);padding:calc(var(--iui-card-padding-local) / 2) var(--iui-card-padding-local)}:host ::ng-deep [iuiCardContent]:first-child{padding-top:var(--iui-card-padding-local)}:host ::ng-deep [iuiCardContent]:last-child{padding-bottom:var(--iui-card-padding-local)}:host ::ng-deep [iuiCardContent]>:last-child{margin-bottom:0}:host ::ng-deep [iuiCardFooter]{display:block;margin-top:auto;box-sizing:border-box;padding:calc(var(--iui-card-padding-local) / 2) var(--iui-card-padding-local) var(--iui-card-padding-local) var(--iui-card-padding-local)}\n"] }]
        }], propDecorators: { padding: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiCardComponent };
//# sourceMappingURL=itero-ui-components-angular-card.mjs.map
