import { CdkListbox, CdkOption } from '@angular/cdk/listbox';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i0 from '@angular/core';
import { inject, ChangeDetectorRef, forwardRef, Input, Component } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { IuiCheckboxComponent } from '@itero/ui-components-angular/checkbox';
import { IuiRadioButtonComponent } from '@itero/ui-components-angular/radio-button';

class IuiListboxComponent extends CdkListbox {
    constructor() {
        super(...arguments);
        this.size = 'l';
        this.hideSelectionIndicator = false;
        this.togglePosition = 'after';
        this._changeDetectorRef = inject(ChangeDetectorRef);
    }
    get multipleSelection() {
        return super.multiple;
    }
    set multipleSelection(value) {
        const newValue = coerceBooleanProperty(value);
        if (newValue !== super.multiple) {
            super.multiple = newValue;
        }
    }
    /**
     * @method
     * @ignore
     */
    ngOnChanges(changes) {
        const size = changes['size'];
        if (size && size.currentValue !== size.previousValue) {
            this.updateChildren();
        }
    }
    /**
     * @method
     * @ignore
     */
    ngAfterContentInit() {
        super.ngAfterContentInit();
        this.updateChildren();
    }
    /**
     * @method
     * @ignore
     */
    updateChildren() {
        this.options?.forEach(option => {
            option.size = this.size;
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiListboxComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiListboxComponent, isStandalone: true, selector: "iui-listbox", inputs: { size: "size", multipleSelection: ["multiple", "multipleSelection"], hideSelectionIndicator: "hideSelectionIndicator", togglePosition: "togglePosition" }, host: { properties: { "class.iui-listbox": "true", "attr.disabled": "disabled ? true : null" } }, providers: [
            { provide: CdkListbox, useExisting: IuiListboxComponent },
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiListboxComponent),
                multi: true
            }
        ], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '<ng-content select="iui-listbox-option"></ng-content>', isInline: true, styles: [":host{display:flex;flex-direction:column;-webkit-user-select:none;user-select:none;outline:none;border:none;text-decoration:none;-webkit-tap-highlight-color:transparent;transition:background-color .2s ease-out}:host::-moz-focus-inner{border:0}:host.iui-listbox_disabled{border-color:var(--iui-listbox-disabled-border);color:var(--iui-listbox-disabled-color);cursor:auto}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiListboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-listbox', template: '<ng-content select="iui-listbox-option"></ng-content>', imports: [CommonModule], providers: [
                        { provide: CdkListbox, useExisting: IuiListboxComponent },
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiListboxComponent),
                            multi: true
                        }
                    ], standalone: true, host: {
                        '[class.iui-listbox]': 'true',
                        '[attr.disabled]': 'disabled ? true : null'
                    }, styles: [":host{display:flex;flex-direction:column;-webkit-user-select:none;user-select:none;outline:none;border:none;text-decoration:none;-webkit-tap-highlight-color:transparent;transition:background-color .2s ease-out}:host::-moz-focus-inner{border:0}:host.iui-listbox_disabled{border-color:var(--iui-listbox-disabled-border);color:var(--iui-listbox-disabled-color);cursor:auto}\n"] }]
        }], propDecorators: { size: [{
                type: Input
            }], multipleSelection: [{
                type: Input,
                args: ['multiple']
            }], hideSelectionIndicator: [{
                type: Input
            }], togglePosition: [{
                type: Input
            }] } });

class IuiListboxOptionComponent extends CdkOption {
    constructor() {
        super(...arguments);
        this.size = 'l';
        /** Indeterminate value option of checkbox. */
        this.indeterminate = false;
    }
    get disabled() {
        return super.disabled;
    }
    set disabled(val) {
        super.disabled = val;
    }
    get _radioId() {
        return `${this.listbox.id}-radio-id-${this.id}`;
    }
    get _radioName() {
        return `${this.listbox.id}-radio-names`;
    }
    get _radioValue() {
        return `${this.listbox.id}-radio-value-${this.value}`;
    }
    /**
     * @method
     * @ignore
     */
    _clickHandler(event) {
        // when User clicks, clickEvent bubbles up to CdkListboxOption, where there is event.preventDefault() call
        // it makes target uncheck, so we need to check target manually at next tick
        setTimeout(() => {
            if (event.target instanceof HTMLInputElement && event.target.type === 'radio') {
                event.target.checked = this.isSelected();
            }
        }, 1);
    }
    /** Whether a checkbox is shown at the given position. */
    _hasCheckboxAt(position) {
        const listbox = this.listbox;
        return listbox.multipleSelection && listbox.togglePosition === position && !listbox.hideSelectionIndicator;
    }
    /** Whether a radio indicator is shown at the given position. */
    _hasRadioAt(position) {
        const listbox = this.listbox;
        return !listbox.multipleSelection && listbox.togglePosition === position && !listbox.hideSelectionIndicator;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiListboxOptionComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiListboxOptionComponent, isStandalone: true, selector: "iui-listbox-option", inputs: { size: "size", indeterminate: "indeterminate", value: "value", disabled: "disabled" }, host: { properties: { "class.iui-listbox-option": "true", "class.iui-listbox-option_size_l": "size === \"l\"", "class.iui-listbox-option_size_m": "size === \"m\"", "class.iui-listbox-option_size_s": "size === \"s\"", "class.iui-listbox-option_disabled": "disabled" } }, providers: [{ provide: CdkOption, useExisting: IuiListboxOptionComponent }], usesInheritance: true, ngImport: i0, template: "<ng-template #checkbox>\n\t<iui-checkbox\n\t\t[isDisabled]=\"disabled\"\n\t\t[checked]=\"isSelected()\"\n\t\t[indeterminate]=\"indeterminate || false\">\n\t</iui-checkbox>\n</ng-template>\n\n<ng-template #radio>\n\t<iui-radio-button\n\t\t[id]=\"_radioId\"\n\t\t[name]=\"_radioName\"\n\t\t[value]=\"_radioValue\"\n\t\t[checked]=\"isSelected()\"\n\t\t[disabled]=\"disabled\"\n\t\t(click)=\"_clickHandler($event)\">\n\t</iui-radio-button>\n</ng-template>\n\n<span class=\"iui-listbox-option__toggle-before\">\n\t<ng-content select=\"[left]\"></ng-content>\n\t<ng-template [ngTemplateOutlet]=\"checkbox\" *ngIf=\"_hasCheckboxAt('before')\"></ng-template>\n\t<ng-template [ngTemplateOutlet]=\"radio\" *ngIf=\"_hasRadioAt('before')\"></ng-template>\n</span>\n\n<div class=\"iui-listbox-option__content\">\n\t<ng-content select=\"[optionTitle]\"></ng-content>\n\t<ng-content select=\"[optionSubtitle]\"></ng-content>\n</div>\n\n\n\n<span #unscopedContent class=\"iui-option-unscoped-content\">\n\t<ng-content></ng-content>\n</span>\n\n<span class=\"iui-listbox-option__toggle-after\">\n\t<ng-content select=\"[right]\"></ng-content>\n\t<ng-template [ngTemplateOutlet]=\"checkbox\" *ngIf=\"_hasCheckboxAt('after')\"></ng-template>\n\t<ng-template [ngTemplateOutlet]=\"radio\" *ngIf=\"_hasRadioAt('after')\"></ng-template>\n</span>\n\n\n", styles: [":host{-webkit-user-select:none;user-select:none;outline:none;border:none;text-decoration:none;-webkit-tap-highlight-color:transparent;display:flex;flex-direction:row;align-items:center;box-sizing:border-box;color:var(--iui-listbox-option-title-color);border-bottom:var(--iui-border-width) solid var(--iui-listbox-option-border);padding:0 calc(var(--iui-main-unit) * 4);gap:calc(var(--iui-main-unit) * 3)}:host::-moz-focus-inner{border:0}:host .iui-listbox-option__toggle-before,:host .iui-listbox-option__toggle-after{display:flex;align-items:center;gap:calc(var(--iui-main-unit) * 3)}:host .iui-listbox-option__toggle-before.iui-listbox-option__toggle-after,:host .iui-listbox-option__toggle-after.iui-listbox-option__toggle-after{margin-left:auto}:host .iui-listbox-option__toggle-before:empty,:host .iui-listbox-option__toggle-after:empty,:host .iui-option-unscoped-content:empty,:host .iui-listbox-option__content:empty{display:none}:host .iui-option-center{display:flex;flex-direction:column;justify-content:center;overflow:hidden;flex:1 1 0}:host ::ng-deep [optionTitle]{color:var(--iui-listbox-option-title-color)}:host ::ng-deep [optionSubtitle]{color:var(--iui-listbox-option-subtitle-color)}:host .iui-listbox-option__content{display:flex;flex:1;flex-direction:column;align-items:flex-start;overflow:hidden}:host.iui-listbox-option_disabled{border-color:var(--iui-listbox-option-disabled-border);color:var(--iui-listbox-option-disabled-color);cursor:auto;opacity:.5}:host.iui-listbox-option_size_l{min-height:calc(20 * var(--iui-main-unit))}:host.iui-listbox-option_size_l ::ng-deep [optionTitle]{font:var(--iui-tp-heading-04-font)}:host.iui-listbox-option_size_l ::ng-deep [optionSubtitle]{font:var(--iui-tp-body-02-font)}:host.iui-listbox-option_size_m{min-height:calc(16 * var(--iui-main-unit))}:host.iui-listbox-option_size_m ::ng-deep [optionTitle]{font:var(--iui-tp-body-01-font)}:host.iui-listbox-option_size_m ::ng-deep [optionSubtitle]{font:var(--iui-tp-label-01-font)}:host.iui-listbox-option_size_s{min-height:calc(12 * var(--iui-main-unit))}:host.iui-listbox-option_size_s ::ng-deep [optionTitle]{font:var(--iui-tp-label-01-font)}:host.iui-listbox-option_size_s ::ng-deep [optionSubtitle]{font:var(--iui-tp-label-01-font)}:host:not(.iui-listbox-option_disabled):hover{background-color:var(--iui-listbox-option-hover-bg)}:host:not(.iui-listbox-option_disabled):active{background-color:var(--iui-listbox-option-active-bg)}:host:not(.iui-listbox-option_disabled):focus-visible{box-shadow:0 0 0 calc(var(--iui-border-width) * 2) var(--iui-listbox-option-focus-shadow)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: IuiCheckboxComponent, selector: "iui-checkbox", inputs: ["id", "showValue", "skeleton", "checked", "indeterminate"], outputs: ["changeEvent", "indeterminateChanged"] }, { kind: "component", type: IuiRadioButtonComponent, selector: "iui-radio-button", inputs: ["id", "value", "label", "description", "name", "arialabel", "arialabelledby", "showValue", "skeleton", "disabled", "checked", "required"], outputs: ["_change"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiListboxOptionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-listbox-option', imports: [CommonModule, IuiCheckboxComponent, IuiRadioButtonComponent], providers: [{ provide: CdkOption, useExisting: IuiListboxOptionComponent }], standalone: true, host: {
                        '[class.iui-listbox-option]': 'true',
                        '[class.iui-listbox-option_size_l]': 'size === "l"',
                        '[class.iui-listbox-option_size_m]': 'size === "m"',
                        '[class.iui-listbox-option_size_s]': 'size === "s"',
                        '[class.iui-listbox-option_disabled]': 'disabled'
                    }, template: "<ng-template #checkbox>\n\t<iui-checkbox\n\t\t[isDisabled]=\"disabled\"\n\t\t[checked]=\"isSelected()\"\n\t\t[indeterminate]=\"indeterminate || false\">\n\t</iui-checkbox>\n</ng-template>\n\n<ng-template #radio>\n\t<iui-radio-button\n\t\t[id]=\"_radioId\"\n\t\t[name]=\"_radioName\"\n\t\t[value]=\"_radioValue\"\n\t\t[checked]=\"isSelected()\"\n\t\t[disabled]=\"disabled\"\n\t\t(click)=\"_clickHandler($event)\">\n\t</iui-radio-button>\n</ng-template>\n\n<span class=\"iui-listbox-option__toggle-before\">\n\t<ng-content select=\"[left]\"></ng-content>\n\t<ng-template [ngTemplateOutlet]=\"checkbox\" *ngIf=\"_hasCheckboxAt('before')\"></ng-template>\n\t<ng-template [ngTemplateOutlet]=\"radio\" *ngIf=\"_hasRadioAt('before')\"></ng-template>\n</span>\n\n<div class=\"iui-listbox-option__content\">\n\t<ng-content select=\"[optionTitle]\"></ng-content>\n\t<ng-content select=\"[optionSubtitle]\"></ng-content>\n</div>\n\n\n\n<span #unscopedContent class=\"iui-option-unscoped-content\">\n\t<ng-content></ng-content>\n</span>\n\n<span class=\"iui-listbox-option__toggle-after\">\n\t<ng-content select=\"[right]\"></ng-content>\n\t<ng-template [ngTemplateOutlet]=\"checkbox\" *ngIf=\"_hasCheckboxAt('after')\"></ng-template>\n\t<ng-template [ngTemplateOutlet]=\"radio\" *ngIf=\"_hasRadioAt('after')\"></ng-template>\n</span>\n\n\n", styles: [":host{-webkit-user-select:none;user-select:none;outline:none;border:none;text-decoration:none;-webkit-tap-highlight-color:transparent;display:flex;flex-direction:row;align-items:center;box-sizing:border-box;color:var(--iui-listbox-option-title-color);border-bottom:var(--iui-border-width) solid var(--iui-listbox-option-border);padding:0 calc(var(--iui-main-unit) * 4);gap:calc(var(--iui-main-unit) * 3)}:host::-moz-focus-inner{border:0}:host .iui-listbox-option__toggle-before,:host .iui-listbox-option__toggle-after{display:flex;align-items:center;gap:calc(var(--iui-main-unit) * 3)}:host .iui-listbox-option__toggle-before.iui-listbox-option__toggle-after,:host .iui-listbox-option__toggle-after.iui-listbox-option__toggle-after{margin-left:auto}:host .iui-listbox-option__toggle-before:empty,:host .iui-listbox-option__toggle-after:empty,:host .iui-option-unscoped-content:empty,:host .iui-listbox-option__content:empty{display:none}:host .iui-option-center{display:flex;flex-direction:column;justify-content:center;overflow:hidden;flex:1 1 0}:host ::ng-deep [optionTitle]{color:var(--iui-listbox-option-title-color)}:host ::ng-deep [optionSubtitle]{color:var(--iui-listbox-option-subtitle-color)}:host .iui-listbox-option__content{display:flex;flex:1;flex-direction:column;align-items:flex-start;overflow:hidden}:host.iui-listbox-option_disabled{border-color:var(--iui-listbox-option-disabled-border);color:var(--iui-listbox-option-disabled-color);cursor:auto;opacity:.5}:host.iui-listbox-option_size_l{min-height:calc(20 * var(--iui-main-unit))}:host.iui-listbox-option_size_l ::ng-deep [optionTitle]{font:var(--iui-tp-heading-04-font)}:host.iui-listbox-option_size_l ::ng-deep [optionSubtitle]{font:var(--iui-tp-body-02-font)}:host.iui-listbox-option_size_m{min-height:calc(16 * var(--iui-main-unit))}:host.iui-listbox-option_size_m ::ng-deep [optionTitle]{font:var(--iui-tp-body-01-font)}:host.iui-listbox-option_size_m ::ng-deep [optionSubtitle]{font:var(--iui-tp-label-01-font)}:host.iui-listbox-option_size_s{min-height:calc(12 * var(--iui-main-unit))}:host.iui-listbox-option_size_s ::ng-deep [optionTitle]{font:var(--iui-tp-label-01-font)}:host.iui-listbox-option_size_s ::ng-deep [optionSubtitle]{font:var(--iui-tp-label-01-font)}:host:not(.iui-listbox-option_disabled):hover{background-color:var(--iui-listbox-option-hover-bg)}:host:not(.iui-listbox-option_disabled):active{background-color:var(--iui-listbox-option-active-bg)}:host:not(.iui-listbox-option_disabled):focus-visible{box-shadow:0 0 0 calc(var(--iui-border-width) * 2) var(--iui-listbox-option-focus-shadow)}\n"] }]
        }], propDecorators: { size: [{
                type: Input
            }], indeterminate: [{
                type: Input
            }], value: [{
                type: Input
            }], disabled: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiListboxComponent, IuiListboxOptionComponent };
//# sourceMappingURL=itero-ui-components-angular-listbox.mjs.map
