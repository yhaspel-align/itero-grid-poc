import * as i0 from '@angular/core';
import { EventEmitter, Optional, Inject, Component, InjectionToken, Injectable, Input, ChangeDetectionStrategy, NgModule } from '@angular/core';
import * as i2 from '@angular/cdk/dialog';
import { CdkDialogContainer, DialogRef, DialogConfig, DialogModule } from '@angular/cdk/dialog';
import * as i3 from '@angular/cdk/overlay';
import { OverlayModule } from '@angular/cdk/overlay';
import * as i2$1 from '@angular/common';
import { DOCUMENT, CommonModule } from '@angular/common';
import * as i1 from '@angular/cdk/a11y';
import { trigger, state, style, transition, group, animate, query, animateChild } from '@angular/animations';
import * as i4 from '@angular/cdk/portal';
import { PortalModule } from '@angular/cdk/portal';

/**
 * Default parameters for the animation for backwards compatibility.
 * @docs-private
 */
const _defaultParams = {
    params: { enterAnimationDuration: '150ms', exitAnimationDuration: '75ms' },
};
const iuiDialogAnimations = {
    /** Animation that is applied on the dialog container by default. */
    dialogContainer: trigger('dialogContainer', [
        // Note: The `enter` animation transitions to `transform: none`, because for some reason
        // specifying the transform explicitly, causes IE both to blur the dialog content and
        // decimate the animation performance. Leaving it as `none` solves both issues.
        state('void, exit', style({ opacity: 0, transform: 'scale(0.7)' })),
        state('enter', style({ transform: 'none' })),
        transition('* => enter', group([
            animate('{{enterAnimationDuration}} cubic-bezier(0, 0, 0.2, 1)', style({ transform: 'none', opacity: 1 })),
            query('@*', animateChild(), { optional: true }),
        ]), _defaultParams),
        transition('* => void, * => exit', group([
            animate('{{exitAnimationDuration}} cubic-bezier(0.4, 0.0, 0.2, 1)', style({ opacity: 0 })),
            query('@*', animateChild(), { optional: true }),
        ]), _defaultParams),
    ]),
};

class IuiModalContainerComponent extends CdkDialogContainer {
    constructor(elementRef, focusTrapFactory, _document, dialogConfig, interactivityChecker, ngZone, _changeDetectorRef, overlayRef, focusMonitor) {
        super(elementRef, focusTrapFactory, _document, dialogConfig, interactivityChecker, ngZone, overlayRef, focusMonitor);
        this._changeDetectorRef = _changeDetectorRef;
        /** Emits when an animation state changes. */
        this._animationStateChanged = new EventEmitter();
        /** State of the dialog animation. */
        this._state = 'enter';
    }
    _getAnimationState() {
        return {
            value: this._state,
            params: {
                enterAnimationDuration: _defaultParams.params.enterAnimationDuration,
                exitAnimationDuration: _defaultParams.params.exitAnimationDuration
            }
        };
    }
    /** Callback, invoked when an animation on the host starts. */
    _onAnimationStart({ toState, totalTime }) {
        if (toState === 'enter') {
            this._animationStateChanged.next({ state: 'opening', totalTime });
        }
        else if (toState === 'exit' || toState === 'void') {
            this._animationStateChanged.next({ state: 'closing', totalTime });
        }
    }
    /** Callback, invoked whenever an animation on the host completes. */
    _onAnimationDone({ toState, totalTime }) {
        if (toState === 'enter') {
            this._openAnimationDone(totalTime);
        }
        else if (toState === 'exit') {
            this._animationStateChanged.next({ state: 'closed', totalTime });
        }
    }
    _openAnimationDone(totalTime) {
        this._animationStateChanged.next({ state: 'opened', totalTime });
    }
    /** Starts the dialog exit animation. */
    _startExitAnimation() {
        this._state = 'exit';
        // Mark the container for check so it can react if the
        // view container is using OnPush change detection.
        this._changeDetectorRef.markForCheck();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalContainerComponent, deps: [{ token: i0.ElementRef }, { token: i1.FocusTrapFactory }, { token: DOCUMENT, optional: true }, { token: i2.DialogConfig }, { token: i1.InteractivityChecker }, { token: i0.NgZone }, { token: i0.ChangeDetectorRef }, { token: i3.OverlayRef }, { token: i1.FocusMonitor }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiModalContainerComponent, selector: "iui-modal-container", host: { attributes: { "tabindex": "-1" }, listeners: { "@dialogContainer.start": "_onAnimationStart($event)", "@dialogContainer.done": "_onAnimationDone($event)" }, properties: { "attr.aria-modal": "_config.ariaModal", "id": "_config.id", "attr.role": "_config.role", "attr.aria-labelledby": "_config.ariaLabel ? null : _ariaLabelledBy", "attr.aria-label": "_config.ariaLabel", "attr.aria-describedby": "_config.ariaDescribedBy || null", "@dialogContainer": "_getAnimationState()" }, classAttribute: "iui-modal__container" }, usesInheritance: true, ngImport: i0, template: "<ng-template cdkPortalOutlet></ng-template>\n", styles: [":host{display:flex;flex-direction:column;gap:24px;overflow:hidden;box-sizing:border-box;background:var(--iui-modal-bg);border-radius:var(--iui-border-radius-large);box-shadow:var(--iui-box-shadow-l);outline:none;padding:24px;width:100%;max-height:inherit;min-height:inherit;min-width:inherit;max-width:inherit;font:var(--iui-tp-body-02-font);color:var(--iui-modal-color)}\n"], dependencies: [{ kind: "directive", type: i4.CdkPortalOutlet, selector: "[cdkPortalOutlet]", inputs: ["cdkPortalOutlet"], outputs: ["attached"], exportAs: ["cdkPortalOutlet"] }], animations: [iuiDialogAnimations.dialogContainer] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-modal-container', animations: [iuiDialogAnimations.dialogContainer], host: {
                        class: 'iui-modal__container',
                        tabindex: '-1',
                        '[attr.aria-modal]': '_config.ariaModal',
                        '[id]': '_config.id',
                        '[attr.role]': '_config.role',
                        '[attr.aria-labelledby]': '_config.ariaLabel ? null : _ariaLabelledBy',
                        '[attr.aria-label]': '_config.ariaLabel',
                        '[attr.aria-describedby]': '_config.ariaDescribedBy || null',
                        '[@dialogContainer]': '_getAnimationState()',
                        '(@dialogContainer.start)': '_onAnimationStart($event)',
                        '(@dialogContainer.done)': '_onAnimationDone($event)'
                    }, template: "<ng-template cdkPortalOutlet></ng-template>\n", styles: [":host{display:flex;flex-direction:column;gap:24px;overflow:hidden;box-sizing:border-box;background:var(--iui-modal-bg);border-radius:var(--iui-border-radius-large);box-shadow:var(--iui-box-shadow-l);outline:none;padding:24px;width:100%;max-height:inherit;min-height:inherit;min-width:inherit;max-width:inherit;font:var(--iui-tp-body-02-font);color:var(--iui-modal-color)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.FocusTrapFactory }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i2.DialogConfig }, { type: i1.InteractivityChecker }, { type: i0.NgZone }, { type: i0.ChangeDetectorRef }, { type: i3.OverlayRef }, { type: i1.FocusMonitor }] });

const IUI_MODAL_WINDOW_DATA = new InjectionToken('IUI_MODAL_WINDOW_DATA');
class IuiModalWindowRef extends DialogRef {
    constructor(overlayRef, config) {
        super(overlayRef, config);
    }
}
// Counter for unique dialog ids.
let uniqueId = 0;
class IuiModalWindowService {
    constructor(dialog, _overlay) {
        this.dialog = dialog;
        this._overlay = _overlay;
        this.afterAllClosed = this.dialog.afterAllClosed;
        this._defaultOptions = {
            backdropClass: 'iui-modal__backdrop',
            panelClass: 'iui-modal__overlay-panel'
        };
        this._idPrefix = 'iui-modal-window-';
        this._sizePanelClassMap = {
            sm: 'iui-modal_size_sm',
            md: 'iui-modal_size_md',
            lg: 'iui-modal_size_lg',
            xl: 'iui-modal_size_xl'
        };
    }
    open(componentOrTemplateRef, customConfig) {
        const sizePanelClass = this._resolveSizePanelClass(customConfig);
        const panelClass = this._definePanelClasses(this._defaultOptions.panelClass, customConfig?.panelClass, sizePanelClass);
        const config = { ...this._defaultOptions, ...(customConfig || {}), panelClass };
        config.id = config.id || `${this._idPrefix}${uniqueId++}`;
        config.scrollStrategy = config.scrollStrategy || this._overlay.scrollStrategies.block();
        const closeConfig = {
            // Disable closing since we need to sync it up to the animation ourselves.
            disableClose: true,
            // Disable closing on destroy, because this service cleans up its open dialogs as well.
            // We want to do the cleanup here, rather than the CDK service, because the CDK destroys
            // the dialogs immediately whereas we want it to wait for the animations to finish.
            closeOnDestroy: false,
            // Disable closing on detachments so that we can sync up the animation.
            // The Material dialog ref handles this manually.
            closeOnOverlayDetachments: false
        };
        const dialogRef = this.dialog.open(componentOrTemplateRef, ({
            ...config,
            positionStrategy: this._overlay.position().global().centerHorizontally().centerVertically(),
            //TODO: enable when we start handling close animation
            // ...closeConfig,
            container: {
                type: IuiModalContainerComponent,
                providers: () => [
                    // Provide our config as the CDK config as well since it has the same interface as the
                    // CDK one, but it contains the actual values passed in by the user for things like
                    // `disableClose` which we disable for the CDK dialog since we handle it ourselves.
                    //{ provide: this.dialogConfigClass, useValue: config },
                    { provide: DialogConfig, useValue: config }
                ]
            },
            templateContext: () => ({ dialogRef }),
            providers: (ref, cdkConfig, dialogContainer) => {
                // dialogRef = new this._dialogRefConstructor(ref, config, dialogContainer);
                // dialogRef.updatePosition(config?.position);
                return [
                    { provide: IuiModalContainerComponent, useValue: dialogContainer },
                    { provide: IUI_MODAL_WINDOW_DATA, useValue: cdkConfig.data },
                    { provide: DialogRef, useValue: ref },
                    { provide: IuiModalWindowRef, useValue: ref }
                ];
            }
        }));
        return dialogRef;
    }
    /**
     * Closes all the currently-open dialogs.
     */
    closeAll() {
        this.dialog.closeAll();
    }
    /**
     * Finds an open dialog by its id.
     * @param id ID to use when looking up the dialog.
     */
    getDialogById(id) {
        return this.dialog.getDialogById(id);
    }
    get openDialogs() {
        return this.dialog.openDialogs;
    }
    get afterOpened() {
        return this.dialog.afterOpened;
    }
    /**
     * Call onDestroy method in yours microfrontend's app.component to remove pendiing subscriptions and opened dialogs
     * Otherwise it wont be destroyed because of microfrontend architecture
     * */
    ngOnDestroy() {
        this.dialog.ngOnDestroy();
    }
    /**
     * Returns the size panel class if applicable.
     * If an explicit width is set, no size class is applied (backwards compat).
     * If no size and no explicit width, defaults to 'md'.
     */
    _resolveSizePanelClass(config) {
        if (config?.width) {
            return null;
        }
        const size = config?.size ?? 'md';
        return this._sizePanelClassMap[size];
    }
    _definePanelClasses(defaultPanelClass, additionalClasses, sizeClass) {
        const classes = [defaultPanelClass];
        if (sizeClass) {
            classes.push(sizeClass);
        }
        if (Array.isArray(additionalClasses) && additionalClasses.length > 0) {
            classes.push(...additionalClasses);
        }
        else if (typeof additionalClasses === 'string' && additionalClasses.length > 0) {
            classes.push(additionalClasses);
        }
        return classes.length === 1 ? classes[0] : classes;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalWindowService, deps: [{ token: i2.Dialog }, { token: i3.Overlay }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalWindowService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalWindowService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i2.Dialog }, { type: i3.Overlay }] });

class ModalUtils {
    /**
     * Finds the closest IuiModalWindowRef to an element by looking at the DOM.
     * @param element Element relative to which to look for a dialog.
     * @param openDialogs References to the currently-open dialogs.
     */
    static getClosestDialog(element, openDialogs) {
        let parent = element.nativeElement.parentElement;
        while (parent && !parent.classList.contains('mat-mdc-dialog-container')) {
            parent = parent.parentElement;
        }
        return parent ? openDialogs.find(dialog => dialog.id === parent.id) : null;
    }
}

/**
 * Title of a dialog element. Stays fixed to the top of the dialog when scrolling.
 */
let nextElementId = 0;
class IuiModalHeaderComponent {
    constructor(_dialogRef, _elementRef, _dialog) {
        this._dialogRef = _dialogRef;
        this._elementRef = _elementRef;
        this._dialog = _dialog;
        this.id = `iui-modal-header-${nextElementId++}`;
        /** Whether to show the built-in close button. Default: true */
        this.showCloseButton = true;
    }
    ngOnInit() {
        if (!this._dialogRef) {
            this._dialogRef = ModalUtils.getClosestDialog(this._elementRef, this._dialog.openDialogs);
        }
        if (this._dialogRef) {
            Promise.resolve().then(() => {
                const container = this._dialogRef?.containerInstance;
                if (container && !container._ariaLabelledByQueue?.length) {
                    container._ariaLabelledByQueue = [this.id];
                }
            });
        }
    }
    close() {
        if (!this._dialogRef) {
            this._dialogRef = ModalUtils.getClosestDialog(this._elementRef, this._dialog.openDialogs);
        }
        this._dialogRef?.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalHeaderComponent, deps: [{ token: DialogRef, optional: true }, { token: i0.ElementRef }, { token: IuiModalWindowService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiModalHeaderComponent, selector: "iui-modal-header", inputs: { id: "id", description: "description", showCloseButton: "showCloseButton" }, host: { properties: { "id": "id" }, classAttribute: "iui-modal__header" }, ngImport: i0, template: "<ng-content select=\"[left-icon]\"></ng-content>\n<div class=\"iui-modal__headline\">\n\t<div class=\"iui-modal__header-row\">\n\t\t<div class=\"iui-modal__header-title\">\n\t\t\t<ng-content></ng-content>\n\t\t</div>\n\t\t<button *ngIf=\"showCloseButton\"\n\t\t\t\tclass=\"iui-modal__close-btn\"\n\t\t\t\ttype=\"button\"\n\t\t\t\taria-label=\"Close\"\n\t\t\t\t(click)=\"close()\">\n\t\t\t<svg class=\"iui-modal__close-icon\" width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n\t\t\t\t<path d=\"M15 5L5 15M5 5L15 15\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n\t\t\t</svg>\n\t\t</button>\n\t\t<ng-content select=\"[right-icon]\"></ng-content>\n\t</div>\n\t<p *ngIf=\"description\" class=\"iui-modal__description\">{{ description }}</p>\n</div>\n", styles: [":host{display:flex;align-items:flex-start;width:100%}.iui-modal__headline{display:flex;flex-direction:column;gap:8px;flex:1}.iui-modal__header-row{display:flex;align-items:flex-start;gap:16px}.iui-modal__header-title{flex:1;font:var(--iui-tp-heading-02-font);color:var(--iui-modal-title-color);max-height:48px;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.iui-modal__close-btn{display:flex;align-items:center;justify-content:center;flex-shrink:0;padding:2px 0;border:none;background:none;cursor:pointer;color:var(--iui-modal-close-color)}.iui-modal__close-btn:hover{color:var(--iui-modal-close-hover-color)}.iui-modal__close-btn:focus-visible{outline:2px solid var(--iui-border-focus);outline-offset:2px;border-radius:4px}.iui-modal__close-icon{width:20px;height:20px}.iui-modal__description{font:var(--iui-tp-body-01-font);color:var(--iui-modal-description-color);margin:0}\n"], dependencies: [{ kind: "directive", type: i2$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-modal-header', host: {
                        'class': 'iui-modal__header',
                        '[id]': 'id'
                    }, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content select=\"[left-icon]\"></ng-content>\n<div class=\"iui-modal__headline\">\n\t<div class=\"iui-modal__header-row\">\n\t\t<div class=\"iui-modal__header-title\">\n\t\t\t<ng-content></ng-content>\n\t\t</div>\n\t\t<button *ngIf=\"showCloseButton\"\n\t\t\t\tclass=\"iui-modal__close-btn\"\n\t\t\t\ttype=\"button\"\n\t\t\t\taria-label=\"Close\"\n\t\t\t\t(click)=\"close()\">\n\t\t\t<svg class=\"iui-modal__close-icon\" width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n\t\t\t\t<path d=\"M15 5L5 15M5 5L15 15\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n\t\t\t</svg>\n\t\t</button>\n\t\t<ng-content select=\"[right-icon]\"></ng-content>\n\t</div>\n\t<p *ngIf=\"description\" class=\"iui-modal__description\">{{ description }}</p>\n</div>\n", styles: [":host{display:flex;align-items:flex-start;width:100%}.iui-modal__headline{display:flex;flex-direction:column;gap:8px;flex:1}.iui-modal__header-row{display:flex;align-items:flex-start;gap:16px}.iui-modal__header-title{flex:1;font:var(--iui-tp-heading-02-font);color:var(--iui-modal-title-color);max-height:48px;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.iui-modal__close-btn{display:flex;align-items:center;justify-content:center;flex-shrink:0;padding:2px 0;border:none;background:none;cursor:pointer;color:var(--iui-modal-close-color)}.iui-modal__close-btn:hover{color:var(--iui-modal-close-hover-color)}.iui-modal__close-btn:focus-visible{outline:2px solid var(--iui-border-focus);outline-offset:2px;border-radius:4px}.iui-modal__close-icon{width:20px;height:20px}.iui-modal__description{font:var(--iui-tp-body-01-font);color:var(--iui-modal-description-color);margin:0}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [DialogRef]
                }, {
                    type: Optional
                }] }, { type: i0.ElementRef }, { type: IuiModalWindowService }], propDecorators: { id: [{
                type: Input
            }], description: [{
                type: Input
            }], showCloseButton: [{
                type: Input
            }] } });

class IuiModalFooterComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalFooterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiModalFooterComponent, selector: "iui-modal-footer", ngImport: i0, template: "<ng-content select=\"[left-buttons]\"></ng-content>\n<div class=\"iui-modal__footer-actions\">\n\t<ng-content select=\"[right-buttons]\"></ng-content>\n\t<ng-content></ng-content>\n</div>\n", styles: [":host{display:flex;align-items:center;width:100%}.iui-modal__footer-actions{display:flex;align-items:center;gap:8px;margin-left:auto}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalFooterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-modal-footer', template: "<ng-content select=\"[left-buttons]\"></ng-content>\n<div class=\"iui-modal__footer-actions\">\n\t<ng-content select=\"[right-buttons]\"></ng-content>\n\t<ng-content></ng-content>\n</div>\n", styles: [":host{display:flex;align-items:center;width:100%}.iui-modal__footer-actions{display:flex;align-items:center;gap:8px;margin-left:auto}\n"] }]
        }] });

class IuiModalContentComponent {
    constructor() {
        this._padding = '0px';
    }
    set padding(value) {
        this._padding = value + 'px';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiModalContentComponent, selector: "iui-modal-content", inputs: { padding: "padding" }, host: { properties: { "class.iui-modal__content": "true", "style.--iui-modal-content-padding": "_padding" } }, ngImport: i0, template: "<ng-content></ng-content>\n", styles: [":host{display:block;overflow:auto;box-sizing:border-box;padding:var(--iui-modal-content-padding);flex:1;min-height:0}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalContentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-modal-content', host: {
                        '[class.iui-modal__content]': 'true',
                        '[style.--iui-modal-content-padding]': '_padding'
                    }, template: "<ng-content></ng-content>\n", styles: [":host{display:block;overflow:auto;box-sizing:border-box;padding:var(--iui-modal-content-padding);flex:1;min-height:0}\n"] }]
        }], propDecorators: { padding: [{
                type: Input
            }] } });

class IuiModalWindowModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalWindowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "17.3.12", ngImport: i0, type: IuiModalWindowModule, declarations: [IuiModalContainerComponent, IuiModalHeaderComponent, IuiModalFooterComponent, IuiModalContentComponent], imports: [DialogModule, OverlayModule, PortalModule, CommonModule], exports: [IuiModalContainerComponent, IuiModalHeaderComponent, IuiModalFooterComponent, IuiModalContentComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalWindowModule, providers: [IuiModalWindowService], imports: [DialogModule, OverlayModule, PortalModule, CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalWindowModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [DialogModule, OverlayModule, PortalModule, CommonModule],
                    declarations: [IuiModalContainerComponent, IuiModalHeaderComponent, IuiModalFooterComponent, IuiModalContentComponent],
                    exports: [IuiModalContainerComponent, IuiModalHeaderComponent, IuiModalFooterComponent, IuiModalContentComponent],
                    providers: [IuiModalWindowService]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { IUI_MODAL_WINDOW_DATA, IuiModalContainerComponent, IuiModalContentComponent, IuiModalFooterComponent, IuiModalHeaderComponent, IuiModalWindowModule, IuiModalWindowRef, IuiModalWindowService };
//# sourceMappingURL=itero-ui-components-angular-modal-window.mjs.map
