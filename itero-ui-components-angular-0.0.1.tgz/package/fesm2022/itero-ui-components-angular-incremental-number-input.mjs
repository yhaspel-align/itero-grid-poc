import * as i0 from '@angular/core';
import { forwardRef, Input, ViewChild, Self, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import { Validators, NG_VALUE_ACCESSOR } from '@angular/forms';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i1 from '@itero/ui-components-angular/core';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import { IuiButtonComponent } from '@itero/ui-components-angular/button';
import { SubtractEmptyIconComponent, AddEmptyIconComponent } from '@itero/ui-components-angular/icons';

let nextUniqueId = 0;
/**
 * @deprecated Use `IuiNumberInputComponent` from `@itero/ui-components-angular/number-input` instead.
 * This component will be removed in the next major version.
 */
class IuiIncrementalNumberInputComponent {
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    get required() {
        return this._required ?? this.ngControlDirective.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get _focused() {
        return this.__focused;
    }
    get _inputId() {
        return this.id + '-input';
    }
    get _isAtMin() {
        return this.__value != null && this.__value <= this.min;
    }
    get _isAtMax() {
        return this.__value != null && this.__value >= this.max;
    }
    get _inputSize() {
        const len = this._displayValue.length;
        return len > 0 ? len : 1;
    }
    get _ariaValueMin() {
        return isFinite(this.min) ? this.min : null;
    }
    get _ariaValueMax() {
        return isFinite(this.max) ? this.max : null;
    }
    get _displayValue() {
        if (this._rawInput != null) {
            return this._rawInput;
        }
        return this.__value != null ? String(this.__value) : '';
    }
    get _value() {
        return this.__value;
    }
    constructor(_changeDetectorRef, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._changeDetectorRef = _changeDetectorRef;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        this._id = `iui-incremental-number-input-${nextUniqueId++}`;
        this.label = '';
        this.helperText = '';
        this.name = '';
        this.min = -Infinity;
        this.max = Infinity;
        this.step = 1;
        this.__value = null;
        this.__focused = false;
        this._rawInput = null;
        this._onChange = () => { };
        this._onTouched = () => { };
    }
    _increment() {
        const current = this.__value ?? 0;
        const newValue = Math.min(current + this.step, this.max);
        this._setValue(newValue);
    }
    _decrement() {
        const current = this.__value ?? 0;
        const newValue = Math.max(current - this.step, this.min);
        this._setValue(newValue);
    }
    _onKeydown(event) {
        if (event.key === 'ArrowUp') {
            event.preventDefault();
            this._increment();
        }
        else if (event.key === 'ArrowDown') {
            event.preventDefault();
            this._decrement();
        }
    }
    _onInputChange(event) {
        const raw = event.target.value;
        this._rawInput = raw;
        if (raw === '') {
            this._assignValue(null);
            return;
        }
        if (raw === '-') {
            return;
        }
        const parsed = Number(raw);
        if (!isNaN(parsed)) {
            this._setValue(this._clamp(parsed));
        }
    }
    _onFocus() {
        if (!this.disabled) {
            this.__focused = true;
            this._rawInput = this._displayValue;
        }
    }
    _onBlur() {
        this.__focused = false;
        this._rawInput = null;
        if (this.__value == null) {
            const resolved = isFinite(this.min) ? this.min : 0;
            this._setValue(resolved);
        }
        else {
            this._setValue(this._clamp(this.__value));
        }
        if (!this.disabled) {
            this._onTouched();
            this._changeDetectorRef.markForCheck();
        }
    }
    writeValue(value) {
        this._assignValue(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._changeDetectorRef.markForCheck();
    }
    _setValue(value) {
        const hasAssigned = this._assignValue(value);
        if (hasAssigned) {
            this._onChange(value);
        }
    }
    _assignValue(newValue) {
        if (newValue !== this.__value) {
            this.__value = newValue;
            this._changeDetectorRef.markForCheck();
            return true;
        }
        return false;
    }
    _clamp(value) {
        return Math.min(Math.max(value, this.min), this.max);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiIncrementalNumberInputComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.NgControlDirective, self: true }, { token: i1.IuiErrorStateMatcherDirective, self: true }, { token: i1.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiIncrementalNumberInputComponent, isStandalone: true, selector: "iui-incremental-number-input", inputs: { id: "id", label: "label", helperText: "helperText", name: "name", min: "min", max: "max", step: "step", required: "required" }, host: { properties: { "class.iui-incremental-number-input_focused": "_focused", "class.iui-incremental-number-input_required": "required", "class.iui-incremental-number-input_disabled": "disabled", "class.iui-incremental-number-input_invalid": "_errorState", "attr.id": "id" }, classAttribute: "iui-incremental-number-input" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiIncrementalNumberInputComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true }], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<div class=\"iui-incremental-number-input__label-group\">\n\t<div class=\"iui-incremental-number-input__label\">\n\t\t<span class=\"iui-incremental-number-input__label-text\">{{ label }}</span>\n\t\t<span *ngIf=\"required\" class=\"iui-incremental-number-input__asterisk\">*</span>\n\t</div>\n\t<span *ngIf=\"helperText\" class=\"iui-incremental-number-input__helper-text\">{{ helperText }}</span>\n</div>\n\n<div class=\"iui-incremental-number-input__field\">\n\t<button\n\t\tiuiButton\n\t\temphasis=\"ghost\"\n\t\tsize=\"m\"\n\t\t[attr.type]=\"'button'\"\n\t\tclass=\"iui-incremental-number-input__button iui-incremental-number-input__button_decrement\"\n\t\t[disabled]=\"disabled || _isAtMin\"\n\t\t(click)=\"_decrement()\"\n\t\ttabindex=\"-1\"\n\t\taria-label=\"Decrease value\"\n\t>\n\t\t<iui-subtract-empty-icon class=\"iui-icon iui-icon_size_m\"></iui-subtract-empty-icon>\n\t</button>\n\n\t<div class=\"iui-incremental-number-input__value-container\">\n\t\t<input\n\t\t\t#inputElement\n\t\t\ttype=\"text\"\n\t\t\tinputmode=\"numeric\"\n\t\t\tclass=\"iui-incremental-number-input__input\"\n\t\t\t[attr.id]=\"_inputId\"\n\t\t\t[attr.name]=\"name\"\n\t\t\trole=\"spinbutton\"\n\t\t\t[attr.aria-label]=\"label\"\n\t\t\t[attr.aria-valuemin]=\"_ariaValueMin\"\n\t\t\t[attr.aria-valuemax]=\"_ariaValueMax\"\n\t\t\t[attr.aria-valuenow]=\"_value ?? null\"\n\t\t\t[attr.size]=\"_inputSize\"\n\t\t\t[disabled]=\"disabled\"\n\t\t\t[value]=\"_displayValue\"\n\t\t\t(input)=\"_onInputChange($event)\"\n\t\t\t(focus)=\"_onFocus()\"\n\t\t\t(blur)=\"_onBlur()\"\n\t\t\t(keydown)=\"_onKeydown($event)\"\n\t\t/>\n\t</div>\n\n\t<button\n\t\tiuiButton\n\t\temphasis=\"ghost\"\n\t\tsize=\"m\"\n\t\t[attr.type]=\"'button'\"\n\t\tclass=\"iui-incremental-number-input__button iui-incremental-number-input__button_increment\"\n\t\t[disabled]=\"disabled || _isAtMax\"\n\t\t(click)=\"_increment()\"\n\t\ttabindex=\"-1\"\n\t\taria-label=\"Increase value\"\n\t>\n\t\t<iui-add-empty-icon class=\"iui-icon iui-icon_size_m\"></iui-add-empty-icon>\n\t</button>\n\n</div>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;gap:8px;align-items:flex-start}.iui-incremental-number-input__label-group{display:flex;flex-direction:column;justify-content:center;align-self:stretch;min-height:52px}.iui-incremental-number-input__label{display:flex;gap:0;align-items:center;font:var(--iui-tp-body-01-font);color:var(--iui-incremental-input-color)}.iui-incremental-number-input__asterisk{font:var(--iui-tp-label-01-font);margin-left:8px;color:var(--iui-incremental-input-error-color)}.iui-incremental-number-input__helper-text{font:var(--iui-tp-label-01-font);color:var(--iui-incremental-input-color)}.iui-incremental-number-input__field{display:flex;align-items:center;height:52px;flex-shrink:0;width:fit-content;border-bottom:1px solid var(--iui-incremental-input-border);transition:border-color .2s ease-out,border-bottom-width .2s ease-out}.iui-incremental-number-input__button{flex-shrink:0}.iui-incremental-number-input__value-container{display:flex;align-items:center;justify-content:center;height:100%;padding:0 calc(var(--iui-main-unit) * 3)}.iui-incremental-number-input__value-container:hover{background:var(--iui-incremental-input-hover-bg);border-radius:var(--iui-border-radius)}.iui-incremental-number-input__input{text-align:center;border:none;outline:none;background:transparent;font:var(--iui-tp-body-01-font);color:var(--iui-incremental-input-color);min-width:1ch;padding:0}:host.iui-incremental-number-input_focused .iui-incremental-number-input__field{border-bottom-width:2px}:host.iui-incremental-number-input_invalid .iui-incremental-number-input__field{border-bottom-width:2px;border-bottom-color:var(--iui-incremental-input-error-color)}:host.iui-incremental-number-input_disabled .iui-incremental-number-input__label,:host.iui-incremental-number-input_disabled .iui-incremental-number-input__helper-text,:host.iui-incremental-number-input_disabled .iui-incremental-number-input__input{color:var(--iui-incremental-input-disabled-color)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IuiButtonComponent, selector: "button[iuiButton]", inputs: ["type", "emphasis", "size", "disabled", "loading", "menu"] }, { kind: "component", type: SubtractEmptyIconComponent, selector: "iui-subtract-empty-icon" }, { kind: "component", type: AddEmptyIconComponent, selector: "iui-add-empty-icon" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiIncrementalNumberInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-incremental-number-input', standalone: true, imports: [CommonModule, IuiButtonComponent, SubtractEmptyIconComponent, AddEmptyIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiIncrementalNumberInputComponent),
                            multi: true
                        }
                    ], host: {
                        class: 'iui-incremental-number-input',
                        '[class.iui-incremental-number-input_focused]': '_focused',
                        '[class.iui-incremental-number-input_required]': 'required',
                        '[class.iui-incremental-number-input_disabled]': 'disabled',
                        '[class.iui-incremental-number-input_invalid]': '_errorState',
                        '[attr.id]': 'id'
                    }, template: "<div class=\"iui-incremental-number-input__label-group\">\n\t<div class=\"iui-incremental-number-input__label\">\n\t\t<span class=\"iui-incremental-number-input__label-text\">{{ label }}</span>\n\t\t<span *ngIf=\"required\" class=\"iui-incremental-number-input__asterisk\">*</span>\n\t</div>\n\t<span *ngIf=\"helperText\" class=\"iui-incremental-number-input__helper-text\">{{ helperText }}</span>\n</div>\n\n<div class=\"iui-incremental-number-input__field\">\n\t<button\n\t\tiuiButton\n\t\temphasis=\"ghost\"\n\t\tsize=\"m\"\n\t\t[attr.type]=\"'button'\"\n\t\tclass=\"iui-incremental-number-input__button iui-incremental-number-input__button_decrement\"\n\t\t[disabled]=\"disabled || _isAtMin\"\n\t\t(click)=\"_decrement()\"\n\t\ttabindex=\"-1\"\n\t\taria-label=\"Decrease value\"\n\t>\n\t\t<iui-subtract-empty-icon class=\"iui-icon iui-icon_size_m\"></iui-subtract-empty-icon>\n\t</button>\n\n\t<div class=\"iui-incremental-number-input__value-container\">\n\t\t<input\n\t\t\t#inputElement\n\t\t\ttype=\"text\"\n\t\t\tinputmode=\"numeric\"\n\t\t\tclass=\"iui-incremental-number-input__input\"\n\t\t\t[attr.id]=\"_inputId\"\n\t\t\t[attr.name]=\"name\"\n\t\t\trole=\"spinbutton\"\n\t\t\t[attr.aria-label]=\"label\"\n\t\t\t[attr.aria-valuemin]=\"_ariaValueMin\"\n\t\t\t[attr.aria-valuemax]=\"_ariaValueMax\"\n\t\t\t[attr.aria-valuenow]=\"_value ?? null\"\n\t\t\t[attr.size]=\"_inputSize\"\n\t\t\t[disabled]=\"disabled\"\n\t\t\t[value]=\"_displayValue\"\n\t\t\t(input)=\"_onInputChange($event)\"\n\t\t\t(focus)=\"_onFocus()\"\n\t\t\t(blur)=\"_onBlur()\"\n\t\t\t(keydown)=\"_onKeydown($event)\"\n\t\t/>\n\t</div>\n\n\t<button\n\t\tiuiButton\n\t\temphasis=\"ghost\"\n\t\tsize=\"m\"\n\t\t[attr.type]=\"'button'\"\n\t\tclass=\"iui-incremental-number-input__button iui-incremental-number-input__button_increment\"\n\t\t[disabled]=\"disabled || _isAtMax\"\n\t\t(click)=\"_increment()\"\n\t\ttabindex=\"-1\"\n\t\taria-label=\"Increase value\"\n\t>\n\t\t<iui-add-empty-icon class=\"iui-icon iui-icon_size_m\"></iui-add-empty-icon>\n\t</button>\n\n</div>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;gap:8px;align-items:flex-start}.iui-incremental-number-input__label-group{display:flex;flex-direction:column;justify-content:center;align-self:stretch;min-height:52px}.iui-incremental-number-input__label{display:flex;gap:0;align-items:center;font:var(--iui-tp-body-01-font);color:var(--iui-incremental-input-color)}.iui-incremental-number-input__asterisk{font:var(--iui-tp-label-01-font);margin-left:8px;color:var(--iui-incremental-input-error-color)}.iui-incremental-number-input__helper-text{font:var(--iui-tp-label-01-font);color:var(--iui-incremental-input-color)}.iui-incremental-number-input__field{display:flex;align-items:center;height:52px;flex-shrink:0;width:fit-content;border-bottom:1px solid var(--iui-incremental-input-border);transition:border-color .2s ease-out,border-bottom-width .2s ease-out}.iui-incremental-number-input__button{flex-shrink:0}.iui-incremental-number-input__value-container{display:flex;align-items:center;justify-content:center;height:100%;padding:0 calc(var(--iui-main-unit) * 3)}.iui-incremental-number-input__value-container:hover{background:var(--iui-incremental-input-hover-bg);border-radius:var(--iui-border-radius)}.iui-incremental-number-input__input{text-align:center;border:none;outline:none;background:transparent;font:var(--iui-tp-body-01-font);color:var(--iui-incremental-input-color);min-width:1ch;padding:0}:host.iui-incremental-number-input_focused .iui-incremental-number-input__field{border-bottom-width:2px}:host.iui-incremental-number-input_invalid .iui-incremental-number-input__field{border-bottom-width:2px;border-bottom-color:var(--iui-incremental-input-error-color)}:host.iui-incremental-number-input_disabled .iui-incremental-number-input__label,:host.iui-incremental-number-input_disabled .iui-incremental-number-input__helper-text,:host.iui-incremental-number-input_disabled .iui-incremental-number-input__input{color:var(--iui-incremental-input-disabled-color)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { inputElement: [{
                type: ViewChild,
                args: ['inputElement']
            }], id: [{
                type: Input
            }], label: [{
                type: Input
            }], helperText: [{
                type: Input
            }], name: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], step: [{
                type: Input
            }], required: [{
                type: Input
            }] } });

/** @deprecated Use IuiNumberInputComponent from @itero/ui-components-angular/number-input instead. Will be removed in the next major version. */

/**
 * Generated bundle index. Do not edit.
 */

export { IuiIncrementalNumberInputComponent };
//# sourceMappingURL=itero-ui-components-angular-incremental-number-input.mjs.map
