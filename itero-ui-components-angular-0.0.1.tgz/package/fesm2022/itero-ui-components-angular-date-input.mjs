import * as i0 from '@angular/core';
import { EventEmitter, forwardRef, Input, Output, ViewChild, Self, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import { Validators, NG_VALUE_ACCESSOR } from '@angular/forms';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i1 from '@itero/ui-components-angular/core';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';

let nextUniqueId = 0;
class IuiDateInputComponent {
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    get required() {
        return this._required ?? this.ngControlDirective.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value) || undefined;
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get _value() {
        return this.__value;
    }
    get _inputId() {
        return `${this._id}-input`;
    }
    get empty() {
        return this.__value == null || this.__value === '';
    }
    constructor(_changeDetectorRef, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._changeDetectorRef = _changeDetectorRef;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        this.size = 'l';
        this.layerSet = 'set-01';
        this.label = '';
        this.placeholder = 'MM/DD/YYYY';
        this.name = '';
        this.showLabel = true;
        this.showHelper = true;
        // showExplainer: reserved for future tooltip integration — no-op in v1
        this.showExplainer = false;
        this.skeleton = false;
        this.valueChange = new EventEmitter();
        this._id = `iui-date-input-${nextUniqueId++}`;
        this.__value = null;
        this._focused = false;
        this._onChange = () => { };
        this._onTouched = () => { };
    }
    _onModelChange(value) {
        this.__value = value || null;
        this._onChange(this.__value);
        this.valueChange.emit(this.__value);
        this._changeDetectorRef.markForCheck();
    }
    _onFocus() {
        this._focused = true;
        this._changeDetectorRef.markForCheck();
    }
    _onBlur() {
        this._focused = false;
        this._onTouched();
        this._changeDetectorRef.markForCheck();
    }
    _focusInput() {
        this.inputElement?.nativeElement?.focus();
    }
    writeValue(value) {
        this.__value = typeof value === 'string' ? value : null;
        this._changeDetectorRef.markForCheck();
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._changeDetectorRef.markForCheck();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiDateInputComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.NgControlDirective, self: true }, { token: i1.IuiErrorStateMatcherDirective, self: true }, { token: i1.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiDateInputComponent, isStandalone: true, selector: "iui-date-input", inputs: { id: "id", size: "size", layerSet: "layerSet", label: "label", placeholder: "placeholder", name: "name", showLabel: "showLabel", showHelper: "showHelper", showExplainer: "showExplainer", skeleton: "skeleton", required: "required" }, outputs: { valueChange: "valueChange" }, host: { properties: { "class.iui-date-input_size_l": "size === \"l\"", "class.iui-date-input_size_m": "size === \"m\"", "class.iui-date-input_size_s": "size === \"s\"", "class.iui-date-input_layer-set-02": "layerSet === \"set-02\"", "class.iui-date-input_required": "required", "class.iui-date-input_focused": "_focused", "class.iui-date-input_filled": "!empty", "class.iui-date-input_disabled": "disabled", "class.iui-date-input_invalid": "_errorState", "class.iui-date-input_skeleton": "skeleton", "attr.id": "id", "attr.data-testid": "id" }, classAttribute: "iui-date-input" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiDateInputComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true }], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\r\n\t<div class=\"iui-date-input__skeleton-label\" *ngIf=\"showLabel\"></div>\r\n\t<div class=\"iui-date-input__skeleton-field\"></div>\r\n\t<div class=\"iui-date-input__skeleton-helper\" *ngIf=\"showHelper\"></div>\r\n</ng-container>\r\n\r\n<ng-template #normalTemplate>\r\n\r\n\t<div class=\"iui-date-input__label-row\" *ngIf=\"showLabel && label\">\r\n\t\t<label class=\"iui-date-input__label\" [attr.for]=\"_inputId\">\r\n\t\t\t{{ label }}<span class=\"iui-date-input__required\" *ngIf=\"required\">*</span>\r\n\t\t</label>\r\n\t</div>\r\n\r\n\t<div class=\"iui-date-input__field\" (click)=\"_focusInput()\">\r\n\t\t<input\r\n\t\t\t#inputElement\r\n\t\t\tclass=\"iui-date-input__input\"\r\n\t\t\ttype=\"text\"\r\n\t\t\tinputmode=\"numeric\"\r\n\t\t\t[id]=\"_inputId\"\r\n\t\t\t[attr.name]=\"name || null\"\r\n\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t[disabled]=\"disabled\"\r\n\t\t\t[required]=\"required\"\r\n\t\t\t[attr.aria-label]=\"label || placeholder\"\r\n\t\t\t[attr.aria-invalid]=\"_errorState\"\r\n\t\t\t[attr.aria-disabled]=\"disabled.toString()\"\r\n\t\t\t[value]=\"_value ?? ''\"\r\n\t\t\t(input)=\"_onModelChange(inputElement.value)\"\r\n\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t(blur)=\"_onBlur()\"\r\n\t\t/>\r\n\t\t<ng-content select=\"[iuiSuffix]\"></ng-content>\r\n\t</div>\r\n\r\n\t<div class=\"iui-date-input__helper-row\" *ngIf=\"showHelper\">\r\n\t\t<span *ngIf=\"_errorState\" class=\"iui-date-input__error\">\r\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t</span>\r\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-date-input__helper\">\r\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t</span>\r\n\t</div>\r\n\r\n</ng-template>\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;min-width:160px;max-width:100%}.iui-date-input__label-row{display:flex;align-items:flex-start;padding-bottom:8px}.iui-date-input__label{font:var(--iui-tp-label-01-font);color:var(--iui-date-input-label-color);flex:1;min-width:0}.iui-date-input__required{color:var(--iui-date-input-error-color);margin-left:4px}:host.iui-date-input_disabled .iui-date-input__label{color:var(--iui-date-input-disabled-color)}.iui-date-input__field{display:flex;align-items:center;overflow:hidden;background:var(--iui-date-input-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:text}:host.iui-date-input_size_l .iui-date-input__field,:host:not(.iui-date-input_size_m):not(.iui-date-input_size_s) .iui-date-input__field{height:44px;padding:12px 16px}:host.iui-date-input_size_m .iui-date-input__field{height:36px;padding:8px 12px}:host.iui-date-input_size_s .iui-date-input__field{height:28px;padding:4px 8px;border-radius:var(--iui-border-radius)}:host.iui-date-input_layer-set-02 .iui-date-input__field{background:var(--iui-date-input-bg-layer-02)}:host.iui-date-input_focused .iui-date-input__field{border-color:var(--iui-date-input-focus-border)}:host.iui-date-input_invalid .iui-date-input__field{border-color:var(--iui-date-input-error-border)}:host.iui-date-input_disabled .iui-date-input__field{cursor:default;pointer-events:none}[iuiSuffix]{flex-shrink:0;display:flex;align-items:center}.iui-date-input__input{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-date-input-color);background:transparent;border:none;outline:none;padding:0;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.iui-date-input__input::placeholder{color:var(--iui-date-input-placeholder-color)}.iui-date-input__input:disabled{color:var(--iui-date-input-disabled-color)}.iui-date-input__input:disabled::placeholder{color:var(--iui-date-input-disabled-color)}.iui-date-input__helper-row{padding-top:8px}.iui-date-input__helper{font:var(--iui-tp-label-01-font);color:var(--iui-date-input-helper-color)}.iui-date-input__error{font:var(--iui-tp-label-01-font);color:var(--iui-date-input-error-color)}:host.iui-date-input_disabled .iui-date-input__helper{color:var(--iui-date-input-disabled-color)}.iui-date-input__skeleton-label{width:80px;height:8px;background:var(--iui-date-input-skeleton-bg);border-radius:2px;margin-bottom:8px}.iui-date-input__skeleton-field{width:100%;background:var(--iui-date-input-skeleton-bg)}:host.iui-date-input_size_l .iui-date-input__skeleton-field,:host:not(.iui-date-input_size_m):not(.iui-date-input_size_s) .iui-date-input__skeleton-field{height:44px;border-radius:var(--iui-border-radius-medium)}:host.iui-date-input_size_m .iui-date-input__skeleton-field{height:36px;border-radius:var(--iui-border-radius-medium)}:host.iui-date-input_size_s .iui-date-input__skeleton-field{height:28px;border-radius:var(--iui-border-radius)}.iui-date-input__skeleton-helper{width:80px;height:8px;background:var(--iui-date-input-skeleton-bg);border-radius:2px;margin-top:8px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiDateInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-date-input', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [CommonModule], hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiDateInputComponent),
                            multi: true
                        }
                    ], host: {
                        class: 'iui-date-input',
                        '[class.iui-date-input_size_l]': 'size === "l"',
                        '[class.iui-date-input_size_m]': 'size === "m"',
                        '[class.iui-date-input_size_s]': 'size === "s"',
                        '[class.iui-date-input_layer-set-02]': 'layerSet === "set-02"',
                        '[class.iui-date-input_required]': 'required',
                        '[class.iui-date-input_focused]': '_focused',
                        '[class.iui-date-input_filled]': '!empty',
                        '[class.iui-date-input_disabled]': 'disabled',
                        '[class.iui-date-input_invalid]': '_errorState',
                        '[class.iui-date-input_skeleton]': 'skeleton',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\r\n\t<div class=\"iui-date-input__skeleton-label\" *ngIf=\"showLabel\"></div>\r\n\t<div class=\"iui-date-input__skeleton-field\"></div>\r\n\t<div class=\"iui-date-input__skeleton-helper\" *ngIf=\"showHelper\"></div>\r\n</ng-container>\r\n\r\n<ng-template #normalTemplate>\r\n\r\n\t<div class=\"iui-date-input__label-row\" *ngIf=\"showLabel && label\">\r\n\t\t<label class=\"iui-date-input__label\" [attr.for]=\"_inputId\">\r\n\t\t\t{{ label }}<span class=\"iui-date-input__required\" *ngIf=\"required\">*</span>\r\n\t\t</label>\r\n\t</div>\r\n\r\n\t<div class=\"iui-date-input__field\" (click)=\"_focusInput()\">\r\n\t\t<input\r\n\t\t\t#inputElement\r\n\t\t\tclass=\"iui-date-input__input\"\r\n\t\t\ttype=\"text\"\r\n\t\t\tinputmode=\"numeric\"\r\n\t\t\t[id]=\"_inputId\"\r\n\t\t\t[attr.name]=\"name || null\"\r\n\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t[disabled]=\"disabled\"\r\n\t\t\t[required]=\"required\"\r\n\t\t\t[attr.aria-label]=\"label || placeholder\"\r\n\t\t\t[attr.aria-invalid]=\"_errorState\"\r\n\t\t\t[attr.aria-disabled]=\"disabled.toString()\"\r\n\t\t\t[value]=\"_value ?? ''\"\r\n\t\t\t(input)=\"_onModelChange(inputElement.value)\"\r\n\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t(blur)=\"_onBlur()\"\r\n\t\t/>\r\n\t\t<ng-content select=\"[iuiSuffix]\"></ng-content>\r\n\t</div>\r\n\r\n\t<div class=\"iui-date-input__helper-row\" *ngIf=\"showHelper\">\r\n\t\t<span *ngIf=\"_errorState\" class=\"iui-date-input__error\">\r\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t</span>\r\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-date-input__helper\">\r\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t</span>\r\n\t</div>\r\n\r\n</ng-template>\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;min-width:160px;max-width:100%}.iui-date-input__label-row{display:flex;align-items:flex-start;padding-bottom:8px}.iui-date-input__label{font:var(--iui-tp-label-01-font);color:var(--iui-date-input-label-color);flex:1;min-width:0}.iui-date-input__required{color:var(--iui-date-input-error-color);margin-left:4px}:host.iui-date-input_disabled .iui-date-input__label{color:var(--iui-date-input-disabled-color)}.iui-date-input__field{display:flex;align-items:center;overflow:hidden;background:var(--iui-date-input-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:text}:host.iui-date-input_size_l .iui-date-input__field,:host:not(.iui-date-input_size_m):not(.iui-date-input_size_s) .iui-date-input__field{height:44px;padding:12px 16px}:host.iui-date-input_size_m .iui-date-input__field{height:36px;padding:8px 12px}:host.iui-date-input_size_s .iui-date-input__field{height:28px;padding:4px 8px;border-radius:var(--iui-border-radius)}:host.iui-date-input_layer-set-02 .iui-date-input__field{background:var(--iui-date-input-bg-layer-02)}:host.iui-date-input_focused .iui-date-input__field{border-color:var(--iui-date-input-focus-border)}:host.iui-date-input_invalid .iui-date-input__field{border-color:var(--iui-date-input-error-border)}:host.iui-date-input_disabled .iui-date-input__field{cursor:default;pointer-events:none}[iuiSuffix]{flex-shrink:0;display:flex;align-items:center}.iui-date-input__input{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-date-input-color);background:transparent;border:none;outline:none;padding:0;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.iui-date-input__input::placeholder{color:var(--iui-date-input-placeholder-color)}.iui-date-input__input:disabled{color:var(--iui-date-input-disabled-color)}.iui-date-input__input:disabled::placeholder{color:var(--iui-date-input-disabled-color)}.iui-date-input__helper-row{padding-top:8px}.iui-date-input__helper{font:var(--iui-tp-label-01-font);color:var(--iui-date-input-helper-color)}.iui-date-input__error{font:var(--iui-tp-label-01-font);color:var(--iui-date-input-error-color)}:host.iui-date-input_disabled .iui-date-input__helper{color:var(--iui-date-input-disabled-color)}.iui-date-input__skeleton-label{width:80px;height:8px;background:var(--iui-date-input-skeleton-bg);border-radius:2px;margin-bottom:8px}.iui-date-input__skeleton-field{width:100%;background:var(--iui-date-input-skeleton-bg)}:host.iui-date-input_size_l .iui-date-input__skeleton-field,:host:not(.iui-date-input_size_m):not(.iui-date-input_size_s) .iui-date-input__skeleton-field{height:44px;border-radius:var(--iui-border-radius-medium)}:host.iui-date-input_size_m .iui-date-input__skeleton-field{height:36px;border-radius:var(--iui-border-radius-medium)}:host.iui-date-input_size_s .iui-date-input__skeleton-field{height:28px;border-radius:var(--iui-border-radius)}.iui-date-input__skeleton-helper{width:80px;height:8px;background:var(--iui-date-input-skeleton-bg);border-radius:2px;margin-top:8px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { inputElement: [{
                type: ViewChild,
                args: ['inputElement']
            }], id: [{
                type: Input
            }], size: [{
                type: Input
            }], layerSet: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], name: [{
                type: Input
            }], showLabel: [{
                type: Input
            }], showHelper: [{
                type: Input
            }], showExplainer: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], required: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiDateInputComponent };
//# sourceMappingURL=itero-ui-components-angular-date-input.mjs.map
