import * as i0 from '@angular/core';
import { Input, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

let nextGroupId = 0;
class IuiCheckboxGroupComponent {
    constructor() {
        this.label = '';
        this.showLabel = true;
        this.orientation = 'vertical';
        this.required = false;
        this.levels = '1';
        this._labelId = `iui-checkbox-group-label-${nextGroupId++}`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCheckboxGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiCheckboxGroupComponent, isStandalone: true, selector: "iui-checkbox-group", inputs: { label: "label", showLabel: "showLabel", orientation: "orientation", required: "required", levels: "levels" }, host: { attributes: { "role": "group" }, properties: { "class.iui-checkbox-group--horizontal": "orientation === \"horizontal\"", "class.iui-checkbox-group--level-2": "levels === \"2\"", "attr.aria-labelledby": "showLabel && label ? _labelId : null" }, classAttribute: "iui-checkbox-group" }, ngImport: i0, template: "<div class=\"iui-checkbox-group__label\" *ngIf=\"showLabel && label\">\n\t<span class=\"iui-checkbox-group__label-text\" [attr.id]=\"_labelId\">{{ label }}</span>\n\t<span class=\"iui-checkbox-group__required\" *ngIf=\"required\">*</span>\n</div>\n<div class=\"iui-checkbox-group__items\"\n\t[class.iui-checkbox-group__items--horizontal]=\"orientation === 'horizontal'\">\n\t<ng-content></ng-content>\n</div>\n", styles: [":host{display:flex;flex-direction:column;align-items:flex-start}.iui-checkbox-group__label{display:flex;gap:4px;align-items:flex-start;padding-bottom:8px}.iui-checkbox-group__label-text{font:var(--iui-tp-label-01-font);color:var(--iui-checkbox-group-label-color)}.iui-checkbox-group__required{font:var(--iui-tp-label-01-font);color:var(--iui-checkbox-group-required-color)}.iui-checkbox-group__items{display:flex;flex-direction:column;gap:8px;align-items:flex-start}.iui-checkbox-group__items--horizontal{flex-direction:row;gap:16px}:host(.iui-checkbox-group--level-2) ::ng-deep .iui-checkbox-group__nested{padding-left:28px;display:flex;flex-direction:column;gap:8px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCheckboxGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-checkbox-group', standalone: true, imports: [CommonModule], host: {
                        'class': 'iui-checkbox-group',
                        '[class.iui-checkbox-group--horizontal]': 'orientation === "horizontal"',
                        '[class.iui-checkbox-group--level-2]': 'levels === "2"',
                        'role': 'group',
                        '[attr.aria-labelledby]': 'showLabel && label ? _labelId : null'
                    }, template: "<div class=\"iui-checkbox-group__label\" *ngIf=\"showLabel && label\">\n\t<span class=\"iui-checkbox-group__label-text\" [attr.id]=\"_labelId\">{{ label }}</span>\n\t<span class=\"iui-checkbox-group__required\" *ngIf=\"required\">*</span>\n</div>\n<div class=\"iui-checkbox-group__items\"\n\t[class.iui-checkbox-group__items--horizontal]=\"orientation === 'horizontal'\">\n\t<ng-content></ng-content>\n</div>\n", styles: [":host{display:flex;flex-direction:column;align-items:flex-start}.iui-checkbox-group__label{display:flex;gap:4px;align-items:flex-start;padding-bottom:8px}.iui-checkbox-group__label-text{font:var(--iui-tp-label-01-font);color:var(--iui-checkbox-group-label-color)}.iui-checkbox-group__required{font:var(--iui-tp-label-01-font);color:var(--iui-checkbox-group-required-color)}.iui-checkbox-group__items{display:flex;flex-direction:column;gap:8px;align-items:flex-start}.iui-checkbox-group__items--horizontal{flex-direction:row;gap:16px}:host(.iui-checkbox-group--level-2) ::ng-deep .iui-checkbox-group__nested{padding-left:28px;display:flex;flex-direction:column;gap:8px}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], showLabel: [{
                type: Input
            }], orientation: [{
                type: Input
            }], required: [{
                type: Input
            }], levels: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IuiCheckboxGroupComponent };
//# sourceMappingURL=itero-ui-components-angular-checkbox-group.mjs.map
