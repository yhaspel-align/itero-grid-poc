/**
 * AG Grid `themeQuartz` params for light mode.
 *
 * @example
 * ```typescript
 * import { themeQuartz, iconSetQuartzLight } from 'ag-grid-community';
 * import { GRID_LIGHT_THEME } from '@itero/ui-components-angular/grid-tokens';
 *
 * export const lightTheme = themeQuartz
 *   .withPart(iconSetQuartzLight)
 *   .withParams(GRID_LIGHT_THEME);
 * ```
 */
const GRID_LIGHT_THEME = {
    backgroundColor: '#FFFFFF', // background-subtle-01
    browserColorScheme: 'light',
    columnBorder: false,
    fontFamily: { googleFont: 'Roboto' }, // Align brand font
    foregroundColor: '#000000ED', // text-primary
    headerBackgroundColor: '#F4F4F4', // background-subtle-00
    headerFontWeight: 500, // tp-heading weight
    headerTextColor: '#000000A1', // text-secondary
    oddRowBackgroundColor: '#F4F4F4', // background-subtle-00
    rowBorder: false,
    sidePanelBorder: false,
    spacing: 8, // 2 × iui-main-unit (4px)
    wrapperBorder: false,
    wrapperBorderRadius: 0,
};
/**
 * AG Grid `themeQuartz` params for dark mode.
 *
 * @example
 * ```typescript
 * import { themeQuartz } from 'ag-grid-community';
 * import { GRID_DARK_THEME } from '@itero/ui-components-angular/grid-tokens';
 *
 * export const darkTheme = themeQuartz
 *   .withParams(GRID_DARK_THEME);
 * ```
 */
const GRID_DARK_THEME = {
    accentColor: '#009ACE', // background-interactive
    backgroundColor: '#1B1B1B', // background-subtle-01 dark
    borderColor: '#FFFFFF16', // border-subtle dark
    borderRadius: 0,
    browserColorScheme: 'dark',
    cellHorizontalPaddingScale: 0.8,
    cellTextColor: '#FFFFFF', // text-primary dark
    columnBorder: true,
    fontFamily: { googleFont: 'Roboto' }, // Align brand font
    fontSize: 14, // tp-body-01
    foregroundColor: '#FFFFFF', // text-primary dark
    headerBackgroundColor: '#121212', // background-subtle-00 dark
    headerFontWeight: 500, // tp-heading weight
    headerTextColor: '#FFFFFFA1', // text-secondary dark
    headerVerticalPaddingScale: 1.5,
    oddRowBackgroundColor: '#121212', // background-subtle-00 dark
    rangeSelectionBackgroundColor: '#FFFFFF0A', // background-layer-selected dark
    rangeSelectionBorderColor: '#41C1F0', // border-interactive dark
    rangeSelectionBorderStyle: 'solid',
    rowBorder: true,
    rowVerticalPaddingScale: 1.5,
    sidePanelBorder: true,
    spacing: 4, // 1 × iui-main-unit (4px)
    wrapperBorder: true,
    wrapperBorderRadius: 0,
};
/**
 * `GridHeaderTheme` values for light mode.
 *
 * @example
 * ```typescript
 * import { GRID_HEADER_LIGHT_THEME } from '@itero/ui-components-angular/grid-tokens';
 *
 * @Component({ template: `<iui-grid-header [theme]="theme">` })
 * export class MyComponent {
 *   readonly theme = GRID_HEADER_LIGHT_THEME;
 * }
 * ```
 */
const GRID_HEADER_LIGHT_THEME = {
    backgroundColor: '#FFFFFF', // background-subtle-01
    textColor: '#000000ED', // text-primary
    borderColor: '#00000016', // border-subtle
    fontFamily: 'Roboto, Arial, sans-serif', // Align brand font
    inputBackground: '#FFFFFF', // background-subtle-01
    inputTextColor: '#000000ED', // text-primary
    inputBorderColor: '#00000016', // border-subtle
    inputBorderFocusColor: '#009ACE', // border-focus / border-interactive
    inputFocusShadow: 'rgba(0, 154, 206, 0.15)', // border-interactive (#009ACE) at 15%
    placeholderColor: '#00000071', // text-tertiary
    buttonBackground: '#FFFFFF', // background-subtle-01
    buttonTextColor: '#000000ED', // text-primary
    buttonBorderColor: '#00000016', // border-subtle
    buttonHoverBackground: '#00000016', // background-subtle-active (9% black)
    buttonHoverBorderColor: '#00000020', // border-subtle-hover (13% black)
    accentColor: '#009ACE', // background-interactive
};
/**
 * `GridHeaderTheme` values for dark mode.
 *
 * @example
 * ```typescript
 * import { GRID_HEADER_DARK_THEME } from '@itero/ui-components-angular/grid-tokens';
 *
 * @Component({ template: `<iui-grid-header [theme]="theme">` })
 * export class MyComponent {
 *   readonly theme = GRID_HEADER_DARK_THEME;
 * }
 * ```
 */
const GRID_HEADER_DARK_THEME = {
    backgroundColor: '#1B1B1B', // background-subtle-01 dark
    textColor: '#FFFFFF', // text-primary dark
    borderColor: '#FFFFFF16', // border-subtle dark
    fontFamily: 'Roboto, Arial, sans-serif', // Align brand font
    inputBackground: '#1B1B1B', // background-subtle-01 dark
    inputTextColor: '#FFFFFF', // text-primary dark
    inputBorderColor: '#FFFFFF16', // border-subtle dark
    inputBorderFocusColor: '#41C1F0', // border-interactive dark
    inputFocusShadow: 'rgba(65, 193, 240, 0.15)', // border-interactive (#41C1F0) at 15%
    placeholderColor: '#FFFFFF78', // text-tertiary dark
    buttonBackground: '#1B1B1B', // background-subtle-01 dark
    buttonTextColor: '#FFFFFF', // text-primary dark
    buttonBorderColor: '#FFFFFF16', // border-subtle dark
    buttonHoverBackground: '#FFFFFF0B', // background-subtle-hover dark
    buttonHoverBorderColor: '#FFFFFF20', // border-subtle-hover dark
    accentColor: '#009ACE', // background-interactive
};

/**
 * Generated bundle index. Do not edit.
 */

export { GRID_DARK_THEME, GRID_HEADER_DARK_THEME, GRID_HEADER_LIGHT_THEME, GRID_LIGHT_THEME };
//# sourceMappingURL=itero-ui-components-angular-grid-tokens.mjs.map
