import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CalendarDayState, RangePosition } from './iui-calendar-day.component';
import { CalendarView, DatePickerType, DateRange } from './types';
import * as i0 from "@angular/core";
export interface CalendarCell {
    date: Date;
    state: CalendarDayState;
    isToday: boolean;
    rangePosition: RangePosition;
}
export declare class IuiCalendarComponent implements OnChanges {
    type: DatePickerType;
    currentView: CalendarView;
    displayMonth: Date;
    selectedDate: Date | null;
    selectedRange: DateRange | null;
    hoverDate: Date | null;
    minDate: Date | null;
    maxDate: Date | null;
    dateSelected: EventEmitter<Date>;
    viewChange: EventEmitter<CalendarView>;
    displayMonthChange: EventEmitter<Date>;
    dateHover: EventEmitter<Date | null>;
    readonly weekdays: string[];
    _weeks: (CalendarCell | null)[][];
    _monthRows: {
        label: string;
        index: number;
        isSelected: boolean;
        isCurrentMonth: boolean;
    }[][];
    _yearRows: {
        value: number;
        isSelected: number;
        isCurrentYear: boolean;
    }[][];
    _yearRangeStart: number;
    ngOnChanges(changes: SimpleChanges): void;
    get _monthName(): string;
    get _year(): number;
    get _yearRangeLabel(): string;
    _navigatePrevMonth(): void;
    _navigateNextMonth(): void;
    _switchToMonthView(): void;
    _switchToYearView(): void;
    _selectMonth(monthIndex: number): void;
    _selectYear(year: number): void;
    _onDayClick(date: Date): void;
    _onDayHover(date: Date): void;
    _onDayLeave(): void;
    _buildWeeks(): void;
    _getDayState(date: Date): CalendarDayState;
    _getRangePosition(date: Date): RangePosition;
    _buildMonthGrid(): void;
    _buildYearGrid(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiCalendarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiCalendarComponent, "iui-calendar", never, { "type": { "alias": "type"; "required": false; }; "currentView": { "alias": "currentView"; "required": false; }; "displayMonth": { "alias": "displayMonth"; "required": false; }; "selectedDate": { "alias": "selectedDate"; "required": false; }; "selectedRange": { "alias": "selectedRange"; "required": false; }; "hoverDate": { "alias": "hoverDate"; "required": false; }; "minDate": { "alias": "minDate"; "required": false; }; "maxDate": { "alias": "maxDate"; "required": false; }; }, { "dateSelected": "dateSelected"; "viewChange": "viewChange"; "displayMonthChange": "displayMonthChange"; "dateHover": "dateHover"; }, never, never, true, never>;
}
