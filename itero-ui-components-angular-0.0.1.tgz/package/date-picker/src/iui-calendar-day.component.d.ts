import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type CalendarDayState = 'enabled' | 'hovered' | 'pressed' | 'focused' | 'selected' | 'in-range' | 'disabled';
export type RangePosition = 'none' | 'start' | 'middle' | 'end';
export declare class IuiCalendarDayComponent {
    date: Date;
    state: CalendarDayState;
    isToday: boolean;
    rangePosition: RangePosition;
    dayClick: EventEmitter<Date>;
    dayHover: EventEmitter<Date>;
    dayLeave: EventEmitter<void>;
    _handleClick(): void;
    _handleMouseEnter(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiCalendarDayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiCalendarDayComponent, "iui-calendar-day", never, { "date": { "alias": "date"; "required": false; }; "state": { "alias": "state"; "required": false; }; "isToday": { "alias": "isToday"; "required": false; }; "rangePosition": { "alias": "rangePosition"; "required": false; }; }, { "dayClick": "dayClick"; "dayHover": "dayHover"; "dayLeave": "dayLeave"; }, never, never, true, never>;
}
