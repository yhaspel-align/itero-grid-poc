import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
type mapperFunc<V = any, T extends any[] = any[], U = any> = (value: V, ...args: T) => U;
export declare class MapperPipe implements PipeTransform {
    transform<V = any, T extends any[] = any[], U = any>(value: V, callBack: mapperFunc<V, T, U>, ...args: T): ReturnType<mapperFunc<V, T, U>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MapperPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<MapperPipe, "mapper", true>;
}
export {};
