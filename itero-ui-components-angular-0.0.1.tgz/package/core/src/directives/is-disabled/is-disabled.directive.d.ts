import { EventEmitter, OnInit } from '@angular/core';
import { NgControlDirective } from '../ng-control/ng-control.directive';
import * as i0 from "@angular/core";
interface DisabledAccessor {
    setDisabledState(isDisabled: boolean): void;
}
export declare class IuiIsDisabledDirective implements DisabledAccessor, OnInit {
    /**
     * whether the control is disabled.
     * [part of IuiIsDisabledDirective]
     * By assigning this input to truthy value, it makes associated formControl disabled.
     * The name "isDisabled" differs to traditional naming "disabled" because it clashes with attribute "disabled" of the formControl
     * */
    set isDisabled(value: boolean | string | undefined | null);
    get isDisabled(): boolean;
    private _isDisabled;
    protected ngControlDirective: NgControlDirective<any> | null;
    disableChangeEvent: EventEmitter<boolean>;
    private get control();
    ngOnInit(): void;
    private handleDisabled;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiIsDisabledDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IuiIsDisabledDirective, "[isDisabled]", never, { "isDisabled": { "alias": "isDisabled"; "required": false; }; }, { "disableChangeEvent": "disableChangeEvent"; }, never, never, true, never>;
}
export {};
