import { ChangeDetectorRef, DoCheck, Injector, OnInit } from '@angular/core';
import { AbstractControl, FormGroupDirective, NgForm } from '@angular/forms';
import * as i0 from "@angular/core";
/** Error state matcher that matches when a control is invalid and dirty. */
export declare class ShowOnDirtyErrorStateMatcher implements IuiErrorStateMatcher {
    isErrorState(control: AbstractControl | null, form: FormGroupDirective | NgForm | null): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShowOnDirtyErrorStateMatcher, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ShowOnDirtyErrorStateMatcher>;
}
export declare class IuiInstantErrorStateMatcher implements IuiErrorStateMatcher {
    isErrorState(control: AbstractControl | null, form: FormGroupDirective | NgForm | null): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiInstantErrorStateMatcher, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IuiInstantErrorStateMatcher>;
}
/** Provider that defines how form controls behave with regards to displaying error messages. */
export declare class IuiErrorStateMatcher {
    isErrorState(control: AbstractControl | null, form: FormGroupDirective | NgForm | null): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiErrorStateMatcher, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IuiErrorStateMatcher>;
}
export declare class IuiErrorStateMatcherDirective implements OnInit, DoCheck {
    /** Whether the component is in an error state. */
    errorState: boolean;
    defaultErrorStateMatcher: IuiErrorStateMatcher;
    /** An object used to control the error state of the component. */
    errorStateMatcher: IuiErrorStateMatcher | undefined;
    cdr: ChangeDetectorRef;
    protected injector: Injector;
    private _parentFormGroup;
    private _parentForm;
    private _ngControl;
    ngOnInit(): void;
    /** returns true if errorState has changed */
    updateErrorState(): boolean;
    ngDoCheck(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiErrorStateMatcherDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IuiErrorStateMatcherDirective, never, never, { "errorStateMatcher": { "alias": "errorStateMatcher"; "required": false; }; }, {}, never, never, true, never>;
}
