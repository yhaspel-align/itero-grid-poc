# Progress Bar

`iui-progress-bar` displays measurable task completion progress. Use this component when you can estimate the completion percentage: file uploads, data imports, installations, or other long-running operations.

For indeterminate waiting where progress cannot be measured, use `iui-loading-spinner`.

## Import

```typescript
import { IuiProgressBarComponent } from '@itero/ui-components-angular/progress-bar';
```

## Basic Usage

```html
<iui-progress-bar
	label="Uploading file"
	[value]="50"
	helperText="128/256 items"
></iui-progress-bar>
```

## Success State

```html
<iui-progress-bar
	label="Uploading file"
	[value]="100"
	status="success"
	helperText="Upload complete"
></iui-progress-bar>
```

## Error and Retry

```html
<iui-progress-bar
	label="Uploading file"
	status="error"
	errorText="Upload failed"
	retryLabel="Try again"
	(retry)="retryUpload()"
></iui-progress-bar>
```

## Accessibility

- The component has `role="progressbar"` and sets `aria-valuemin`, `aria-valuemax`, `aria-valuenow`.
- If the visible `label` is hidden via `[showLabel]="false"`, provide `ariaLabel`.
- In the `error` state the component sets `aria-invalid="true"` and does not set `aria-valuenow`, since this represents an error state rather than numeric progress.
