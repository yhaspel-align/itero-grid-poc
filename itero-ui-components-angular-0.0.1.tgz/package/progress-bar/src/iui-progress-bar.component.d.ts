import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type IuiProgressBarStatus = 'in-progress' | 'success' | 'error';
export declare class IuiProgressBarComponent {
    /** Completion percentage. Values outside 0..100 are clamped. */
    value: number;
    /** Current progress status. Success and error render a full-width status bar. */
    status: IuiProgressBarStatus;
    /** Textual description of the task being completed. */
    label: string;
    get showLabel(): boolean;
    set showLabel(value: boolean | string | null | undefined);
    /** Assistive text shown below non-error progress states. */
    helperText: string;
    get showHelperText(): boolean;
    set showHelperText(value: boolean | string | null | undefined);
    /** Error message shown below the bar when status is error. */
    errorText: string;
    /** Text for the retry action shown in the error state. */
    retryLabel: string;
    /** Accessible name used when the visible label is hidden or unavailable. */
    ariaLabel: string;
    retry: EventEmitter<void>;
    private _showLabel;
    private _showHelperText;
    get normalizedValue(): number;
    get visualValue(): number;
    get progressStyle(): {
        width: string;
    };
    get computedAriaLabel(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiProgressBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiProgressBarComponent, "iui-progress-bar", never, { "value": { "alias": "value"; "required": false; }; "status": { "alias": "status"; "required": false; }; "label": { "alias": "label"; "required": false; }; "showLabel": { "alias": "showLabel"; "required": false; }; "helperText": { "alias": "helperText"; "required": false; }; "showHelperText": { "alias": "showHelperText"; "required": false; }; "errorText": { "alias": "errorText"; "required": false; }; "retryLabel": { "alias": "retryLabel"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, { "retry": "retry"; }, never, never, true, never>;
}
