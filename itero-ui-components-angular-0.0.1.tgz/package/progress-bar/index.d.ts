export * from './src/iui-progress-bar.component';
