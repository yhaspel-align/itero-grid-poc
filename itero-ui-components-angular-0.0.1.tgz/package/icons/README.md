# @itero/ui-components-angular/icons

Secondary entry point of `@itero/ui-components-angular`. It can be used by importing from `@itero/ui-components-angular/icons`.
this subpackage contains icons designed by Align.
You can preview icons in Align Design System. https://www.figma.com/file/N1toXOJRTuXXnATYuq8rmj/07.-Icons-library-%5B0.8.0%5D?type=design&node-id=2667-596&mode=design&t=j9qJJx20BTODxumk-0

To use these icons in your application You should 
1. Import corresponding component in your host component, for example
```typescript
import { Component } from '@angular/core';
import {ChevronDownIconComponent, HomeIconComponent } from "@itero/ui-components-angular/icons";

@Component({
	standalone: true,
	imports: [ChevronDownIconComponent, HomeIconComponent],
	selector: 'itero-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss'],
})
export class AppComponent {
}
```
2. Then you can use corresponded tag in the template
```angular2html
<iui-chevron-down-icon style="height: 32px; width: 32px"></iui-chevron-down-icon>
<iui-home-icon style="height: 32px; width: 32px; color: green"></iui-home-icon>
```
3. As you can see the name of the typescript component is written in PascalCase and ends with "Component" word, while the html tag of the component is written in kebap-case and starts with prefix "iui" (means iTero UI).
4. These rules of naming are related to all icons produced by this lib
