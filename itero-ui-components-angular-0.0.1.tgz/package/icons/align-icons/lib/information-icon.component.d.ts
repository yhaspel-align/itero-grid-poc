import * as i0 from "@angular/core";
export declare class InformationIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<InformationIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InformationIconComponent, "iui-information-icon", never, {}, {}, never, never, true, never>;
}
