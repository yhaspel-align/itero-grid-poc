import * as i0 from "@angular/core";
export declare class FlashOffFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FlashOffFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FlashOffFillIconComponent, "iui-flash-off-fill-icon", never, {}, {}, never, never, true, never>;
}
