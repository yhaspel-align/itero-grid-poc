import * as i0 from "@angular/core";
export declare class FolderAddIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FolderAddIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FolderAddIconComponent, "iui-folder-add-icon", never, {}, {}, never, never, true, never>;
}
