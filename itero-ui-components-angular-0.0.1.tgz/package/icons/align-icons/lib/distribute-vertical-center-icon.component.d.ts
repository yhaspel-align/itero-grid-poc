import * as i0 from "@angular/core";
export declare class DistributeVerticalCenterIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DistributeVerticalCenterIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DistributeVerticalCenterIconComponent, "iui-distribute-vertical-center-icon", never, {}, {}, never, never, true, never>;
}
