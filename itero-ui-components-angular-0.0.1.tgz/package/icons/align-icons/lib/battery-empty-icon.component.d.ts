import * as i0 from "@angular/core";
export declare class BatteryEmptyIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BatteryEmptyIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BatteryEmptyIconComponent, "iui-battery-empty-icon", never, {}, {}, never, never, true, never>;
}
