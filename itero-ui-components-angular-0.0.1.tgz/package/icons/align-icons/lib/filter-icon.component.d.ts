import * as i0 from "@angular/core";
export declare class FilterIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterIconComponent, "iui-filter-icon", never, {}, {}, never, never, true, never>;
}
