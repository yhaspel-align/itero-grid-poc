import * as i0 from "@angular/core";
export declare class CommunityIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommunityIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CommunityIconComponent, "iui-community-icon", never, {}, {}, never, never, true, never>;
}
