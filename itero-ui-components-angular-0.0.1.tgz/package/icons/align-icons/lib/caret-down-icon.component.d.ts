import * as i0 from "@angular/core";
export declare class CaretDownIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaretDownIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaretDownIconComponent, "iui-caret-down-icon", never, {}, {}, never, never, true, never>;
}
