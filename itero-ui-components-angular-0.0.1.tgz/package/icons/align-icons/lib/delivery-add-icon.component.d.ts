import * as i0 from "@angular/core";
export declare class DeliveryAddIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DeliveryAddIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeliveryAddIconComponent, "iui-delivery-add-icon", never, {}, {}, never, never, true, never>;
}
