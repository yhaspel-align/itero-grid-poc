import * as i0 from "@angular/core";
export declare class BookmarkAddIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BookmarkAddIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BookmarkAddIconComponent, "iui-bookmark-add-icon", never, {}, {}, never, never, true, never>;
}
