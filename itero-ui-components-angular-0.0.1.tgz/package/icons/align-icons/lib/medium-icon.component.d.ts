import * as i0 from "@angular/core";
export declare class MediumIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MediumIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MediumIconComponent, "iui-medium-icon", never, {}, {}, never, never, true, never>;
}
