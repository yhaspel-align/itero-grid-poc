import * as i0 from "@angular/core";
export declare class IdentificationIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<IdentificationIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IdentificationIconComponent, "iui-identification-icon", never, {}, {}, never, never, true, never>;
}
