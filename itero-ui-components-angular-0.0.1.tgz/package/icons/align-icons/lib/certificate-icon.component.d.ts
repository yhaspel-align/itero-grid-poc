import * as i0 from "@angular/core";
export declare class CertificateIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CertificateIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CertificateIconComponent, "iui-certificate-icon", never, {}, {}, never, never, true, never>;
}
