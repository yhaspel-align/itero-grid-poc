import * as i0 from "@angular/core";
export declare class GiftIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<GiftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiftIconComponent, "iui-gift-icon", never, {}, {}, never, never, true, never>;
}
