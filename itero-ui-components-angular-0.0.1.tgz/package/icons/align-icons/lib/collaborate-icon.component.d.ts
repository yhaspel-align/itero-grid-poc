import * as i0 from "@angular/core";
export declare class CollaborateIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CollaborateIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CollaborateIconComponent, "iui-collaborate-icon", never, {}, {}, never, never, true, never>;
}
