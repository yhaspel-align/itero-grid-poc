import * as i0 from "@angular/core";
export declare class ListIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ListIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListIconComponent, "iui-list-icon", never, {}, {}, never, never, true, never>;
}
