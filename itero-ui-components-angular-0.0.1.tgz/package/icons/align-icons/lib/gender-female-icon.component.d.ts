import * as i0 from "@angular/core";
export declare class GenderFemaleIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<GenderFemaleIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GenderFemaleIconComponent, "iui-gender-female-icon", never, {}, {}, never, never, true, never>;
}
