import * as i0 from "@angular/core";
export declare class JsonIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<JsonIconComponent, "iui-json-icon", never, {}, {}, never, never, true, never>;
}
