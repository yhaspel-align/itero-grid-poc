import * as i0 from "@angular/core";
export declare class CalendarRemindIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CalendarRemindIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CalendarRemindIconComponent, "iui-calendar-remind-icon", never, {}, {}, never, never, true, never>;
}
