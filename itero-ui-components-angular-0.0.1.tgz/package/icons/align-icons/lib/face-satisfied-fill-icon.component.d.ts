import * as i0 from "@angular/core";
export declare class FaceSatisfiedFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FaceSatisfiedFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaceSatisfiedFillIconComponent, "iui-face-satisfied-fill-icon", never, {}, {}, never, never, true, never>;
}
