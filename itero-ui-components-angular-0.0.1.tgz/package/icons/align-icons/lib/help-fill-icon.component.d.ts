import * as i0 from "@angular/core";
export declare class HelpFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<HelpFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HelpFillIconComponent, "iui-help-fill-icon", never, {}, {}, never, never, true, never>;
}
