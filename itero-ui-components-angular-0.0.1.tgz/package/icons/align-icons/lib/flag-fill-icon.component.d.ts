import * as i0 from "@angular/core";
export declare class FlagFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FlagFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FlagFillIconComponent, "iui-flag-fill-icon", never, {}, {}, never, never, true, never>;
}
