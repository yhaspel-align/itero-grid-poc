import * as i0 from "@angular/core";
export declare class MicrophoneOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MicrophoneOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MicrophoneOutlineIconComponent, "iui-microphone-outline-icon", never, {}, {}, never, never, true, never>;
}
