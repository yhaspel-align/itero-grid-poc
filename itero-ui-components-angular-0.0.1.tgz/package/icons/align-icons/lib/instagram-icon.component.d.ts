import * as i0 from "@angular/core";
export declare class InstagramIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<InstagramIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InstagramIconComponent, "iui-instagram-icon", never, {}, {}, never, never, true, never>;
}
