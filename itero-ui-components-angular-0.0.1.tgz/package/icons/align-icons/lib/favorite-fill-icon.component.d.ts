import * as i0 from "@angular/core";
export declare class FavoriteFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FavoriteFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FavoriteFillIconComponent, "iui-favorite-fill-icon", never, {}, {}, never, never, true, never>;
}
