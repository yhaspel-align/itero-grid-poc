import * as i0 from "@angular/core";
export declare class IsoIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<IsoIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IsoIconComponent, "iui-iso-icon", never, {}, {}, never, never, true, never>;
}
