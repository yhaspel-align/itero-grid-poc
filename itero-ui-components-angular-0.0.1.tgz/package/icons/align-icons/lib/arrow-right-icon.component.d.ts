import * as i0 from "@angular/core";
export declare class ArrowRightIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ArrowRightIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ArrowRightIconComponent, "iui-arrow-right-icon", never, {}, {}, never, never, true, never>;
}
