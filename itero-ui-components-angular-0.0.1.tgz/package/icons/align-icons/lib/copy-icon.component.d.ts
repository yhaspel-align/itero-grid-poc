import * as i0 from "@angular/core";
export declare class CopyIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CopyIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CopyIconComponent, "iui-copy-icon", never, {}, {}, never, never, true, never>;
}
