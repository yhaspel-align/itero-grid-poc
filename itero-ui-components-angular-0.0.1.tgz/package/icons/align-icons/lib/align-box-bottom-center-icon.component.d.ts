import * as i0 from "@angular/core";
export declare class AlignBoxBottomCenterIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignBoxBottomCenterIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignBoxBottomCenterIconComponent, "iui-align-box-bottom-center-icon", never, {}, {}, never, never, true, never>;
}
