import * as i0 from "@angular/core";
export declare class DocumentAddIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentAddIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentAddIconComponent, "iui-document-add-icon", never, {}, {}, never, never, true, never>;
}
