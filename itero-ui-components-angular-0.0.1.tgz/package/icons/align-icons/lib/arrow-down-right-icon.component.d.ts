import * as i0 from "@angular/core";
export declare class ArrowDownRightIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ArrowDownRightIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ArrowDownRightIconComponent, "iui-arrow-down-right-icon", never, {}, {}, never, never, true, never>;
}
