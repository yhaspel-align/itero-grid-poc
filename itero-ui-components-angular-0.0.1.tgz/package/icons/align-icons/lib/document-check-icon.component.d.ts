import * as i0 from "@angular/core";
export declare class DocumentCheckIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentCheckIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentCheckIconComponent, "iui-document-check-icon", never, {}, {}, never, never, true, never>;
}
