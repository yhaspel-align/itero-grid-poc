import * as i0 from "@angular/core";
export declare class AlignHorizontalCenterIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignHorizontalCenterIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignHorizontalCenterIconComponent, "iui-align-horizontal-center-icon", never, {}, {}, never, never, true, never>;
}
