import * as i0 from "@angular/core";
export declare class CaretLeftIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaretLeftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaretLeftIconComponent, "iui-caret-left-icon", never, {}, {}, never, never, true, never>;
}
