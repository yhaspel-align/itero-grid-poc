import * as i0 from "@angular/core";
export declare class FitToWidthIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FitToWidthIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FitToWidthIconComponent, "iui-fit-to-width-icon", never, {}, {}, never, never, true, never>;
}
