import * as i0 from "@angular/core";
export declare class CircleDashedIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CircleDashedIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CircleDashedIconComponent, "iui-circle-dashed-icon", never, {}, {}, never, never, true, never>;
}
