import * as i0 from "@angular/core";
export declare class ForwardIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ForwardIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ForwardIconComponent, "iui-forward-icon", never, {}, {}, never, never, true, never>;
}
