import * as i0 from "@angular/core";
export declare class ExitIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExitIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExitIconComponent, "iui-exit-icon", never, {}, {}, never, never, true, never>;
}
