import * as i0 from "@angular/core";
export declare class GalleryIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<GalleryIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GalleryIconComponent, "iui-gallery-icon", never, {}, {}, never, never, true, never>;
}
