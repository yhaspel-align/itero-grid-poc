import * as i0 from "@angular/core";
export declare class DesktopIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DesktopIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DesktopIconComponent, "iui-desktop-icon", never, {}, {}, never, never, true, never>;
}
