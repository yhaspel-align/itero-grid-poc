import * as i0 from "@angular/core";
export declare class Forward5IconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<Forward5IconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Forward5IconComponent, "iui-forward5-icon", never, {}, {}, never, never, true, never>;
}
