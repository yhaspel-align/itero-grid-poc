import * as i0 from "@angular/core";
export declare class DocumentAudioIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentAudioIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentAudioIconComponent, "iui-document-audio-icon", never, {}, {}, never, never, true, never>;
}
