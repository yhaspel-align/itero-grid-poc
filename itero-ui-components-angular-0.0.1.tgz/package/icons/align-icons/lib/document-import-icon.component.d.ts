import * as i0 from "@angular/core";
export declare class DocumentImportIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentImportIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentImportIconComponent, "iui-document-import-icon", never, {}, {}, never, never, true, never>;
}
