import * as i0 from "@angular/core";
export declare class DragHorizontalIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DragHorizontalIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DragHorizontalIconComponent, "iui-drag-horizontal-icon", never, {}, {}, never, never, true, never>;
}
