import * as i0 from "@angular/core";
export declare class FaceWinkOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FaceWinkOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaceWinkOutlineIconComponent, "iui-face-wink-outline-icon", never, {}, {}, never, never, true, never>;
}
