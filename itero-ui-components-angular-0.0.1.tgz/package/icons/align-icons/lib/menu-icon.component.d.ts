import * as i0 from "@angular/core";
export declare class MenuIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MenuIconComponent, "iui-menu-icon", never, {}, {}, never, never, true, never>;
}
