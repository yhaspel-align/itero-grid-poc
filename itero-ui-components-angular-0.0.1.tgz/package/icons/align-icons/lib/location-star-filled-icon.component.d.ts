import * as i0 from "@angular/core";
export declare class LocationStarFilledIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LocationStarFilledIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LocationStarFilledIconComponent, "iui-location-star-filled-icon", never, {}, {}, never, never, true, never>;
}
