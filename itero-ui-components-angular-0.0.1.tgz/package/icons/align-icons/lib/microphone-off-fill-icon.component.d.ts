import * as i0 from "@angular/core";
export declare class MicrophoneOffFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MicrophoneOffFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MicrophoneOffFillIconComponent, "iui-microphone-off-fill-icon", never, {}, {}, never, never, true, never>;
}
