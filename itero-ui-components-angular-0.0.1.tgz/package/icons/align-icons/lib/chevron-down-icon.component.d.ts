import * as i0 from "@angular/core";
export declare class ChevronDownIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ChevronDownIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChevronDownIconComponent, "iui-chevron-down-icon", never, {}, {}, never, never, true, never>;
}
