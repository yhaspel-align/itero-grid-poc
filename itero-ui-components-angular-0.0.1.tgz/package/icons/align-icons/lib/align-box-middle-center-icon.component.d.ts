import * as i0 from "@angular/core";
export declare class AlignBoxMiddleCenterIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignBoxMiddleCenterIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignBoxMiddleCenterIconComponent, "iui-align-box-middle-center-icon", never, {}, {}, never, never, true, never>;
}
