import * as i0 from "@angular/core";
export declare class ImageIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImageIconComponent, "iui-image-icon", never, {}, {}, never, never, true, never>;
}
