import * as i0 from "@angular/core";
export declare class DistributeHorizontalLeftIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DistributeHorizontalLeftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DistributeHorizontalLeftIconComponent, "iui-distribute-horizontal-left-icon", never, {}, {}, never, never, true, never>;
}
