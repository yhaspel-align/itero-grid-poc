import * as i0 from "@angular/core";
export declare class CopyDocumentIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CopyDocumentIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CopyDocumentIconComponent, "iui-copy-document-icon", never, {}, {}, never, never, true, never>;
}
