import * as i0 from "@angular/core";
export declare class DocumentProtectedIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentProtectedIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentProtectedIconComponent, "iui-document-protected-icon", never, {}, {}, never, never, true, never>;
}
