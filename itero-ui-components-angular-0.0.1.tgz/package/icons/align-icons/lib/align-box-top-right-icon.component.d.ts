import * as i0 from "@angular/core";
export declare class AlignBoxTopRightIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignBoxTopRightIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignBoxTopRightIconComponent, "iui-align-box-top-right-icon", never, {}, {}, never, never, true, never>;
}
