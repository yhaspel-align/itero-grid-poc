import * as i0 from "@angular/core";
export declare class DiscordIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DiscordIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DiscordIconComponent, "iui-discord-icon", never, {}, {}, never, never, true, never>;
}
