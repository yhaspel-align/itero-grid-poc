import * as i0 from "@angular/core";
export declare class BookIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BookIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BookIconComponent, "iui-book-icon", never, {}, {}, never, never, true, never>;
}
