import * as i0 from "@angular/core";
export declare class AddFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AddFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddFillIconComponent, "iui-add-fill-icon", never, {}, {}, never, never, true, never>;
}
