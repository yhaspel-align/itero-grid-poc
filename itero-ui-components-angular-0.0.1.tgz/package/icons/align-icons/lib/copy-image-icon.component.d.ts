import * as i0 from "@angular/core";
export declare class CopyImageIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CopyImageIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CopyImageIconComponent, "iui-copy-image-icon", never, {}, {}, never, never, true, never>;
}
