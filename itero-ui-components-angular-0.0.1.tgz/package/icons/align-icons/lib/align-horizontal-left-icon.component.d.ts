import * as i0 from "@angular/core";
export declare class AlignHorizontalLeftIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignHorizontalLeftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignHorizontalLeftIconComponent, "iui-align-horizontal-left-icon", never, {}, {}, never, never, true, never>;
}
