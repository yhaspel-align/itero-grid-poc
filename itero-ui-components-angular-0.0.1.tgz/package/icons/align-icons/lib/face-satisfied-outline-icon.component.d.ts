import * as i0 from "@angular/core";
export declare class FaceSatisfiedOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FaceSatisfiedOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaceSatisfiedOutlineIconComponent, "iui-face-satisfied-outline-icon", never, {}, {}, never, never, true, never>;
}
