import * as i0 from "@angular/core";
export declare class CompareIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CompareIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CompareIconComponent, "iui-compare-icon", never, {}, {}, never, never, true, never>;
}
