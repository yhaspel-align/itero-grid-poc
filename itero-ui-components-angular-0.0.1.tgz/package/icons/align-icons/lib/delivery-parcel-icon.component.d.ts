import * as i0 from "@angular/core";
export declare class DeliveryParcelIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DeliveryParcelIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeliveryParcelIconComponent, "iui-delivery-parcel-icon", never, {}, {}, never, never, true, never>;
}
