import * as i0 from "@angular/core";
export declare class CaretRightIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaretRightIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaretRightIconComponent, "iui-caret-right-icon", never, {}, {}, never, never, true, never>;
}
