import * as i0 from "@angular/core";
export declare class DocumentUnlockIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentUnlockIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentUnlockIconComponent, "iui-document-unlock-icon", never, {}, {}, never, never, true, never>;
}
