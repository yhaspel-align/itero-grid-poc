import * as i0 from "@angular/core";
export declare class BatteryLowIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BatteryLowIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BatteryLowIconComponent, "iui-battery-low-icon", never, {}, {}, never, never, true, never>;
}
