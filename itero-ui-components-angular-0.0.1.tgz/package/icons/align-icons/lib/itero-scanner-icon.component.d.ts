import * as i0 from "@angular/core";
export declare class IteroScannerIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<IteroScannerIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IteroScannerIconComponent, "iui-itero-scanner-icon", never, {}, {}, never, never, true, never>;
}
