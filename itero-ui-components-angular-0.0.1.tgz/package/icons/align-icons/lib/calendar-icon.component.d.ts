import * as i0 from "@angular/core";
export declare class CalendarIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CalendarIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CalendarIconComponent, "iui-calendar-icon", never, {}, {}, never, never, true, never>;
}
