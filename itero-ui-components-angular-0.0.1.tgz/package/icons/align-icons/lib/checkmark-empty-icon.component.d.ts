import * as i0 from "@angular/core";
export declare class CheckmarkEmptyIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckmarkEmptyIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckmarkEmptyIconComponent, "iui-checkmark-empty-icon", never, {}, {}, never, never, true, never>;
}
