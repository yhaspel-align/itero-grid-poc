import * as i0 from "@angular/core";
export declare class FaceDizzyOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FaceDizzyOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaceDizzyOutlineIconComponent, "iui-face-dizzy-outline-icon", never, {}, {}, never, never, true, never>;
}
