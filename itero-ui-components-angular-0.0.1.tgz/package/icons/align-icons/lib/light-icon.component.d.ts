import * as i0 from "@angular/core";
export declare class LightIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LightIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LightIconComponent, "iui-light-icon", never, {}, {}, never, never, true, never>;
}
