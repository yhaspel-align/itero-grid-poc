import * as i0 from "@angular/core";
export declare class BarcodeIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BarcodeIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BarcodeIconComponent, "iui-barcode-icon", never, {}, {}, never, never, true, never>;
}
