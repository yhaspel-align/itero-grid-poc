import * as i0 from "@angular/core";
export declare class AlignVerticalBottomIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignVerticalBottomIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignVerticalBottomIconComponent, "iui-align-vertical-bottom-icon", never, {}, {}, never, never, true, never>;
}
