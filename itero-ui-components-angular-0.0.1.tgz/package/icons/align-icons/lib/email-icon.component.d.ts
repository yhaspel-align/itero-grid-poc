import * as i0 from "@angular/core";
export declare class EmailIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<EmailIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EmailIconComponent, "iui-email-icon", never, {}, {}, never, never, true, never>;
}
