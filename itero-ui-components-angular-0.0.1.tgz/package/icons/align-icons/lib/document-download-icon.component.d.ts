import * as i0 from "@angular/core";
export declare class DocumentDownloadIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentDownloadIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentDownloadIconComponent, "iui-document-download-icon", never, {}, {}, never, never, true, never>;
}
