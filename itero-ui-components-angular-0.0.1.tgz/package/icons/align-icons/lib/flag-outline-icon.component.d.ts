import * as i0 from "@angular/core";
export declare class FlagOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FlagOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FlagOutlineIconComponent, "iui-flag-outline-icon", never, {}, {}, never, never, true, never>;
}
