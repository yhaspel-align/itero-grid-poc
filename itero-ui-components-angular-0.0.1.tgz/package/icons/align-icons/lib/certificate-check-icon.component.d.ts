import * as i0 from "@angular/core";
export declare class CertificateCheckIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CertificateCheckIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CertificateCheckIconComponent, "iui-certificate-check-icon", never, {}, {}, never, never, true, never>;
}
