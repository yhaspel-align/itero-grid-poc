import * as i0 from "@angular/core";
export declare class MobileLandscapeIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MobileLandscapeIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MobileLandscapeIconComponent, "iui-mobile-landscape-icon", never, {}, {}, never, never, true, never>;
}
