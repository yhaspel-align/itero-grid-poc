import * as i0 from "@angular/core";
export declare class DocIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocIconComponent, "iui-doc-icon", never, {}, {}, never, never, true, never>;
}
