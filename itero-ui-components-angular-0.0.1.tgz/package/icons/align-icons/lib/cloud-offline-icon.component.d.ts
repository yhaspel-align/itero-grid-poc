import * as i0 from "@angular/core";
export declare class CloudOfflineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CloudOfflineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CloudOfflineIconComponent, "iui-cloud-offline-icon", never, {}, {}, never, never, true, never>;
}
