import * as i0 from "@angular/core";
export declare class CaretUpIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaretUpIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaretUpIconComponent, "iui-caret-up-icon", never, {}, {}, never, never, true, never>;
}
