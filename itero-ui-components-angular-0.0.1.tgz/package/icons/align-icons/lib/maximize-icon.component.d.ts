import * as i0 from "@angular/core";
export declare class MaximizeIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MaximizeIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MaximizeIconComponent, "iui-maximize-icon", never, {}, {}, never, never, true, never>;
}
