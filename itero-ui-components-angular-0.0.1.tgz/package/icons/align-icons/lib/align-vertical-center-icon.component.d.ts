import * as i0 from "@angular/core";
export declare class AlignVerticalCenterIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignVerticalCenterIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignVerticalCenterIconComponent, "iui-align-vertical-center-icon", never, {}, {}, never, never, true, never>;
}
