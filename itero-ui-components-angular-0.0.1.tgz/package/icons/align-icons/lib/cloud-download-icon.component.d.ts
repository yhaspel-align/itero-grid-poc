import * as i0 from "@angular/core";
export declare class CloudDownloadIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CloudDownloadIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CloudDownloadIconComponent, "iui-cloud-download-icon", never, {}, {}, never, never, true, never>;
}
