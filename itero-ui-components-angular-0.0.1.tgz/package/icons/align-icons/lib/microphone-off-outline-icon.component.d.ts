import * as i0 from "@angular/core";
export declare class MicrophoneOffOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MicrophoneOffOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MicrophoneOffOutlineIconComponent, "iui-microphone-off-outline-icon", never, {}, {}, never, never, true, never>;
}
