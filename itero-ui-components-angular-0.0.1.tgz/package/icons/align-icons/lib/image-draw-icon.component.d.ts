import * as i0 from "@angular/core";
export declare class ImageDrawIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageDrawIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImageDrawIconComponent, "iui-image-draw-icon", never, {}, {}, never, never, true, never>;
}
