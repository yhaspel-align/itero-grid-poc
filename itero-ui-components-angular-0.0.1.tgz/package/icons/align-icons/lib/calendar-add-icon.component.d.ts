import * as i0 from "@angular/core";
export declare class CalendarAddIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CalendarAddIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CalendarAddIconComponent, "iui-calendar-add-icon", never, {}, {}, never, never, true, never>;
}
