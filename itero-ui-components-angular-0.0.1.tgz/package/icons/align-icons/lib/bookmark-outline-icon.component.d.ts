import * as i0 from "@angular/core";
export declare class BookmarkOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BookmarkOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BookmarkOutlineIconComponent, "iui-bookmark-outline-icon", never, {}, {}, never, never, true, never>;
}
