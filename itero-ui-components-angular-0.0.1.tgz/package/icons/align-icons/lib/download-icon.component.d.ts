import * as i0 from "@angular/core";
export declare class DownloadIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DownloadIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DownloadIconComponent, "iui-download-icon", never, {}, {}, never, never, true, never>;
}
