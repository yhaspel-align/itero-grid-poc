import * as i0 from "@angular/core";
export declare class DevicesIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DevicesIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DevicesIconComponent, "iui-devices-icon", never, {}, {}, never, never, true, never>;
}
