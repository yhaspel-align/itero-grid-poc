import * as i0 from "@angular/core";
export declare class DocumentViewIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentViewIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentViewIconComponent, "iui-document-view-icon", never, {}, {}, never, never, true, never>;
}
