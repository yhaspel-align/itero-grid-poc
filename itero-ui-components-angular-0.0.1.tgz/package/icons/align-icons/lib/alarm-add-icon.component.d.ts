import * as i0 from "@angular/core";
export declare class AlarmAddIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlarmAddIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlarmAddIconComponent, "iui-alarm-add-icon", never, {}, {}, never, never, true, never>;
}
