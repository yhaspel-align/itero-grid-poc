import * as i0 from "@angular/core";
export declare class FolderIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FolderIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FolderIconComponent, "iui-folder-icon", never, {}, {}, never, never, true, never>;
}
