import * as i0 from "@angular/core";
export declare class JpgIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<JpgIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<JpgIconComponent, "iui-jpg-icon", never, {}, {}, never, never, true, never>;
}
