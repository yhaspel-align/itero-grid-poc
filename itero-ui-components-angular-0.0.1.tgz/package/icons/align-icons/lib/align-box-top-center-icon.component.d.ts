import * as i0 from "@angular/core";
export declare class AlignBoxTopCenterIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignBoxTopCenterIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignBoxTopCenterIconComponent, "iui-align-box-top-center-icon", never, {}, {}, never, never, true, never>;
}
