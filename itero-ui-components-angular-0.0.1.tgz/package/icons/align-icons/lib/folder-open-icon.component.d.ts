import * as i0 from "@angular/core";
export declare class FolderOpenIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FolderOpenIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FolderOpenIconComponent, "iui-folder-open-icon", never, {}, {}, never, never, true, never>;
}
