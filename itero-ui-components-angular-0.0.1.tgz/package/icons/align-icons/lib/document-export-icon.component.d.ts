import * as i0 from "@angular/core";
export declare class DocumentExportIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentExportIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentExportIconComponent, "iui-document-export-icon", never, {}, {}, never, never, true, never>;
}
