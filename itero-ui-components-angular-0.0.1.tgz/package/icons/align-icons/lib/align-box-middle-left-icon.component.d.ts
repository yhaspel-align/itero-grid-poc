import * as i0 from "@angular/core";
export declare class AlignBoxMiddleLeftIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignBoxMiddleLeftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignBoxMiddleLeftIconComponent, "iui-align-box-middle-left-icon", never, {}, {}, never, never, true, never>;
}
