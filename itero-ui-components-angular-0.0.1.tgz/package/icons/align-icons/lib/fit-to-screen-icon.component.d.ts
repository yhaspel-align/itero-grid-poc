import * as i0 from "@angular/core";
export declare class FitToScreenIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FitToScreenIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FitToScreenIconComponent, "iui-fit-to-screen-icon", never, {}, {}, never, never, true, never>;
}
