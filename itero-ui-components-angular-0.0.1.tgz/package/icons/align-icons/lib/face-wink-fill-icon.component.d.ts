import * as i0 from "@angular/core";
export declare class FaceWinkFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FaceWinkFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaceWinkFillIconComponent, "iui-face-wink-fill-icon", never, {}, {}, never, never, true, never>;
}
