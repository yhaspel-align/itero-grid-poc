import * as i0 from "@angular/core";
export declare class Forward10IconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<Forward10IconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Forward10IconComponent, "iui-forward10-icon", never, {}, {}, never, never, true, never>;
}
