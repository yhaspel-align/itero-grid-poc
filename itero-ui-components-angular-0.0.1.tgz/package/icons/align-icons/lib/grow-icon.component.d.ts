import * as i0 from "@angular/core";
export declare class GrowIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<GrowIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GrowIconComponent, "iui-grow-icon", never, {}, {}, never, never, true, never>;
}
