import * as i0 from "@angular/core";
export declare class HelpOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<HelpOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HelpOutlineIconComponent, "iui-help-outline-icon", never, {}, {}, never, never, true, never>;
}
