import * as i0 from "@angular/core";
export declare class AddCommentIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AddCommentIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddCommentIconComponent, "iui-add-comment-icon", never, {}, {}, never, never, true, never>;
}
