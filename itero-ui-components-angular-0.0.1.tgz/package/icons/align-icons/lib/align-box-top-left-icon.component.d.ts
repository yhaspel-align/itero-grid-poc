import * as i0 from "@angular/core";
export declare class AlignBoxTopLeftIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignBoxTopLeftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignBoxTopLeftIconComponent, "iui-align-box-top-left-icon", never, {}, {}, never, never, true, never>;
}
