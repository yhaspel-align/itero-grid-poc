import * as i0 from "@angular/core";
export declare class LocationStarOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LocationStarOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LocationStarOutlineIconComponent, "iui-location-star-outline-icon", never, {}, {}, never, never, true, never>;
}
