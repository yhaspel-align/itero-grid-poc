import * as i0 from "@angular/core";
export declare class AlignBoxBottomLeftIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignBoxBottomLeftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignBoxBottomLeftIconComponent, "iui-align-box-bottom-left-icon", never, {}, {}, never, never, true, never>;
}
