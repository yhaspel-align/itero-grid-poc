import * as i0 from "@angular/core";
export declare class CheckmarkOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckmarkOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckmarkOutlineIconComponent, "iui-checkmark-outline-icon", never, {}, {}, never, never, true, never>;
}
