import * as i0 from "@angular/core";
export declare class CaretBottomRightIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaretBottomRightIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaretBottomRightIconComponent, "iui-caret-bottom-right-icon", never, {}, {}, never, never, true, never>;
}
