import * as i0 from "@angular/core";
export declare class LaptopIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LaptopIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LaptopIconComponent, "iui-laptop-icon", never, {}, {}, never, never, true, never>;
}
