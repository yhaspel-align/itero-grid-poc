import * as i0 from "@angular/core";
export declare class FacePendingFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FacePendingFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FacePendingFillIconComponent, "iui-face-pending-fill-icon", never, {}, {}, never, never, true, never>;
}
