import * as i0 from "@angular/core";
export declare class FolderDetailIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FolderDetailIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FolderDetailIconComponent, "iui-folder-detail-icon", never, {}, {}, never, never, true, never>;
}
