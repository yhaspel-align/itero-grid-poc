import * as i0 from "@angular/core";
export declare class FacebookIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FacebookIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FacebookIconComponent, "iui-facebook-icon", never, {}, {}, never, never, true, never>;
}
