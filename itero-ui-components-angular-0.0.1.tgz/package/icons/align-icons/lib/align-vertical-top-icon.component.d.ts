import * as i0 from "@angular/core";
export declare class AlignVerticalTopIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignVerticalTopIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignVerticalTopIconComponent, "iui-align-vertical-top-icon", never, {}, {}, never, never, true, never>;
}
