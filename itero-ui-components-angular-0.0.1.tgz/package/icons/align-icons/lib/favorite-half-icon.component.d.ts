import * as i0 from "@angular/core";
export declare class FavoriteHalfIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FavoriteHalfIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FavoriteHalfIconComponent, "iui-favorite-half-icon", never, {}, {}, never, never, true, never>;
}
