import * as i0 from "@angular/core";
export declare class LinkedinIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkedinIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkedinIconComponent, "iui-linkedin-icon", never, {}, {}, never, never, true, never>;
}
