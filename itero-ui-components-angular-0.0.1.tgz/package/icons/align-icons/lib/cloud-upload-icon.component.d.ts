import * as i0 from "@angular/core";
export declare class CloudUploadIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CloudUploadIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CloudUploadIconComponent, "iui-cloud-upload-icon", never, {}, {}, never, never, true, never>;
}
