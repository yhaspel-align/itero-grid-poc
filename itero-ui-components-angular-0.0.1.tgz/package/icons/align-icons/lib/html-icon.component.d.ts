import * as i0 from "@angular/core";
export declare class HtmlIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<HtmlIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HtmlIconComponent, "iui-html-icon", never, {}, {}, never, never, true, never>;
}
