import * as i0 from "@angular/core";
export declare class FactoryIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FactoryIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FactoryIconComponent, "iui-factory-icon", never, {}, {}, never, never, true, never>;
}
