import * as i0 from "@angular/core";
export declare class DocumentSignedIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentSignedIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentSignedIconComponent, "iui-document-signed-icon", never, {}, {}, never, never, true, never>;
}
