import * as i0 from "@angular/core";
export declare class EraseIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<EraseIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EraseIconComponent, "iui-erase-icon", never, {}, {}, never, never, true, never>;
}
