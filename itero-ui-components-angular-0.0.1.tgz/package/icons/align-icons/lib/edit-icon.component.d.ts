import * as i0 from "@angular/core";
export declare class EditIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<EditIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditIconComponent, "iui-edit-icon", never, {}, {}, never, never, true, never>;
}
