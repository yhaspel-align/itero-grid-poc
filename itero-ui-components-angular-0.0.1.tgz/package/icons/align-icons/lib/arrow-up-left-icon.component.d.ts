import * as i0 from "@angular/core";
export declare class ArrowUpLeftIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ArrowUpLeftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ArrowUpLeftIconComponent, "iui-arrow-up-left-icon", never, {}, {}, never, never, true, never>;
}
