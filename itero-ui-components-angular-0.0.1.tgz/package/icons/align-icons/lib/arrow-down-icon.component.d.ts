import * as i0 from "@angular/core";
export declare class ArrowDownIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ArrowDownIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ArrowDownIconComponent, "iui-arrow-down-icon", never, {}, {}, never, never, true, never>;
}
