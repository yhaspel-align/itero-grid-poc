import * as i0 from "@angular/core";
export declare class BadgeIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BadgeIconComponent, "iui-badge-icon", never, {}, {}, never, never, true, never>;
}
