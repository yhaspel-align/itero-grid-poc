import * as i0 from "@angular/core";
export declare class BatteryHalfIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BatteryHalfIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BatteryHalfIconComponent, "iui-battery-half-icon", never, {}, {}, never, never, true, never>;
}
