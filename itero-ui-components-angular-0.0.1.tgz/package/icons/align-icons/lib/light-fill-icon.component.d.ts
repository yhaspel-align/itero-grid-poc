import * as i0 from "@angular/core";
export declare class LightFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LightFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LightFillIconComponent, "iui-light-fill-icon", never, {}, {}, never, never, true, never>;
}
