import * as i0 from "@angular/core";
export declare class CdaIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CdaIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CdaIconComponent, "iui-cda-icon", never, {}, {}, never, never, true, never>;
}
