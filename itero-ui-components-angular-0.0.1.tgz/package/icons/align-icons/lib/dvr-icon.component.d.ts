import * as i0 from "@angular/core";
export declare class DvrIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DvrIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DvrIconComponent, "iui-dvr-icon", never, {}, {}, never, never, true, never>;
}
