import * as i0 from "@angular/core";
export declare class CloseFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CloseFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CloseFillIconComponent, "iui-close-fill-icon", never, {}, {}, never, never, true, never>;
}
