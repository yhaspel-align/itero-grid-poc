import * as i0 from "@angular/core";
export declare class BatteryFullIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BatteryFullIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BatteryFullIconComponent, "iui-battery-full-icon", never, {}, {}, never, never, true, never>;
}
