import * as i0 from "@angular/core";
export declare class FaceDissatisfiedOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FaceDissatisfiedOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaceDissatisfiedOutlineIconComponent, "iui-face-dissatisfied-outline-icon", never, {}, {}, never, never, true, never>;
}
