import * as i0 from "@angular/core";
export declare class CameraIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CameraIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CameraIconComponent, "iui-camera-icon", never, {}, {}, never, never, true, never>;
}
