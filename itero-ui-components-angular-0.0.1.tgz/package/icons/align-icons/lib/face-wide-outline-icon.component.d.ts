import * as i0 from "@angular/core";
export declare class FaceWideOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FaceWideOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaceWideOutlineIconComponent, "iui-face-wide-outline-icon", never, {}, {}, never, never, true, never>;
}
