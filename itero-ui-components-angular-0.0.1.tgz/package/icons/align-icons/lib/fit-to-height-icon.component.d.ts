import * as i0 from "@angular/core";
export declare class FitToHeightIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FitToHeightIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FitToHeightIconComponent, "iui-fit-to-height-icon", never, {}, {}, never, never, true, never>;
}
