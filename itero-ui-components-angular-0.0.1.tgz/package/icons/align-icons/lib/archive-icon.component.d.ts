import * as i0 from "@angular/core";
export declare class ArchiveIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ArchiveIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ArchiveIconComponent, "iui-archive-icon", never, {}, {}, never, never, true, never>;
}
