import * as i0 from "@angular/core";
export declare class LogoutIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoutIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LogoutIconComponent, "iui-logout-icon", never, {}, {}, never, never, true, never>;
}
