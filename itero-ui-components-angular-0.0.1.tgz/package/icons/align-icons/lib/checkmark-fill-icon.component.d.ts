import * as i0 from "@angular/core";
export declare class CheckmarkFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckmarkFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckmarkFillIconComponent, "iui-checkmark-fill-icon", never, {}, {}, never, never, true, never>;
}
