import * as i0 from "@angular/core";
export declare class FolderOffIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FolderOffIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FolderOffIconComponent, "iui-folder-off-icon", never, {}, {}, never, never, true, never>;
}
