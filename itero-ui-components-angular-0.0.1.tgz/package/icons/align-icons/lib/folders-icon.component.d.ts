import * as i0 from "@angular/core";
export declare class FoldersIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FoldersIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FoldersIconComponent, "iui-folders-icon", never, {}, {}, never, never, true, never>;
}
