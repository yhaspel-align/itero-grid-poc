import * as i0 from "@angular/core";
export declare class Forward30IconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<Forward30IconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Forward30IconComponent, "iui-forward30-icon", never, {}, {}, never, never, true, never>;
}
