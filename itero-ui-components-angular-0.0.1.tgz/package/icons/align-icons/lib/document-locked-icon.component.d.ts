import * as i0 from "@angular/core";
export declare class DocumentLockedIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentLockedIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentLockedIconComponent, "iui-document-locked-icon", never, {}, {}, never, never, true, never>;
}
