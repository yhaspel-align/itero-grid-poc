import * as i0 from "@angular/core";
export declare class DocumentSubtractIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentSubtractIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentSubtractIconComponent, "iui-document-subtract-icon", never, {}, {}, never, never, true, never>;
}
