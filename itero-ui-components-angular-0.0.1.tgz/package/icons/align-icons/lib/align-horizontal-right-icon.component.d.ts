import * as i0 from "@angular/core";
export declare class AlignHorizontalRightIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignHorizontalRightIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignHorizontalRightIconComponent, "iui-align-horizontal-right-icon", never, {}, {}, never, never, true, never>;
}
