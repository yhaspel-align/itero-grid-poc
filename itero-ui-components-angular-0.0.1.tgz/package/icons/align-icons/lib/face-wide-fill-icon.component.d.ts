import * as i0 from "@angular/core";
export declare class FaceWideFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FaceWideFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaceWideFillIconComponent, "iui-face-wide-fill-icon", never, {}, {}, never, never, true, never>;
}
