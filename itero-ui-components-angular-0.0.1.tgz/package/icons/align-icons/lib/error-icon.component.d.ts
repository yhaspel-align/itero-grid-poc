import * as i0 from "@angular/core";
export declare class ErrorIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ErrorIconComponent, "iui-error-icon", never, {}, {}, never, never, true, never>;
}
