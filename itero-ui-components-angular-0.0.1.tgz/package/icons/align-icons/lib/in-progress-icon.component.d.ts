import * as i0 from "@angular/core";
export declare class InProgressIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<InProgressIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InProgressIconComponent, "iui-in-progress-icon", never, {}, {}, never, never, true, never>;
}
