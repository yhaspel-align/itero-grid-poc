import * as i0 from "@angular/core";
export declare class CutIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CutIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CutIconComponent, "iui-cut-icon", never, {}, {}, never, never, true, never>;
}
