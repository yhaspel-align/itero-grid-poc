import * as i0 from "@angular/core";
export declare class FaceIdIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FaceIdIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaceIdIconComponent, "iui-face-id-icon", never, {}, {}, never, never, true, never>;
}
