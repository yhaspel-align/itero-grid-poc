import * as i0 from "@angular/core";
export declare class CsvIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CsvIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CsvIconComponent, "iui-csv-icon", never, {}, {}, never, never, true, never>;
}
