import * as i0 from "@angular/core";
export declare class ChatIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChatIconComponent, "iui-chat-icon", never, {}, {}, never, never, true, never>;
}
