import * as i0 from "@angular/core";
export declare class FolderMoveToIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FolderMoveToIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FolderMoveToIconComponent, "iui-folder-move-to-icon", never, {}, {}, never, never, true, never>;
}
