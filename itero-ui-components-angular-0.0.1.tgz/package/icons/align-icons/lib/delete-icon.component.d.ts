import * as i0 from "@angular/core";
export declare class DeleteIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DeleteIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeleteIconComponent, "iui-delete-icon", never, {}, {}, never, never, true, never>;
}
