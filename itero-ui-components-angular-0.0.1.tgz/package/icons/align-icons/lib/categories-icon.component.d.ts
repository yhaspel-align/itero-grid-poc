import * as i0 from "@angular/core";
export declare class CategoriesIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CategoriesIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CategoriesIconComponent, "iui-categories-icon", never, {}, {}, never, never, true, never>;
}
