import * as i0 from "@angular/core";
export declare class ChatLaunchIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatLaunchIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChatLaunchIconComponent, "iui-chat-launch-icon", never, {}, {}, never, never, true, never>;
}
