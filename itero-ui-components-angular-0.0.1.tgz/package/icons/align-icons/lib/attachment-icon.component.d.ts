import * as i0 from "@angular/core";
export declare class AttachmentIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AttachmentIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttachmentIconComponent, "iui-attachment-icon", never, {}, {}, never, never, true, never>;
}
