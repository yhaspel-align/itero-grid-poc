import * as i0 from "@angular/core";
export declare class ArrowUpRightIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ArrowUpRightIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ArrowUpRightIconComponent, "iui-arrow-up-right-icon", never, {}, {}, never, never, true, never>;
}
