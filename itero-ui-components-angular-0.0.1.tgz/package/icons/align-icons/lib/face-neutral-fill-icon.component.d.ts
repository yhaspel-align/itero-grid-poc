import * as i0 from "@angular/core";
export declare class FaceNeutralFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FaceNeutralFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaceNeutralFillIconComponent, "iui-face-neutral-fill-icon", never, {}, {}, never, never, true, never>;
}
