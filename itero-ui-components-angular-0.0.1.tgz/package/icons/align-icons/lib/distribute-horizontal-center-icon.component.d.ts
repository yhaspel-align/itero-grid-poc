import * as i0 from "@angular/core";
export declare class DistributeHorizontalCenterIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DistributeHorizontalCenterIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DistributeHorizontalCenterIconComponent, "iui-distribute-horizontal-center-icon", never, {}, {}, never, never, true, never>;
}
