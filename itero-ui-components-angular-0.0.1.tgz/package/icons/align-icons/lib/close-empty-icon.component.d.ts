import * as i0 from "@angular/core";
export declare class CloseEmptyIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CloseEmptyIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CloseEmptyIconComponent, "iui-close-empty-icon", never, {}, {}, never, never, true, never>;
}
