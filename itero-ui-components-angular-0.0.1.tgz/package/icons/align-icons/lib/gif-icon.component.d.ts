import * as i0 from "@angular/core";
export declare class GifIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<GifIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GifIconComponent, "iui-gif-icon", never, {}, {}, never, never, true, never>;
}
