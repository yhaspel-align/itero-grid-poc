import * as i0 from "@angular/core";
export declare class ChevronUpIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ChevronUpIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChevronUpIconComponent, "iui-chevron-up-icon", never, {}, {}, never, never, true, never>;
}
