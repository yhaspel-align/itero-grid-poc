import * as i0 from "@angular/core";
export declare class FavoriteOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FavoriteOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FavoriteOutlineIconComponent, "iui-favorite-outline-icon", never, {}, {}, never, never, true, never>;
}
