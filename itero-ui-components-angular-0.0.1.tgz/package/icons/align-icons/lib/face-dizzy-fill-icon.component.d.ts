import * as i0 from "@angular/core";
export declare class FaceDizzyFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FaceDizzyFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaceDizzyFillIconComponent, "iui-face-dizzy-fill-icon", never, {}, {}, never, never, true, never>;
}
