import * as i0 from "@angular/core";
export declare class FolderSharedIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FolderSharedIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FolderSharedIconComponent, "iui-folder-shared-icon", never, {}, {}, never, never, true, never>;
}
