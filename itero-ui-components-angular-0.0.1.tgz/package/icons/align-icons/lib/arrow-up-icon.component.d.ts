import * as i0 from "@angular/core";
export declare class ArrowUpIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ArrowUpIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ArrowUpIconComponent, "iui-arrow-up-icon", never, {}, {}, never, never, true, never>;
}
