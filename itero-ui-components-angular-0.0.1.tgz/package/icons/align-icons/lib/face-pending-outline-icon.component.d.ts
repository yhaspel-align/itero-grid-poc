import * as i0 from "@angular/core";
export declare class FacePendingOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FacePendingOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FacePendingOutlineIconComponent, "iui-face-pending-outline-icon", never, {}, {}, never, never, true, never>;
}
