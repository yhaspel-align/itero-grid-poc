import * as i0 from "@angular/core";
export declare class EducationIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<EducationIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EducationIconComponent, "iui-education-icon", never, {}, {}, never, never, true, never>;
}
