import * as i0 from "@angular/core";
export declare class LoginIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoginIconComponent, "iui-login-icon", never, {}, {}, never, never, true, never>;
}
