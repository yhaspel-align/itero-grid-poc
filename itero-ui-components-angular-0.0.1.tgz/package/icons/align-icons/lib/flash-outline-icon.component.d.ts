import * as i0 from "@angular/core";
export declare class FlashOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FlashOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FlashOutlineIconComponent, "iui-flash-outline-icon", never, {}, {}, never, never, true, never>;
}
