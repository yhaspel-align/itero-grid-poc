import * as i0 from "@angular/core";
export declare class MobilePortraitIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MobilePortraitIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MobilePortraitIconComponent, "iui-mobile-portrait-icon", never, {}, {}, never, never, true, never>;
}
