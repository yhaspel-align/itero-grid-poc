import * as i0 from "@angular/core";
export declare class DeliveryIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DeliveryIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeliveryIconComponent, "iui-delivery-icon", never, {}, {}, never, never, true, never>;
}
