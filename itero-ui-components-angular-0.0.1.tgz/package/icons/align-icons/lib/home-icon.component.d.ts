import * as i0 from "@angular/core";
export declare class HomeIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<HomeIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HomeIconComponent, "iui-home-icon", never, {}, {}, never, never, true, never>;
}
