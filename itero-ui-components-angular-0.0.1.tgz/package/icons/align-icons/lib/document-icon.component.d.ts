import * as i0 from "@angular/core";
export declare class DocumentIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentIconComponent, "iui-document-icon", never, {}, {}, never, never, true, never>;
}
