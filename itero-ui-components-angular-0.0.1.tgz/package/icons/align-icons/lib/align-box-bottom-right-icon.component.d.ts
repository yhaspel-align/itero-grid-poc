import * as i0 from "@angular/core";
export declare class AlignBoxBottomRightIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignBoxBottomRightIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignBoxBottomRightIconComponent, "iui-align-box-bottom-right-icon", never, {}, {}, never, never, true, never>;
}
