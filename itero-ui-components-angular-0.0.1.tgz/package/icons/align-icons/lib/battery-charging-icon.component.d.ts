import * as i0 from "@angular/core";
export declare class BatteryChargingIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BatteryChargingIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BatteryChargingIconComponent, "iui-battery-charging-icon", never, {}, {}, never, never, true, never>;
}
