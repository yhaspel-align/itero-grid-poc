import * as i0 from "@angular/core";
export declare class MinimizeIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MinimizeIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MinimizeIconComponent, "iui-minimize-icon", never, {}, {}, never, never, true, never>;
}
