import * as i0 from "@angular/core";
export declare class IncompleteIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<IncompleteIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IncompleteIconComponent, "iui-incomplete-icon", never, {}, {}, never, never, true, never>;
}
