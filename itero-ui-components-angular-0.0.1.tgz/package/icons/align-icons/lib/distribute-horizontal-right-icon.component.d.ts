import * as i0 from "@angular/core";
export declare class DistributeHorizontalRightIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DistributeHorizontalRightIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DistributeHorizontalRightIconComponent, "iui-distribute-horizontal-right-icon", never, {}, {}, never, never, true, never>;
}
