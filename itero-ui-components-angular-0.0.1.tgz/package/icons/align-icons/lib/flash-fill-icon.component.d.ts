import * as i0 from "@angular/core";
export declare class FlashFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FlashFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FlashFillIconComponent, "iui-flash-fill-icon", never, {}, {}, never, never, true, never>;
}
