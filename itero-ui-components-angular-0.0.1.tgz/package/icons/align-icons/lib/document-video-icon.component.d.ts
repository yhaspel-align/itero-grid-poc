import * as i0 from "@angular/core";
export declare class DocumentVideoIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentVideoIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentVideoIconComponent, "iui-document-video-icon", never, {}, {}, never, never, true, never>;
}
