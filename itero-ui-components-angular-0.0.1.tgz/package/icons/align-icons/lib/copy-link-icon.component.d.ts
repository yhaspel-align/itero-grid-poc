import * as i0 from "@angular/core";
export declare class CopyLinkIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CopyLinkIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CopyLinkIconComponent, "iui-copy-link-icon", never, {}, {}, never, never, true, never>;
}
