import * as i0 from "@angular/core";
export declare class DragDropIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DragDropIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DragDropIconComponent, "iui-drag-drop-icon", never, {}, {}, never, never, true, never>;
}
