import * as i0 from "@angular/core";
export declare class DragVerticalIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DragVerticalIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DragVerticalIconComponent, "iui-drag-vertical-icon", never, {}, {}, never, never, true, never>;
}
