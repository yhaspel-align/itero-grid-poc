import * as i0 from "@angular/core";
export declare class LanguageIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LanguageIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LanguageIconComponent, "iui-language-icon", never, {}, {}, never, never, true, never>;
}
