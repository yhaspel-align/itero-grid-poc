import * as i0 from "@angular/core";
export declare class AlarmIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlarmIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlarmIconComponent, "iui-alarm-icon", never, {}, {}, never, never, true, never>;
}
