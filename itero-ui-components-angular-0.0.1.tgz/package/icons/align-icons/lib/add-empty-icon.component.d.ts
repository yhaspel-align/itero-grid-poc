import * as i0 from "@angular/core";
export declare class AddEmptyIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AddEmptyIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddEmptyIconComponent, "iui-add-empty-icon", never, {}, {}, never, never, true, never>;
}
