import * as i0 from "@angular/core";
export declare class FaceDissatisfiedFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FaceDissatisfiedFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaceDissatisfiedFillIconComponent, "iui-face-dissatisfied-fill-icon", never, {}, {}, never, never, true, never>;
}
