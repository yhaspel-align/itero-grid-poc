import * as i0 from "@angular/core";
export declare class CenterToFitIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CenterToFitIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CenterToFitIconComponent, "iui-center-to-fit-icon", never, {}, {}, never, never, true, never>;
}
