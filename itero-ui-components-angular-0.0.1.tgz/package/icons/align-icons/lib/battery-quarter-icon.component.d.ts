import * as i0 from "@angular/core";
export declare class BatteryQuarterIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BatteryQuarterIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BatteryQuarterIconComponent, "iui-battery-quarter-icon", never, {}, {}, never, never, true, never>;
}
