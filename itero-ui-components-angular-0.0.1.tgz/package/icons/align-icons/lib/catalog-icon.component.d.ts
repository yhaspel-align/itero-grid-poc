import * as i0 from "@angular/core";
export declare class CatalogIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CatalogIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CatalogIconComponent, "iui-catalog-icon", never, {}, {}, never, never, true, never>;
}
