import * as i0 from "@angular/core";
export declare class ArrowLeftIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ArrowLeftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ArrowLeftIconComponent, "iui-arrow-left-icon", never, {}, {}, never, never, true, never>;
}
