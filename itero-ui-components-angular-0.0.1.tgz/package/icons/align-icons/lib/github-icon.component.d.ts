import * as i0 from "@angular/core";
export declare class GithubIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<GithubIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GithubIconComponent, "iui-github-icon", never, {}, {}, never, never, true, never>;
}
