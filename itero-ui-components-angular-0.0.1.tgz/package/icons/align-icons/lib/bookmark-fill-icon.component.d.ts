import * as i0 from "@angular/core";
export declare class BookmarkFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BookmarkFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BookmarkFillIconComponent, "iui-bookmark-fill-icon", never, {}, {}, never, never, true, never>;
}
