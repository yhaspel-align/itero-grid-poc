import * as i0 from "@angular/core";
export declare class ChevronLeftIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ChevronLeftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChevronLeftIconComponent, "iui-chevron-left-icon", never, {}, {}, never, never, true, never>;
}
