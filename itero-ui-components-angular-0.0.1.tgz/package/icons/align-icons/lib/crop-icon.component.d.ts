import * as i0 from "@angular/core";
export declare class CropIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CropIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CropIconComponent, "iui-crop-icon", never, {}, {}, never, never, true, never>;
}
