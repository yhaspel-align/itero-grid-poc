import * as i0 from "@angular/core";
export declare class MicrophoneFillIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MicrophoneFillIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MicrophoneFillIconComponent, "iui-microphone-fill-icon", never, {}, {}, never, never, true, never>;
}
