import * as i0 from "@angular/core";
export declare class GenderMaleIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<GenderMaleIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GenderMaleIconComponent, "iui-gender-male-icon", never, {}, {}, never, never, true, never>;
}
