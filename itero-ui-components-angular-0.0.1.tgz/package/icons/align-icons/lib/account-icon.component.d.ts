import * as i0 from "@angular/core";
export declare class AccountIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccountIconComponent, "iui-account-icon", never, {}, {}, never, never, true, never>;
}
