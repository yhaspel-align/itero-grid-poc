import * as i0 from "@angular/core";
export declare class FaceNeutralOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FaceNeutralOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaceNeutralOutlineIconComponent, "iui-face-neutral-outline-icon", never, {}, {}, never, never, true, never>;
}
