import * as i0 from "@angular/core";
export declare class AlarmSubtractIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlarmSubtractIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlarmSubtractIconComponent, "iui-alarm-subtract-icon", never, {}, {}, never, never, true, never>;
}
