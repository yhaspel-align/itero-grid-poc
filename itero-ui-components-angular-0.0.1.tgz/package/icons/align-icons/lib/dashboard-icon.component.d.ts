import * as i0 from "@angular/core";
export declare class DashboardIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DashboardIconComponent, "iui-dashboard-icon", never, {}, {}, never, never, true, never>;
}
