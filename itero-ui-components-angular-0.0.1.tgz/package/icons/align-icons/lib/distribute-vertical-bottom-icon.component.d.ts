import * as i0 from "@angular/core";
export declare class DistributeVerticalBottomIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DistributeVerticalBottomIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DistributeVerticalBottomIconComponent, "iui-distribute-vertical-bottom-icon", never, {}, {}, never, never, true, never>;
}
