import * as i0 from "@angular/core";
export declare class DrawIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DrawIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DrawIconComponent, "iui-draw-icon", never, {}, {}, never, never, true, never>;
}
