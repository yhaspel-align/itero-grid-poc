import * as i0 from "@angular/core";
export declare class AlignBoxMiddleRightIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlignBoxMiddleRightIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlignBoxMiddleRightIconComponent, "iui-align-box-middle-right-icon", never, {}, {}, never, never, true, never>;
}
