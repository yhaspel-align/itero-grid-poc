import * as i0 from "@angular/core";
export declare class LinkIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkIconComponent, "iui-link-icon", never, {}, {}, never, never, true, never>;
}
