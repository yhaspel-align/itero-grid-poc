import * as i0 from "@angular/core";
export declare class LockedIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LockedIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LockedIconComponent, "iui-locked-icon", never, {}, {}, never, never, true, never>;
}
