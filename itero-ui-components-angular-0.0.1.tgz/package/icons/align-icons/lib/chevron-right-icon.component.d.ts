import * as i0 from "@angular/core";
export declare class ChevronRightIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ChevronRightIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChevronRightIconComponent, "iui-chevron-right-icon", never, {}, {}, never, never, true, never>;
}
