import * as i0 from "@angular/core";
export declare class DistributeVerticalTopIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DistributeVerticalTopIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DistributeVerticalTopIconComponent, "iui-distribute-vertical-top-icon", never, {}, {}, never, never, true, never>;
}
