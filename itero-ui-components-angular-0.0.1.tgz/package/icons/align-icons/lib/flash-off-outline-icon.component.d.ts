import * as i0 from "@angular/core";
export declare class FlashOffOutlineIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FlashOffOutlineIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FlashOffOutlineIconComponent, "iui-flash-off-outline-icon", never, {}, {}, never, never, true, never>;
}
