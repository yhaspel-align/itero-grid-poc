import * as i0 from "@angular/core";
export declare class CredentialsIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CredentialsIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CredentialsIconComponent, "iui-credentials-icon", never, {}, {}, never, never, true, never>;
}
