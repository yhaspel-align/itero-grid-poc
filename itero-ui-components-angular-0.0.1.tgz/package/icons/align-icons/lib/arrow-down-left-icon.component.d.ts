import * as i0 from "@angular/core";
export declare class ArrowDownLeftIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ArrowDownLeftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ArrowDownLeftIconComponent, "iui-arrow-down-left-icon", never, {}, {}, never, never, true, never>;
}
