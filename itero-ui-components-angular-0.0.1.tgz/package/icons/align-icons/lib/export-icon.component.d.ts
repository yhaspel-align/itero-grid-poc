import * as i0 from "@angular/core";
export declare class ExportIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExportIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExportIconComponent, "iui-export-icon", never, {}, {}, never, never, true, never>;
}
