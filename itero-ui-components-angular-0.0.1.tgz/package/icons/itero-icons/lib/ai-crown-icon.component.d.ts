import * as i0 from "@angular/core";
export declare class AiCrownIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AiCrownIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AiCrownIconComponent, "iui-ai-crown-icon", never, {}, {}, never, never, true, never>;
}
