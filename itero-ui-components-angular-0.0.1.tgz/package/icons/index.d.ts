import { Type } from '@angular/core';
export declare const ALL_ICONS: ReadonlyArray<Type<any>>;
export * from './align-icons';
export * from './itero-icons';
