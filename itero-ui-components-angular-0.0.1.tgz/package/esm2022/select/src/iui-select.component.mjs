import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, EventEmitter, forwardRef, inject, InjectionToken, Input, isDevMode, Output, QueryList, Self, ViewChild, ViewChildren } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdkConnectedOverlay, Overlay, OverlayModule, ViewportRuler } from '@angular/cdk/overlay';
import { Subject, take, takeUntil } from 'rxjs';
import { CdkListbox, CdkOption } from '@angular/cdk/listbox';
import { NG_VALUE_ACCESSOR, Validators } from '@angular/forms';
import { coerceBooleanProperty, coerceNumberProperty } from '@angular/cdk/coercion';
import { ENTER, SPACE } from '@angular/cdk/keycodes';
import { CaretDownIconComponent, CloseEmptyIconComponent } from '@itero/ui-components-angular/icons';
import { NgControlDirective } from '@itero/ui-components-angular/core';
import { IuiErrorStateMatcherDirective } from '@itero/ui-components-angular/core';
import { IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import { IuiButtonComponent } from '@itero/ui-components-angular/button';
import { MapperPipe } from '@itero/ui-components-angular/core';
import { ALIGNED_LEFT_POSITIONS, ALIGNED_RIGHT_POSITIONS } from './positions';
import * as i0 from "@angular/core";
import * as i1 from "@angular/cdk/overlay";
import * as i2 from "@itero/ui-components-angular/core";
import * as i3 from "@angular/common";
let nextUniqueId = 0;
/** Injection token that determines the scroll handling while a select is open. */
export const IUI_SELECT_SCROLL_STRATEGY = new InjectionToken('iui-select-scroll-strategy', {
    providedIn: 'root',
    factory: () => {
        const overlay = inject(Overlay);
        return () => overlay.scrollStrategies.reposition();
    }
});
export function hasModifierKey(event, ...modifiers) {
    if (modifiers.length) {
        return modifiers.some(modifier => event[modifier]);
    }
    return event.altKey || event.shiftKey || event.ctrlKey || event.metaKey;
}
export class IuiSelectComponent {
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    get _valueId() {
        return this.id + '-value';
    }
    get _labelId() {
        return this.id + '-label';
    }
    get _panelId() {
        return this.id + '-panel';
    }
    get _comboboxId() {
        return this.id + '-combobox';
    }
    get _cancelButtonId() {
        return this.id + '-cancel-selection';
    }
    get autoClose() {
        return this._autoClose;
    }
    set autoClose(value) {
        this._autoCloseExplicitlySet = true;
        this._autoClose = coerceBooleanProperty(value);
    }
    constructor(_elementRef, _changeDetectorRef, _viewportRuler, overlay, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._elementRef = _elementRef;
        this._changeDetectorRef = _changeDetectorRef;
        this._viewportRuler = _viewportRuler;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        this._overlayPanelClass = '';
        this.dropDownOpened = false;
        this._id = `iui-select-${nextUniqueId++}`;
        this.label = '';
        this.placeholder = '';
        this.panelWidth = 'auto';
        this.options = [];
        this.panelStyle = {};
        this.panelClass = '';
        this.hintText = '';
        this.requiredText = '';
        this.cancelSelectionText = '';
        this.flexibleDimensions = false;
        // ADS 1.0.0 inputs
        this.size = 'l';
        this.layerSet = 'set-01';
        this.selectType = 'single';
        this.skeleton = false;
        this._autoClose = true;
        this._autoCloseExplicitlySet = false;
        this._positions = ALIGNED_LEFT_POSITIONS;
        this.openEvent = new EventEmitter();
        this.closeEvent = new EventEmitter();
        this.selectionChange = new EventEmitter();
        this.cancelSelectionEvent = new EventEmitter();
        this._destroy = new Subject();
        this._tabIndex = 0;
        this.__focused = false;
        this.__panelOpen = false;
        this.compareWith = (v1, v2) => v1 === v2;
        this.getOptionId = (index, currentOption) => {
            return `${this._panelId}__option_index_${String(index)}`;
        };
        this.getOptionName = (currentOption) => String(currentOption);
        this.getOptionStyle = () => null;
        this.getOptionClassName = () => '';
        this._onChange = () => { };
        this._onTouched = () => { };
        this._scrollStrategy = overlay.scrollStrategies.reposition();
    }
    get tabIndex() {
        return this._tabIndex;
    }
    set tabIndex(v) {
        this._tabIndex = v == null ? 0 : coerceNumberProperty(v);
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _value() {
        return this.__value;
    }
    set _value(newValue) {
        const hasAssigned = this._assignValue(newValue);
        if (hasAssigned) {
            this._onChange(newValue);
        }
    }
    get required() {
        return this._required ?? this.ngControlDirective.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    get empty() {
        if (this.selectType === 'multi') {
            return !Array.isArray(this.__value) || this.__value.length === 0;
        }
        return this.__value == null;
    }
    get _isMultiple() {
        return this.selectType === 'multi';
    }
    get _multiValue() {
        return Array.isArray(this.__value) ? this.__value : [];
    }
    set dropdownPositions(value) {
        if (typeof value === 'string') {
            this._positions = value === 'right' ? ALIGNED_RIGHT_POSITIONS : ALIGNED_LEFT_POSITIONS;
        }
        else {
            this._positions = value;
        }
    }
    get isDropdownOpened() {
        return this.dropDownOpened;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get requiredError() {
        return !!this.ngControlDirective.control?.errors?.['required'];
    }
    get _focused() {
        return this.__focused || this._panelOpen;
    }
    get _isCancelButtonDisabled() {
        return !!this.cancelSelectionText && this.empty;
    }
    get _effectiveAutoClose() {
        return this.selectType === 'multi' && !this._autoCloseExplicitlySet ? false : this._autoClose;
    }
    get _panelOpen() {
        return this.__panelOpen;
    }
    _valueOrPlaceholder(value) {
        if (value != null && !Array.isArray(value)) {
            return this.getOptionName(value);
        }
        return this.placeholder || null;
    }
    ngOnChanges(changes) {
        const options = changes['options'];
        if (options && options.currentValue != options.previousValue) {
            if (this.selectType === 'multi' && Array.isArray(this.__unmodifiedValue)) {
                this.__value = this.__unmodifiedValue
                    .map(v => this.correspondedValueOrNull(v))
                    .filter((v) => v != null);
                if (this.__value.length === 0) {
                    this.__value = null;
                }
            }
            else {
                this.__value = this.correspondedValueOrNull(this.__unmodifiedValue);
            }
        }
    }
    ngOnInit() {
        this._viewportRuler
            .change()
            .pipe(takeUntil(this._destroy))
            .subscribe(() => {
            if (this._panelOpen) {
                this._overlayWidth = this._getOverlayWidth();
                this._changeDetectorRef.detectChanges();
            }
        });
    }
    ngAfterViewInit() { }
    ngOnDestroy() {
        this._destroy.next();
        this._destroy.complete();
    }
    _handleCancelSelection(event) {
        this.cancelSelectionEvent.emit(event);
        this._value = null;
        if (this._effectiveAutoClose) {
            this.close();
            this._focus();
        }
    }
    _removeTag(option, event) {
        event.stopPropagation();
        if (this.selectType === 'multi' && Array.isArray(this.__value)) {
            const newValue = this.__value.filter(v => !this.compareWith(v, option));
            this._assignValue(newValue.length ? newValue : null);
            this._onChange(this.__value);
        }
    }
    _handleKeydown(event) {
        if (!this.disabled) {
            this._panelOpen ? this._handleOpenKeydown(event) : this._handleClosedKeydown(event);
        }
    }
    _onFocus() {
        if (!this.disabled) {
            this.__focused = true;
        }
    }
    _onBlur() {
        this.__focused = false;
        if (!this.disabled && !this._panelOpen) {
            this._onTouched();
            this._changeDetectorRef.markForCheck();
        }
    }
    _canOpen() {
        return !this._panelOpen && !this.disabled && this.options?.length > 0;
    }
    open() {
        if (!this._canOpen()) {
            return;
        }
        this._overlayWidth = this._getOverlayWidth();
        this.__panelOpen = true;
        this._highlightCorrectOption();
        this._changeDetectorRef.markForCheck();
    }
    close() {
        if (this.__panelOpen) {
            this.__panelOpen = false;
            this._changeDetectorRef.markForCheck();
            this.closeEvent.emit();
            this.dropDownOpened = !this.dropDownOpened;
            this._onTouched();
        }
    }
    _focus(options) {
        this.combobox.nativeElement.focus(options);
    }
    _onAttached() {
        this.openEvent.emit();
        this.dropDownOpened = !this.dropDownOpened;
        const bd = document.querySelector('.iui-select-backdrop');
        bd?.setAttribute('data-testid', 'iui-select-backdrop');
        this._overlayDir.positionChange.pipe(take(1)).subscribe(() => {
            this._changeDetectorRef.detectChanges();
            this._positioningSettled();
        });
    }
    writeValue(value) {
        this._assignValue(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._changeDetectorRef.markForCheck();
    }
    _listBoxValueChange(event) {
        if (this.selectType === 'multi') {
            const newValue = [...event.value];
            this._assignValue(newValue.length ? newValue : null);
            this._onChange(this.__value);
            this._emitSelectionChange(event);
            if (this._effectiveAutoClose && this._panelOpen) {
                this.close();
                this._focus();
            }
        }
        else {
            if (event.value.length) {
                const v = [...event.value]?.[0] ?? null;
                this._assignValue(v);
                this._onChange(v);
                this._emitSelectionChange(event);
                if (this._effectiveAutoClose && this._panelOpen) {
                    this.close();
                    this._focus();
                }
            }
        }
    }
    _onOptionClick(option) {
        if (this.selectType !== 'multi') {
            this._value = option;
            this.close();
        }
    }
    _cdkListBoxValue(value) {
        if (Array.isArray(value)) {
            return value;
        }
        return value != null ? [value] : [];
    }
    _optionClassName(index) {
        return `iui-dropdown-panel__option_index_${String(index)}`;
    }
    _handleOpenKeydown(event) { }
    _handleClosedKeydown(event) {
        const keyCode = event.keyCode;
        const isOpenKey = keyCode === ENTER || keyCode === SPACE;
        if (isOpenKey && !hasModifierKey(event)) {
            event.preventDefault();
            this.open();
        }
    }
    _highlightCorrectOption() {
        this.optionElements.changes.pipe(take(1), takeUntil(this._destroy)).subscribe(() => {
            this.listBox.focus();
            this._changeDetectorRef.detectChanges();
        });
    }
    _positioningSettled() { }
    _getOverlayWidth() {
        if (this.panelWidth == null || this.panelWidth === 'auto') {
            return this._elementRef.nativeElement.getBoundingClientRect().width;
        }
        return this.panelWidth === null ? '' : this.panelWidth;
    }
    _assignValue(newValue) {
        if (this.selectType === 'multi') {
            if (Array.isArray(newValue)) {
                this.__unmodifiedValue = newValue;
                this.__value = newValue;
                this._changeDetectorRef.markForCheck();
                return true;
            }
            else if (newValue == null) {
                this.__unmodifiedValue = null;
                this.__value = null;
                this._changeDetectorRef.markForCheck();
                return true;
            }
            return false;
        }
        const singleValue = newValue;
        if (singleValue !== this.__value) {
            this.__unmodifiedValue = singleValue;
            this.__value = this.correspondedValueOrNull(singleValue);
            this._changeDetectorRef.markForCheck();
            return true;
        }
        return false;
    }
    _emitSelectionChange(event) {
        this.selectionChange.emit(event);
    }
    correspondedValueOrNull(newValue) {
        if (newValue == null) {
            return null;
        }
        if (!this.options || this.options.length === 0) {
            return newValue;
        }
        const index = this.options.findIndex(opt => {
            try {
                return opt != null && this.compareWith(opt, newValue);
            }
            catch (error) {
                if (isDevMode()) {
                    console.warn(error);
                }
                return false;
            }
        });
        return index >= 0 ? this.options[index] : null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiSelectComponent, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i1.ViewportRuler }, { token: i1.Overlay }, { token: i2.NgControlDirective, self: true }, { token: i2.IuiErrorStateMatcherDirective, self: true }, { token: i2.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiSelectComponent, isStandalone: true, selector: "iui-select", inputs: { id: "id", label: "label", placeholder: "placeholder", panelWidth: "panelWidth", options: "options", panelStyle: "panelStyle", panelClass: "panelClass", hintText: "hintText", requiredText: "requiredText", cancelSelectionText: "cancelSelectionText", flexibleDimensions: "flexibleDimensions", size: "size", layerSet: "layerSet", selectType: "selectType", skeleton: "skeleton", autoClose: "autoClose", tabIndex: "tabIndex", required: "required", dropdownPositions: "dropdownPositions", compareWith: "compareWith", getOptionId: "getOptionId", getOptionName: "getOptionName", getOptionStyle: "getOptionStyle", getOptionClassName: "getOptionClassName" }, outputs: { openEvent: "openEvent", closeEvent: "closeEvent", selectionChange: "selectionChange", cancelSelectionEvent: "cancelSelectionEvent" }, host: { properties: { "class.iui-select_size_l": "size === \"l\"", "class.iui-select_size_m": "size === \"m\"", "class.iui-select_size_s": "size === \"s\"", "class.iui-select_layer-set-02": "layerSet === \"set-02\"", "class.iui-select_type_multi": "selectType === \"multi\"", "class.iui-select_required": "required", "class.iui-select_disabled": "disabled", "class.iui-select_focused": "_focused", "class.iui-select_invalid": "_errorState", "class.iui-select_filled": "!empty", "class.iui-select_skeleton": "skeleton", "attr.id": "id", "attr.data-testid": "id" }, classAttribute: "iui-select" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiSelectComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "combobox", first: true, predicate: ["combobox"], descendants: true }, { propertyName: "panel", first: true, predicate: ["panel"], descendants: true }, { propertyName: "listBox", first: true, predicate: CdkListbox, descendants: true }, { propertyName: "_overlayDir", first: true, predicate: CdkConnectedOverlay, descendants: true }, { propertyName: "optionElements", predicate: CdkOption, descendants: true }], usesOnChanges: true, hostDirectives: [{ directive: i2.NgControlDirective }, { directive: i2.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i2.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\n\t<div class=\"iui-select__skeleton-label\"></div>\n\t<div class=\"iui-select__skeleton-field\"></div>\n\t<div class=\"iui-select__skeleton-helper\"></div>\n</ng-container>\n\n<ng-template #normalTemplate>\n\t<div class=\"iui-select__label-row\" *ngIf=\"label\">\n\t\t<label class=\"iui-select__label\" [attr.for]=\"_comboboxId\" [id]=\"_labelId\">\n\t\t\t{{ label }}<span class=\"iui-select__required\" *ngIf=\"required\">*</span>\n\t\t</label>\n\t</div>\n\n\t<div\n\t\t#combobox\n\t\tcdk-overlay-origin\n\t\t#fallbackOverlayOrigin=\"cdkOverlayOrigin\"\n\t\tclass=\"iui-select__field\"\n\t\t[attr.id]=\"_comboboxId\"\n\t\t[attr.aria-owns]=\"_panelOpen ? _panelId : null\"\n\t\trole=\"combobox\"\n\t\taria-autocomplete=\"none\"\n\t\taria-haspopup=\"listbox\"\n\t\t[attr.aria-expanded]=\"_panelOpen\"\n\t\t[attr.aria-required]=\"required.toString()\"\n\t\t[attr.aria-disabled]=\"disabled.toString()\"\n\t\t[attr.aria-invalid]=\"_errorState\"\n\t\t[attr.tabindex]=\"disabled ? -1 : tabIndex\"\n\t\t(keydown)=\"_handleKeydown($event)\"\n\t\t(focus)=\"_onFocus()\"\n\t\t(blur)=\"_onBlur()\"\n\t\t(click)=\"open()\"\n\t>\n\t\t<span class=\"iui-select__prefix\"><ng-content select=\"[iui-prefix]\"></ng-content></span>\n\n\t\t<ng-container *ngIf=\"selectType === 'single'\">\n\t\t\t<span\n\t\t\t\t*ngIf=\"placeholder || !empty\"\n\t\t\t\tclass=\"iui-select__value\"\n\t\t\t\t[attr.id]=\"_valueId\"\n\t\t\t\t[attr.data-testid]=\"_valueId\"\n\t\t\t>\n\t\t\t\t{{ _value | mapper: _valueOrPlaceholder.bind(this) }}\n\t\t\t</span>\n\t\t</ng-container>\n\n\t\t<ng-container *ngIf=\"selectType === 'multi'\">\n\t\t\t<div class=\"iui-select__tags\" *ngIf=\"!empty; else multiPlaceholder\">\n\t\t\t\t<span class=\"iui-select__tag\" *ngFor=\"let tag of _multiValue; trackBy: getOptionId\">\n\t\t\t\t\t<span class=\"iui-select__tag-text\">{{ tag | mapper: getOptionName.bind(this) }}</span>\n\t\t\t\t\t<iui-close-empty-icon\n\t\t\t\t\t\tclass=\"iui-select__tag-remove\"\n\t\t\t\t\t\t(click)=\"_removeTag(tag, $event)\"\n\t\t\t\t\t></iui-close-empty-icon>\n\t\t\t\t</span>\n\t\t\t</div>\n\t\t\t<ng-template #multiPlaceholder>\n\t\t\t\t<span class=\"iui-select__value\" *ngIf=\"placeholder\">{{ placeholder }}</span>\n\t\t\t</ng-template>\n\t\t</ng-container>\n\n\t\t<span class=\"iui-select__chevron\">\n\t\t\t<span class=\"iui-select__suffix\"><ng-content select=\"[iui-suffix]\"></ng-content></span>\n\t\t\t<iui-caret-down-icon\n\t\t\t\tclass=\"iui-select__arrow default-caret\"\n\t\t\t\t[class.iui-select__arrow_opened]=\"isDropdownOpened\">\n\t\t\t</iui-caret-down-icon>\n\t\t</span>\n\t</div>\n\n\t<div class=\"iui-select__helper-row\">\n\t\t<span *ngIf=\"_errorState\" class=\"iui-select__error\">\n\t\t\t<ng-container *ngIf=\"requiredError && requiredText\">{{ requiredText }}</ng-container>\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\n\t\t</span>\n\t\t<span *ngIf=\"!_errorState && hintText\" class=\"iui-select__helper\">\n\t\t\t{{ hintText }}\n\t\t</span>\n\t</div>\n\n\t<ng-template\n\tcdk-connected-overlay\n\tcdkConnectedOverlayLockPosition\n\tcdkConnectedOverlayHasBackdrop\n\t[cdkConnectedOverlayBackdropClass]=\"['cdk-overlay-transparent-backdrop', 'iui-select-backdrop']\"\n\t[cdkConnectedOverlayPanelClass]=\"_overlayPanelClass\"\n\t[cdkConnectedOverlayScrollStrategy]=\"_scrollStrategy\"\n\t[cdkConnectedOverlayOrigin]=\"fallbackOverlayOrigin\"\n\t[cdkConnectedOverlayOpen]=\"_panelOpen\"\n\t[cdkConnectedOverlayPositions]=\"_positions\"\n\t[cdkConnectedOverlayMinWidth]=\"_overlayWidth\"\n\t[cdkConnectedOverlayFlexibleDimensions]=\"flexibleDimensions\"\n\t(backdropClick)=\"close()\"\n\t(attach)=\"_onAttached()\"\n\t(detach)=\"close()\"\n>\n\t<div\n\t\t#panel\n\t\tclass=\"iui-dropdown-panel\"\n\t\t[attr.id]=\"_panelId\"\n\t\t[attr.data-testid]=\"_panelId\"\n\t\t[attr.aria-labelledby]=\"_labelId\"\n\t\t[ngStyle]=\"panelStyle\"\n\t\t[ngClass]=\"panelClass\"\n\t>\n\t\t<ul\n\t\t\tclass=\"iui-dropdown-panel__listbox\"\n\t\t\tcdkListbox\n\t\t\t[cdkListboxValue]=\"_value | mapper : _cdkListBoxValue\"\n\t\t\t(cdkListboxValueChange)=\"_listBoxValueChange($event)\"\n\t\t\t[cdkListboxDisabled]=\"disabled\"\n\t\t\t[cdkListboxCompareWith]=\"compareWith\"\n\t\t\t[cdkListboxMultiple]=\"_isMultiple\"\n\t\t>\n\t\t\t<li\n\t\t\t\tclass=\"iui-dropdown-panel__option\"\n\t\t\t\t[id]=\"index | mapper: getOptionId.bind(this) : option\"\n\t\t\t\t[class]=\"_optionClassName(index)\"\n\t\t\t\t[ngStyle]=\"index | mapper: getOptionStyle.bind(this) : option\"\n\t\t\t\t[ngClass]=\"index | mapper: getOptionClassName.bind(this) : option\"\n\t\t\t\t[cdkOption]=\"option\"\n\t\t\t\t(click)=\"_onOptionClick(option)\"\n\t\t\t\t*ngFor=\"let option of options; let index = index; trackBy: getOptionId\"\n\t\t\t>\n\t\t\t\t{{ option | mapper: getOptionName.bind(this) }}\n\t\t\t</li>\n\t\t</ul>\n\n\t\t<footer class=\"iui-dropdown-panel__footer\" *ngIf=\"cancelSelectionText\">\n\t\t\t<button\n\t\t\t\tiuiButton\n\t\t\t\tsize=\"s\"\n\t\t\t\temphasis=\"secondary\"\n\t\t\t\tclass=\"iui-dropdown-panel__cancel-button\"\n\t\t\t\t[attr.id]=\"_cancelButtonId\"\n\t\t\t\t[disabled]=\"_isCancelButtonDisabled\"\n\t\t\t\t(click)=\"_handleCancelSelection($event)\"\n\t\t\t>\n\t\t\t\t{{ cancelSelectionText }}\n\t\t\t</button>\n\t\t</footer>\n\t</div>\n\t</ng-template>\n</ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;min-width:206px;max-width:100%}.iui-select__label-row{display:flex;align-items:flex-start;padding-bottom:8px}.iui-select__label{font:var(--iui-tp-label-01-font);color:var(--iui-select-label-color);flex:1;min-width:1px}.iui-select__required{color:var(--iui-select-error-color);margin-left:4px}.iui-select__field{display:flex;align-items:center;gap:8px;overflow:hidden;background:var(--iui-select-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:pointer;outline:none}:host.iui-select_size_l .iui-select__field{padding:12px 16px;border-radius:var(--iui-border-radius-medium)}:host.iui-select_size_m .iui-select__field{padding:8px 12px;border-radius:var(--iui-border-radius-medium)}:host.iui-select_size_s .iui-select__field{padding:4px 8px;gap:4px;border-radius:var(--iui-border-radius)}.iui-select__value{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-select-color);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:20px}.iui-select__chevron{display:inline-flex;align-items:center;flex-shrink:0;margin-left:auto;color:var(--iui-select-color)}.iui-select__chevron .default-caret{width:20px;height:20px}.iui-select__prefix{display:none;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:inherit}.iui-select__prefix:not(:empty){display:inline-flex}:host ::ng-deep .iui-select__prefix [iui-prefix]{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;color:inherit}:host ::ng-deep .iui-select__prefix [iui-prefix] svg{display:block;width:100%;height:100%}.iui-select__suffix{display:none;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:inherit}.iui-select__suffix:not(:empty){display:inline-flex}.iui-select__suffix:not(:empty)+.default-caret{display:none}:host ::ng-deep .iui-select__suffix [iui-suffix]{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;color:inherit}:host ::ng-deep .iui-select__suffix [iui-suffix] svg{display:block;width:100%;height:100%}.iui-select__arrow{display:block;transition:transform .3s ease;width:100%;height:100%}.iui-select__arrow_opened{transform:rotate(180deg)}.iui-select__tags{display:flex;flex-wrap:wrap;gap:8px;flex:1;min-width:0;align-items:center}.iui-select__tag{display:inline-flex;align-items:center;gap:4px;min-width:24px;padding:4px 4px 4px 8px;border:1px solid var(--iui-select-tag-border);border-radius:4px;overflow:hidden}.iui-select__tag-text{font:var(--iui-tp-body-01-font);color:var(--iui-select-color);flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:20px}.iui-select__tag-remove{flex-shrink:0;width:20px;height:20px;cursor:pointer;color:inherit}:host.iui-select_type_multi .iui-select__field{align-items:flex-start}:host.iui-select_type_multi.iui-select_size_l .iui-select__field{padding:8px 16px 8px 8px}:host.iui-select_type_multi.iui-select_size_m .iui-select__field{padding:4px 16px 4px 4px}:host.iui-select_type_multi.iui-select_size_s .iui-select__field{padding:4px 8px 4px 4px}:host.iui-select_type_multi .iui-select__chevron{padding-top:4px}:host.iui-select_type_multi.iui-select_size_s .iui-select__chevron{padding-top:0}:host.iui-select_type_multi.iui-select_size_s .iui-select__tags{gap:4px}.iui-select__helper-row{padding-top:8px}.iui-select__helper{font:var(--iui-tp-label-01-font);color:var(--iui-select-helper-color)}.iui-select__error{font:var(--iui-tp-label-01-font);color:var(--iui-select-error-color)}:host.iui-select_focused .iui-select__field{border-color:var(--iui-select-focus-border)}:host.iui-select_invalid .iui-select__field{border-color:var(--iui-select-error-border)}:host.iui-select_disabled .iui-select__field{cursor:default;pointer-events:none}:host.iui-select_disabled .iui-select__value,:host.iui-select_disabled .iui-select__chevron{color:var(--iui-select-disabled-color)}:host.iui-select_disabled .iui-select__label{color:var(--iui-select-disabled-color)}:host.iui-select_disabled .iui-select__helper{color:var(--iui-select-disabled-color)}:host.iui-select_disabled .iui-select__tag{color:var(--iui-select-disabled-color);border-color:var(--iui-select-disabled-color)}:host.iui-select_layer-set-02 .iui-select__field{background:var(--iui-select-bg-layer-02)}.iui-select__skeleton-label{width:40px;height:8px;background:var(--iui-select-skeleton-bg);margin-bottom:8px}.iui-select__skeleton-field{height:44px;border-radius:var(--iui-border-radius-medium);background:var(--iui-select-skeleton-bg)}.iui-select__skeleton-helper{margin-top:8px;width:40px;height:8px;background:var(--iui-select-skeleton-bg)}:host.iui-select_size_m .iui-select__skeleton-field{height:36px}:host.iui-select_size_s .iui-select__skeleton-field{height:28px;border-radius:var(--iui-border-radius)}\n", ".iui-dropdown-panel{display:flex;flex-direction:column;overflow:auto;font:var(--iui-tp-body-01-font);color:var(--iui-select-color);max-height:var(--iui-dropdown-panel-max-height);min-width:fit-content;width:100%;max-width:var(--iui-dropdown-panel-max-width);background-color:var(--iui-select-panel-bg);box-shadow:0 2px 8px #0003,0 1px 2px #00000024;border-radius:var(--iui-border-radius)}ul{overflow:auto;margin:0;margin-block-start:0;margin-block-end:0;margin-inline-start:0;margin-inline-end:0;padding-inline-start:0;padding-inline-end:0;list-style:none}li{line-height:var(--iui-dropdown-option-height);padding:0 calc(4 * var(--iui-main-unit));list-style-type:none;margin:0;cursor:pointer;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}li:hover{background-color:var(--iui-select-option-hover)}li.cdk-option-active{outline:none;background-color:var(--iui-select-option-hover)}li[aria-selected=true]{background-color:var(--iui-select-option-selected)}li[aria-selected=true]:hover,li[aria-selected=true].cdk-option-active{background-color:var(--iui-select-option-selected-hover)}li_hidden{display:none}footer{border-top:1px solid var(--iui-select-footer-border);padding:calc(2 * var(--iui-main-unit)) calc(4 * var(--iui-main-unit));border-bottom-right-radius:var(--iui-border-radius);border-bottom-left-radius:var(--iui-border-radius);display:flex;justify-content:space-between;align-items:center}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i1.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: i1.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "directive", type: CdkListbox, selector: "[cdkListbox]", inputs: ["id", "tabindex", "cdkListboxValue", "cdkListboxMultiple", "cdkListboxDisabled", "cdkListboxUseActiveDescendant", "cdkListboxOrientation", "cdkListboxCompareWith", "cdkListboxNavigationWrapDisabled", "cdkListboxNavigatesDisabledOptions"], outputs: ["cdkListboxValueChange"], exportAs: ["cdkListbox"] }, { kind: "directive", type: CdkOption, selector: "[cdkOption]", inputs: ["id", "cdkOption", "cdkOptionTypeaheadLabel", "cdkOptionDisabled", "tabindex"], exportAs: ["cdkOption"] }, { kind: "component", type: CaretDownIconComponent, selector: "iui-caret-down-icon" }, { kind: "component", type: CloseEmptyIconComponent, selector: "iui-close-empty-icon" }, { kind: "component", type: IuiButtonComponent, selector: "button[iuiButton]", inputs: ["type", "emphasis", "size", "disabled", "loading", "menu"] }, { kind: "pipe", type: MapperPipe, name: "mapper" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-select', standalone: true, imports: [CommonModule, OverlayModule, CdkListbox, CdkOption, CaretDownIconComponent, CloseEmptyIconComponent, IuiButtonComponent, MapperPipe], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiSelectComponent),
                            multi: true
                        }
                    ], host: {
                        class: 'iui-select',
                        '[class.iui-select_size_l]': 'size === "l"',
                        '[class.iui-select_size_m]': 'size === "m"',
                        '[class.iui-select_size_s]': 'size === "s"',
                        '[class.iui-select_layer-set-02]': 'layerSet === "set-02"',
                        '[class.iui-select_type_multi]': 'selectType === "multi"',
                        '[class.iui-select_required]': 'required',
                        '[class.iui-select_disabled]': 'disabled',
                        '[class.iui-select_focused]': '_focused',
                        '[class.iui-select_invalid]': '_errorState',
                        '[class.iui-select_filled]': '!empty',
                        '[class.iui-select_skeleton]': 'skeleton',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\n\t<div class=\"iui-select__skeleton-label\"></div>\n\t<div class=\"iui-select__skeleton-field\"></div>\n\t<div class=\"iui-select__skeleton-helper\"></div>\n</ng-container>\n\n<ng-template #normalTemplate>\n\t<div class=\"iui-select__label-row\" *ngIf=\"label\">\n\t\t<label class=\"iui-select__label\" [attr.for]=\"_comboboxId\" [id]=\"_labelId\">\n\t\t\t{{ label }}<span class=\"iui-select__required\" *ngIf=\"required\">*</span>\n\t\t</label>\n\t</div>\n\n\t<div\n\t\t#combobox\n\t\tcdk-overlay-origin\n\t\t#fallbackOverlayOrigin=\"cdkOverlayOrigin\"\n\t\tclass=\"iui-select__field\"\n\t\t[attr.id]=\"_comboboxId\"\n\t\t[attr.aria-owns]=\"_panelOpen ? _panelId : null\"\n\t\trole=\"combobox\"\n\t\taria-autocomplete=\"none\"\n\t\taria-haspopup=\"listbox\"\n\t\t[attr.aria-expanded]=\"_panelOpen\"\n\t\t[attr.aria-required]=\"required.toString()\"\n\t\t[attr.aria-disabled]=\"disabled.toString()\"\n\t\t[attr.aria-invalid]=\"_errorState\"\n\t\t[attr.tabindex]=\"disabled ? -1 : tabIndex\"\n\t\t(keydown)=\"_handleKeydown($event)\"\n\t\t(focus)=\"_onFocus()\"\n\t\t(blur)=\"_onBlur()\"\n\t\t(click)=\"open()\"\n\t>\n\t\t<span class=\"iui-select__prefix\"><ng-content select=\"[iui-prefix]\"></ng-content></span>\n\n\t\t<ng-container *ngIf=\"selectType === 'single'\">\n\t\t\t<span\n\t\t\t\t*ngIf=\"placeholder || !empty\"\n\t\t\t\tclass=\"iui-select__value\"\n\t\t\t\t[attr.id]=\"_valueId\"\n\t\t\t\t[attr.data-testid]=\"_valueId\"\n\t\t\t>\n\t\t\t\t{{ _value | mapper: _valueOrPlaceholder.bind(this) }}\n\t\t\t</span>\n\t\t</ng-container>\n\n\t\t<ng-container *ngIf=\"selectType === 'multi'\">\n\t\t\t<div class=\"iui-select__tags\" *ngIf=\"!empty; else multiPlaceholder\">\n\t\t\t\t<span class=\"iui-select__tag\" *ngFor=\"let tag of _multiValue; trackBy: getOptionId\">\n\t\t\t\t\t<span class=\"iui-select__tag-text\">{{ tag | mapper: getOptionName.bind(this) }}</span>\n\t\t\t\t\t<iui-close-empty-icon\n\t\t\t\t\t\tclass=\"iui-select__tag-remove\"\n\t\t\t\t\t\t(click)=\"_removeTag(tag, $event)\"\n\t\t\t\t\t></iui-close-empty-icon>\n\t\t\t\t</span>\n\t\t\t</div>\n\t\t\t<ng-template #multiPlaceholder>\n\t\t\t\t<span class=\"iui-select__value\" *ngIf=\"placeholder\">{{ placeholder }}</span>\n\t\t\t</ng-template>\n\t\t</ng-container>\n\n\t\t<span class=\"iui-select__chevron\">\n\t\t\t<span class=\"iui-select__suffix\"><ng-content select=\"[iui-suffix]\"></ng-content></span>\n\t\t\t<iui-caret-down-icon\n\t\t\t\tclass=\"iui-select__arrow default-caret\"\n\t\t\t\t[class.iui-select__arrow_opened]=\"isDropdownOpened\">\n\t\t\t</iui-caret-down-icon>\n\t\t</span>\n\t</div>\n\n\t<div class=\"iui-select__helper-row\">\n\t\t<span *ngIf=\"_errorState\" class=\"iui-select__error\">\n\t\t\t<ng-container *ngIf=\"requiredError && requiredText\">{{ requiredText }}</ng-container>\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\n\t\t</span>\n\t\t<span *ngIf=\"!_errorState && hintText\" class=\"iui-select__helper\">\n\t\t\t{{ hintText }}\n\t\t</span>\n\t</div>\n\n\t<ng-template\n\tcdk-connected-overlay\n\tcdkConnectedOverlayLockPosition\n\tcdkConnectedOverlayHasBackdrop\n\t[cdkConnectedOverlayBackdropClass]=\"['cdk-overlay-transparent-backdrop', 'iui-select-backdrop']\"\n\t[cdkConnectedOverlayPanelClass]=\"_overlayPanelClass\"\n\t[cdkConnectedOverlayScrollStrategy]=\"_scrollStrategy\"\n\t[cdkConnectedOverlayOrigin]=\"fallbackOverlayOrigin\"\n\t[cdkConnectedOverlayOpen]=\"_panelOpen\"\n\t[cdkConnectedOverlayPositions]=\"_positions\"\n\t[cdkConnectedOverlayMinWidth]=\"_overlayWidth\"\n\t[cdkConnectedOverlayFlexibleDimensions]=\"flexibleDimensions\"\n\t(backdropClick)=\"close()\"\n\t(attach)=\"_onAttached()\"\n\t(detach)=\"close()\"\n>\n\t<div\n\t\t#panel\n\t\tclass=\"iui-dropdown-panel\"\n\t\t[attr.id]=\"_panelId\"\n\t\t[attr.data-testid]=\"_panelId\"\n\t\t[attr.aria-labelledby]=\"_labelId\"\n\t\t[ngStyle]=\"panelStyle\"\n\t\t[ngClass]=\"panelClass\"\n\t>\n\t\t<ul\n\t\t\tclass=\"iui-dropdown-panel__listbox\"\n\t\t\tcdkListbox\n\t\t\t[cdkListboxValue]=\"_value | mapper : _cdkListBoxValue\"\n\t\t\t(cdkListboxValueChange)=\"_listBoxValueChange($event)\"\n\t\t\t[cdkListboxDisabled]=\"disabled\"\n\t\t\t[cdkListboxCompareWith]=\"compareWith\"\n\t\t\t[cdkListboxMultiple]=\"_isMultiple\"\n\t\t>\n\t\t\t<li\n\t\t\t\tclass=\"iui-dropdown-panel__option\"\n\t\t\t\t[id]=\"index | mapper: getOptionId.bind(this) : option\"\n\t\t\t\t[class]=\"_optionClassName(index)\"\n\t\t\t\t[ngStyle]=\"index | mapper: getOptionStyle.bind(this) : option\"\n\t\t\t\t[ngClass]=\"index | mapper: getOptionClassName.bind(this) : option\"\n\t\t\t\t[cdkOption]=\"option\"\n\t\t\t\t(click)=\"_onOptionClick(option)\"\n\t\t\t\t*ngFor=\"let option of options; let index = index; trackBy: getOptionId\"\n\t\t\t>\n\t\t\t\t{{ option | mapper: getOptionName.bind(this) }}\n\t\t\t</li>\n\t\t</ul>\n\n\t\t<footer class=\"iui-dropdown-panel__footer\" *ngIf=\"cancelSelectionText\">\n\t\t\t<button\n\t\t\t\tiuiButton\n\t\t\t\tsize=\"s\"\n\t\t\t\temphasis=\"secondary\"\n\t\t\t\tclass=\"iui-dropdown-panel__cancel-button\"\n\t\t\t\t[attr.id]=\"_cancelButtonId\"\n\t\t\t\t[disabled]=\"_isCancelButtonDisabled\"\n\t\t\t\t(click)=\"_handleCancelSelection($event)\"\n\t\t\t>\n\t\t\t\t{{ cancelSelectionText }}\n\t\t\t</button>\n\t\t</footer>\n\t</div>\n\t</ng-template>\n</ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;min-width:206px;max-width:100%}.iui-select__label-row{display:flex;align-items:flex-start;padding-bottom:8px}.iui-select__label{font:var(--iui-tp-label-01-font);color:var(--iui-select-label-color);flex:1;min-width:1px}.iui-select__required{color:var(--iui-select-error-color);margin-left:4px}.iui-select__field{display:flex;align-items:center;gap:8px;overflow:hidden;background:var(--iui-select-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:pointer;outline:none}:host.iui-select_size_l .iui-select__field{padding:12px 16px;border-radius:var(--iui-border-radius-medium)}:host.iui-select_size_m .iui-select__field{padding:8px 12px;border-radius:var(--iui-border-radius-medium)}:host.iui-select_size_s .iui-select__field{padding:4px 8px;gap:4px;border-radius:var(--iui-border-radius)}.iui-select__value{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-select-color);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:20px}.iui-select__chevron{display:inline-flex;align-items:center;flex-shrink:0;margin-left:auto;color:var(--iui-select-color)}.iui-select__chevron .default-caret{width:20px;height:20px}.iui-select__prefix{display:none;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:inherit}.iui-select__prefix:not(:empty){display:inline-flex}:host ::ng-deep .iui-select__prefix [iui-prefix]{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;color:inherit}:host ::ng-deep .iui-select__prefix [iui-prefix] svg{display:block;width:100%;height:100%}.iui-select__suffix{display:none;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:inherit}.iui-select__suffix:not(:empty){display:inline-flex}.iui-select__suffix:not(:empty)+.default-caret{display:none}:host ::ng-deep .iui-select__suffix [iui-suffix]{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;color:inherit}:host ::ng-deep .iui-select__suffix [iui-suffix] svg{display:block;width:100%;height:100%}.iui-select__arrow{display:block;transition:transform .3s ease;width:100%;height:100%}.iui-select__arrow_opened{transform:rotate(180deg)}.iui-select__tags{display:flex;flex-wrap:wrap;gap:8px;flex:1;min-width:0;align-items:center}.iui-select__tag{display:inline-flex;align-items:center;gap:4px;min-width:24px;padding:4px 4px 4px 8px;border:1px solid var(--iui-select-tag-border);border-radius:4px;overflow:hidden}.iui-select__tag-text{font:var(--iui-tp-body-01-font);color:var(--iui-select-color);flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:20px}.iui-select__tag-remove{flex-shrink:0;width:20px;height:20px;cursor:pointer;color:inherit}:host.iui-select_type_multi .iui-select__field{align-items:flex-start}:host.iui-select_type_multi.iui-select_size_l .iui-select__field{padding:8px 16px 8px 8px}:host.iui-select_type_multi.iui-select_size_m .iui-select__field{padding:4px 16px 4px 4px}:host.iui-select_type_multi.iui-select_size_s .iui-select__field{padding:4px 8px 4px 4px}:host.iui-select_type_multi .iui-select__chevron{padding-top:4px}:host.iui-select_type_multi.iui-select_size_s .iui-select__chevron{padding-top:0}:host.iui-select_type_multi.iui-select_size_s .iui-select__tags{gap:4px}.iui-select__helper-row{padding-top:8px}.iui-select__helper{font:var(--iui-tp-label-01-font);color:var(--iui-select-helper-color)}.iui-select__error{font:var(--iui-tp-label-01-font);color:var(--iui-select-error-color)}:host.iui-select_focused .iui-select__field{border-color:var(--iui-select-focus-border)}:host.iui-select_invalid .iui-select__field{border-color:var(--iui-select-error-border)}:host.iui-select_disabled .iui-select__field{cursor:default;pointer-events:none}:host.iui-select_disabled .iui-select__value,:host.iui-select_disabled .iui-select__chevron{color:var(--iui-select-disabled-color)}:host.iui-select_disabled .iui-select__label{color:var(--iui-select-disabled-color)}:host.iui-select_disabled .iui-select__helper{color:var(--iui-select-disabled-color)}:host.iui-select_disabled .iui-select__tag{color:var(--iui-select-disabled-color);border-color:var(--iui-select-disabled-color)}:host.iui-select_layer-set-02 .iui-select__field{background:var(--iui-select-bg-layer-02)}.iui-select__skeleton-label{width:40px;height:8px;background:var(--iui-select-skeleton-bg);margin-bottom:8px}.iui-select__skeleton-field{height:44px;border-radius:var(--iui-border-radius-medium);background:var(--iui-select-skeleton-bg)}.iui-select__skeleton-helper{margin-top:8px;width:40px;height:8px;background:var(--iui-select-skeleton-bg)}:host.iui-select_size_m .iui-select__skeleton-field{height:36px}:host.iui-select_size_s .iui-select__skeleton-field{height:28px;border-radius:var(--iui-border-radius)}\n", ".iui-dropdown-panel{display:flex;flex-direction:column;overflow:auto;font:var(--iui-tp-body-01-font);color:var(--iui-select-color);max-height:var(--iui-dropdown-panel-max-height);min-width:fit-content;width:100%;max-width:var(--iui-dropdown-panel-max-width);background-color:var(--iui-select-panel-bg);box-shadow:0 2px 8px #0003,0 1px 2px #00000024;border-radius:var(--iui-border-radius)}ul{overflow:auto;margin:0;margin-block-start:0;margin-block-end:0;margin-inline-start:0;margin-inline-end:0;padding-inline-start:0;padding-inline-end:0;list-style:none}li{line-height:var(--iui-dropdown-option-height);padding:0 calc(4 * var(--iui-main-unit));list-style-type:none;margin:0;cursor:pointer;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}li:hover{background-color:var(--iui-select-option-hover)}li.cdk-option-active{outline:none;background-color:var(--iui-select-option-hover)}li[aria-selected=true]{background-color:var(--iui-select-option-selected)}li[aria-selected=true]:hover,li[aria-selected=true].cdk-option-active{background-color:var(--iui-select-option-selected-hover)}li_hidden{display:none}footer{border-top:1px solid var(--iui-select-footer-border);padding:calc(2 * var(--iui-main-unit)) calc(4 * var(--iui-main-unit));border-bottom-right-radius:var(--iui-border-radius);border-bottom-left-radius:var(--iui-border-radius);display:flex;justify-content:space-between;align-items:center}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i1.ViewportRuler }, { type: i1.Overlay }, { type: i2.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i2.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i2.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { combobox: [{
                type: ViewChild,
                args: ['combobox']
            }], panel: [{
                type: ViewChild,
                args: ['panel']
            }], listBox: [{
                type: ViewChild,
                args: [CdkListbox]
            }], optionElements: [{
                type: ViewChildren,
                args: [CdkOption]
            }], id: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], panelWidth: [{
                type: Input
            }], options: [{
                type: Input
            }], panelStyle: [{
                type: Input
            }], panelClass: [{
                type: Input
            }], hintText: [{
                type: Input
            }], requiredText: [{
                type: Input
            }], cancelSelectionText: [{
                type: Input
            }], flexibleDimensions: [{
                type: Input
            }], size: [{
                type: Input
            }], layerSet: [{
                type: Input
            }], selectType: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], autoClose: [{
                type: Input
            }], openEvent: [{
                type: Output
            }], closeEvent: [{
                type: Output
            }], selectionChange: [{
                type: Output
            }], cancelSelectionEvent: [{
                type: Output
            }], _overlayDir: [{
                type: ViewChild,
                args: [CdkConnectedOverlay]
            }], tabIndex: [{
                type: Input
            }], required: [{
                type: Input
            }], dropdownPositions: [{
                type: Input
            }], compareWith: [{
                type: Input
            }], getOptionId: [{
                type: Input
            }], getOptionName: [{
                type: Input
            }], getOptionStyle: [{
                type: Input
            }], getOptionClassName: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLXNlbGVjdC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS9zZWxlY3Qvc3JjL2l1aS1zZWxlY3QuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvc2VsZWN0L3NyYy9pdWktc2VsZWN0LmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTix1QkFBdUIsRUFDdkIsaUJBQWlCLEVBQ2pCLFNBQVMsRUFDVCxVQUFVLEVBQ1YsWUFBWSxFQUNaLFVBQVUsRUFDVixNQUFNLEVBQ04sY0FBYyxFQUNkLEtBQUssRUFDTCxTQUFTLEVBSVQsTUFBTSxFQUNOLFNBQVMsRUFDVCxJQUFJLEVBRUosU0FBUyxFQUNULFlBQVksRUFDWixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDL0MsT0FBTyxFQUFFLG1CQUFtQixFQUFxQixPQUFPLEVBQUUsYUFBYSxFQUFrQixhQUFhLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUNySSxPQUFPLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDaEQsT0FBTyxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQTJCLE1BQU0sc0JBQXNCLENBQUM7QUFDdEYsT0FBTyxFQUF3QixpQkFBaUIsRUFBRSxVQUFVLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUNyRixPQUFPLEVBQUUscUJBQXFCLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUNwRixPQUFPLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ3JELE9BQU8sRUFBRSxzQkFBc0IsRUFBRSx1QkFBdUIsRUFBRSxNQUFNLG9DQUFvQyxDQUFDO0FBQ3JHLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLG1DQUFtQyxDQUFDO0FBQ3ZFLE9BQU8sRUFBRSw2QkFBNkIsRUFBRSxNQUFNLG1DQUFtQyxDQUFDO0FBQ2xGLE9BQU8sRUFBRSxzQkFBc0IsRUFBRSxNQUFNLG1DQUFtQyxDQUFDO0FBQzNFLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLHFDQUFxQyxDQUFDO0FBQ3pFLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQztBQUMvRCxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSxhQUFhLENBQUM7Ozs7O0FBTzlFLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztBQUlyQixrRkFBa0Y7QUFDbEYsTUFBTSxDQUFDLE1BQU0sMEJBQTBCLEdBQUcsSUFBSSxjQUFjLENBQXVCLDRCQUE0QixFQUFFO0lBQ2hILFVBQVUsRUFBRSxNQUFNO0lBQ2xCLE9BQU8sRUFBRSxHQUFHLEVBQUU7UUFDYixNQUFNLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFaEMsT0FBTyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDcEQsQ0FBQztDQUNELENBQUMsQ0FBQztBQUlILE1BQU0sVUFBVSxjQUFjLENBQUMsS0FBb0IsRUFBRSxHQUFHLFNBQXdCO0lBQy9FLElBQUksU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3RCLE9BQU8sU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFRCxPQUFPLEtBQUssQ0FBQyxNQUFNLElBQUksS0FBSyxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsT0FBTyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUM7QUFDekUsQ0FBQztBQTZDRCxNQUFNLE9BQU8sa0JBQWtCO0lBUTlCLElBQ0ksRUFBRSxDQUFDLEtBQWE7UUFDbkIsSUFBSSxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUM7SUFDbEIsQ0FBQztJQUVELElBQUksRUFBRTtRQUNMLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUNqQixDQUFDO0lBSUQsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsRUFBRSxHQUFHLFFBQVEsQ0FBQztJQUMzQixDQUFDO0lBQ0QsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsRUFBRSxHQUFHLFFBQVEsQ0FBQztJQUMzQixDQUFDO0lBQ0QsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsRUFBRSxHQUFHLFFBQVEsQ0FBQztJQUMzQixDQUFDO0lBQ0QsSUFBSSxXQUFXO1FBQ2QsT0FBTyxJQUFJLENBQUMsRUFBRSxHQUFHLFdBQVcsQ0FBQztJQUM5QixDQUFDO0lBQ0QsSUFBSSxlQUFlO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLEVBQUUsR0FBRyxtQkFBbUIsQ0FBQztJQUN0QyxDQUFDO0lBc0JELElBQ0ksU0FBUztRQUNaLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQztJQUN4QixDQUFDO0lBRUQsSUFBSSxTQUFTLENBQUMsS0FBMEM7UUFDdkQsSUFBSSxDQUFDLHVCQUF1QixHQUFHLElBQUksQ0FBQztRQUNwQyxJQUFJLENBQUMsVUFBVSxHQUFHLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFhRCxZQUNXLFdBQXVCLEVBQ3ZCLGtCQUFxQyxFQUNyQyxjQUE2QixFQUN2QyxPQUFnQixFQUNFLGtCQUEwRCxFQUMxRCwwQkFBeUQsRUFDekQsbUJBQTJDO1FBTm5ELGdCQUFXLEdBQVgsV0FBVyxDQUFZO1FBQ3ZCLHVCQUFrQixHQUFsQixrQkFBa0IsQ0FBbUI7UUFDckMsbUJBQWMsR0FBZCxjQUFjLENBQWU7UUFFckIsdUJBQWtCLEdBQWxCLGtCQUFrQixDQUF3QztRQUMxRCwrQkFBMEIsR0FBMUIsMEJBQTBCLENBQStCO1FBQ3pELHdCQUFtQixHQUFuQixtQkFBbUIsQ0FBd0I7UUE5RTlELHVCQUFrQixHQUFzQixFQUFFLENBQUM7UUFDM0MsbUJBQWMsR0FBRyxLQUFLLENBQUM7UUFXdkIsUUFBRyxHQUFHLGNBQWMsWUFBWSxFQUFFLEVBQUUsQ0FBQztRQWtCNUIsVUFBSyxHQUFHLEVBQUUsQ0FBQztRQUNYLGdCQUFXLEdBQUcsRUFBRSxDQUFDO1FBQ2pCLGVBQVUsR0FBMkIsTUFBTSxDQUFDO1FBQzVDLFlBQU8sR0FBYyxFQUFFLENBQUM7UUFDeEIsZUFBVSxHQUF5QixFQUFFLENBQUM7UUFDdEMsZUFBVSxHQUE2RCxFQUFFLENBQUM7UUFDMUUsYUFBUSxHQUFHLEVBQUUsQ0FBQztRQUNkLGlCQUFZLEdBQUcsRUFBRSxDQUFDO1FBQ2xCLHdCQUFtQixHQUFHLEVBQUUsQ0FBQztRQUN6Qix1QkFBa0IsR0FBRyxLQUFLLENBQUM7UUFFcEMsbUJBQW1CO1FBQ1YsU0FBSSxHQUFlLEdBQUcsQ0FBQztRQUN2QixhQUFRLEdBQW1CLFFBQVEsQ0FBQztRQUNwQyxlQUFVLEdBQWUsUUFBUSxDQUFDO1FBQ2xDLGFBQVEsR0FBRyxLQUFLLENBQUM7UUFFbEIsZUFBVSxHQUFHLElBQUksQ0FBQztRQUNsQiw0QkFBdUIsR0FBRyxLQUFLLENBQUM7UUFZeEMsZUFBVSxHQUF3QixzQkFBc0IsQ0FBQztRQUMvQyxjQUFTLEdBQUcsSUFBSSxZQUFZLEVBQVEsQ0FBQztRQUNyQyxlQUFVLEdBQUcsSUFBSSxZQUFZLEVBQVEsQ0FBQztRQUN0QyxvQkFBZSxHQUFHLElBQUksWUFBWSxFQUFvQyxDQUFDO1FBQ3ZFLHlCQUFvQixHQUFHLElBQUksWUFBWSxFQUFjLENBQUM7UUFLN0MsYUFBUSxHQUFHLElBQUksT0FBTyxFQUFRLENBQUM7UUFjMUMsY0FBUyxHQUFHLENBQUMsQ0FBQztRQTZFZCxjQUFTLEdBQUcsS0FBSyxDQUFDO1FBY2xCLGdCQUFXLEdBQUcsS0FBSyxDQUFDO1FBTW5CLGdCQUFXLEdBQUcsQ0FBQyxFQUFXLEVBQUUsRUFBVyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDO1FBRXRELGdCQUFXLEdBQUcsQ0FBQyxLQUFhLEVBQUUsYUFBc0IsRUFBRSxFQUFFO1lBQ2hFLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxrQkFBa0IsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7UUFDMUQsQ0FBQyxDQUFDO1FBRU8sa0JBQWEsR0FBdUMsQ0FBQyxhQUFzQixFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDdEcsbUJBQWMsR0FBZ0YsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDO1FBQ3pHLHVCQUFrQixHQUFpRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7UUFVckksY0FBUyxHQUF3QyxHQUFHLEVBQUUsR0FBRSxDQUFDLENBQUM7UUFDMUQsZUFBVSxHQUFHLEdBQUcsRUFBRSxHQUFFLENBQUMsQ0FBQztRQXZIckIsSUFBSSxDQUFDLGVBQWUsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDOUQsQ0FBQztJQUlELElBQUksUUFBUTtRQUNYLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDO0lBRUQsSUFDSSxRQUFRLENBQUMsQ0FBVTtRQUN0QixJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUVELElBQUksUUFBUTtRQUNYLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFVBQVUsQ0FBQztJQUM1QyxDQUFDO0lBS0QsSUFBSSxNQUFNO1FBQ1QsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBQ3JCLENBQUM7SUFFRCxJQUFJLE1BQU0sQ0FBQyxRQUE0QjtRQUN0QyxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRWhELElBQUksV0FBVyxFQUFFLENBQUM7WUFDakIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMxQixDQUFDO0lBQ0YsQ0FBQztJQUlELElBQ0ksUUFBUTtRQUNYLE9BQU8sSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLFlBQVksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksS0FBSyxDQUFDO0lBQ3RHLENBQUM7SUFFRCxJQUFJLFFBQVEsQ0FBQyxLQUEwQztRQUN0RCxJQUFJLENBQUMsU0FBUyxHQUFHLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRCxJQUFJLEtBQUs7UUFDUixJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssT0FBTyxFQUFFLENBQUM7WUFDakMsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQztRQUNsRSxDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQztJQUM3QixDQUFDO0lBRUQsSUFBSSxXQUFXO1FBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLE9BQU8sQ0FBQztJQUNwQyxDQUFDO0lBRUQsSUFBSSxXQUFXO1FBQ2QsT0FBTyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQ3hELENBQUM7SUFFRCxJQUNJLGlCQUFpQixDQUFDLEtBQTZDO1FBQ2xFLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDL0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUM7UUFDeEYsQ0FBQzthQUFNLENBQUM7WUFDUCxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUN6QixDQUFDO0lBQ0YsQ0FBQztJQUVELElBQUksZ0JBQWdCO1FBQ25CLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUM1QixDQUFDO0lBRUQsSUFBSSxXQUFXO1FBQ2QsT0FBTyxJQUFJLENBQUMsMEJBQTBCLENBQUMsVUFBVSxDQUFDO0lBQ25ELENBQUM7SUFFRCxJQUFJLGFBQWE7UUFDaEIsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBSUQsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUM7SUFDMUMsQ0FBQztJQUVELElBQUksdUJBQXVCO1FBQzFCLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDO0lBQ2pELENBQUM7SUFFRCxJQUFJLG1CQUFtQjtRQUN0QixPQUFPLElBQUksQ0FBQyxVQUFVLEtBQUssT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7SUFDL0YsQ0FBQztJQUlELElBQUksVUFBVTtRQUNiLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUN6QixDQUFDO0lBWUQsbUJBQW1CLENBQUMsS0FBeUI7UUFDNUMsSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQzVDLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNsQyxDQUFDO1FBRUQsT0FBTyxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQztJQUNqQyxDQUFDO0lBS0QsV0FBVyxDQUFDLE9BQXNCO1FBQ2pDLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUVuQyxJQUFJLE9BQU8sSUFBSSxPQUFPLENBQUMsWUFBWSxJQUFJLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUM5RCxJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssT0FBTyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQztnQkFDMUUsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsaUJBQWlCO3FCQUNuQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ3pDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBZ0IsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQztnQkFDekMsSUFBSyxJQUFJLENBQUMsT0FBcUIsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7b0JBQzlDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO2dCQUNyQixDQUFDO1lBQ0YsQ0FBQztpQkFBTSxDQUFDO2dCQUNQLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxpQkFBbUMsQ0FBQyxDQUFDO1lBQ3ZGLENBQUM7UUFDRixDQUFDO0lBQ0YsQ0FBQztJQUVELFFBQVE7UUFDUCxJQUFJLENBQUMsY0FBYzthQUNqQixNQUFNLEVBQUU7YUFDUixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUM5QixTQUFTLENBQUMsR0FBRyxFQUFFO1lBQ2YsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ3JCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQzdDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN6QyxDQUFDO1FBQ0YsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsZUFBZSxLQUFJLENBQUM7SUFFcEIsV0FBVztRQUNWLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsc0JBQXNCLENBQUMsS0FBaUI7UUFDdkMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUV0QyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUVuQixJQUFJLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1lBQzlCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNiLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNmLENBQUM7SUFDRixDQUFDO0lBRUQsVUFBVSxDQUFDLE1BQWUsRUFBRSxLQUFpQjtRQUM1QyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDeEIsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLE9BQU8sSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1lBQ2hFLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ3hFLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNyRCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM5QixDQUFDO0lBQ0YsQ0FBQztJQUVELGNBQWMsQ0FBQyxLQUFvQjtRQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3JGLENBQUM7SUFDRixDQUFDO0lBRUQsUUFBUTtRQUNQLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDcEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFDdkIsQ0FBQztJQUNGLENBQUM7SUFFRCxPQUFPO1FBQ04sSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFFdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDeEMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2xCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUN4QyxDQUFDO0lBQ0YsQ0FBQztJQUVTLFFBQVE7UUFDakIsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQztJQUN2RSxDQUFDO0lBRUQsSUFBSTtRQUNILElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQztZQUN0QixPQUFPO1FBQ1IsQ0FBQztRQUVELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDN0MsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7UUFDeEIsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7UUFDL0IsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ3hDLENBQUM7SUFFRCxLQUFLO1FBQ0osSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDdEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFDekIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7WUFDM0MsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ25CLENBQUM7SUFDRixDQUFDO0lBRUQsTUFBTSxDQUFDLE9BQXNCO1FBQzVCLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQsV0FBVztRQUNWLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLGNBQWMsR0FBRyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7UUFFM0MsTUFBTSxFQUFFLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBRTFELEVBQUUsRUFBRSxZQUFZLENBQUMsYUFBYSxFQUFFLHFCQUFxQixDQUFDLENBQUM7UUFFdkQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7WUFDNUQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQzVCLENBQUMsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQUVELFVBQVUsQ0FBQyxLQUF5QjtRQUNuQyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzFCLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxFQUF1QztRQUN2RCxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztJQUNyQixDQUFDO0lBRUQsaUJBQWlCLENBQUMsRUFBYztRQUMvQixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsVUFBbUI7UUFDbkMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3RELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN4QyxDQUFDO0lBRUQsbUJBQW1CLENBQUMsS0FBdUM7UUFDMUQsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLE9BQU8sRUFBRSxDQUFDO1lBQ2pDLE1BQU0sUUFBUSxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3JELElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzdCLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUVqQyxJQUFJLElBQUksQ0FBQyxtQkFBbUIsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ2pELElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztnQkFDYixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDZixDQUFDO1FBQ0YsQ0FBQzthQUFNLENBQUM7WUFDUCxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ3hCLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUM7Z0JBRXhDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JCLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xCLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFFakMsSUFBSSxJQUFJLENBQUMsbUJBQW1CLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO29CQUNqRCxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ2IsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNmLENBQUM7WUFDRixDQUFDO1FBQ0YsQ0FBQztJQUNGLENBQUM7SUFFRCxjQUFjLENBQUMsTUFBVztRQUN6QixJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssT0FBTyxFQUFFLENBQUM7WUFDakMsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7WUFDckIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2QsQ0FBQztJQUNGLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxLQUF5QjtRQUN6QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUMxQixPQUFPLEtBQUssQ0FBQztRQUNkLENBQUM7UUFDRCxPQUFPLEtBQUssSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUNyQyxDQUFDO0lBRUQsZ0JBQWdCLENBQUMsS0FBYTtRQUM3QixPQUFPLG9DQUFvQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztJQUM1RCxDQUFDO0lBRU8sa0JBQWtCLENBQUMsS0FBb0IsSUFBUyxDQUFDO0lBRWpELG9CQUFvQixDQUFDLEtBQW9CO1FBQ2hELE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFFOUIsTUFBTSxTQUFTLEdBQUcsT0FBTyxLQUFLLEtBQUssSUFBSSxPQUFPLEtBQUssS0FBSyxDQUFDO1FBRXpELElBQUksU0FBUyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDekMsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNiLENBQUM7SUFDRixDQUFDO0lBRU8sdUJBQXVCO1FBQzlCLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7WUFDbEYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNyQixJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDekMsQ0FBQyxDQUFDLENBQUM7SUFDSixDQUFDO0lBRU8sbUJBQW1CLEtBQUksQ0FBQztJQUV4QixnQkFBZ0I7UUFDdkIsSUFBSSxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLE1BQU0sRUFBRSxDQUFDO1lBQzNELE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7UUFDckUsQ0FBQztRQUVELE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztJQUN4RCxDQUFDO0lBRU8sWUFBWSxDQUFDLFFBQTRCO1FBQ2hELElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxPQUFPLEVBQUUsQ0FBQztZQUNqQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQztnQkFDN0IsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFFBQVEsQ0FBQztnQkFDbEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUM7Z0JBQ3hCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDdkMsT0FBTyxJQUFJLENBQUM7WUFDYixDQUFDO2lCQUFNLElBQUksUUFBUSxJQUFJLElBQUksRUFBRSxDQUFDO2dCQUM3QixJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO2dCQUM5QixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztnQkFDcEIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUN2QyxPQUFPLElBQUksQ0FBQztZQUNiLENBQUM7WUFDRCxPQUFPLEtBQUssQ0FBQztRQUNkLENBQUM7UUFFRCxNQUFNLFdBQVcsR0FBRyxRQUEwQixDQUFDO1FBQy9DLElBQUksV0FBVyxLQUFLLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNsQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsV0FBVyxDQUFDO1lBQ3JDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3pELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUN2QyxPQUFPLElBQUksQ0FBQztRQUNiLENBQUM7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNkLENBQUM7SUFFTyxvQkFBb0IsQ0FBQyxLQUF1QztRQUNuRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNsQyxDQUFDO0lBRU8sdUJBQXVCLENBQUMsUUFBd0I7UUFDdkQsSUFBSSxRQUFRLElBQUksSUFBSSxFQUFFLENBQUM7WUFDdEIsT0FBTyxJQUFJLENBQUM7UUFDYixDQUFDO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDaEQsT0FBTyxRQUFRLENBQUM7UUFDakIsQ0FBQztRQUVELE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQzFDLElBQUksQ0FBQztnQkFDSixPQUFPLEdBQUcsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDdkQsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2hCLElBQUksU0FBUyxFQUFFLEVBQUUsQ0FBQztvQkFDakIsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDckIsQ0FBQztnQkFFRCxPQUFPLEtBQUssQ0FBQztZQUNkLENBQUM7UUFDRixDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQ2hELENBQUM7K0dBdGRXLGtCQUFrQjttR0FBbEIsa0JBQWtCLGc3Q0F4Qm5CO1lBQ1Y7Z0JBQ0MsT0FBTyxFQUFFLGlCQUFpQjtnQkFDMUIsV0FBVyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztnQkFDakQsS0FBSyxFQUFFLElBQUk7YUFDWDtTQUNELDJPQXFCVSxVQUFVLDhFQXFFVixtQkFBbUIsb0VBcEVoQixTQUFTLHlXQ2pIeEIsaXRLQWdKQSxneU1EM0VXLFlBQVksa2JBQUUsYUFBYSwyckNBQUUsVUFBVSwrV0FBRSxTQUFTLDBLQUFFLHNCQUFzQixnRUFBRSx1QkFBdUIsaUVBQUUsa0JBQWtCLDhIQUFFLFVBQVU7OzRGQXdDakksa0JBQWtCO2tCQTNDOUIsU0FBUzsrQkFDQyxZQUFZLGNBQ1YsSUFBSSxXQUNQLENBQUMsWUFBWSxFQUFFLGFBQWEsRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLHNCQUFzQixFQUFFLHVCQUF1QixFQUFFLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxtQkFHN0gsdUJBQXVCLENBQUMsTUFBTSxrQkFDL0I7d0JBQ2Ysa0JBQWtCO3dCQUNsQjs0QkFDQyxTQUFTLEVBQUUsNkJBQTZCOzRCQUN4QyxNQUFNLEVBQUUsQ0FBQyxtQkFBbUIsQ0FBQzt5QkFDN0I7d0JBQ0Q7NEJBQ0MsU0FBUyxFQUFFLHNCQUFzQjs0QkFDakMsTUFBTSxFQUFFLENBQUMsWUFBWSxDQUFDOzRCQUN0QixPQUFPLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQzt5QkFDL0I7cUJBQ0QsYUFDVTt3QkFDVjs0QkFDQyxPQUFPLEVBQUUsaUJBQWlCOzRCQUMxQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxtQkFBbUIsQ0FBQzs0QkFDakQsS0FBSyxFQUFFLElBQUk7eUJBQ1g7cUJBQ0QsUUFDSzt3QkFDTCxLQUFLLEVBQUUsWUFBWTt3QkFDbkIsMkJBQTJCLEVBQUUsY0FBYzt3QkFDM0MsMkJBQTJCLEVBQUUsY0FBYzt3QkFDM0MsMkJBQTJCLEVBQUUsY0FBYzt3QkFDM0MsaUNBQWlDLEVBQUUsdUJBQXVCO3dCQUMxRCwrQkFBK0IsRUFBRSx3QkFBd0I7d0JBQ3pELDZCQUE2QixFQUFFLFVBQVU7d0JBQ3pDLDZCQUE2QixFQUFFLFVBQVU7d0JBQ3pDLDRCQUE0QixFQUFFLFVBQVU7d0JBQ3hDLDRCQUE0QixFQUFFLGFBQWE7d0JBQzNDLDJCQUEyQixFQUFFLFFBQVE7d0JBQ3JDLDZCQUE2QixFQUFFLFVBQVU7d0JBQ3pDLFdBQVcsRUFBRSxJQUFJO3dCQUNqQixvQkFBb0IsRUFBRSxJQUFJO3FCQUMxQjs7MEJBbUZDLElBQUk7OzBCQUNKLElBQUk7OzBCQUNKLElBQUk7eUNBbEZpQixRQUFRO3NCQUE5QixTQUFTO3VCQUFDLFVBQVU7Z0JBQ0QsS0FBSztzQkFBeEIsU0FBUzt1QkFBQyxPQUFPO2dCQUNLLE9BQU87c0JBQTdCLFNBQVM7dUJBQUMsVUFBVTtnQkFDSSxjQUFjO3NCQUF0QyxZQUFZO3VCQUFDLFNBQVM7Z0JBS25CLEVBQUU7c0JBREwsS0FBSztnQkEyQkcsS0FBSztzQkFBYixLQUFLO2dCQUNHLFdBQVc7c0JBQW5CLEtBQUs7Z0JBQ0csVUFBVTtzQkFBbEIsS0FBSztnQkFDRyxPQUFPO3NCQUFmLEtBQUs7Z0JBQ0csVUFBVTtzQkFBbEIsS0FBSztnQkFDRyxVQUFVO3NCQUFsQixLQUFLO2dCQUNHLFFBQVE7c0JBQWhCLEtBQUs7Z0JBQ0csWUFBWTtzQkFBcEIsS0FBSztnQkFDRyxtQkFBbUI7c0JBQTNCLEtBQUs7Z0JBQ0csa0JBQWtCO3NCQUExQixLQUFLO2dCQUdHLElBQUk7c0JBQVosS0FBSztnQkFDRyxRQUFRO3NCQUFoQixLQUFLO2dCQUNHLFVBQVU7c0JBQWxCLEtBQUs7Z0JBQ0csUUFBUTtzQkFBaEIsS0FBSztnQkFNRixTQUFTO3NCQURaLEtBQUs7Z0JBV0ksU0FBUztzQkFBbEIsTUFBTTtnQkFDRyxVQUFVO3NCQUFuQixNQUFNO2dCQUNHLGVBQWU7c0JBQXhCLE1BQU07Z0JBQ0csb0JBQW9CO3NCQUE3QixNQUFNO2dCQUlHLFdBQVc7c0JBRHBCLFNBQVM7dUJBQUMsbUJBQW1CO2dCQXVCMUIsUUFBUTtzQkFEWCxLQUFLO2dCQTJCRixRQUFRO3NCQURYLEtBQUs7Z0JBeUJGLGlCQUFpQjtzQkFEcEIsS0FBSztnQkF5Q0csV0FBVztzQkFBbkIsS0FBSztnQkFFRyxXQUFXO3NCQUFuQixLQUFLO2dCQUlHLGFBQWE7c0JBQXJCLEtBQUs7Z0JBQ0csY0FBYztzQkFBdEIsS0FBSztnQkFDRyxrQkFBa0I7c0JBQTFCLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuXHRBZnRlclZpZXdJbml0LFxuXHRDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcblx0Q2hhbmdlRGV0ZWN0b3JSZWYsXG5cdENvbXBvbmVudCxcblx0RWxlbWVudFJlZixcblx0RXZlbnRFbWl0dGVyLFxuXHRmb3J3YXJkUmVmLFxuXHRpbmplY3QsXG5cdEluamVjdGlvblRva2VuLFxuXHRJbnB1dCxcblx0aXNEZXZNb2RlLFxuXHRPbkNoYW5nZXMsXG5cdE9uRGVzdHJveSxcblx0T25Jbml0LFxuXHRPdXRwdXQsXG5cdFF1ZXJ5TGlzdCxcblx0U2VsZixcblx0U2ltcGxlQ2hhbmdlcyxcblx0Vmlld0NoaWxkLFxuXHRWaWV3Q2hpbGRyZW5cbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgQ2RrQ29ubmVjdGVkT3ZlcmxheSwgQ29ubmVjdGVkUG9zaXRpb24sIE92ZXJsYXksIE92ZXJsYXlNb2R1bGUsIFNjcm9sbFN0cmF0ZWd5LCBWaWV3cG9ydFJ1bGVyIH0gZnJvbSAnQGFuZ3VsYXIvY2RrL292ZXJsYXknO1xuaW1wb3J0IHsgU3ViamVjdCwgdGFrZSwgdGFrZVVudGlsIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBDZGtMaXN0Ym94LCBDZGtPcHRpb24sIExpc3Rib3hWYWx1ZUNoYW5nZUV2ZW50IH0gZnJvbSAnQGFuZ3VsYXIvY2RrL2xpc3Rib3gnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIE5HX1ZBTFVFX0FDQ0VTU09SLCBWYWxpZGF0b3JzIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgY29lcmNlQm9vbGVhblByb3BlcnR5LCBjb2VyY2VOdW1iZXJQcm9wZXJ0eSB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9jb2VyY2lvbic7XG5pbXBvcnQgeyBFTlRFUiwgU1BBQ0UgfSBmcm9tICdAYW5ndWxhci9jZGsva2V5Y29kZXMnO1xuaW1wb3J0IHsgQ2FyZXREb3duSWNvbkNvbXBvbmVudCwgQ2xvc2VFbXB0eUljb25Db21wb25lbnQgfSBmcm9tICdAaXRlcm8vdWktY29tcG9uZW50cy1hbmd1bGFyL2ljb25zJztcbmltcG9ydCB7IE5nQ29udHJvbERpcmVjdGl2ZSB9IGZyb20gJ0BpdGVyby91aS1jb21wb25lbnRzLWFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJdWlFcnJvclN0YXRlTWF0Y2hlckRpcmVjdGl2ZSB9IGZyb20gJ0BpdGVyby91aS1jb21wb25lbnRzLWFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJdWlJc0Rpc2FibGVkRGlyZWN0aXZlIH0gZnJvbSAnQGl0ZXJvL3VpLWNvbXBvbmVudHMtYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEl1aUJ1dHRvbkNvbXBvbmVudCB9IGZyb20gJ0BpdGVyby91aS1jb21wb25lbnRzLWFuZ3VsYXIvYnV0dG9uJztcbmltcG9ydCB7IE1hcHBlclBpcGUgfSBmcm9tICdAaXRlcm8vdWktY29tcG9uZW50cy1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQUxJR05FRF9MRUZUX1BPU0lUSU9OUywgQUxJR05FRF9SSUdIVF9QT1NJVElPTlMgfSBmcm9tICcuL3Bvc2l0aW9ucyc7XG5pbXBvcnQgeyBGb2N1c09wdGlvbnMgfSBmcm9tICdAYW5ndWxhci9jZGsvYTExeSc7XG5cbmV4cG9ydCB0eXBlIFNlbGVjdFNpemUgPSAnbCcgfCAnbScgfCAncyc7XG5leHBvcnQgdHlwZSBTZWxlY3RMYXllclNldCA9ICdzZXQtMDEnIHwgJ3NldC0wMic7XG5leHBvcnQgdHlwZSBTZWxlY3RUeXBlID0gJ3NpbmdsZScgfCAnbXVsdGknO1xuXG5sZXQgbmV4dFVuaXF1ZUlkID0gMDtcblxudHlwZSBWYWx1ZVR5cGU8VD4gPSBUIHwgVFtdIHwgbnVsbDtcblxuLyoqIEluamVjdGlvbiB0b2tlbiB0aGF0IGRldGVybWluZXMgdGhlIHNjcm9sbCBoYW5kbGluZyB3aGlsZSBhIHNlbGVjdCBpcyBvcGVuLiAqL1xuZXhwb3J0IGNvbnN0IElVSV9TRUxFQ1RfU0NST0xMX1NUUkFURUdZID0gbmV3IEluamVjdGlvblRva2VuPCgpID0+IFNjcm9sbFN0cmF0ZWd5PignaXVpLXNlbGVjdC1zY3JvbGwtc3RyYXRlZ3knLCB7XG5cdHByb3ZpZGVkSW46ICdyb290Jyxcblx0ZmFjdG9yeTogKCkgPT4ge1xuXHRcdGNvbnN0IG92ZXJsYXkgPSBpbmplY3QoT3ZlcmxheSk7XG5cblx0XHRyZXR1cm4gKCkgPT4gb3ZlcmxheS5zY3JvbGxTdHJhdGVnaWVzLnJlcG9zaXRpb24oKTtcblx0fVxufSk7XG5cbmV4cG9ydCB0eXBlIE1vZGlmaWVyS2V5ID0gJ2FsdEtleScgfCAnc2hpZnRLZXknIHwgJ2N0cmxLZXknIHwgJ21ldGFLZXknO1xuXG5leHBvcnQgZnVuY3Rpb24gaGFzTW9kaWZpZXJLZXkoZXZlbnQ6IEtleWJvYXJkRXZlbnQsIC4uLm1vZGlmaWVyczogTW9kaWZpZXJLZXlbXSk6IGJvb2xlYW4ge1xuXHRpZiAobW9kaWZpZXJzLmxlbmd0aCkge1xuXHRcdHJldHVybiBtb2RpZmllcnMuc29tZShtb2RpZmllciA9PiBldmVudFttb2RpZmllcl0pO1xuXHR9XG5cblx0cmV0dXJuIGV2ZW50LmFsdEtleSB8fCBldmVudC5zaGlmdEtleSB8fCBldmVudC5jdHJsS2V5IHx8IGV2ZW50Lm1ldGFLZXk7XG59XG5cbkBDb21wb25lbnQoe1xuXHRzZWxlY3RvcjogJ2l1aS1zZWxlY3QnLFxuXHRzdGFuZGFsb25lOiB0cnVlLFxuXHRpbXBvcnRzOiBbQ29tbW9uTW9kdWxlLCBPdmVybGF5TW9kdWxlLCBDZGtMaXN0Ym94LCBDZGtPcHRpb24sIENhcmV0RG93bkljb25Db21wb25lbnQsIENsb3NlRW1wdHlJY29uQ29tcG9uZW50LCBJdWlCdXR0b25Db21wb25lbnQsIE1hcHBlclBpcGVdLFxuXHR0ZW1wbGF0ZVVybDogJy4vaXVpLXNlbGVjdC5jb21wb25lbnQuaHRtbCcsXG5cdHN0eWxlVXJsczogWycuL2l1aS1zZWxlY3QuY29tcG9uZW50LnNjc3MnLCAnLi9pdWktZHJvcGRvd24uc2NzcyddLFxuXHRjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcblx0aG9zdERpcmVjdGl2ZXM6IFtcblx0XHROZ0NvbnRyb2xEaXJlY3RpdmUsXG5cdFx0e1xuXHRcdFx0ZGlyZWN0aXZlOiBJdWlFcnJvclN0YXRlTWF0Y2hlckRpcmVjdGl2ZSxcblx0XHRcdGlucHV0czogWydlcnJvclN0YXRlTWF0Y2hlciddXG5cdFx0fSxcblx0XHR7XG5cdFx0XHRkaXJlY3RpdmU6IEl1aUlzRGlzYWJsZWREaXJlY3RpdmUsXG5cdFx0XHRpbnB1dHM6IFsnaXNEaXNhYmxlZCddLFxuXHRcdFx0b3V0cHV0czogWydkaXNhYmxlQ2hhbmdlRXZlbnQnXVxuXHRcdH1cblx0XSxcblx0cHJvdmlkZXJzOiBbXG5cdFx0e1xuXHRcdFx0cHJvdmlkZTogTkdfVkFMVUVfQUNDRVNTT1IsXG5cdFx0XHR1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBJdWlTZWxlY3RDb21wb25lbnQpLFxuXHRcdFx0bXVsdGk6IHRydWVcblx0XHR9XG5cdF0sXG5cdGhvc3Q6IHtcblx0XHRjbGFzczogJ2l1aS1zZWxlY3QnLFxuXHRcdCdbY2xhc3MuaXVpLXNlbGVjdF9zaXplX2xdJzogJ3NpemUgPT09IFwibFwiJyxcblx0XHQnW2NsYXNzLml1aS1zZWxlY3Rfc2l6ZV9tXSc6ICdzaXplID09PSBcIm1cIicsXG5cdFx0J1tjbGFzcy5pdWktc2VsZWN0X3NpemVfc10nOiAnc2l6ZSA9PT0gXCJzXCInLFxuXHRcdCdbY2xhc3MuaXVpLXNlbGVjdF9sYXllci1zZXQtMDJdJzogJ2xheWVyU2V0ID09PSBcInNldC0wMlwiJyxcblx0XHQnW2NsYXNzLml1aS1zZWxlY3RfdHlwZV9tdWx0aV0nOiAnc2VsZWN0VHlwZSA9PT0gXCJtdWx0aVwiJyxcblx0XHQnW2NsYXNzLml1aS1zZWxlY3RfcmVxdWlyZWRdJzogJ3JlcXVpcmVkJyxcblx0XHQnW2NsYXNzLml1aS1zZWxlY3RfZGlzYWJsZWRdJzogJ2Rpc2FibGVkJyxcblx0XHQnW2NsYXNzLml1aS1zZWxlY3RfZm9jdXNlZF0nOiAnX2ZvY3VzZWQnLFxuXHRcdCdbY2xhc3MuaXVpLXNlbGVjdF9pbnZhbGlkXSc6ICdfZXJyb3JTdGF0ZScsXG5cdFx0J1tjbGFzcy5pdWktc2VsZWN0X2ZpbGxlZF0nOiAnIWVtcHR5Jyxcblx0XHQnW2NsYXNzLml1aS1zZWxlY3Rfc2tlbGV0b25dJzogJ3NrZWxldG9uJyxcblx0XHQnW2F0dHIuaWRdJzogJ2lkJyxcblx0XHQnW2F0dHIuZGF0YS10ZXN0aWRdJzogJ2lkJ1xuXHR9XG59KVxuZXhwb3J0IGNsYXNzIEl1aVNlbGVjdENvbXBvbmVudDxUT3B0aW9uPiBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95LCBDb250cm9sVmFsdWVBY2Nlc3NvciwgQWZ0ZXJWaWV3SW5pdCwgT25DaGFuZ2VzIHtcblx0QFZpZXdDaGlsZCgnY29tYm9ib3gnKSBjb21ib2JveCE6IEVsZW1lbnRSZWY7XG5cdEBWaWV3Q2hpbGQoJ3BhbmVsJykgcGFuZWwhOiBFbGVtZW50UmVmO1xuXHRAVmlld0NoaWxkKENka0xpc3Rib3gpIGxpc3RCb3ghOiBDZGtMaXN0Ym94PFRPcHRpb24+O1xuXHRAVmlld0NoaWxkcmVuKENka09wdGlvbikgb3B0aW9uRWxlbWVudHMhOiBRdWVyeUxpc3Q8Q2RrT3B0aW9uPFRPcHRpb24+Pjtcblx0X292ZXJsYXlQYW5lbENsYXNzOiBzdHJpbmcgfCBzdHJpbmdbXSA9ICcnO1xuXHRkcm9wRG93bk9wZW5lZCA9IGZhbHNlO1xuXG5cdEBJbnB1dCgpXG5cdHNldCBpZCh2YWx1ZTogc3RyaW5nKSB7XG5cdFx0dGhpcy5faWQgPSB2YWx1ZTtcblx0fVxuXG5cdGdldCBpZCgpIHtcblx0XHRyZXR1cm4gdGhpcy5faWQ7XG5cdH1cblxuXHRfaWQgPSBgaXVpLXNlbGVjdC0ke25leHRVbmlxdWVJZCsrfWA7XG5cblx0Z2V0IF92YWx1ZUlkKCkge1xuXHRcdHJldHVybiB0aGlzLmlkICsgJy12YWx1ZSc7XG5cdH1cblx0Z2V0IF9sYWJlbElkKCkge1xuXHRcdHJldHVybiB0aGlzLmlkICsgJy1sYWJlbCc7XG5cdH1cblx0Z2V0IF9wYW5lbElkKCkge1xuXHRcdHJldHVybiB0aGlzLmlkICsgJy1wYW5lbCc7XG5cdH1cblx0Z2V0IF9jb21ib2JveElkKCkge1xuXHRcdHJldHVybiB0aGlzLmlkICsgJy1jb21ib2JveCc7XG5cdH1cblx0Z2V0IF9jYW5jZWxCdXR0b25JZCgpIHtcblx0XHRyZXR1cm4gdGhpcy5pZCArICctY2FuY2VsLXNlbGVjdGlvbic7XG5cdH1cblxuXHRASW5wdXQoKSBsYWJlbCA9ICcnO1xuXHRASW5wdXQoKSBwbGFjZWhvbGRlciA9ICcnO1xuXHRASW5wdXQoKSBwYW5lbFdpZHRoOiBzdHJpbmcgfCBudW1iZXIgfCBudWxsID0gJ2F1dG8nO1xuXHRASW5wdXQoKSBvcHRpb25zOiBUT3B0aW9uW10gPSBbXTtcblx0QElucHV0KCkgcGFuZWxTdHlsZTogeyBbcDogc3RyaW5nXTogYW55IH0gPSB7fTtcblx0QElucHV0KCkgcGFuZWxDbGFzczogc3RyaW5nIHwgc3RyaW5nW10gfCBTZXQ8c3RyaW5nPiB8IHsgW2tleTogc3RyaW5nXTogYW55IH0gPSAnJztcblx0QElucHV0KCkgaGludFRleHQgPSAnJztcblx0QElucHV0KCkgcmVxdWlyZWRUZXh0ID0gJyc7XG5cdEBJbnB1dCgpIGNhbmNlbFNlbGVjdGlvblRleHQgPSAnJztcblx0QElucHV0KCkgZmxleGlibGVEaW1lbnNpb25zID0gZmFsc2U7XG5cblx0Ly8gQURTIDEuMC4wIGlucHV0c1xuXHRASW5wdXQoKSBzaXplOiBTZWxlY3RTaXplID0gJ2wnO1xuXHRASW5wdXQoKSBsYXllclNldDogU2VsZWN0TGF5ZXJTZXQgPSAnc2V0LTAxJztcblx0QElucHV0KCkgc2VsZWN0VHlwZTogU2VsZWN0VHlwZSA9ICdzaW5nbGUnO1xuXHRASW5wdXQoKSBza2VsZXRvbiA9IGZhbHNlO1xuXG5cdHByaXZhdGUgX2F1dG9DbG9zZSA9IHRydWU7XG5cdHByaXZhdGUgX2F1dG9DbG9zZUV4cGxpY2l0bHlTZXQgPSBmYWxzZTtcblxuXHRASW5wdXQoKVxuXHRnZXQgYXV0b0Nsb3NlKCk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiB0aGlzLl9hdXRvQ2xvc2U7XG5cdH1cblxuXHRzZXQgYXV0b0Nsb3NlKHZhbHVlOiBib29sZWFuIHwgc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZCkge1xuXHRcdHRoaXMuX2F1dG9DbG9zZUV4cGxpY2l0bHlTZXQgPSB0cnVlO1xuXHRcdHRoaXMuX2F1dG9DbG9zZSA9IGNvZXJjZUJvb2xlYW5Qcm9wZXJ0eSh2YWx1ZSk7XG5cdH1cblxuXHRfcG9zaXRpb25zOiBDb25uZWN0ZWRQb3NpdGlvbltdID0gQUxJR05FRF9MRUZUX1BPU0lUSU9OUztcblx0QE91dHB1dCgpIG9wZW5FdmVudCA9IG5ldyBFdmVudEVtaXR0ZXI8dm9pZD4oKTtcblx0QE91dHB1dCgpIGNsb3NlRXZlbnQgPSBuZXcgRXZlbnRFbWl0dGVyPHZvaWQ+KCk7XG5cdEBPdXRwdXQoKSBzZWxlY3Rpb25DaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyPExpc3Rib3hWYWx1ZUNoYW5nZUV2ZW50PFRPcHRpb24+PigpO1xuXHRAT3V0cHV0KCkgY2FuY2VsU2VsZWN0aW9uRXZlbnQgPSBuZXcgRXZlbnRFbWl0dGVyPE1vdXNlRXZlbnQ+KCk7XG5cdF9zY3JvbGxTdHJhdGVneTogU2Nyb2xsU3RyYXRlZ3k7XG5cdF9vdmVybGF5V2lkdGghOiBzdHJpbmcgfCBudW1iZXI7XG5cdEBWaWV3Q2hpbGQoQ2RrQ29ubmVjdGVkT3ZlcmxheSlcblx0cHJvdGVjdGVkIF9vdmVybGF5RGlyITogQ2RrQ29ubmVjdGVkT3ZlcmxheTtcblx0cHJvdGVjdGVkIHJlYWRvbmx5IF9kZXN0cm95ID0gbmV3IFN1YmplY3Q8dm9pZD4oKTtcblxuXHRjb25zdHJ1Y3Rvcihcblx0XHRwcm90ZWN0ZWQgX2VsZW1lbnRSZWY6IEVsZW1lbnRSZWYsXG5cdFx0cHJvdGVjdGVkIF9jaGFuZ2VEZXRlY3RvclJlZjogQ2hhbmdlRGV0ZWN0b3JSZWYsXG5cdFx0cHJvdGVjdGVkIF92aWV3cG9ydFJ1bGVyOiBWaWV3cG9ydFJ1bGVyLFxuXHRcdG92ZXJsYXk6IE92ZXJsYXksXG5cdFx0QFNlbGYoKSBwcm90ZWN0ZWQgbmdDb250cm9sRGlyZWN0aXZlOiBOZ0NvbnRyb2xEaXJlY3RpdmU8VmFsdWVUeXBlPFRPcHRpb24+Pixcblx0XHRAU2VsZigpIHByb3RlY3RlZCBlcnJvclN0YXRlTWF0Y2hlckRpcmVjdGl2ZTogSXVpRXJyb3JTdGF0ZU1hdGNoZXJEaXJlY3RpdmUsXG5cdFx0QFNlbGYoKSBwcm90ZWN0ZWQgaXNEaXNhYmxlZERpcmVjdGl2ZTogSXVpSXNEaXNhYmxlZERpcmVjdGl2ZVxuXHQpIHtcblx0XHR0aGlzLl9zY3JvbGxTdHJhdGVneSA9IG92ZXJsYXkuc2Nyb2xsU3RyYXRlZ2llcy5yZXBvc2l0aW9uKCk7XG5cdH1cblxuXHRwcml2YXRlIF90YWJJbmRleCA9IDA7XG5cblx0Z2V0IHRhYkluZGV4KCk6IG51bWJlciB7XG5cdFx0cmV0dXJuIHRoaXMuX3RhYkluZGV4O1xuXHR9XG5cblx0QElucHV0KClcblx0c2V0IHRhYkluZGV4KHY6IHVua25vd24pIHtcblx0XHR0aGlzLl90YWJJbmRleCA9IHYgPT0gbnVsbCA/IDAgOiBjb2VyY2VOdW1iZXJQcm9wZXJ0eSh2KTtcblx0fVxuXG5cdGdldCBkaXNhYmxlZCgpOiBib29sZWFuIHtcblx0XHRyZXR1cm4gdGhpcy5pc0Rpc2FibGVkRGlyZWN0aXZlLmlzRGlzYWJsZWQ7XG5cdH1cblxuXHRwcml2YXRlIF9fdW5tb2RpZmllZFZhbHVlITogVmFsdWVUeXBlPFRPcHRpb24+O1xuXHRwcml2YXRlIF9fdmFsdWUhOiBWYWx1ZVR5cGU8VE9wdGlvbj47XG5cblx0Z2V0IF92YWx1ZSgpOiBWYWx1ZVR5cGU8VE9wdGlvbj4ge1xuXHRcdHJldHVybiB0aGlzLl9fdmFsdWU7XG5cdH1cblxuXHRzZXQgX3ZhbHVlKG5ld1ZhbHVlOiBWYWx1ZVR5cGU8VE9wdGlvbj4pIHtcblx0XHRjb25zdCBoYXNBc3NpZ25lZCA9IHRoaXMuX2Fzc2lnblZhbHVlKG5ld1ZhbHVlKTtcblxuXHRcdGlmIChoYXNBc3NpZ25lZCkge1xuXHRcdFx0dGhpcy5fb25DaGFuZ2UobmV3VmFsdWUpO1xuXHRcdH1cblx0fVxuXG5cdHByaXZhdGUgX3JlcXVpcmVkOiBib29sZWFuIHwgdW5kZWZpbmVkO1xuXG5cdEBJbnB1dCgpXG5cdGdldCByZXF1aXJlZCgpOiBib29sZWFuIHtcblx0XHRyZXR1cm4gdGhpcy5fcmVxdWlyZWQgPz8gdGhpcy5uZ0NvbnRyb2xEaXJlY3RpdmUuY29udHJvbD8uaGFzVmFsaWRhdG9yKFZhbGlkYXRvcnMucmVxdWlyZWQpID8/IGZhbHNlO1xuXHR9XG5cblx0c2V0IHJlcXVpcmVkKHZhbHVlOiBzdHJpbmcgfCBib29sZWFuIHwgbnVsbCB8IHVuZGVmaW5lZCkge1xuXHRcdHRoaXMuX3JlcXVpcmVkID0gY29lcmNlQm9vbGVhblByb3BlcnR5KHZhbHVlKTtcblx0fVxuXG5cdGdldCBlbXB0eSgpOiBib29sZWFuIHtcblx0XHRpZiAodGhpcy5zZWxlY3RUeXBlID09PSAnbXVsdGknKSB7XG5cdFx0XHRyZXR1cm4gIUFycmF5LmlzQXJyYXkodGhpcy5fX3ZhbHVlKSB8fCB0aGlzLl9fdmFsdWUubGVuZ3RoID09PSAwO1xuXHRcdH1cblx0XHRyZXR1cm4gdGhpcy5fX3ZhbHVlID09IG51bGw7XG5cdH1cblxuXHRnZXQgX2lzTXVsdGlwbGUoKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuc2VsZWN0VHlwZSA9PT0gJ211bHRpJztcblx0fVxuXG5cdGdldCBfbXVsdGlWYWx1ZSgpOiBUT3B0aW9uW10ge1xuXHRcdHJldHVybiBBcnJheS5pc0FycmF5KHRoaXMuX192YWx1ZSkgPyB0aGlzLl9fdmFsdWUgOiBbXTtcblx0fVxuXG5cdEBJbnB1dCgpXG5cdHNldCBkcm9wZG93blBvc2l0aW9ucyh2YWx1ZTogQ29ubmVjdGVkUG9zaXRpb25bXSB8ICdsZWZ0JyB8ICdyaWdodCcpIHtcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykge1xuXHRcdFx0dGhpcy5fcG9zaXRpb25zID0gdmFsdWUgPT09ICdyaWdodCcgPyBBTElHTkVEX1JJR0hUX1BPU0lUSU9OUyA6IEFMSUdORURfTEVGVF9QT1NJVElPTlM7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHRoaXMuX3Bvc2l0aW9ucyA9IHZhbHVlO1xuXHRcdH1cblx0fVxuXG5cdGdldCBpc0Ryb3Bkb3duT3BlbmVkKCkge1xuXHRcdHJldHVybiB0aGlzLmRyb3BEb3duT3BlbmVkO1xuXHR9XG5cblx0Z2V0IF9lcnJvclN0YXRlKCkge1xuXHRcdHJldHVybiB0aGlzLmVycm9yU3RhdGVNYXRjaGVyRGlyZWN0aXZlLmVycm9yU3RhdGU7XG5cdH1cblxuXHRnZXQgcmVxdWlyZWRFcnJvcigpIHtcblx0XHRyZXR1cm4gISF0aGlzLm5nQ29udHJvbERpcmVjdGl2ZS5jb250cm9sPy5lcnJvcnM/LlsncmVxdWlyZWQnXTtcblx0fVxuXG5cdHByaXZhdGUgX19mb2N1c2VkID0gZmFsc2U7XG5cblx0Z2V0IF9mb2N1c2VkKCk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiB0aGlzLl9fZm9jdXNlZCB8fCB0aGlzLl9wYW5lbE9wZW47XG5cdH1cblxuXHRnZXQgX2lzQ2FuY2VsQnV0dG9uRGlzYWJsZWQoKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuICEhdGhpcy5jYW5jZWxTZWxlY3Rpb25UZXh0ICYmIHRoaXMuZW1wdHk7XG5cdH1cblxuXHRnZXQgX2VmZmVjdGl2ZUF1dG9DbG9zZSgpOiBib29sZWFuIHtcblx0XHRyZXR1cm4gdGhpcy5zZWxlY3RUeXBlID09PSAnbXVsdGknICYmICF0aGlzLl9hdXRvQ2xvc2VFeHBsaWNpdGx5U2V0ID8gZmFsc2UgOiB0aGlzLl9hdXRvQ2xvc2U7XG5cdH1cblxuXHRwcml2YXRlIF9fcGFuZWxPcGVuID0gZmFsc2U7XG5cblx0Z2V0IF9wYW5lbE9wZW4oKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuX19wYW5lbE9wZW47XG5cdH1cblxuXHRASW5wdXQoKSBjb21wYXJlV2l0aCA9ICh2MTogVE9wdGlvbiwgdjI6IFRPcHRpb24pID0+IHYxID09PSB2MjtcblxuXHRASW5wdXQoKSBnZXRPcHRpb25JZCA9IChpbmRleDogbnVtYmVyLCBjdXJyZW50T3B0aW9uOiBUT3B0aW9uKSA9PiB7XG5cdFx0cmV0dXJuIGAke3RoaXMuX3BhbmVsSWR9X19vcHRpb25faW5kZXhfJHtTdHJpbmcoaW5kZXgpfWA7XG5cdH07XG5cblx0QElucHV0KCkgZ2V0T3B0aW9uTmFtZTogKGN1cnJlbnRPcHRpb246IFRPcHRpb24pID0+IHN0cmluZyA9IChjdXJyZW50T3B0aW9uOiBUT3B0aW9uKSA9PiBTdHJpbmcoY3VycmVudE9wdGlvbik7XG5cdEBJbnB1dCgpIGdldE9wdGlvblN0eWxlOiAoaW5kZXg6IG51bWJlciwgb3B0aW9uOiBUT3B0aW9uKSA9PiB7IFtwOiBzdHJpbmddOiBhbnkgfSB8IG51bGwgfCB1bmRlZmluZWQgPSAoKSA9PiBudWxsO1xuXHRASW5wdXQoKSBnZXRPcHRpb25DbGFzc05hbWU6IChpbmRleDogbnVtYmVyLCBvcHRpb246IFRPcHRpb24pID0+IHN0cmluZyB8IHN0cmluZ1tdIHwgU2V0PHN0cmluZz4gfCB7IFtrZXk6IHN0cmluZ106IGFueSB9ID0gKCkgPT4gJyc7XG5cblx0X3ZhbHVlT3JQbGFjZWhvbGRlcih2YWx1ZTogVmFsdWVUeXBlPFRPcHRpb24+KTogc3RyaW5nIHwgbnVsbCB7XG5cdFx0aWYgKHZhbHVlICE9IG51bGwgJiYgIUFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG5cdFx0XHRyZXR1cm4gdGhpcy5nZXRPcHRpb25OYW1lKHZhbHVlKTtcblx0XHR9XG5cblx0XHRyZXR1cm4gdGhpcy5wbGFjZWhvbGRlciB8fCBudWxsO1xuXHR9XG5cblx0X29uQ2hhbmdlOiAodmFsdWU6IFZhbHVlVHlwZTxUT3B0aW9uPikgPT4gdm9pZCA9ICgpID0+IHt9O1xuXHRfb25Ub3VjaGVkID0gKCkgPT4ge307XG5cblx0bmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuXHRcdGNvbnN0IG9wdGlvbnMgPSBjaGFuZ2VzWydvcHRpb25zJ107XG5cblx0XHRpZiAob3B0aW9ucyAmJiBvcHRpb25zLmN1cnJlbnRWYWx1ZSAhPSBvcHRpb25zLnByZXZpb3VzVmFsdWUpIHtcblx0XHRcdGlmICh0aGlzLnNlbGVjdFR5cGUgPT09ICdtdWx0aScgJiYgQXJyYXkuaXNBcnJheSh0aGlzLl9fdW5tb2RpZmllZFZhbHVlKSkge1xuXHRcdFx0XHR0aGlzLl9fdmFsdWUgPSB0aGlzLl9fdW5tb2RpZmllZFZhbHVlXG5cdFx0XHRcdFx0Lm1hcCh2ID0+IHRoaXMuY29ycmVzcG9uZGVkVmFsdWVPck51bGwodikpXG5cdFx0XHRcdFx0LmZpbHRlcigodik6IHYgaXMgVE9wdGlvbiA9PiB2ICE9IG51bGwpO1xuXHRcdFx0XHRpZiAoKHRoaXMuX192YWx1ZSBhcyBUT3B0aW9uW10pLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0XHRcdHRoaXMuX192YWx1ZSA9IG51bGw7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHRoaXMuX192YWx1ZSA9IHRoaXMuY29ycmVzcG9uZGVkVmFsdWVPck51bGwodGhpcy5fX3VubW9kaWZpZWRWYWx1ZSBhcyBUT3B0aW9uIHwgbnVsbCk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0bmdPbkluaXQoKSB7XG5cdFx0dGhpcy5fdmlld3BvcnRSdWxlclxuXHRcdFx0LmNoYW5nZSgpXG5cdFx0XHQucGlwZSh0YWtlVW50aWwodGhpcy5fZGVzdHJveSkpXG5cdFx0XHQuc3Vic2NyaWJlKCgpID0+IHtcblx0XHRcdFx0aWYgKHRoaXMuX3BhbmVsT3Blbikge1xuXHRcdFx0XHRcdHRoaXMuX292ZXJsYXlXaWR0aCA9IHRoaXMuX2dldE92ZXJsYXlXaWR0aCgpO1xuXHRcdFx0XHRcdHRoaXMuX2NoYW5nZURldGVjdG9yUmVmLmRldGVjdENoYW5nZXMoKTtcblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdH1cblxuXHRuZ0FmdGVyVmlld0luaXQoKSB7fVxuXG5cdG5nT25EZXN0cm95KCkge1xuXHRcdHRoaXMuX2Rlc3Ryb3kubmV4dCgpO1xuXHRcdHRoaXMuX2Rlc3Ryb3kuY29tcGxldGUoKTtcblx0fVxuXG5cdF9oYW5kbGVDYW5jZWxTZWxlY3Rpb24oZXZlbnQ6IE1vdXNlRXZlbnQpIHtcblx0XHR0aGlzLmNhbmNlbFNlbGVjdGlvbkV2ZW50LmVtaXQoZXZlbnQpO1xuXG5cdFx0dGhpcy5fdmFsdWUgPSBudWxsO1xuXG5cdFx0aWYgKHRoaXMuX2VmZmVjdGl2ZUF1dG9DbG9zZSkge1xuXHRcdFx0dGhpcy5jbG9zZSgpO1xuXHRcdFx0dGhpcy5fZm9jdXMoKTtcblx0XHR9XG5cdH1cblxuXHRfcmVtb3ZlVGFnKG9wdGlvbjogVE9wdGlvbiwgZXZlbnQ6IE1vdXNlRXZlbnQpOiB2b2lkIHtcblx0XHRldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcblx0XHRpZiAodGhpcy5zZWxlY3RUeXBlID09PSAnbXVsdGknICYmIEFycmF5LmlzQXJyYXkodGhpcy5fX3ZhbHVlKSkge1xuXHRcdFx0Y29uc3QgbmV3VmFsdWUgPSB0aGlzLl9fdmFsdWUuZmlsdGVyKHYgPT4gIXRoaXMuY29tcGFyZVdpdGgodiwgb3B0aW9uKSk7XG5cdFx0XHR0aGlzLl9hc3NpZ25WYWx1ZShuZXdWYWx1ZS5sZW5ndGggPyBuZXdWYWx1ZSA6IG51bGwpO1xuXHRcdFx0dGhpcy5fb25DaGFuZ2UodGhpcy5fX3ZhbHVlKTtcblx0XHR9XG5cdH1cblxuXHRfaGFuZGxlS2V5ZG93bihldmVudDogS2V5Ym9hcmRFdmVudCk6IHZvaWQge1xuXHRcdGlmICghdGhpcy5kaXNhYmxlZCkge1xuXHRcdFx0dGhpcy5fcGFuZWxPcGVuID8gdGhpcy5faGFuZGxlT3BlbktleWRvd24oZXZlbnQpIDogdGhpcy5faGFuZGxlQ2xvc2VkS2V5ZG93bihldmVudCk7XG5cdFx0fVxuXHR9XG5cblx0X29uRm9jdXMoKSB7XG5cdFx0aWYgKCF0aGlzLmRpc2FibGVkKSB7XG5cdFx0XHR0aGlzLl9fZm9jdXNlZCA9IHRydWU7XG5cdFx0fVxuXHR9XG5cblx0X29uQmx1cigpIHtcblx0XHR0aGlzLl9fZm9jdXNlZCA9IGZhbHNlO1xuXG5cdFx0aWYgKCF0aGlzLmRpc2FibGVkICYmICF0aGlzLl9wYW5lbE9wZW4pIHtcblx0XHRcdHRoaXMuX29uVG91Y2hlZCgpO1xuXHRcdFx0dGhpcy5fY2hhbmdlRGV0ZWN0b3JSZWYubWFya0ZvckNoZWNrKCk7XG5cdFx0fVxuXHR9XG5cblx0cHJvdGVjdGVkIF9jYW5PcGVuKCk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiAhdGhpcy5fcGFuZWxPcGVuICYmICF0aGlzLmRpc2FibGVkICYmIHRoaXMub3B0aW9ucz8ubGVuZ3RoID4gMDtcblx0fVxuXG5cdG9wZW4oKTogdm9pZCB7XG5cdFx0aWYgKCF0aGlzLl9jYW5PcGVuKCkpIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHR0aGlzLl9vdmVybGF5V2lkdGggPSB0aGlzLl9nZXRPdmVybGF5V2lkdGgoKTtcblx0XHR0aGlzLl9fcGFuZWxPcGVuID0gdHJ1ZTtcblx0XHR0aGlzLl9oaWdobGlnaHRDb3JyZWN0T3B0aW9uKCk7XG5cdFx0dGhpcy5fY2hhbmdlRGV0ZWN0b3JSZWYubWFya0ZvckNoZWNrKCk7XG5cdH1cblxuXHRjbG9zZSgpOiB2b2lkIHtcblx0XHRpZiAodGhpcy5fX3BhbmVsT3Blbikge1xuXHRcdFx0dGhpcy5fX3BhbmVsT3BlbiA9IGZhbHNlO1xuXHRcdFx0dGhpcy5fY2hhbmdlRGV0ZWN0b3JSZWYubWFya0ZvckNoZWNrKCk7XG5cdFx0XHR0aGlzLmNsb3NlRXZlbnQuZW1pdCgpO1xuXHRcdFx0dGhpcy5kcm9wRG93bk9wZW5lZCA9ICF0aGlzLmRyb3BEb3duT3BlbmVkO1xuXHRcdFx0dGhpcy5fb25Ub3VjaGVkKCk7XG5cdFx0fVxuXHR9XG5cblx0X2ZvY3VzKG9wdGlvbnM/OiBGb2N1c09wdGlvbnMpOiB2b2lkIHtcblx0XHR0aGlzLmNvbWJvYm94Lm5hdGl2ZUVsZW1lbnQuZm9jdXMob3B0aW9ucyk7XG5cdH1cblxuXHRfb25BdHRhY2hlZCgpOiB2b2lkIHtcblx0XHR0aGlzLm9wZW5FdmVudC5lbWl0KCk7XG5cdFx0dGhpcy5kcm9wRG93bk9wZW5lZCA9ICF0aGlzLmRyb3BEb3duT3BlbmVkO1xuXG5cdFx0Y29uc3QgYmQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuaXVpLXNlbGVjdC1iYWNrZHJvcCcpO1xuXG5cdFx0YmQ/LnNldEF0dHJpYnV0ZSgnZGF0YS10ZXN0aWQnLCAnaXVpLXNlbGVjdC1iYWNrZHJvcCcpO1xuXG5cdFx0dGhpcy5fb3ZlcmxheURpci5wb3NpdGlvbkNoYW5nZS5waXBlKHRha2UoMSkpLnN1YnNjcmliZSgoKSA9PiB7XG5cdFx0XHR0aGlzLl9jaGFuZ2VEZXRlY3RvclJlZi5kZXRlY3RDaGFuZ2VzKCk7XG5cdFx0XHR0aGlzLl9wb3NpdGlvbmluZ1NldHRsZWQoKTtcblx0XHR9KTtcblx0fVxuXG5cdHdyaXRlVmFsdWUodmFsdWU6IFZhbHVlVHlwZTxUT3B0aW9uPik6IHZvaWQge1xuXHRcdHRoaXMuX2Fzc2lnblZhbHVlKHZhbHVlKTtcblx0fVxuXG5cdHJlZ2lzdGVyT25DaGFuZ2UoZm46ICh2YWx1ZTogVmFsdWVUeXBlPFRPcHRpb24+KSA9PiB2b2lkKTogdm9pZCB7XG5cdFx0dGhpcy5fb25DaGFuZ2UgPSBmbjtcblx0fVxuXG5cdHJlZ2lzdGVyT25Ub3VjaGVkKGZuOiAoKSA9PiB2b2lkKTogdm9pZCB7XG5cdFx0dGhpcy5fb25Ub3VjaGVkID0gZm47XG5cdH1cblxuXHRzZXREaXNhYmxlZFN0YXRlKGlzRGlzYWJsZWQ6IGJvb2xlYW4pOiB2b2lkIHtcblx0XHR0aGlzLmlzRGlzYWJsZWREaXJlY3RpdmUuc2V0RGlzYWJsZWRTdGF0ZShpc0Rpc2FibGVkKTtcblx0XHR0aGlzLl9jaGFuZ2VEZXRlY3RvclJlZi5tYXJrRm9yQ2hlY2soKTtcblx0fVxuXG5cdF9saXN0Qm94VmFsdWVDaGFuZ2UoZXZlbnQ6IExpc3Rib3hWYWx1ZUNoYW5nZUV2ZW50PFRPcHRpb24+KSB7XG5cdFx0aWYgKHRoaXMuc2VsZWN0VHlwZSA9PT0gJ211bHRpJykge1xuXHRcdFx0Y29uc3QgbmV3VmFsdWUgPSBbLi4uZXZlbnQudmFsdWVdO1xuXHRcdFx0dGhpcy5fYXNzaWduVmFsdWUobmV3VmFsdWUubGVuZ3RoID8gbmV3VmFsdWUgOiBudWxsKTtcblx0XHRcdHRoaXMuX29uQ2hhbmdlKHRoaXMuX192YWx1ZSk7XG5cdFx0XHR0aGlzLl9lbWl0U2VsZWN0aW9uQ2hhbmdlKGV2ZW50KTtcblxuXHRcdFx0aWYgKHRoaXMuX2VmZmVjdGl2ZUF1dG9DbG9zZSAmJiB0aGlzLl9wYW5lbE9wZW4pIHtcblx0XHRcdFx0dGhpcy5jbG9zZSgpO1xuXHRcdFx0XHR0aGlzLl9mb2N1cygpO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRpZiAoZXZlbnQudmFsdWUubGVuZ3RoKSB7XG5cdFx0XHRcdGNvbnN0IHYgPSBbLi4uZXZlbnQudmFsdWVdPy5bMF0gPz8gbnVsbDtcblxuXHRcdFx0XHR0aGlzLl9hc3NpZ25WYWx1ZSh2KTtcblx0XHRcdFx0dGhpcy5fb25DaGFuZ2Uodik7XG5cdFx0XHRcdHRoaXMuX2VtaXRTZWxlY3Rpb25DaGFuZ2UoZXZlbnQpO1xuXG5cdFx0XHRcdGlmICh0aGlzLl9lZmZlY3RpdmVBdXRvQ2xvc2UgJiYgdGhpcy5fcGFuZWxPcGVuKSB7XG5cdFx0XHRcdFx0dGhpcy5jbG9zZSgpO1xuXHRcdFx0XHRcdHRoaXMuX2ZvY3VzKCk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRfb25PcHRpb25DbGljayhvcHRpb246IGFueSkge1xuXHRcdGlmICh0aGlzLnNlbGVjdFR5cGUgIT09ICdtdWx0aScpIHtcblx0XHRcdHRoaXMuX3ZhbHVlID0gb3B0aW9uO1xuXHRcdFx0dGhpcy5jbG9zZSgpO1xuXHRcdH1cblx0fVxuXG5cdF9jZGtMaXN0Qm94VmFsdWUodmFsdWU6IFZhbHVlVHlwZTxUT3B0aW9uPik6IFRPcHRpb25bXSB7XG5cdFx0aWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG5cdFx0XHRyZXR1cm4gdmFsdWU7XG5cdFx0fVxuXHRcdHJldHVybiB2YWx1ZSAhPSBudWxsID8gW3ZhbHVlXSA6IFtdO1xuXHR9XG5cblx0X29wdGlvbkNsYXNzTmFtZShpbmRleDogbnVtYmVyKSB7XG5cdFx0cmV0dXJuIGBpdWktZHJvcGRvd24tcGFuZWxfX29wdGlvbl9pbmRleF8ke1N0cmluZyhpbmRleCl9YDtcblx0fVxuXG5cdHByaXZhdGUgX2hhbmRsZU9wZW5LZXlkb3duKGV2ZW50OiBLZXlib2FyZEV2ZW50KTogdm9pZCB7fVxuXG5cdHByaXZhdGUgX2hhbmRsZUNsb3NlZEtleWRvd24oZXZlbnQ6IEtleWJvYXJkRXZlbnQpOiB2b2lkIHtcblx0XHRjb25zdCBrZXlDb2RlID0gZXZlbnQua2V5Q29kZTtcblxuXHRcdGNvbnN0IGlzT3BlbktleSA9IGtleUNvZGUgPT09IEVOVEVSIHx8IGtleUNvZGUgPT09IFNQQUNFO1xuXG5cdFx0aWYgKGlzT3BlbktleSAmJiAhaGFzTW9kaWZpZXJLZXkoZXZlbnQpKSB7XG5cdFx0XHRldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdFx0dGhpcy5vcGVuKCk7XG5cdFx0fVxuXHR9XG5cblx0cHJpdmF0ZSBfaGlnaGxpZ2h0Q29ycmVjdE9wdGlvbigpOiB2b2lkIHtcblx0XHR0aGlzLm9wdGlvbkVsZW1lbnRzLmNoYW5nZXMucGlwZSh0YWtlKDEpLCB0YWtlVW50aWwodGhpcy5fZGVzdHJveSkpLnN1YnNjcmliZSgoKSA9PiB7XG5cdFx0XHR0aGlzLmxpc3RCb3guZm9jdXMoKTtcblx0XHRcdHRoaXMuX2NoYW5nZURldGVjdG9yUmVmLmRldGVjdENoYW5nZXMoKTtcblx0XHR9KTtcblx0fVxuXG5cdHByaXZhdGUgX3Bvc2l0aW9uaW5nU2V0dGxlZCgpIHt9XG5cblx0cHJpdmF0ZSBfZ2V0T3ZlcmxheVdpZHRoKCk6IHN0cmluZyB8IG51bWJlciB7XG5cdFx0aWYgKHRoaXMucGFuZWxXaWR0aCA9PSBudWxsIHx8IHRoaXMucGFuZWxXaWR0aCA9PT0gJ2F1dG8nKSB7XG5cdFx0XHRyZXR1cm4gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xuXHRcdH1cblxuXHRcdHJldHVybiB0aGlzLnBhbmVsV2lkdGggPT09IG51bGwgPyAnJyA6IHRoaXMucGFuZWxXaWR0aDtcblx0fVxuXG5cdHByaXZhdGUgX2Fzc2lnblZhbHVlKG5ld1ZhbHVlOiBWYWx1ZVR5cGU8VE9wdGlvbj4pOiBib29sZWFuIHtcblx0XHRpZiAodGhpcy5zZWxlY3RUeXBlID09PSAnbXVsdGknKSB7XG5cdFx0XHRpZiAoQXJyYXkuaXNBcnJheShuZXdWYWx1ZSkpIHtcblx0XHRcdFx0dGhpcy5fX3VubW9kaWZpZWRWYWx1ZSA9IG5ld1ZhbHVlO1xuXHRcdFx0XHR0aGlzLl9fdmFsdWUgPSBuZXdWYWx1ZTtcblx0XHRcdFx0dGhpcy5fY2hhbmdlRGV0ZWN0b3JSZWYubWFya0ZvckNoZWNrKCk7XG5cdFx0XHRcdHJldHVybiB0cnVlO1xuXHRcdFx0fSBlbHNlIGlmIChuZXdWYWx1ZSA9PSBudWxsKSB7XG5cdFx0XHRcdHRoaXMuX191bm1vZGlmaWVkVmFsdWUgPSBudWxsO1xuXHRcdFx0XHR0aGlzLl9fdmFsdWUgPSBudWxsO1xuXHRcdFx0XHR0aGlzLl9jaGFuZ2VEZXRlY3RvclJlZi5tYXJrRm9yQ2hlY2soKTtcblx0XHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXG5cdFx0Y29uc3Qgc2luZ2xlVmFsdWUgPSBuZXdWYWx1ZSBhcyBUT3B0aW9uIHwgbnVsbDtcblx0XHRpZiAoc2luZ2xlVmFsdWUgIT09IHRoaXMuX192YWx1ZSkge1xuXHRcdFx0dGhpcy5fX3VubW9kaWZpZWRWYWx1ZSA9IHNpbmdsZVZhbHVlO1xuXHRcdFx0dGhpcy5fX3ZhbHVlID0gdGhpcy5jb3JyZXNwb25kZWRWYWx1ZU9yTnVsbChzaW5nbGVWYWx1ZSk7XG5cdFx0XHR0aGlzLl9jaGFuZ2VEZXRlY3RvclJlZi5tYXJrRm9yQ2hlY2soKTtcblx0XHRcdHJldHVybiB0cnVlO1xuXHRcdH1cblxuXHRcdHJldHVybiBmYWxzZTtcblx0fVxuXG5cdHByaXZhdGUgX2VtaXRTZWxlY3Rpb25DaGFuZ2UoZXZlbnQ6IExpc3Rib3hWYWx1ZUNoYW5nZUV2ZW50PFRPcHRpb24+KTogdm9pZCB7XG5cdFx0dGhpcy5zZWxlY3Rpb25DaGFuZ2UuZW1pdChldmVudCk7XG5cdH1cblxuXHRwcml2YXRlIGNvcnJlc3BvbmRlZFZhbHVlT3JOdWxsKG5ld1ZhbHVlOiBUT3B0aW9uIHwgbnVsbCk6IFRPcHRpb24gfCBudWxsIHtcblx0XHRpZiAobmV3VmFsdWUgPT0gbnVsbCkge1xuXHRcdFx0cmV0dXJuIG51bGw7XG5cdFx0fVxuXHRcdGlmICghdGhpcy5vcHRpb25zIHx8IHRoaXMub3B0aW9ucy5sZW5ndGggPT09IDApIHtcblx0XHRcdHJldHVybiBuZXdWYWx1ZTtcblx0XHR9XG5cblx0XHRjb25zdCBpbmRleCA9IHRoaXMub3B0aW9ucy5maW5kSW5kZXgob3B0ID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHJldHVybiBvcHQgIT0gbnVsbCAmJiB0aGlzLmNvbXBhcmVXaXRoKG9wdCwgbmV3VmFsdWUpO1xuXHRcdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdFx0aWYgKGlzRGV2TW9kZSgpKSB7XG5cdFx0XHRcdFx0Y29uc29sZS53YXJuKGVycm9yKTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdHJldHVybiBmYWxzZTtcblx0XHRcdH1cblx0XHR9KTtcblxuXHRcdHJldHVybiBpbmRleCA+PSAwID8gdGhpcy5vcHRpb25zW2luZGV4XSA6IG51bGw7XG5cdH1cbn1cbiIsIjxuZy1jb250YWluZXIgKm5nSWY9XCJza2VsZXRvbjsgZWxzZSBub3JtYWxUZW1wbGF0ZVwiPlxuXHQ8ZGl2IGNsYXNzPVwiaXVpLXNlbGVjdF9fc2tlbGV0b24tbGFiZWxcIj48L2Rpdj5cblx0PGRpdiBjbGFzcz1cIml1aS1zZWxlY3RfX3NrZWxldG9uLWZpZWxkXCI+PC9kaXY+XG5cdDxkaXYgY2xhc3M9XCJpdWktc2VsZWN0X19za2VsZXRvbi1oZWxwZXJcIj48L2Rpdj5cbjwvbmctY29udGFpbmVyPlxuXG48bmctdGVtcGxhdGUgI25vcm1hbFRlbXBsYXRlPlxuXHQ8ZGl2IGNsYXNzPVwiaXVpLXNlbGVjdF9fbGFiZWwtcm93XCIgKm5nSWY9XCJsYWJlbFwiPlxuXHRcdDxsYWJlbCBjbGFzcz1cIml1aS1zZWxlY3RfX2xhYmVsXCIgW2F0dHIuZm9yXT1cIl9jb21ib2JveElkXCIgW2lkXT1cIl9sYWJlbElkXCI+XG5cdFx0XHR7eyBsYWJlbCB9fTxzcGFuIGNsYXNzPVwiaXVpLXNlbGVjdF9fcmVxdWlyZWRcIiAqbmdJZj1cInJlcXVpcmVkXCI+Kjwvc3Bhbj5cblx0XHQ8L2xhYmVsPlxuXHQ8L2Rpdj5cblxuXHQ8ZGl2XG5cdFx0I2NvbWJvYm94XG5cdFx0Y2RrLW92ZXJsYXktb3JpZ2luXG5cdFx0I2ZhbGxiYWNrT3ZlcmxheU9yaWdpbj1cImNka092ZXJsYXlPcmlnaW5cIlxuXHRcdGNsYXNzPVwiaXVpLXNlbGVjdF9fZmllbGRcIlxuXHRcdFthdHRyLmlkXT1cIl9jb21ib2JveElkXCJcblx0XHRbYXR0ci5hcmlhLW93bnNdPVwiX3BhbmVsT3BlbiA/IF9wYW5lbElkIDogbnVsbFwiXG5cdFx0cm9sZT1cImNvbWJvYm94XCJcblx0XHRhcmlhLWF1dG9jb21wbGV0ZT1cIm5vbmVcIlxuXHRcdGFyaWEtaGFzcG9wdXA9XCJsaXN0Ym94XCJcblx0XHRbYXR0ci5hcmlhLWV4cGFuZGVkXT1cIl9wYW5lbE9wZW5cIlxuXHRcdFthdHRyLmFyaWEtcmVxdWlyZWRdPVwicmVxdWlyZWQudG9TdHJpbmcoKVwiXG5cdFx0W2F0dHIuYXJpYS1kaXNhYmxlZF09XCJkaXNhYmxlZC50b1N0cmluZygpXCJcblx0XHRbYXR0ci5hcmlhLWludmFsaWRdPVwiX2Vycm9yU3RhdGVcIlxuXHRcdFthdHRyLnRhYmluZGV4XT1cImRpc2FibGVkID8gLTEgOiB0YWJJbmRleFwiXG5cdFx0KGtleWRvd24pPVwiX2hhbmRsZUtleWRvd24oJGV2ZW50KVwiXG5cdFx0KGZvY3VzKT1cIl9vbkZvY3VzKClcIlxuXHRcdChibHVyKT1cIl9vbkJsdXIoKVwiXG5cdFx0KGNsaWNrKT1cIm9wZW4oKVwiXG5cdD5cblx0XHQ8c3BhbiBjbGFzcz1cIml1aS1zZWxlY3RfX3ByZWZpeFwiPjxuZy1jb250ZW50IHNlbGVjdD1cIltpdWktcHJlZml4XVwiPjwvbmctY29udGVudD48L3NwYW4+XG5cblx0XHQ8bmctY29udGFpbmVyICpuZ0lmPVwic2VsZWN0VHlwZSA9PT0gJ3NpbmdsZSdcIj5cblx0XHRcdDxzcGFuXG5cdFx0XHRcdCpuZ0lmPVwicGxhY2Vob2xkZXIgfHwgIWVtcHR5XCJcblx0XHRcdFx0Y2xhc3M9XCJpdWktc2VsZWN0X192YWx1ZVwiXG5cdFx0XHRcdFthdHRyLmlkXT1cIl92YWx1ZUlkXCJcblx0XHRcdFx0W2F0dHIuZGF0YS10ZXN0aWRdPVwiX3ZhbHVlSWRcIlxuXHRcdFx0PlxuXHRcdFx0XHR7eyBfdmFsdWUgfCBtYXBwZXI6IF92YWx1ZU9yUGxhY2Vob2xkZXIuYmluZCh0aGlzKSB9fVxuXHRcdFx0PC9zcGFuPlxuXHRcdDwvbmctY29udGFpbmVyPlxuXG5cdFx0PG5nLWNvbnRhaW5lciAqbmdJZj1cInNlbGVjdFR5cGUgPT09ICdtdWx0aSdcIj5cblx0XHRcdDxkaXYgY2xhc3M9XCJpdWktc2VsZWN0X190YWdzXCIgKm5nSWY9XCIhZW1wdHk7IGVsc2UgbXVsdGlQbGFjZWhvbGRlclwiPlxuXHRcdFx0XHQ8c3BhbiBjbGFzcz1cIml1aS1zZWxlY3RfX3RhZ1wiICpuZ0Zvcj1cImxldCB0YWcgb2YgX211bHRpVmFsdWU7IHRyYWNrQnk6IGdldE9wdGlvbklkXCI+XG5cdFx0XHRcdFx0PHNwYW4gY2xhc3M9XCJpdWktc2VsZWN0X190YWctdGV4dFwiPnt7IHRhZyB8IG1hcHBlcjogZ2V0T3B0aW9uTmFtZS5iaW5kKHRoaXMpIH19PC9zcGFuPlxuXHRcdFx0XHRcdDxpdWktY2xvc2UtZW1wdHktaWNvblxuXHRcdFx0XHRcdFx0Y2xhc3M9XCJpdWktc2VsZWN0X190YWctcmVtb3ZlXCJcblx0XHRcdFx0XHRcdChjbGljayk9XCJfcmVtb3ZlVGFnKHRhZywgJGV2ZW50KVwiXG5cdFx0XHRcdFx0PjwvaXVpLWNsb3NlLWVtcHR5LWljb24+XG5cdFx0XHRcdDwvc3Bhbj5cblx0XHRcdDwvZGl2PlxuXHRcdFx0PG5nLXRlbXBsYXRlICNtdWx0aVBsYWNlaG9sZGVyPlxuXHRcdFx0XHQ8c3BhbiBjbGFzcz1cIml1aS1zZWxlY3RfX3ZhbHVlXCIgKm5nSWY9XCJwbGFjZWhvbGRlclwiPnt7IHBsYWNlaG9sZGVyIH19PC9zcGFuPlxuXHRcdFx0PC9uZy10ZW1wbGF0ZT5cblx0XHQ8L25nLWNvbnRhaW5lcj5cblxuXHRcdDxzcGFuIGNsYXNzPVwiaXVpLXNlbGVjdF9fY2hldnJvblwiPlxuXHRcdFx0PHNwYW4gY2xhc3M9XCJpdWktc2VsZWN0X19zdWZmaXhcIj48bmctY29udGVudCBzZWxlY3Q9XCJbaXVpLXN1ZmZpeF1cIj48L25nLWNvbnRlbnQ+PC9zcGFuPlxuXHRcdFx0PGl1aS1jYXJldC1kb3duLWljb25cblx0XHRcdFx0Y2xhc3M9XCJpdWktc2VsZWN0X19hcnJvdyBkZWZhdWx0LWNhcmV0XCJcblx0XHRcdFx0W2NsYXNzLml1aS1zZWxlY3RfX2Fycm93X29wZW5lZF09XCJpc0Ryb3Bkb3duT3BlbmVkXCI+XG5cdFx0XHQ8L2l1aS1jYXJldC1kb3duLWljb24+XG5cdFx0PC9zcGFuPlxuXHQ8L2Rpdj5cblxuXHQ8ZGl2IGNsYXNzPVwiaXVpLXNlbGVjdF9faGVscGVyLXJvd1wiPlxuXHRcdDxzcGFuICpuZ0lmPVwiX2Vycm9yU3RhdGVcIiBjbGFzcz1cIml1aS1zZWxlY3RfX2Vycm9yXCI+XG5cdFx0XHQ8bmctY29udGFpbmVyICpuZ0lmPVwicmVxdWlyZWRFcnJvciAmJiByZXF1aXJlZFRleHRcIj57eyByZXF1aXJlZFRleHQgfX08L25nLWNvbnRhaW5lcj5cblx0XHRcdDxuZy1jb250ZW50IHNlbGVjdD1cIltpdWktZXJyb3JdXCI+PC9uZy1jb250ZW50PlxuXHRcdDwvc3Bhbj5cblx0XHQ8c3BhbiAqbmdJZj1cIiFfZXJyb3JTdGF0ZSAmJiBoaW50VGV4dFwiIGNsYXNzPVwiaXVpLXNlbGVjdF9faGVscGVyXCI+XG5cdFx0XHR7eyBoaW50VGV4dCB9fVxuXHRcdDwvc3Bhbj5cblx0PC9kaXY+XG5cblx0PG5nLXRlbXBsYXRlXG5cdGNkay1jb25uZWN0ZWQtb3ZlcmxheVxuXHRjZGtDb25uZWN0ZWRPdmVybGF5TG9ja1Bvc2l0aW9uXG5cdGNka0Nvbm5lY3RlZE92ZXJsYXlIYXNCYWNrZHJvcFxuXHRbY2RrQ29ubmVjdGVkT3ZlcmxheUJhY2tkcm9wQ2xhc3NdPVwiWydjZGstb3ZlcmxheS10cmFuc3BhcmVudC1iYWNrZHJvcCcsICdpdWktc2VsZWN0LWJhY2tkcm9wJ11cIlxuXHRbY2RrQ29ubmVjdGVkT3ZlcmxheVBhbmVsQ2xhc3NdPVwiX292ZXJsYXlQYW5lbENsYXNzXCJcblx0W2Nka0Nvbm5lY3RlZE92ZXJsYXlTY3JvbGxTdHJhdGVneV09XCJfc2Nyb2xsU3RyYXRlZ3lcIlxuXHRbY2RrQ29ubmVjdGVkT3ZlcmxheU9yaWdpbl09XCJmYWxsYmFja092ZXJsYXlPcmlnaW5cIlxuXHRbY2RrQ29ubmVjdGVkT3ZlcmxheU9wZW5dPVwiX3BhbmVsT3BlblwiXG5cdFtjZGtDb25uZWN0ZWRPdmVybGF5UG9zaXRpb25zXT1cIl9wb3NpdGlvbnNcIlxuXHRbY2RrQ29ubmVjdGVkT3ZlcmxheU1pbldpZHRoXT1cIl9vdmVybGF5V2lkdGhcIlxuXHRbY2RrQ29ubmVjdGVkT3ZlcmxheUZsZXhpYmxlRGltZW5zaW9uc109XCJmbGV4aWJsZURpbWVuc2lvbnNcIlxuXHQoYmFja2Ryb3BDbGljayk9XCJjbG9zZSgpXCJcblx0KGF0dGFjaCk9XCJfb25BdHRhY2hlZCgpXCJcblx0KGRldGFjaCk9XCJjbG9zZSgpXCJcbj5cblx0PGRpdlxuXHRcdCNwYW5lbFxuXHRcdGNsYXNzPVwiaXVpLWRyb3Bkb3duLXBhbmVsXCJcblx0XHRbYXR0ci5pZF09XCJfcGFuZWxJZFwiXG5cdFx0W2F0dHIuZGF0YS10ZXN0aWRdPVwiX3BhbmVsSWRcIlxuXHRcdFthdHRyLmFyaWEtbGFiZWxsZWRieV09XCJfbGFiZWxJZFwiXG5cdFx0W25nU3R5bGVdPVwicGFuZWxTdHlsZVwiXG5cdFx0W25nQ2xhc3NdPVwicGFuZWxDbGFzc1wiXG5cdD5cblx0XHQ8dWxcblx0XHRcdGNsYXNzPVwiaXVpLWRyb3Bkb3duLXBhbmVsX19saXN0Ym94XCJcblx0XHRcdGNka0xpc3Rib3hcblx0XHRcdFtjZGtMaXN0Ym94VmFsdWVdPVwiX3ZhbHVlIHwgbWFwcGVyIDogX2Nka0xpc3RCb3hWYWx1ZVwiXG5cdFx0XHQoY2RrTGlzdGJveFZhbHVlQ2hhbmdlKT1cIl9saXN0Qm94VmFsdWVDaGFuZ2UoJGV2ZW50KVwiXG5cdFx0XHRbY2RrTGlzdGJveERpc2FibGVkXT1cImRpc2FibGVkXCJcblx0XHRcdFtjZGtMaXN0Ym94Q29tcGFyZVdpdGhdPVwiY29tcGFyZVdpdGhcIlxuXHRcdFx0W2Nka0xpc3Rib3hNdWx0aXBsZV09XCJfaXNNdWx0aXBsZVwiXG5cdFx0PlxuXHRcdFx0PGxpXG5cdFx0XHRcdGNsYXNzPVwiaXVpLWRyb3Bkb3duLXBhbmVsX19vcHRpb25cIlxuXHRcdFx0XHRbaWRdPVwiaW5kZXggfCBtYXBwZXI6IGdldE9wdGlvbklkLmJpbmQodGhpcykgOiBvcHRpb25cIlxuXHRcdFx0XHRbY2xhc3NdPVwiX29wdGlvbkNsYXNzTmFtZShpbmRleClcIlxuXHRcdFx0XHRbbmdTdHlsZV09XCJpbmRleCB8IG1hcHBlcjogZ2V0T3B0aW9uU3R5bGUuYmluZCh0aGlzKSA6IG9wdGlvblwiXG5cdFx0XHRcdFtuZ0NsYXNzXT1cImluZGV4IHwgbWFwcGVyOiBnZXRPcHRpb25DbGFzc05hbWUuYmluZCh0aGlzKSA6IG9wdGlvblwiXG5cdFx0XHRcdFtjZGtPcHRpb25dPVwib3B0aW9uXCJcblx0XHRcdFx0KGNsaWNrKT1cIl9vbk9wdGlvbkNsaWNrKG9wdGlvbilcIlxuXHRcdFx0XHQqbmdGb3I9XCJsZXQgb3B0aW9uIG9mIG9wdGlvbnM7IGxldCBpbmRleCA9IGluZGV4OyB0cmFja0J5OiBnZXRPcHRpb25JZFwiXG5cdFx0XHQ+XG5cdFx0XHRcdHt7IG9wdGlvbiB8IG1hcHBlcjogZ2V0T3B0aW9uTmFtZS5iaW5kKHRoaXMpIH19XG5cdFx0XHQ8L2xpPlxuXHRcdDwvdWw+XG5cblx0XHQ8Zm9vdGVyIGNsYXNzPVwiaXVpLWRyb3Bkb3duLXBhbmVsX19mb290ZXJcIiAqbmdJZj1cImNhbmNlbFNlbGVjdGlvblRleHRcIj5cblx0XHRcdDxidXR0b25cblx0XHRcdFx0aXVpQnV0dG9uXG5cdFx0XHRcdHNpemU9XCJzXCJcblx0XHRcdFx0ZW1waGFzaXM9XCJzZWNvbmRhcnlcIlxuXHRcdFx0XHRjbGFzcz1cIml1aS1kcm9wZG93bi1wYW5lbF9fY2FuY2VsLWJ1dHRvblwiXG5cdFx0XHRcdFthdHRyLmlkXT1cIl9jYW5jZWxCdXR0b25JZFwiXG5cdFx0XHRcdFtkaXNhYmxlZF09XCJfaXNDYW5jZWxCdXR0b25EaXNhYmxlZFwiXG5cdFx0XHRcdChjbGljayk9XCJfaGFuZGxlQ2FuY2VsU2VsZWN0aW9uKCRldmVudClcIlxuXHRcdFx0PlxuXHRcdFx0XHR7eyBjYW5jZWxTZWxlY3Rpb25UZXh0IH19XG5cdFx0XHQ8L2J1dHRvbj5cblx0XHQ8L2Zvb3Rlcj5cblx0PC9kaXY+XG5cdDwvbmctdGVtcGxhdGU+XG48L25nLXRlbXBsYXRlPlxuIl19