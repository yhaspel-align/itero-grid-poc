export const ALIGNED_LEFT_POSITIONS = [
    {
        originX: 'start', // left corner of the trigger
        originY: 'bottom', // bottom corner of the trigger
        overlayX: 'start', // left corner of the overlay to the origin
        overlayY: 'top' // top corner of the overlay to the origin,
    },
    {
        originX: 'start', // left corner of the trigger
        originY: 'top', // top corner of the trigger
        overlayX: 'start', // left corner of the overlay to the origin
        overlayY: 'bottom' // bottom corner of the overlay to the origin
    },
    {
        originX: 'start',
        originY: 'top', // top corner of the trigger
        overlayX: 'start',
        overlayY: 'top'
    },
    {
        originX: 'start',
        originY: 'bottom', // bottom corner of the trigger
        overlayX: 'start',
        overlayY: 'bottom'
    },
    {
        originX: 'start',
        originY: 'center', // center of the origin
        overlayX: 'start',
        overlayY: 'center' // center of the overlay
    }
];
export const ALIGNED_RIGHT_POSITIONS = [
    {
        originX: 'end', // right corner of the trigger
        originY: 'bottom', // bottom corner of the trigger
        overlayX: 'end', // right corner of the overlay to the origin
        overlayY: 'top' // top corner of the overlay to the origin
    },
    {
        originX: 'end', // right corner of the button
        originY: 'top', // top corner of the button
        overlayX: 'end', // right corner of the overlay to the origin
        overlayY: 'bottom' // top corner of the overlay to the origin
    },
    {
        originX: 'end',
        originY: 'top',
        overlayX: 'end',
        overlayY: 'top'
    },
    {
        originX: 'end',
        originY: 'bottom',
        overlayX: 'end',
        overlayY: 'bottom'
    },
    {
        originX: 'end',
        originY: 'center', // center of the origin
        overlayX: 'end',
        overlayY: 'center' // center of the overlay
    }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9zaXRpb25zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvc2VsZWN0L3NyYy9wb3NpdGlvbnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBSUEsTUFBTSxDQUFDLE1BQU0sc0JBQXNCLEdBQXdCO0lBQzFEO1FBQ0MsT0FBTyxFQUFFLE9BQU8sRUFBRSw2QkFBNkI7UUFDL0MsT0FBTyxFQUFFLFFBQVEsRUFBRSwrQkFBK0I7UUFDbEQsUUFBUSxFQUFFLE9BQU8sRUFBRSwyQ0FBMkM7UUFDOUQsUUFBUSxFQUFFLEtBQUssQ0FBQywyQ0FBMkM7S0FDM0Q7SUFDRDtRQUNDLE9BQU8sRUFBRSxPQUFPLEVBQUUsNkJBQTZCO1FBQy9DLE9BQU8sRUFBRSxLQUFLLEVBQUUsNEJBQTRCO1FBQzVDLFFBQVEsRUFBRSxPQUFPLEVBQUUsMkNBQTJDO1FBQzlELFFBQVEsRUFBRSxRQUFRLENBQUMsNkNBQTZDO0tBQ2hFO0lBQ0Q7UUFDQyxPQUFPLEVBQUUsT0FBTztRQUNoQixPQUFPLEVBQUUsS0FBSyxFQUFFLDRCQUE0QjtRQUM1QyxRQUFRLEVBQUUsT0FBTztRQUNqQixRQUFRLEVBQUUsS0FBSztLQUNmO0lBQ0Q7UUFDQyxPQUFPLEVBQUUsT0FBTztRQUNoQixPQUFPLEVBQUUsUUFBUSxFQUFFLCtCQUErQjtRQUNsRCxRQUFRLEVBQUUsT0FBTztRQUNqQixRQUFRLEVBQUUsUUFBUTtLQUNsQjtJQUNEO1FBQ0MsT0FBTyxFQUFFLE9BQU87UUFDaEIsT0FBTyxFQUFFLFFBQVEsRUFBRSx1QkFBdUI7UUFDMUMsUUFBUSxFQUFFLE9BQU87UUFDakIsUUFBUSxFQUFFLFFBQVEsQ0FBQyx3QkFBd0I7S0FDM0M7Q0FDRCxDQUFDO0FBRUYsTUFBTSxDQUFDLE1BQU0sdUJBQXVCLEdBQXdCO0lBQzNEO1FBQ0MsT0FBTyxFQUFFLEtBQUssRUFBRSw4QkFBOEI7UUFDOUMsT0FBTyxFQUFFLFFBQVEsRUFBRSwrQkFBK0I7UUFDbEQsUUFBUSxFQUFFLEtBQUssRUFBRSw0Q0FBNEM7UUFDN0QsUUFBUSxFQUFFLEtBQUssQ0FBQywwQ0FBMEM7S0FDMUQ7SUFDRDtRQUNDLE9BQU8sRUFBRSxLQUFLLEVBQUUsNkJBQTZCO1FBQzdDLE9BQU8sRUFBRSxLQUFLLEVBQUUsMkJBQTJCO1FBQzNDLFFBQVEsRUFBRSxLQUFLLEVBQUUsNENBQTRDO1FBQzdELFFBQVEsRUFBRSxRQUFRLENBQUMsMENBQTBDO0tBQzdEO0lBQ0Q7UUFDQyxPQUFPLEVBQUUsS0FBSztRQUNkLE9BQU8sRUFBRSxLQUFLO1FBQ2QsUUFBUSxFQUFFLEtBQUs7UUFDZixRQUFRLEVBQUUsS0FBSztLQUNmO0lBQ0Q7UUFDQyxPQUFPLEVBQUUsS0FBSztRQUNkLE9BQU8sRUFBRSxRQUFRO1FBQ2pCLFFBQVEsRUFBRSxLQUFLO1FBQ2YsUUFBUSxFQUFFLFFBQVE7S0FDbEI7SUFDRDtRQUNDLE9BQU8sRUFBRSxLQUFLO1FBQ2QsT0FBTyxFQUFFLFFBQVEsRUFBRSx1QkFBdUI7UUFDMUMsUUFBUSxFQUFFLEtBQUs7UUFDZixRQUFRLEVBQUUsUUFBUSxDQUFDLHdCQUF3QjtLQUMzQztDQUNELENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb25uZWN0ZWRQb3NpdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9vdmVybGF5JztcblxuZXhwb3J0IHsgQ29ubmVjdGVkUG9zaXRpb24gfTtcblxuZXhwb3J0IGNvbnN0IEFMSUdORURfTEVGVF9QT1NJVElPTlM6IENvbm5lY3RlZFBvc2l0aW9uW10gPSBbXG5cdHtcblx0XHRvcmlnaW5YOiAnc3RhcnQnLCAvLyBsZWZ0IGNvcm5lciBvZiB0aGUgdHJpZ2dlclxuXHRcdG9yaWdpblk6ICdib3R0b20nLCAvLyBib3R0b20gY29ybmVyIG9mIHRoZSB0cmlnZ2VyXG5cdFx0b3ZlcmxheVg6ICdzdGFydCcsIC8vIGxlZnQgY29ybmVyIG9mIHRoZSBvdmVybGF5IHRvIHRoZSBvcmlnaW5cblx0XHRvdmVybGF5WTogJ3RvcCcgLy8gdG9wIGNvcm5lciBvZiB0aGUgb3ZlcmxheSB0byB0aGUgb3JpZ2luLFxuXHR9LFxuXHR7XG5cdFx0b3JpZ2luWDogJ3N0YXJ0JywgLy8gbGVmdCBjb3JuZXIgb2YgdGhlIHRyaWdnZXJcblx0XHRvcmlnaW5ZOiAndG9wJywgLy8gdG9wIGNvcm5lciBvZiB0aGUgdHJpZ2dlclxuXHRcdG92ZXJsYXlYOiAnc3RhcnQnLCAvLyBsZWZ0IGNvcm5lciBvZiB0aGUgb3ZlcmxheSB0byB0aGUgb3JpZ2luXG5cdFx0b3ZlcmxheVk6ICdib3R0b20nIC8vIGJvdHRvbSBjb3JuZXIgb2YgdGhlIG92ZXJsYXkgdG8gdGhlIG9yaWdpblxuXHR9LFxuXHR7XG5cdFx0b3JpZ2luWDogJ3N0YXJ0Jyxcblx0XHRvcmlnaW5ZOiAndG9wJywgLy8gdG9wIGNvcm5lciBvZiB0aGUgdHJpZ2dlclxuXHRcdG92ZXJsYXlYOiAnc3RhcnQnLFxuXHRcdG92ZXJsYXlZOiAndG9wJ1xuXHR9LFxuXHR7XG5cdFx0b3JpZ2luWDogJ3N0YXJ0Jyxcblx0XHRvcmlnaW5ZOiAnYm90dG9tJywgLy8gYm90dG9tIGNvcm5lciBvZiB0aGUgdHJpZ2dlclxuXHRcdG92ZXJsYXlYOiAnc3RhcnQnLFxuXHRcdG92ZXJsYXlZOiAnYm90dG9tJ1xuXHR9LFxuXHR7XG5cdFx0b3JpZ2luWDogJ3N0YXJ0Jyxcblx0XHRvcmlnaW5ZOiAnY2VudGVyJywgLy8gY2VudGVyIG9mIHRoZSBvcmlnaW5cblx0XHRvdmVybGF5WDogJ3N0YXJ0Jyxcblx0XHRvdmVybGF5WTogJ2NlbnRlcicgLy8gY2VudGVyIG9mIHRoZSBvdmVybGF5XG5cdH1cbl07XG5cbmV4cG9ydCBjb25zdCBBTElHTkVEX1JJR0hUX1BPU0lUSU9OUzogQ29ubmVjdGVkUG9zaXRpb25bXSA9IFtcblx0e1xuXHRcdG9yaWdpblg6ICdlbmQnLCAvLyByaWdodCBjb3JuZXIgb2YgdGhlIHRyaWdnZXJcblx0XHRvcmlnaW5ZOiAnYm90dG9tJywgLy8gYm90dG9tIGNvcm5lciBvZiB0aGUgdHJpZ2dlclxuXHRcdG92ZXJsYXlYOiAnZW5kJywgLy8gcmlnaHQgY29ybmVyIG9mIHRoZSBvdmVybGF5IHRvIHRoZSBvcmlnaW5cblx0XHRvdmVybGF5WTogJ3RvcCcgLy8gdG9wIGNvcm5lciBvZiB0aGUgb3ZlcmxheSB0byB0aGUgb3JpZ2luXG5cdH0sXG5cdHtcblx0XHRvcmlnaW5YOiAnZW5kJywgLy8gcmlnaHQgY29ybmVyIG9mIHRoZSBidXR0b25cblx0XHRvcmlnaW5ZOiAndG9wJywgLy8gdG9wIGNvcm5lciBvZiB0aGUgYnV0dG9uXG5cdFx0b3ZlcmxheVg6ICdlbmQnLCAvLyByaWdodCBjb3JuZXIgb2YgdGhlIG92ZXJsYXkgdG8gdGhlIG9yaWdpblxuXHRcdG92ZXJsYXlZOiAnYm90dG9tJyAvLyB0b3AgY29ybmVyIG9mIHRoZSBvdmVybGF5IHRvIHRoZSBvcmlnaW5cblx0fSxcblx0e1xuXHRcdG9yaWdpblg6ICdlbmQnLFxuXHRcdG9yaWdpblk6ICd0b3AnLFxuXHRcdG92ZXJsYXlYOiAnZW5kJyxcblx0XHRvdmVybGF5WTogJ3RvcCdcblx0fSxcblx0e1xuXHRcdG9yaWdpblg6ICdlbmQnLFxuXHRcdG9yaWdpblk6ICdib3R0b20nLFxuXHRcdG92ZXJsYXlYOiAnZW5kJyxcblx0XHRvdmVybGF5WTogJ2JvdHRvbSdcblx0fSxcblx0e1xuXHRcdG9yaWdpblg6ICdlbmQnLFxuXHRcdG9yaWdpblk6ICdjZW50ZXInLCAvLyBjZW50ZXIgb2YgdGhlIG9yaWdpblxuXHRcdG92ZXJsYXlYOiAnZW5kJyxcblx0XHRvdmVybGF5WTogJ2NlbnRlcicgLy8gY2VudGVyIG9mIHRoZSBvdmVybGF5XG5cdH1cbl07XG4iXX0=