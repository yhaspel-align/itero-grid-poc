import { Injectable, InjectionToken } from '@angular/core';
import { Dialog, DialogConfig, DialogRef } from '@angular/cdk/dialog';
import { Overlay } from '@angular/cdk/overlay';
import { IuiModalContainerComponent } from './modal-container/iui-modal-container.component';
import * as i0 from "@angular/core";
import * as i1 from "@angular/cdk/dialog";
import * as i2 from "@angular/cdk/overlay";
export const IUI_MODAL_WINDOW_DATA = new InjectionToken('IUI_MODAL_WINDOW_DATA');
export class IuiModalWindowRef extends DialogRef {
    constructor(overlayRef, config) {
        super(overlayRef, config);
    }
}
// Counter for unique dialog ids.
let uniqueId = 0;
export class IuiModalWindowService {
    constructor(dialog, _overlay) {
        this.dialog = dialog;
        this._overlay = _overlay;
        this.afterAllClosed = this.dialog.afterAllClosed;
        this._defaultOptions = {
            backdropClass: 'iui-modal__backdrop',
            panelClass: 'iui-modal__overlay-panel'
        };
        this._idPrefix = 'iui-modal-window-';
        this._sizePanelClassMap = {
            sm: 'iui-modal_size_sm',
            md: 'iui-modal_size_md',
            lg: 'iui-modal_size_lg',
            xl: 'iui-modal_size_xl'
        };
    }
    open(componentOrTemplateRef, customConfig) {
        const sizePanelClass = this._resolveSizePanelClass(customConfig);
        const panelClass = this._definePanelClasses(this._defaultOptions.panelClass, customConfig?.panelClass, sizePanelClass);
        const config = { ...this._defaultOptions, ...(customConfig || {}), panelClass };
        config.id = config.id || `${this._idPrefix}${uniqueId++}`;
        config.scrollStrategy = config.scrollStrategy || this._overlay.scrollStrategies.block();
        const closeConfig = {
            // Disable closing since we need to sync it up to the animation ourselves.
            disableClose: true,
            // Disable closing on destroy, because this service cleans up its open dialogs as well.
            // We want to do the cleanup here, rather than the CDK service, because the CDK destroys
            // the dialogs immediately whereas we want it to wait for the animations to finish.
            closeOnDestroy: false,
            // Disable closing on detachments so that we can sync up the animation.
            // The Material dialog ref handles this manually.
            closeOnOverlayDetachments: false
        };
        const dialogRef = this.dialog.open(componentOrTemplateRef, ({
            ...config,
            positionStrategy: this._overlay.position().global().centerHorizontally().centerVertically(),
            //TODO: enable when we start handling close animation
            // ...closeConfig,
            container: {
                type: IuiModalContainerComponent,
                providers: () => [
                    // Provide our config as the CDK config as well since it has the same interface as the
                    // CDK one, but it contains the actual values passed in by the user for things like
                    // `disableClose` which we disable for the CDK dialog since we handle it ourselves.
                    //{ provide: this.dialogConfigClass, useValue: config },
                    { provide: DialogConfig, useValue: config }
                ]
            },
            templateContext: () => ({ dialogRef }),
            providers: (ref, cdkConfig, dialogContainer) => {
                // dialogRef = new this._dialogRefConstructor(ref, config, dialogContainer);
                // dialogRef.updatePosition(config?.position);
                return [
                    { provide: IuiModalContainerComponent, useValue: dialogContainer },
                    { provide: IUI_MODAL_WINDOW_DATA, useValue: cdkConfig.data },
                    { provide: DialogRef, useValue: ref },
                    { provide: IuiModalWindowRef, useValue: ref }
                ];
            }
        }));
        return dialogRef;
    }
    /**
     * Closes all the currently-open dialogs.
     */
    closeAll() {
        this.dialog.closeAll();
    }
    /**
     * Finds an open dialog by its id.
     * @param id ID to use when looking up the dialog.
     */
    getDialogById(id) {
        return this.dialog.getDialogById(id);
    }
    get openDialogs() {
        return this.dialog.openDialogs;
    }
    get afterOpened() {
        return this.dialog.afterOpened;
    }
    /**
     * Call onDestroy method in yours microfrontend's app.component to remove pendiing subscriptions and opened dialogs
     * Otherwise it wont be destroyed because of microfrontend architecture
     * */
    ngOnDestroy() {
        this.dialog.ngOnDestroy();
    }
    /**
     * Returns the size panel class if applicable.
     * If an explicit width is set, no size class is applied (backwards compat).
     * If no size and no explicit width, defaults to 'md'.
     */
    _resolveSizePanelClass(config) {
        if (config?.width) {
            return null;
        }
        const size = config?.size ?? 'md';
        return this._sizePanelClassMap[size];
    }
    _definePanelClasses(defaultPanelClass, additionalClasses, sizeClass) {
        const classes = [defaultPanelClass];
        if (sizeClass) {
            classes.push(sizeClass);
        }
        if (Array.isArray(additionalClasses) && additionalClasses.length > 0) {
            classes.push(...additionalClasses);
        }
        else if (typeof additionalClasses === 'string' && additionalClasses.length > 0) {
            classes.push(additionalClasses);
        }
        return classes.length === 1 ? classes[0] : classes;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalWindowService, deps: [{ token: i1.Dialog }, { token: i2.Overlay }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalWindowService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalWindowService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.Dialog }, { type: i2.Overlay }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLW1vZGFsLXdpbmRvdy5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvbW9kYWwtd2luZG93L3NyYy9pdWktbW9kYWwtd2luZG93LnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxjQUFjLEVBQTBCLE1BQU0sZUFBZSxDQUFDO0FBQ25GLE9BQU8sRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQ3RFLE9BQU8sRUFBaUIsT0FBTyxFQUFjLE1BQU0sc0JBQXNCLENBQUM7QUFDMUUsT0FBTyxFQUFFLDBCQUEwQixFQUFFLE1BQU0saURBQWlELENBQUM7Ozs7QUFHN0YsTUFBTSxDQUFDLE1BQU0scUJBQXFCLEdBQUcsSUFBSSxjQUFjLENBQUMsdUJBQXVCLENBQUMsQ0FBQztBQVNqRixNQUFNLE9BQU8saUJBQTRDLFNBQVEsU0FBZTtJQUMvRSxZQUFZLFVBQXNCLEVBQUUsTUFBb0U7UUFDdkcsS0FBSyxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUMzQixDQUFDO0NBQ0Q7QUFFRCxpQ0FBaUM7QUFDakMsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDO0FBR2pCLE1BQU0sT0FBTyxxQkFBcUI7SUFDakMsWUFDUyxNQUFjLEVBQ2QsUUFBaUI7UUFEakIsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQUNkLGFBQVEsR0FBUixRQUFRLENBQVM7UUFHakIsbUJBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQztRQUU3QyxvQkFBZSxHQUFpQjtZQUN2QyxhQUFhLEVBQUUscUJBQXFCO1lBQ3BDLFVBQVUsRUFBRSwwQkFBMEI7U0FDdEMsQ0FBQztRQUVRLGNBQVMsR0FBRyxtQkFBbUIsQ0FBQztRQUVsQyx1QkFBa0IsR0FBaUM7WUFDMUQsRUFBRSxFQUFFLG1CQUFtQjtZQUN2QixFQUFFLEVBQUUsbUJBQW1CO1lBQ3ZCLEVBQUUsRUFBRSxtQkFBbUI7WUFDdkIsRUFBRSxFQUFFLG1CQUFtQjtTQUN2QixDQUFDO0lBaEJDLENBQUM7SUFvQ0osSUFBSSxDQUF3QyxzQkFBeUQsRUFBRSxZQUFzQztRQUM1SSxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDakUsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsVUFBb0IsRUFBRSxZQUFZLEVBQUUsVUFBVSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQ2pJLE1BQU0sTUFBTSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLEdBQUcsQ0FBQyxZQUFZLElBQUksRUFBRSxDQUFDLEVBQUUsVUFBVSxFQUFFLENBQUM7UUFFaEYsTUFBTSxDQUFDLEVBQUUsR0FBRyxNQUFNLENBQUMsRUFBRSxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLEVBQUUsRUFBRSxDQUFDO1FBQzFELE1BQU0sQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLGNBQWMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEtBQUssRUFBRSxDQUFDO1FBRXhGLE1BQU0sV0FBVyxHQUEwQjtZQUMxQywwRUFBMEU7WUFDMUUsWUFBWSxFQUFFLElBQUk7WUFDbEIsdUZBQXVGO1lBQ3ZGLHdGQUF3RjtZQUN4RixtRkFBbUY7WUFDbkYsY0FBYyxFQUFFLEtBQUs7WUFDckIsdUVBQXVFO1lBQ3ZFLGlEQUFpRDtZQUNqRCx5QkFBeUIsRUFBRSxLQUFLO1NBQ2hDLENBQUM7UUFFRixNQUFNLFNBQVMsR0FBb0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQVUsc0JBQXNCLEVBQUUsQ0FBQztZQUNyRixHQUFHLE1BQU07WUFDVCxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLGtCQUFrQixFQUFFLENBQUMsZ0JBQWdCLEVBQUU7WUFDM0YscURBQXFEO1lBQ3JELGtCQUFrQjtZQUNsQixTQUFTLEVBQUU7Z0JBQ1YsSUFBSSxFQUFFLDBCQUEwQjtnQkFDaEMsU0FBUyxFQUFFLEdBQUcsRUFBRSxDQUFDO29CQUNoQixzRkFBc0Y7b0JBQ3RGLG1GQUFtRjtvQkFDbkYsbUZBQW1GO29CQUNuRix3REFBd0Q7b0JBQ3hELEVBQUUsT0FBTyxFQUFFLFlBQVksRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFO2lCQUMzQzthQUNEO1lBQ0QsZUFBZSxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQztZQUN0QyxTQUFTLEVBQUUsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFLGVBQWUsRUFBRSxFQUFFO2dCQUM5Qyw0RUFBNEU7Z0JBQzVFLDhDQUE4QztnQkFFOUMsT0FBTztvQkFDTixFQUFFLE9BQU8sRUFBRSwwQkFBMEIsRUFBRSxRQUFRLEVBQUUsZUFBZSxFQUFFO29CQUNsRSxFQUFFLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLElBQUksRUFBRTtvQkFDNUQsRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxHQUFHLEVBQUU7b0JBQ3JDLEVBQUUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLFFBQVEsRUFBRSxHQUFHLEVBQUU7aUJBQzdDLENBQUM7WUFDSCxDQUFDO1NBQ0QsQ0FBdUQsQ0FBQyxDQUFDO1FBRTFELE9BQU8sU0FBUyxDQUFDO0lBQ2xCLENBQUM7SUFFRDs7T0FFRztJQUNILFFBQVE7UUFDUCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3hCLENBQUM7SUFFRDs7O09BR0c7SUFDSCxhQUFhLENBQU8sRUFBVTtRQUM3QixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRCxJQUFJLFdBQVc7UUFDZCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO0lBQ2hDLENBQUM7SUFFRCxJQUFJLFdBQVc7UUFDZCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO0lBQ2hDLENBQUM7SUFDRDs7O1NBR0s7SUFDTCxXQUFXO1FBQ1YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLHNCQUFzQixDQUFDLE1BQTZDO1FBQzNFLElBQUksTUFBTSxFQUFFLEtBQUssRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDO1FBQ2IsQ0FBQztRQUNELE1BQU0sSUFBSSxHQUFpQixNQUFNLEVBQUUsSUFBSSxJQUFJLElBQUksQ0FBQztRQUNoRCxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRU8sbUJBQW1CLENBQUMsaUJBQXlCLEVBQUUsaUJBQWdELEVBQUUsU0FBd0I7UUFDaEksTUFBTSxPQUFPLEdBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBRTlDLElBQUksU0FBUyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3pCLENBQUM7UUFFRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsSUFBSSxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDdEUsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLGlCQUFpQixDQUFDLENBQUM7UUFDcEMsQ0FBQzthQUFNLElBQUksT0FBTyxpQkFBaUIsS0FBSyxRQUFRLElBQUksaUJBQWlCLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQ2xGLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUNqQyxDQUFDO1FBRUQsT0FBTyxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7SUFDcEQsQ0FBQzsrR0FySlcscUJBQXFCO21IQUFyQixxQkFBcUI7OzRGQUFyQixxQkFBcUI7a0JBRGpDLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlLCBJbmplY3Rpb25Ub2tlbiwgT25EZXN0cm95LCBUZW1wbGF0ZVJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRGlhbG9nLCBEaWFsb2dDb25maWcsIERpYWxvZ1JlZiB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9kaWFsb2cnO1xuaW1wb3J0IHsgQ29tcG9uZW50VHlwZSwgT3ZlcmxheSwgT3ZlcmxheVJlZiB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9vdmVybGF5JztcbmltcG9ydCB7IEl1aU1vZGFsQ29udGFpbmVyQ29tcG9uZW50IH0gZnJvbSAnLi9tb2RhbC1jb250YWluZXIvaXVpLW1vZGFsLWNvbnRhaW5lci5jb21wb25lbnQnO1xuaW1wb3J0IHsgQmFzZVBvcnRhbE91dGxldCB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9wb3J0YWwnO1xuXG5leHBvcnQgY29uc3QgSVVJX01PREFMX1dJTkRPV19EQVRBID0gbmV3IEluamVjdGlvblRva2VuKCdJVUlfTU9EQUxfV0lORE9XX0RBVEEnKTtcblxuZXhwb3J0IHR5cGUgSXVpTW9kYWxTaXplID0gJ3NtJyB8ICdtZCcgfCAnbGcnIHwgJ3hsJztcblxuZXhwb3J0IGludGVyZmFjZSBJdWlNb2RhbFdpbmRvd0NvbmZpZzxEID0gdW5rbm93bj4gZXh0ZW5kcyBEaWFsb2dDb25maWc8RD4ge1xuXHQvKiogTW9kYWwgd2lkdGggcHJlc2V0LiBEZWZhdWx0OiAnbWQnICg2NTZweCkuICovXG5cdHNpemU/OiBJdWlNb2RhbFNpemU7XG59XG5cbmV4cG9ydCBjbGFzcyBJdWlNb2RhbFdpbmRvd1JlZjxSID0gdW5rbm93biwgQyA9IHVua25vd24+IGV4dGVuZHMgRGlhbG9nUmVmPFIsIEM+IHtcblx0Y29uc3RydWN0b3Iob3ZlcmxheVJlZjogT3ZlcmxheVJlZiwgY29uZmlnOiBEaWFsb2dDb25maWc8YW55LCBJdWlNb2RhbFdpbmRvd1JlZjxSLCBDPiwgQmFzZVBvcnRhbE91dGxldD4pIHtcblx0XHRzdXBlcihvdmVybGF5UmVmLCBjb25maWcpO1xuXHR9XG59XG5cbi8vIENvdW50ZXIgZm9yIHVuaXF1ZSBkaWFsb2cgaWRzLlxubGV0IHVuaXF1ZUlkID0gMDtcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIEl1aU1vZGFsV2luZG93U2VydmljZSBpbXBsZW1lbnRzIE9uRGVzdHJveSB7XG5cdGNvbnN0cnVjdG9yKFxuXHRcdHByaXZhdGUgZGlhbG9nOiBEaWFsb2csXG5cdFx0cHJpdmF0ZSBfb3ZlcmxheTogT3ZlcmxheVxuXHQpIHt9XG5cblx0cmVhZG9ubHkgYWZ0ZXJBbGxDbG9zZWQgPSB0aGlzLmRpYWxvZy5hZnRlckFsbENsb3NlZDtcblxuXHRwcml2YXRlIF9kZWZhdWx0T3B0aW9uczogRGlhbG9nQ29uZmlnID0ge1xuXHRcdGJhY2tkcm9wQ2xhc3M6ICdpdWktbW9kYWxfX2JhY2tkcm9wJyxcblx0XHRwYW5lbENsYXNzOiAnaXVpLW1vZGFsX19vdmVybGF5LXBhbmVsJ1xuXHR9O1xuXG5cdHByb3RlY3RlZCBfaWRQcmVmaXggPSAnaXVpLW1vZGFsLXdpbmRvdy0nO1xuXG5cdHByaXZhdGUgX3NpemVQYW5lbENsYXNzTWFwOiBSZWNvcmQ8SXVpTW9kYWxTaXplLCBzdHJpbmc+ID0ge1xuXHRcdHNtOiAnaXVpLW1vZGFsX3NpemVfc20nLFxuXHRcdG1kOiAnaXVpLW1vZGFsX3NpemVfbWQnLFxuXHRcdGxnOiAnaXVpLW1vZGFsX3NpemVfbGcnLFxuXHRcdHhsOiAnaXVpLW1vZGFsX3NpemVfeGwnXG5cdH07XG5cblx0LyoqXG5cdCAqIE9wZW5zIGEgbW9kYWwgZGlhbG9nIGNvbnRhaW5pbmcgdGhlIGdpdmVuIGNvbXBvbmVudC5cblx0ICogQHBhcmFtIGNvbXBvbmVudCBUeXBlIG9mIHRoZSBjb21wb25lbnQgdG8gbG9hZCBpbnRvIHRoZSBkaWFsb2cuXG5cdCAqIEBwYXJhbSBjb25maWcgRXh0cmEgY29uZmlndXJhdGlvbiBvcHRpb25zLlxuXHQgKiBAcmV0dXJucyBSZWZlcmVuY2UgdG8gdGhlIG5ld2x5LW9wZW5lZCBkaWFsb2cuXG5cdCAqL1xuXHRvcGVuPFIgPSB1bmtub3duLCBEID0gdW5rbm93biwgQyA9IHVua25vd24+KGNvbXBvbmVudDogQ29tcG9uZW50VHlwZTxDPiwgY29uZmlnPzogSXVpTW9kYWxXaW5kb3dDb25maWc8RD4pOiBEaWFsb2dSZWY8UiwgQz47XG5cblx0LyoqXG5cdCAqIE9wZW5zIGEgbW9kYWwgZGlhbG9nIGNvbnRhaW5pbmcgdGhlIGdpdmVuIHRlbXBsYXRlLlxuXHQgKiBAcGFyYW0gdGVtcGxhdGUgVGVtcGxhdGVSZWYgdG8gaW5zdGFudGlhdGUgYXMgdGhlIGRpYWxvZyBjb250ZW50LlxuXHQgKiBAcGFyYW0gY29uZmlnIEV4dHJhIGNvbmZpZ3VyYXRpb24gb3B0aW9ucy5cblx0ICogQHJldHVybnMgUmVmZXJlbmNlIHRvIHRoZSBuZXdseS1vcGVuZWQgZGlhbG9nLlxuXHQgKi9cblx0b3BlbjxSID0gdW5rbm93biwgRCA9IHVua25vd24sIEMgPSB1bmtub3duPih0ZW1wbGF0ZTogVGVtcGxhdGVSZWY8Qz4sIGNvbmZpZz86IEl1aU1vZGFsV2luZG93Q29uZmlnPEQ+KTogRGlhbG9nUmVmPFIsIEM+O1xuXG5cdG9wZW48UiA9IHVua25vd24sIEQgPSB1bmtub3duLCBDID0gdW5rbm93bj4oY29tcG9uZW50T3JUZW1wbGF0ZVJlZjogQ29tcG9uZW50VHlwZTxDPiB8IFRlbXBsYXRlUmVmPEM+LCBjb25maWc/OiBJdWlNb2RhbFdpbmRvd0NvbmZpZzxEPik6IERpYWxvZ1JlZjxSLCBDPjtcblxuXHRvcGVuPFIgPSB1bmtub3duLCBEID0gdW5rbm93biwgQyA9IHVua25vd24+KGNvbXBvbmVudE9yVGVtcGxhdGVSZWY6IENvbXBvbmVudFR5cGU8Qz4gfCBUZW1wbGF0ZVJlZjxDPiwgY3VzdG9tQ29uZmlnPzogSXVpTW9kYWxXaW5kb3dDb25maWc8RD4pOiBEaWFsb2dSZWY8UiwgQz4ge1xuXHRcdGNvbnN0IHNpemVQYW5lbENsYXNzID0gdGhpcy5fcmVzb2x2ZVNpemVQYW5lbENsYXNzKGN1c3RvbUNvbmZpZyk7XG5cdFx0Y29uc3QgcGFuZWxDbGFzcyA9IHRoaXMuX2RlZmluZVBhbmVsQ2xhc3Nlcyh0aGlzLl9kZWZhdWx0T3B0aW9ucy5wYW5lbENsYXNzIGFzIHN0cmluZywgY3VzdG9tQ29uZmlnPy5wYW5lbENsYXNzLCBzaXplUGFuZWxDbGFzcyk7XG5cdFx0Y29uc3QgY29uZmlnID0geyAuLi50aGlzLl9kZWZhdWx0T3B0aW9ucywgLi4uKGN1c3RvbUNvbmZpZyB8fCB7fSksIHBhbmVsQ2xhc3MgfTtcblxuXHRcdGNvbmZpZy5pZCA9IGNvbmZpZy5pZCB8fCBgJHt0aGlzLl9pZFByZWZpeH0ke3VuaXF1ZUlkKyt9YDtcblx0XHRjb25maWcuc2Nyb2xsU3RyYXRlZ3kgPSBjb25maWcuc2Nyb2xsU3RyYXRlZ3kgfHwgdGhpcy5fb3ZlcmxheS5zY3JvbGxTdHJhdGVnaWVzLmJsb2NrKCk7XG5cblx0XHRjb25zdCBjbG9zZUNvbmZpZzogUGFydGlhbDxEaWFsb2dDb25maWc+ID0ge1xuXHRcdFx0Ly8gRGlzYWJsZSBjbG9zaW5nIHNpbmNlIHdlIG5lZWQgdG8gc3luYyBpdCB1cCB0byB0aGUgYW5pbWF0aW9uIG91cnNlbHZlcy5cblx0XHRcdGRpc2FibGVDbG9zZTogdHJ1ZSxcblx0XHRcdC8vIERpc2FibGUgY2xvc2luZyBvbiBkZXN0cm95LCBiZWNhdXNlIHRoaXMgc2VydmljZSBjbGVhbnMgdXAgaXRzIG9wZW4gZGlhbG9ncyBhcyB3ZWxsLlxuXHRcdFx0Ly8gV2Ugd2FudCB0byBkbyB0aGUgY2xlYW51cCBoZXJlLCByYXRoZXIgdGhhbiB0aGUgQ0RLIHNlcnZpY2UsIGJlY2F1c2UgdGhlIENESyBkZXN0cm95c1xuXHRcdFx0Ly8gdGhlIGRpYWxvZ3MgaW1tZWRpYXRlbHkgd2hlcmVhcyB3ZSB3YW50IGl0IHRvIHdhaXQgZm9yIHRoZSBhbmltYXRpb25zIHRvIGZpbmlzaC5cblx0XHRcdGNsb3NlT25EZXN0cm95OiBmYWxzZSxcblx0XHRcdC8vIERpc2FibGUgY2xvc2luZyBvbiBkZXRhY2htZW50cyBzbyB0aGF0IHdlIGNhbiBzeW5jIHVwIHRoZSBhbmltYXRpb24uXG5cdFx0XHQvLyBUaGUgTWF0ZXJpYWwgZGlhbG9nIHJlZiBoYW5kbGVzIHRoaXMgbWFudWFsbHkuXG5cdFx0XHRjbG9zZU9uT3ZlcmxheURldGFjaG1lbnRzOiBmYWxzZVxuXHRcdH07XG5cblx0XHRjb25zdCBkaWFsb2dSZWY6IERpYWxvZ1JlZjxSLCBDPiA9IHRoaXMuZGlhbG9nLm9wZW48UiwgRCwgQz4oY29tcG9uZW50T3JUZW1wbGF0ZVJlZiwgKHtcblx0XHRcdC4uLmNvbmZpZyxcblx0XHRcdHBvc2l0aW9uU3RyYXRlZ3k6IHRoaXMuX292ZXJsYXkucG9zaXRpb24oKS5nbG9iYWwoKS5jZW50ZXJIb3Jpem9udGFsbHkoKS5jZW50ZXJWZXJ0aWNhbGx5KCksXG5cdFx0XHQvL1RPRE86IGVuYWJsZSB3aGVuIHdlIHN0YXJ0IGhhbmRsaW5nIGNsb3NlIGFuaW1hdGlvblxuXHRcdFx0Ly8gLi4uY2xvc2VDb25maWcsXG5cdFx0XHRjb250YWluZXI6IHtcblx0XHRcdFx0dHlwZTogSXVpTW9kYWxDb250YWluZXJDb21wb25lbnQsXG5cdFx0XHRcdHByb3ZpZGVyczogKCkgPT4gW1xuXHRcdFx0XHRcdC8vIFByb3ZpZGUgb3VyIGNvbmZpZyBhcyB0aGUgQ0RLIGNvbmZpZyBhcyB3ZWxsIHNpbmNlIGl0IGhhcyB0aGUgc2FtZSBpbnRlcmZhY2UgYXMgdGhlXG5cdFx0XHRcdFx0Ly8gQ0RLIG9uZSwgYnV0IGl0IGNvbnRhaW5zIHRoZSBhY3R1YWwgdmFsdWVzIHBhc3NlZCBpbiBieSB0aGUgdXNlciBmb3IgdGhpbmdzIGxpa2Vcblx0XHRcdFx0XHQvLyBgZGlzYWJsZUNsb3NlYCB3aGljaCB3ZSBkaXNhYmxlIGZvciB0aGUgQ0RLIGRpYWxvZyBzaW5jZSB3ZSBoYW5kbGUgaXQgb3Vyc2VsdmVzLlxuXHRcdFx0XHRcdC8veyBwcm92aWRlOiB0aGlzLmRpYWxvZ0NvbmZpZ0NsYXNzLCB1c2VWYWx1ZTogY29uZmlnIH0sXG5cdFx0XHRcdFx0eyBwcm92aWRlOiBEaWFsb2dDb25maWcsIHVzZVZhbHVlOiBjb25maWcgfVxuXHRcdFx0XHRdXG5cdFx0XHR9LFxuXHRcdFx0dGVtcGxhdGVDb250ZXh0OiAoKSA9PiAoeyBkaWFsb2dSZWYgfSksXG5cdFx0XHRwcm92aWRlcnM6IChyZWYsIGNka0NvbmZpZywgZGlhbG9nQ29udGFpbmVyKSA9PiB7XG5cdFx0XHRcdC8vIGRpYWxvZ1JlZiA9IG5ldyB0aGlzLl9kaWFsb2dSZWZDb25zdHJ1Y3RvcihyZWYsIGNvbmZpZywgZGlhbG9nQ29udGFpbmVyKTtcblx0XHRcdFx0Ly8gZGlhbG9nUmVmLnVwZGF0ZVBvc2l0aW9uKGNvbmZpZz8ucG9zaXRpb24pO1xuXG5cdFx0XHRcdHJldHVybiBbXG5cdFx0XHRcdFx0eyBwcm92aWRlOiBJdWlNb2RhbENvbnRhaW5lckNvbXBvbmVudCwgdXNlVmFsdWU6IGRpYWxvZ0NvbnRhaW5lciB9LFxuXHRcdFx0XHRcdHsgcHJvdmlkZTogSVVJX01PREFMX1dJTkRPV19EQVRBLCB1c2VWYWx1ZTogY2RrQ29uZmlnLmRhdGEgfSxcblx0XHRcdFx0XHR7IHByb3ZpZGU6IERpYWxvZ1JlZiwgdXNlVmFsdWU6IHJlZiB9LFxuXHRcdFx0XHRcdHsgcHJvdmlkZTogSXVpTW9kYWxXaW5kb3dSZWYsIHVzZVZhbHVlOiByZWYgfVxuXHRcdFx0XHRdO1xuXHRcdFx0fVxuXHRcdH0pIGFzIERpYWxvZ0NvbmZpZzxELCBEaWFsb2dSZWY8UiwgQz4sIEJhc2VQb3J0YWxPdXRsZXQ+KTtcblxuXHRcdHJldHVybiBkaWFsb2dSZWY7XG5cdH1cblxuXHQvKipcblx0ICogQ2xvc2VzIGFsbCB0aGUgY3VycmVudGx5LW9wZW4gZGlhbG9ncy5cblx0ICovXG5cdGNsb3NlQWxsKCk6IHZvaWQge1xuXHRcdHRoaXMuZGlhbG9nLmNsb3NlQWxsKCk7XG5cdH1cblxuXHQvKipcblx0ICogRmluZHMgYW4gb3BlbiBkaWFsb2cgYnkgaXRzIGlkLlxuXHQgKiBAcGFyYW0gaWQgSUQgdG8gdXNlIHdoZW4gbG9va2luZyB1cCB0aGUgZGlhbG9nLlxuXHQgKi9cblx0Z2V0RGlhbG9nQnlJZDxSLCBDPihpZDogc3RyaW5nKTogRGlhbG9nUmVmPFIsIEM+IHwgdW5kZWZpbmVkIHtcblx0XHRyZXR1cm4gdGhpcy5kaWFsb2cuZ2V0RGlhbG9nQnlJZChpZCk7XG5cdH1cblxuXHRnZXQgb3BlbkRpYWxvZ3MoKSB7XG5cdFx0cmV0dXJuIHRoaXMuZGlhbG9nLm9wZW5EaWFsb2dzO1xuXHR9XG5cblx0Z2V0IGFmdGVyT3BlbmVkKCkge1xuXHRcdHJldHVybiB0aGlzLmRpYWxvZy5hZnRlck9wZW5lZDtcblx0fVxuXHQvKipcblx0ICogQ2FsbCBvbkRlc3Ryb3kgbWV0aG9kIGluIHlvdXJzIG1pY3JvZnJvbnRlbmQncyBhcHAuY29tcG9uZW50IHRvIHJlbW92ZSBwZW5kaWluZyBzdWJzY3JpcHRpb25zIGFuZCBvcGVuZWQgZGlhbG9nc1xuXHQgKiBPdGhlcndpc2UgaXQgd29udCBiZSBkZXN0cm95ZWQgYmVjYXVzZSBvZiBtaWNyb2Zyb250ZW5kIGFyY2hpdGVjdHVyZVxuXHQgKiAqL1xuXHRuZ09uRGVzdHJveSgpIHtcblx0XHR0aGlzLmRpYWxvZy5uZ09uRGVzdHJveSgpO1xuXHR9XG5cblx0LyoqXG5cdCAqIFJldHVybnMgdGhlIHNpemUgcGFuZWwgY2xhc3MgaWYgYXBwbGljYWJsZS5cblx0ICogSWYgYW4gZXhwbGljaXQgd2lkdGggaXMgc2V0LCBubyBzaXplIGNsYXNzIGlzIGFwcGxpZWQgKGJhY2t3YXJkcyBjb21wYXQpLlxuXHQgKiBJZiBubyBzaXplIGFuZCBubyBleHBsaWNpdCB3aWR0aCwgZGVmYXVsdHMgdG8gJ21kJy5cblx0ICovXG5cdHByaXZhdGUgX3Jlc29sdmVTaXplUGFuZWxDbGFzcyhjb25maWc6IEl1aU1vZGFsV2luZG93Q29uZmlnPGFueT4gfCB1bmRlZmluZWQpOiBzdHJpbmcgfCBudWxsIHtcblx0XHRpZiAoY29uZmlnPy53aWR0aCkge1xuXHRcdFx0cmV0dXJuIG51bGw7XG5cdFx0fVxuXHRcdGNvbnN0IHNpemU6IEl1aU1vZGFsU2l6ZSA9IGNvbmZpZz8uc2l6ZSA/PyAnbWQnO1xuXHRcdHJldHVybiB0aGlzLl9zaXplUGFuZWxDbGFzc01hcFtzaXplXTtcblx0fVxuXG5cdHByaXZhdGUgX2RlZmluZVBhbmVsQ2xhc3NlcyhkZWZhdWx0UGFuZWxDbGFzczogc3RyaW5nLCBhZGRpdGlvbmFsQ2xhc3Nlczogc3RyaW5nIHwgc3RyaW5nW10gfCB1bmRlZmluZWQsIHNpemVDbGFzczogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IHN0cmluZ1tdIHtcblx0XHRjb25zdCBjbGFzc2VzOiBzdHJpbmdbXSA9IFtkZWZhdWx0UGFuZWxDbGFzc107XG5cblx0XHRpZiAoc2l6ZUNsYXNzKSB7XG5cdFx0XHRjbGFzc2VzLnB1c2goc2l6ZUNsYXNzKTtcblx0XHR9XG5cblx0XHRpZiAoQXJyYXkuaXNBcnJheShhZGRpdGlvbmFsQ2xhc3NlcykgJiYgYWRkaXRpb25hbENsYXNzZXMubGVuZ3RoID4gMCkge1xuXHRcdFx0Y2xhc3Nlcy5wdXNoKC4uLmFkZGl0aW9uYWxDbGFzc2VzKTtcblx0XHR9IGVsc2UgaWYgKHR5cGVvZiBhZGRpdGlvbmFsQ2xhc3NlcyA9PT0gJ3N0cmluZycgJiYgYWRkaXRpb25hbENsYXNzZXMubGVuZ3RoID4gMCkge1xuXHRcdFx0Y2xhc3Nlcy5wdXNoKGFkZGl0aW9uYWxDbGFzc2VzKTtcblx0XHR9XG5cblx0XHRyZXR1cm4gY2xhc3Nlcy5sZW5ndGggPT09IDEgPyBjbGFzc2VzWzBdIDogY2xhc3Nlcztcblx0fVxufVxuIl19