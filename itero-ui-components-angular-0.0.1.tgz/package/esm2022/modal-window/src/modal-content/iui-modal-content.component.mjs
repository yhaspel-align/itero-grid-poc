import { Component, Input } from '@angular/core';
import * as i0 from "@angular/core";
export class IuiModalContentComponent {
    constructor() {
        this._padding = '0px';
    }
    set padding(value) {
        this._padding = value + 'px';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiModalContentComponent, selector: "iui-modal-content", inputs: { padding: "padding" }, host: { properties: { "class.iui-modal__content": "true", "style.--iui-modal-content-padding": "_padding" } }, ngImport: i0, template: "<ng-content></ng-content>\n", styles: [":host{display:block;overflow:auto;box-sizing:border-box;padding:var(--iui-modal-content-padding);flex:1;min-height:0}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalContentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-modal-content', host: {
                        '[class.iui-modal__content]': 'true',
                        '[style.--iui-modal-content-padding]': '_padding'
                    }, template: "<ng-content></ng-content>\n", styles: [":host{display:block;overflow:auto;box-sizing:border-box;padding:var(--iui-modal-content-padding);flex:1;min-height:0}\n"] }]
        }], propDecorators: { padding: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLW1vZGFsLWNvbnRlbnQuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvbW9kYWwtd2luZG93L3NyYy9tb2RhbC1jb250ZW50L2l1aS1tb2RhbC1jb250ZW50LmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uL2xpYnMvdWktY29tcG9uZW50cy1hbmd1bGFyLXB1Ymxpc2hhYmxlL21vZGFsLXdpbmRvdy9zcmMvbW9kYWwtY29udGVudC9pdWktbW9kYWwtY29udGVudC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFXakQsTUFBTSxPQUFPLHdCQUF3QjtJQVRyQztRQWVDLGFBQVEsR0FBRyxLQUFLLENBQUM7S0FDakI7SUFOQSxJQUNJLE9BQU8sQ0FBQyxLQUFhO1FBQ3hCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxHQUFHLElBQUksQ0FBQztJQUM5QixDQUFDOytHQUpXLHdCQUF3QjttR0FBeEIsd0JBQXdCLHdNQ1hyQyw2QkFDQTs7NEZEVWEsd0JBQXdCO2tCQVRwQyxTQUFTOytCQUNDLG1CQUFtQixRQUd2Qjt3QkFDTCw0QkFBNEIsRUFBRSxNQUFNO3dCQUNwQyxxQ0FBcUMsRUFBRSxVQUFVO3FCQUNqRDs4QkFJRyxPQUFPO3NCQURWLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBDb21wb25lbnQoe1xuXHRzZWxlY3RvcjogJ2l1aS1tb2RhbC1jb250ZW50Jyxcblx0dGVtcGxhdGVVcmw6ICcuL2l1aS1tb2RhbC1jb250ZW50LmNvbXBvbmVudC5odG1sJyxcblx0c3R5bGVVcmxzOiBbJy4vaXVpLW1vZGFsLWNvbnRlbnQuY29tcG9uZW50LnNjc3MnXSxcblx0aG9zdDoge1xuXHRcdCdbY2xhc3MuaXVpLW1vZGFsX19jb250ZW50XSc6ICd0cnVlJyxcblx0XHQnW3N0eWxlLi0taXVpLW1vZGFsLWNvbnRlbnQtcGFkZGluZ10nOiAnX3BhZGRpbmcnXG5cdH1cbn0pXG5leHBvcnQgY2xhc3MgSXVpTW9kYWxDb250ZW50Q29tcG9uZW50IHtcblx0QElucHV0KClcblx0c2V0IHBhZGRpbmcodmFsdWU6IG51bWJlcikge1xuXHRcdHRoaXMuX3BhZGRpbmcgPSB2YWx1ZSArICdweCc7XG5cdH1cblxuXHRfcGFkZGluZyA9ICcwcHgnO1xufVxuIiwiPG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PlxuIl19