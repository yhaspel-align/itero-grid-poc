import { animate, animateChild, group, query, state, style, transition, trigger } from '@angular/animations';
/**
 * Default parameters for the animation for backwards compatibility.
 * @docs-private
 */
export const _defaultParams = {
    params: { enterAnimationDuration: '150ms', exitAnimationDuration: '75ms' },
};
export const iuiDialogAnimations = {
    /** Animation that is applied on the dialog container by default. */
    dialogContainer: trigger('dialogContainer', [
        // Note: The `enter` animation transitions to `transform: none`, because for some reason
        // specifying the transform explicitly, causes IE both to blur the dialog content and
        // decimate the animation performance. Leaving it as `none` solves both issues.
        state('void, exit', style({ opacity: 0, transform: 'scale(0.7)' })),
        state('enter', style({ transform: 'none' })),
        transition('* => enter', group([
            animate('{{enterAnimationDuration}} cubic-bezier(0, 0, 0.2, 1)', style({ transform: 'none', opacity: 1 })),
            query('@*', animateChild(), { optional: true }),
        ]), _defaultParams),
        transition('* => void, * => exit', group([
            animate('{{exitAnimationDuration}} cubic-bezier(0.4, 0.0, 0.2, 1)', style({ opacity: 0 })),
            query('@*', animateChild(), { optional: true }),
        ]), _defaultParams),
    ]),
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYW5pbWF0aW9ucy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL2xpYnMvdWktY29tcG9uZW50cy1hbmd1bGFyLXB1Ymxpc2hhYmxlL21vZGFsLXdpbmRvdy9zcmMvbW9kYWwtY29udGFpbmVyL2FuaW1hdGlvbnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNOLE9BQU8sRUFBRSxZQUFZLEVBRXJCLEtBQUssRUFDTCxLQUFLLEVBQ0wsS0FBSyxFQUNMLEtBQUssRUFDTCxVQUFVLEVBQ1YsT0FBTyxFQUNQLE1BQU0scUJBQXFCLENBQUM7QUFFN0I7OztHQUdHO0FBQ0gsTUFBTSxDQUFDLE1BQU0sY0FBYyxHQUFHO0lBQzdCLE1BQU0sRUFBRSxFQUFFLHNCQUFzQixFQUFFLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLEVBQUU7Q0FDMUUsQ0FBQztBQUVGLE1BQU0sQ0FBQyxNQUFNLG1CQUFtQixHQUU1QjtJQUNILG9FQUFvRTtJQUNwRSxlQUFlLEVBQUUsT0FBTyxDQUFDLGlCQUFpQixFQUFFO1FBQzNDLHdGQUF3RjtRQUN4RixxRkFBcUY7UUFDckYsK0VBQStFO1FBQy9FLEtBQUssQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLEVBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFDLENBQUMsQ0FBQztRQUNqRSxLQUFLLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxFQUFDLFNBQVMsRUFBRSxNQUFNLEVBQUMsQ0FBQyxDQUFDO1FBQzFDLFVBQVUsQ0FDVCxZQUFZLEVBQ1osS0FBSyxDQUFDO1lBQ0wsT0FBTyxDQUNOLHVEQUF1RCxFQUN2RCxLQUFLLENBQUMsRUFBQyxTQUFTLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUN0QztZQUNELEtBQUssQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFDLENBQUM7U0FDN0MsQ0FBQyxFQUNGLGNBQWMsQ0FDZDtRQUNELFVBQVUsQ0FDVCxzQkFBc0IsRUFDdEIsS0FBSyxDQUFDO1lBQ0wsT0FBTyxDQUFDLDBEQUEwRCxFQUFFLEtBQUssQ0FBQyxFQUFDLE9BQU8sRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDO1lBQ3hGLEtBQUssQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFDLENBQUM7U0FDN0MsQ0FBQyxFQUNGLGNBQWMsQ0FDZDtLQUNELENBQUM7Q0FDRixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcblx0YW5pbWF0ZSwgYW5pbWF0ZUNoaWxkLFxuXHRBbmltYXRpb25UcmlnZ2VyTWV0YWRhdGEsXG5cdGdyb3VwLFxuXHRxdWVyeSxcblx0c3RhdGUsXG5cdHN0eWxlLFxuXHR0cmFuc2l0aW9uLFxuXHR0cmlnZ2VyXG59IGZyb20gJ0Bhbmd1bGFyL2FuaW1hdGlvbnMnO1xuXG4vKipcbiAqIERlZmF1bHQgcGFyYW1ldGVycyBmb3IgdGhlIGFuaW1hdGlvbiBmb3IgYmFja3dhcmRzIGNvbXBhdGliaWxpdHkuXG4gKiBAZG9jcy1wcml2YXRlXG4gKi9cbmV4cG9ydCBjb25zdCBfZGVmYXVsdFBhcmFtcyA9IHtcblx0cGFyYW1zOiB7IGVudGVyQW5pbWF0aW9uRHVyYXRpb246ICcxNTBtcycsIGV4aXRBbmltYXRpb25EdXJhdGlvbjogJzc1bXMnIH0sXG59O1xuXG5leHBvcnQgY29uc3QgaXVpRGlhbG9nQW5pbWF0aW9uczoge1xuXHRyZWFkb25seSBkaWFsb2dDb250YWluZXI6IEFuaW1hdGlvblRyaWdnZXJNZXRhZGF0YTtcbn0gPSB7XG5cdC8qKiBBbmltYXRpb24gdGhhdCBpcyBhcHBsaWVkIG9uIHRoZSBkaWFsb2cgY29udGFpbmVyIGJ5IGRlZmF1bHQuICovXG5cdGRpYWxvZ0NvbnRhaW5lcjogdHJpZ2dlcignZGlhbG9nQ29udGFpbmVyJywgW1xuXHRcdC8vIE5vdGU6IFRoZSBgZW50ZXJgIGFuaW1hdGlvbiB0cmFuc2l0aW9ucyB0byBgdHJhbnNmb3JtOiBub25lYCwgYmVjYXVzZSBmb3Igc29tZSByZWFzb25cblx0XHQvLyBzcGVjaWZ5aW5nIHRoZSB0cmFuc2Zvcm0gZXhwbGljaXRseSwgY2F1c2VzIElFIGJvdGggdG8gYmx1ciB0aGUgZGlhbG9nIGNvbnRlbnQgYW5kXG5cdFx0Ly8gZGVjaW1hdGUgdGhlIGFuaW1hdGlvbiBwZXJmb3JtYW5jZS4gTGVhdmluZyBpdCBhcyBgbm9uZWAgc29sdmVzIGJvdGggaXNzdWVzLlxuXHRcdHN0YXRlKCd2b2lkLCBleGl0Jywgc3R5bGUoe29wYWNpdHk6IDAsIHRyYW5zZm9ybTogJ3NjYWxlKDAuNyknfSkpLFxuXHRcdHN0YXRlKCdlbnRlcicsIHN0eWxlKHt0cmFuc2Zvcm06ICdub25lJ30pKSxcblx0XHR0cmFuc2l0aW9uKFxuXHRcdFx0JyogPT4gZW50ZXInLFxuXHRcdFx0Z3JvdXAoW1xuXHRcdFx0XHRhbmltYXRlKFxuXHRcdFx0XHRcdCd7e2VudGVyQW5pbWF0aW9uRHVyYXRpb259fSBjdWJpYy1iZXppZXIoMCwgMCwgMC4yLCAxKScsXG5cdFx0XHRcdFx0c3R5bGUoe3RyYW5zZm9ybTogJ25vbmUnLCBvcGFjaXR5OiAxfSksXG5cdFx0XHRcdCksXG5cdFx0XHRcdHF1ZXJ5KCdAKicsIGFuaW1hdGVDaGlsZCgpLCB7b3B0aW9uYWw6IHRydWV9KSxcblx0XHRcdF0pLFxuXHRcdFx0X2RlZmF1bHRQYXJhbXMsXG5cdFx0KSxcblx0XHR0cmFuc2l0aW9uKFxuXHRcdFx0JyogPT4gdm9pZCwgKiA9PiBleGl0Jyxcblx0XHRcdGdyb3VwKFtcblx0XHRcdFx0YW5pbWF0ZSgne3tleGl0QW5pbWF0aW9uRHVyYXRpb259fSBjdWJpYy1iZXppZXIoMC40LCAwLjAsIDAuMiwgMSknLCBzdHlsZSh7b3BhY2l0eTogMH0pKSxcblx0XHRcdFx0cXVlcnkoJ0AqJywgYW5pbWF0ZUNoaWxkKCksIHtvcHRpb25hbDogdHJ1ZX0pLFxuXHRcdFx0XSksXG5cdFx0XHRfZGVmYXVsdFBhcmFtcyxcblx0XHQpLFxuXHRdKSxcbn07XG4iXX0=