import { ChangeDetectorRef, Component, ElementRef, EventEmitter, Inject, NgZone, Optional } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { CdkDialogContainer, DialogConfig } from '@angular/cdk/dialog';
import { FocusMonitor, FocusTrapFactory, InteractivityChecker } from '@angular/cdk/a11y';
import { OverlayRef } from '@angular/cdk/overlay';
import { _defaultParams, iuiDialogAnimations } from './animations';
import * as i0 from "@angular/core";
import * as i1 from "@angular/cdk/a11y";
import * as i2 from "@angular/cdk/dialog";
import * as i3 from "@angular/cdk/overlay";
import * as i4 from "@angular/cdk/portal";
export class IuiModalContainerComponent extends CdkDialogContainer {
    constructor(elementRef, focusTrapFactory, _document, dialogConfig, interactivityChecker, ngZone, _changeDetectorRef, overlayRef, focusMonitor) {
        super(elementRef, focusTrapFactory, _document, dialogConfig, interactivityChecker, ngZone, overlayRef, focusMonitor);
        this._changeDetectorRef = _changeDetectorRef;
        /** Emits when an animation state changes. */
        this._animationStateChanged = new EventEmitter();
        /** State of the dialog animation. */
        this._state = 'enter';
    }
    _getAnimationState() {
        return {
            value: this._state,
            params: {
                enterAnimationDuration: _defaultParams.params.enterAnimationDuration,
                exitAnimationDuration: _defaultParams.params.exitAnimationDuration
            }
        };
    }
    /** Callback, invoked when an animation on the host starts. */
    _onAnimationStart({ toState, totalTime }) {
        if (toState === 'enter') {
            this._animationStateChanged.next({ state: 'opening', totalTime });
        }
        else if (toState === 'exit' || toState === 'void') {
            this._animationStateChanged.next({ state: 'closing', totalTime });
        }
    }
    /** Callback, invoked whenever an animation on the host completes. */
    _onAnimationDone({ toState, totalTime }) {
        if (toState === 'enter') {
            this._openAnimationDone(totalTime);
        }
        else if (toState === 'exit') {
            this._animationStateChanged.next({ state: 'closed', totalTime });
        }
    }
    _openAnimationDone(totalTime) {
        this._animationStateChanged.next({ state: 'opened', totalTime });
    }
    /** Starts the dialog exit animation. */
    _startExitAnimation() {
        this._state = 'exit';
        // Mark the container for check so it can react if the
        // view container is using OnPush change detection.
        this._changeDetectorRef.markForCheck();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalContainerComponent, deps: [{ token: i0.ElementRef }, { token: i1.FocusTrapFactory }, { token: DOCUMENT, optional: true }, { token: i2.DialogConfig }, { token: i1.InteractivityChecker }, { token: i0.NgZone }, { token: i0.ChangeDetectorRef }, { token: i3.OverlayRef }, { token: i1.FocusMonitor }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiModalContainerComponent, selector: "iui-modal-container", host: { attributes: { "tabindex": "-1" }, listeners: { "@dialogContainer.start": "_onAnimationStart($event)", "@dialogContainer.done": "_onAnimationDone($event)" }, properties: { "attr.aria-modal": "_config.ariaModal", "id": "_config.id", "attr.role": "_config.role", "attr.aria-labelledby": "_config.ariaLabel ? null : _ariaLabelledBy", "attr.aria-label": "_config.ariaLabel", "attr.aria-describedby": "_config.ariaDescribedBy || null", "@dialogContainer": "_getAnimationState()" }, classAttribute: "iui-modal__container" }, usesInheritance: true, ngImport: i0, template: "<ng-template cdkPortalOutlet></ng-template>\n", styles: [":host{display:flex;flex-direction:column;gap:24px;overflow:hidden;box-sizing:border-box;background:var(--iui-modal-bg);border-radius:var(--iui-border-radius-large);box-shadow:var(--iui-box-shadow-l);outline:none;padding:24px;width:100%;max-height:inherit;min-height:inherit;min-width:inherit;max-width:inherit;font:var(--iui-tp-body-02-font);color:var(--iui-modal-color)}\n"], dependencies: [{ kind: "directive", type: i4.CdkPortalOutlet, selector: "[cdkPortalOutlet]", inputs: ["cdkPortalOutlet"], outputs: ["attached"], exportAs: ["cdkPortalOutlet"] }], animations: [iuiDialogAnimations.dialogContainer] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiModalContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-modal-container', animations: [iuiDialogAnimations.dialogContainer], host: {
                        class: 'iui-modal__container',
                        tabindex: '-1',
                        '[attr.aria-modal]': '_config.ariaModal',
                        '[id]': '_config.id',
                        '[attr.role]': '_config.role',
                        '[attr.aria-labelledby]': '_config.ariaLabel ? null : _ariaLabelledBy',
                        '[attr.aria-label]': '_config.ariaLabel',
                        '[attr.aria-describedby]': '_config.ariaDescribedBy || null',
                        '[@dialogContainer]': '_getAnimationState()',
                        '(@dialogContainer.start)': '_onAnimationStart($event)',
                        '(@dialogContainer.done)': '_onAnimationDone($event)'
                    }, template: "<ng-template cdkPortalOutlet></ng-template>\n", styles: [":host{display:flex;flex-direction:column;gap:24px;overflow:hidden;box-sizing:border-box;background:var(--iui-modal-bg);border-radius:var(--iui-border-radius-large);box-shadow:var(--iui-box-shadow-l);outline:none;padding:24px;width:100%;max-height:inherit;min-height:inherit;min-width:inherit;max-width:inherit;font:var(--iui-tp-body-02-font);color:var(--iui-modal-color)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.FocusTrapFactory }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i2.DialogConfig }, { type: i1.InteractivityChecker }, { type: i0.NgZone }, { type: i0.ChangeDetectorRef }, { type: i3.OverlayRef }, { type: i1.FocusMonitor }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLW1vZGFsLWNvbnRhaW5lci5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS9tb2RhbC13aW5kb3cvc3JjL21vZGFsLWNvbnRhaW5lci9pdWktbW9kYWwtY29udGFpbmVyLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uL2xpYnMvdWktY29tcG9uZW50cy1hbmd1bGFyLXB1Ymxpc2hhYmxlL21vZGFsLXdpbmRvdy9zcmMvbW9kYWwtY29udGFpbmVyL2l1aS1tb2RhbC1jb250YWluZXIuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLGlCQUFpQixFQUFFLFNBQVMsRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ2pILE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMzQyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsWUFBWSxFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFDdkUsT0FBTyxFQUFFLFlBQVksRUFBRSxnQkFBZ0IsRUFBRSxvQkFBb0IsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ3pGLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUdsRCxPQUFPLEVBQUUsY0FBYyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sY0FBYyxDQUFDOzs7Ozs7QUEwQm5FLE1BQU0sT0FBTywwQkFBMkIsU0FBUSxrQkFBa0I7SUFDakUsWUFDQyxVQUFzQixFQUN0QixnQkFBa0MsRUFDSixTQUFjLEVBQzVDLFlBQTBCLEVBQzFCLG9CQUEwQyxFQUMxQyxNQUFjLEVBQ2Msa0JBQXFDLEVBQ2pFLFVBQXNCLEVBQ3RCLFlBQTJCO1FBRzNCLEtBQUssQ0FBQyxVQUFVLEVBQUUsZ0JBQWdCLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxvQkFBb0IsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBTHpGLHVCQUFrQixHQUFsQixrQkFBa0IsQ0FBbUI7UUFRbEUsNkNBQTZDO1FBQzdDLDJCQUFzQixHQUFHLElBQUksWUFBWSxFQUFnQyxDQUFDO1FBRTFFLHFDQUFxQztRQUNyQyxXQUFNLEdBQThCLE9BQU8sQ0FBQztJQU41QyxDQUFDO0lBUUQsa0JBQWtCO1FBQ2pCLE9BQU87WUFDTixLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDbEIsTUFBTSxFQUFFO2dCQUNQLHNCQUFzQixFQUFFLGNBQWMsQ0FBQyxNQUFNLENBQUMsc0JBQXNCO2dCQUNwRSxxQkFBcUIsRUFBRSxjQUFjLENBQUMsTUFBTSxDQUFDLHFCQUFxQjthQUNsRTtTQUNELENBQUM7SUFDSCxDQUFDO0lBRUQsOERBQThEO0lBQzlELGlCQUFpQixDQUFDLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBa0I7UUFDdkQsSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQztRQUNuRSxDQUFDO2FBQU0sSUFBSSxPQUFPLEtBQUssTUFBTSxJQUFJLE9BQU8sS0FBSyxNQUFNLEVBQUUsQ0FBQztZQUNyRCxJQUFJLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQ25FLENBQUM7SUFDRixDQUFDO0lBRUQscUVBQXFFO0lBQ3JFLGdCQUFnQixDQUFDLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBa0I7UUFDdEQsSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3BDLENBQUM7YUFBTSxJQUFJLE9BQU8sS0FBSyxNQUFNLEVBQUUsQ0FBQztZQUMvQixJQUFJLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQ2xFLENBQUM7SUFDRixDQUFDO0lBR1Msa0JBQWtCLENBQUMsU0FBaUI7UUFDN0MsSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxFQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFDLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBRUQsd0NBQXdDO0lBQ3hDLG1CQUFtQjtRQUNsQixJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUVyQixzREFBc0Q7UUFDdEQsbURBQW1EO1FBQ25ELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN4QyxDQUFDOytHQTlEVywwQkFBMEIsNEVBSWpCLFFBQVE7bUdBSmpCLDBCQUEwQixnbUJDakN2QywrQ0FDQSxva0JEaUJhLENBQUMsbUJBQW1CLENBQUMsZUFBZSxDQUFDOzs0RkFlckMsMEJBQTBCO2tCQW5CdEMsU0FBUzsrQkFDQyxxQkFBcUIsY0FHbkIsQ0FBQyxtQkFBbUIsQ0FBQyxlQUFlLENBQUMsUUFDM0M7d0JBQ0wsS0FBSyxFQUFFLHNCQUFzQjt3QkFDN0IsUUFBUSxFQUFFLElBQUk7d0JBQ2QsbUJBQW1CLEVBQUUsbUJBQW1CO3dCQUN4QyxNQUFNLEVBQUUsWUFBWTt3QkFDcEIsYUFBYSxFQUFFLGNBQWM7d0JBQzdCLHdCQUF3QixFQUFFLDRDQUE0Qzt3QkFDdEUsbUJBQW1CLEVBQUUsbUJBQW1CO3dCQUN4Qyx5QkFBeUIsRUFBRSxpQ0FBaUM7d0JBQzVELG9CQUFvQixFQUFFLHNCQUFzQjt3QkFDNUMsMEJBQTBCLEVBQUUsMkJBQTJCO3dCQUN2RCx5QkFBeUIsRUFBRSwwQkFBMEI7cUJBQ3JEOzswQkFNQyxRQUFROzswQkFBSSxNQUFNOzJCQUFDLFFBQVEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDaGFuZ2VEZXRlY3RvclJlZiwgQ29tcG9uZW50LCBFbGVtZW50UmVmLCBFdmVudEVtaXR0ZXIsIEluamVjdCwgTmdab25lLCBPcHRpb25hbCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRE9DVU1FTlQgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgQ2RrRGlhbG9nQ29udGFpbmVyLCBEaWFsb2dDb25maWcgfSBmcm9tICdAYW5ndWxhci9jZGsvZGlhbG9nJztcbmltcG9ydCB7IEZvY3VzTW9uaXRvciwgRm9jdXNUcmFwRmFjdG9yeSwgSW50ZXJhY3Rpdml0eUNoZWNrZXIgfSBmcm9tICdAYW5ndWxhci9jZGsvYTExeSc7XG5pbXBvcnQgeyBPdmVybGF5UmVmIH0gZnJvbSAnQGFuZ3VsYXIvY2RrL292ZXJsYXknO1xuXG5pbXBvcnQgeyBBbmltYXRpb25FdmVudCB9IGZyb20gJ0Bhbmd1bGFyL2FuaW1hdGlvbnMnO1xuaW1wb3J0IHsgX2RlZmF1bHRQYXJhbXMsIGl1aURpYWxvZ0FuaW1hdGlvbnMgfSBmcm9tICcuL2FuaW1hdGlvbnMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEl1aU1vZGFsV2luZG93QW5pbWF0aW9uRXZlbnQge1xuXHRzdGF0ZTogJ29wZW5lZCcgfCAnb3BlbmluZycgfCAnY2xvc2luZycgfCAnY2xvc2VkJztcblx0dG90YWxUaW1lOiBudW1iZXI7XG59XG5cbkBDb21wb25lbnQoe1xuXHRzZWxlY3RvcjogJ2l1aS1tb2RhbC1jb250YWluZXInLFxuXHR0ZW1wbGF0ZVVybDogJy4vaXVpLW1vZGFsLWNvbnRhaW5lci5jb21wb25lbnQuaHRtbCcsXG5cdHN0eWxlVXJsczogWycuL2l1aS1tb2RhbC1jb250YWluZXIuY29tcG9uZW50LnNjc3MnXSxcblx0YW5pbWF0aW9uczogW2l1aURpYWxvZ0FuaW1hdGlvbnMuZGlhbG9nQ29udGFpbmVyXSxcblx0aG9zdDoge1xuXHRcdGNsYXNzOiAnaXVpLW1vZGFsX19jb250YWluZXInLFxuXHRcdHRhYmluZGV4OiAnLTEnLFxuXHRcdCdbYXR0ci5hcmlhLW1vZGFsXSc6ICdfY29uZmlnLmFyaWFNb2RhbCcsXG5cdFx0J1tpZF0nOiAnX2NvbmZpZy5pZCcsXG5cdFx0J1thdHRyLnJvbGVdJzogJ19jb25maWcucm9sZScsXG5cdFx0J1thdHRyLmFyaWEtbGFiZWxsZWRieV0nOiAnX2NvbmZpZy5hcmlhTGFiZWwgPyBudWxsIDogX2FyaWFMYWJlbGxlZEJ5Jyxcblx0XHQnW2F0dHIuYXJpYS1sYWJlbF0nOiAnX2NvbmZpZy5hcmlhTGFiZWwnLFxuXHRcdCdbYXR0ci5hcmlhLWRlc2NyaWJlZGJ5XSc6ICdfY29uZmlnLmFyaWFEZXNjcmliZWRCeSB8fCBudWxsJyxcblx0XHQnW0BkaWFsb2dDb250YWluZXJdJzogJ19nZXRBbmltYXRpb25TdGF0ZSgpJyxcblx0XHQnKEBkaWFsb2dDb250YWluZXIuc3RhcnQpJzogJ19vbkFuaW1hdGlvblN0YXJ0KCRldmVudCknLFxuXHRcdCcoQGRpYWxvZ0NvbnRhaW5lci5kb25lKSc6ICdfb25BbmltYXRpb25Eb25lKCRldmVudCknXG5cdH1cbn0pXG5leHBvcnQgY2xhc3MgSXVpTW9kYWxDb250YWluZXJDb21wb25lbnQgZXh0ZW5kcyBDZGtEaWFsb2dDb250YWluZXIge1xuXHRjb25zdHJ1Y3Rvcihcblx0XHRlbGVtZW50UmVmOiBFbGVtZW50UmVmLFxuXHRcdGZvY3VzVHJhcEZhY3Rvcnk6IEZvY3VzVHJhcEZhY3RvcnksXG5cdFx0QE9wdGlvbmFsKCkgQEluamVjdChET0NVTUVOVCkgX2RvY3VtZW50OiBhbnksXG5cdFx0ZGlhbG9nQ29uZmlnOiBEaWFsb2dDb25maWcsXG5cdFx0aW50ZXJhY3Rpdml0eUNoZWNrZXI6IEludGVyYWN0aXZpdHlDaGVja2VyLFxuXHRcdG5nWm9uZTogTmdab25lLFxuXHRcdHByb3RlY3RlZCBvdmVycmlkZSByZWFkb25seSBfY2hhbmdlRGV0ZWN0b3JSZWY6IENoYW5nZURldGVjdG9yUmVmLFxuXHRcdG92ZXJsYXlSZWY6IE92ZXJsYXlSZWYsXG5cdFx0Zm9jdXNNb25pdG9yPzogRm9jdXNNb25pdG9yLFxuXG5cdCkge1xuXHRcdHN1cGVyKGVsZW1lbnRSZWYsIGZvY3VzVHJhcEZhY3RvcnksIF9kb2N1bWVudCwgZGlhbG9nQ29uZmlnLCBpbnRlcmFjdGl2aXR5Q2hlY2tlciwgbmdab25lLCBvdmVybGF5UmVmLCBmb2N1c01vbml0b3IpO1xuXHR9XG5cblx0LyoqIEVtaXRzIHdoZW4gYW4gYW5pbWF0aW9uIHN0YXRlIGNoYW5nZXMuICovXG5cdF9hbmltYXRpb25TdGF0ZUNoYW5nZWQgPSBuZXcgRXZlbnRFbWl0dGVyPEl1aU1vZGFsV2luZG93QW5pbWF0aW9uRXZlbnQ+KCk7XG5cblx0LyoqIFN0YXRlIG9mIHRoZSBkaWFsb2cgYW5pbWF0aW9uLiAqL1xuXHRfc3RhdGU6ICd2b2lkJyB8ICdlbnRlcicgfCAnZXhpdCcgPSAnZW50ZXInO1xuXG5cdF9nZXRBbmltYXRpb25TdGF0ZSgpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0dmFsdWU6IHRoaXMuX3N0YXRlLFxuXHRcdFx0cGFyYW1zOiB7XG5cdFx0XHRcdGVudGVyQW5pbWF0aW9uRHVyYXRpb246IF9kZWZhdWx0UGFyYW1zLnBhcmFtcy5lbnRlckFuaW1hdGlvbkR1cmF0aW9uLFxuXHRcdFx0XHRleGl0QW5pbWF0aW9uRHVyYXRpb246IF9kZWZhdWx0UGFyYW1zLnBhcmFtcy5leGl0QW5pbWF0aW9uRHVyYXRpb25cblx0XHRcdH1cblx0XHR9O1xuXHR9XG5cblx0LyoqIENhbGxiYWNrLCBpbnZva2VkIHdoZW4gYW4gYW5pbWF0aW9uIG9uIHRoZSBob3N0IHN0YXJ0cy4gKi9cblx0X29uQW5pbWF0aW9uU3RhcnQoeyB0b1N0YXRlLCB0b3RhbFRpbWUgfTogQW5pbWF0aW9uRXZlbnQpIHtcblx0XHRpZiAodG9TdGF0ZSA9PT0gJ2VudGVyJykge1xuXHRcdFx0dGhpcy5fYW5pbWF0aW9uU3RhdGVDaGFuZ2VkLm5leHQoeyBzdGF0ZTogJ29wZW5pbmcnLCB0b3RhbFRpbWUgfSk7XG5cdFx0fSBlbHNlIGlmICh0b1N0YXRlID09PSAnZXhpdCcgfHwgdG9TdGF0ZSA9PT0gJ3ZvaWQnKSB7XG5cdFx0XHR0aGlzLl9hbmltYXRpb25TdGF0ZUNoYW5nZWQubmV4dCh7IHN0YXRlOiAnY2xvc2luZycsIHRvdGFsVGltZSB9KTtcblx0XHR9XG5cdH1cblxuXHQvKiogQ2FsbGJhY2ssIGludm9rZWQgd2hlbmV2ZXIgYW4gYW5pbWF0aW9uIG9uIHRoZSBob3N0IGNvbXBsZXRlcy4gKi9cblx0X29uQW5pbWF0aW9uRG9uZSh7IHRvU3RhdGUsIHRvdGFsVGltZSB9OiBBbmltYXRpb25FdmVudCkge1xuXHRcdGlmICh0b1N0YXRlID09PSAnZW50ZXInKSB7XG5cdFx0XHR0aGlzLl9vcGVuQW5pbWF0aW9uRG9uZSh0b3RhbFRpbWUpO1xuXHRcdH0gZWxzZSBpZiAodG9TdGF0ZSA9PT0gJ2V4aXQnKSB7XG5cdFx0XHR0aGlzLl9hbmltYXRpb25TdGF0ZUNoYW5nZWQubmV4dCh7IHN0YXRlOiAnY2xvc2VkJywgdG90YWxUaW1lIH0pO1xuXHRcdH1cblx0fVxuXG5cblx0cHJvdGVjdGVkIF9vcGVuQW5pbWF0aW9uRG9uZSh0b3RhbFRpbWU6IG51bWJlcikge1xuXHRcdHRoaXMuX2FuaW1hdGlvblN0YXRlQ2hhbmdlZC5uZXh0KHtzdGF0ZTogJ29wZW5lZCcsIHRvdGFsVGltZX0pO1xuXHR9XG5cblx0LyoqIFN0YXJ0cyB0aGUgZGlhbG9nIGV4aXQgYW5pbWF0aW9uLiAqL1xuXHRfc3RhcnRFeGl0QW5pbWF0aW9uKCk6IHZvaWQge1xuXHRcdHRoaXMuX3N0YXRlID0gJ2V4aXQnO1xuXG5cdFx0Ly8gTWFyayB0aGUgY29udGFpbmVyIGZvciBjaGVjayBzbyBpdCBjYW4gcmVhY3QgaWYgdGhlXG5cdFx0Ly8gdmlldyBjb250YWluZXIgaXMgdXNpbmcgT25QdXNoIGNoYW5nZSBkZXRlY3Rpb24uXG5cdFx0dGhpcy5fY2hhbmdlRGV0ZWN0b3JSZWYubWFya0ZvckNoZWNrKCk7XG5cdH1cbn1cbiIsIjxuZy10ZW1wbGF0ZSBjZGtQb3J0YWxPdXRsZXQ+PC9uZy10ZW1wbGF0ZT5cbiJdfQ==