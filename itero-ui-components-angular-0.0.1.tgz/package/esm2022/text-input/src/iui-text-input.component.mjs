import { ChangeDetectionStrategy, ChangeDetectorRef, Component, forwardRef, Input, Self, ViewChildren } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import { FormsModule, NG_VALUE_ACCESSOR, Validators } from '@angular/forms';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { CloseEmptyIconComponent } from '@itero/ui-components-angular/icons';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
let nextUniqueId = 0;
export class IuiTextInputComponent {
    /** Unique id of the element */
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    /** Whether the component is required. */
    get required() {
        return this._required ?? this.ngControlDirective.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    get _labelId() {
        return this.id + '-label';
    }
    get _inputId() {
        return this.id + '-input';
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get empty() {
        return this._value == null || this._value == '';
    }
    get _counterText() {
        const len = this._value?.length ?? 0;
        return this.maxLength ? `${len}/${this.maxLength}` : `${len}`;
    }
    constructor(_changeDetectorRef, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._changeDetectorRef = _changeDetectorRef;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        /** Label of component, default is '', strongly recommended to be filled */
        this.label = '';
        /** Placeholder of component, rendered in the place of the value when no selections/input */
        this.placeholder = '';
        /** Whether the input contains "X" icon to clear the field */
        this.cancelable = false;
        /** Name assigned to input element inside */
        this.name = '';
        this.autocomplete = null;
        /** Type of input element, supported: text, password, email */
        this.type = 'text';
        /** Size of the input field: large (default), medium, small */
        this.size = 'l';
        /** Layer set: set-01 (white bg, default) or set-02 (gray bg) */
        this.layerSet = 'set-01';
        /** Whether to show character counter in the label row */
        this.showCounter = false;
        /** Max character length; displayed in counter as current/max */
        this.maxLength = null;
        /** Whether to show the skeleton loading state */
        this.skeleton = false;
        this.__focused = false;
        this._id = `iui-text-input-${nextUniqueId++}`;
        /** `View -> model callback called when value changes` */
        this._onChange = () => { };
        /** `View -> model callback called when select has been touched` */
        this._onTouched = () => { };
    }
    /** Value of the select control. */
    get _value() {
        return this.__value;
    }
    set _value(newValue) {
        const hasAssigned = this._assignValue(newValue);
        if (hasAssigned) {
            this._onChange(newValue);
        }
    }
    /** Whether the select is focused. */
    get _focused() {
        return this.__focused;
    }
    _onFocus() {
        if (!this.disabled) {
            this.__focused = true;
        }
    }
    _onBlur() {
        this.__focused = false;
        if (!this.disabled) {
            this._onTouched();
            this._changeDetectorRef.markForCheck();
        }
    }
    _focusInput(input) {
        if (!this.disabled) {
            input.focus();
        }
    }
    _cancelSelection(event) {
        event.stopPropagation();
        if (!this.disabled) {
            this._value = '';
        }
    }
    writeValue(value) {
        this._assignValue(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._changeDetectorRef.markForCheck();
    }
    modelChangeHandler(value) {
        this._assignValue(value);
        this._onChange(value);
    }
    _assignValue(newValue) {
        if (newValue !== this.__value) {
            this.__value = newValue;
            this._changeDetectorRef.markForCheck();
            return true;
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTextInputComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.NgControlDirective, self: true }, { token: i1.IuiErrorStateMatcherDirective, self: true }, { token: i1.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiTextInputComponent, isStandalone: true, selector: "iui-text-input", inputs: { id: "id", label: "label", placeholder: "placeholder", cancelable: "cancelable", name: "name", autocomplete: "autocomplete", type: "type", size: "size", layerSet: "layerSet", showCounter: "showCounter", maxLength: "maxLength", skeleton: "skeleton", required: "required" }, host: { properties: { "class.iui-text-input_size_l": "size === \"l\"", "class.iui-text-input_size_m": "size === \"m\"", "class.iui-text-input_size_s": "size === \"s\"", "class.iui-text-input_layer-set-02": "layerSet === \"set-02\"", "class.iui-text-input_required": "required", "class.iui-text-input_disabled": "disabled", "class.iui-text-input_invalid": "_errorState", "class.iui-text-input_focused": "_focused", "class.iui-text-input_filled": "!empty", "class.iui-text-input_skeleton": "skeleton", "attr.id": "id", "attr.data-testid": "id" }, classAttribute: "iui-text-input" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiTextInputComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "inputElement", predicate: ["inputElement"], descendants: true }], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\n\t<div class=\"iui-text-input__skeleton-field\"></div>\n\t<div class=\"iui-text-input__skeleton-helper\"></div>\n</ng-container>\n\n<ng-template #normalTemplate>\n\t<div class=\"iui-text-input__label-row\" *ngIf=\"label || showCounter\">\n\t\t<label *ngIf=\"label\" class=\"iui-text-input__label\" [attr.for]=\"_inputId\" [id]=\"_labelId\">\n\t\t\t{{ label }}<span class=\"iui-text-input__required\" *ngIf=\"required\">*</span>\n\t\t</label>\n\t\t<span class=\"iui-text-input__counter\" *ngIf=\"showCounter\">{{ _counterText }}</span>\n\t</div>\n\n\t<div class=\"iui-text-input__field\" (click)=\"_focusInput(inputElement)\">\n\t\t<span class=\"iui-text-input__prefix\">\n\t\t\t<ng-content select=\"[iui-prefix]\"></ng-content>\n\t\t</span>\n\n\t\t<input\n\t\t\t#inputElement\n\t\t\tclass=\"iui-text-input__input\"\n\t\t\t[required]=\"required\"\n\t\t\t[disabled]=\"disabled\"\n\t\t\t[attr.aria-invalid]=\"_errorState\"\n\t\t\t[attr.aria-disabled]=\"disabled.toString()\"\n\t\t\t[attr.aria-labelledby]=\"label ? _labelId : null\"\n\t\t\t[attr.autocomplete]=\"autocomplete\"\n\t\t\t[attr.maxlength]=\"maxLength\"\n\t\t\t[placeholder]=\"placeholder\"\n\t\t\t[name]=\"name\"\n\t\t\t[attr.name]=\"name\"\n\t\t\t[type]=\"type\"\n\t\t\t[id]=\"_inputId\"\n\t\t\t[value]=\"_value\"\n\t\t\t[ngModel]=\"_value\"\n\t\t\t(ngModelChange)=\"modelChangeHandler($event)\"\n\t\t\t(focus)=\"_onFocus()\"\n\t\t\t(blur)=\"_onBlur()\"\n\t\t/>\n\n\t\t<iui-close-empty-icon\n\t\t\t*ngIf=\"cancelable && !empty && !disabled\"\n\t\t\t(click)=\"_cancelSelection($event)\"\n\t\t\tclass=\"iui-text-input__clear-icon iui-icon iui-icon_size_s\"\n\t\t\t[attr.aria-label]=\"'Clear'\"\n\t\t></iui-close-empty-icon>\n\n\t\t<span class=\"iui-text-input__suffix\">\n\t\t\t<ng-content select=\"[iui-suffix]\"></ng-content>\n\t\t</span>\n\t</div>\n\n\t<div class=\"iui-text-input__helper-row\">\n\t\t<span *ngIf=\"_errorState\" class=\"iui-text-input__error\">\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\n\t\t</span>\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-text-input__helper\">\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\n\t\t</span>\n\t</div>\n</ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;min-width:206px;max-width:100%}.iui-text-input__label-row{display:flex;align-items:flex-start;justify-content:space-between;padding-bottom:8px}.iui-text-input__label{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-label-color);flex:1;min-width:1px}.iui-text-input__required{color:var(--iui-text-input-error-color);margin-left:4px}.iui-text-input__counter{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-label-color);padding-left:8px;flex-shrink:0;white-space:nowrap}.iui-text-input__field{display:flex;align-items:center;gap:8px;overflow:hidden;background:var(--iui-text-input-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:text}:host.iui-text-input_size_l .iui-text-input__field{padding:12px 16px;border-radius:var(--iui-border-radius-medium)}:host.iui-text-input_size_m .iui-text-input__field{padding:8px 12px;border-radius:var(--iui-border-radius-medium)}:host.iui-text-input_size_s .iui-text-input__field{padding:4px 8px;border-radius:var(--iui-border-radius)}.iui-text-input__input{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-text-input-color);background:transparent;border:none;outline:none;padding:0;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.iui-text-input__input::placeholder{color:var(--iui-text-input-placeholder-color)}.iui-text-input__input:disabled{color:var(--iui-text-input-disabled-color)}.iui-text-input__input:disabled::placeholder{color:var(--iui-text-input-disabled-color)}.iui-text-input__prefix,.iui-text-input__suffix{display:inline-flex;align-items:center;flex-shrink:0}.iui-text-input__prefix:empty,.iui-text-input__suffix:empty{display:none}.iui-text-input__clear-icon{flex-shrink:0;cursor:pointer;color:inherit;pointer-events:auto}:host.iui-text-input_invalid .iui-text-input__clear-icon{color:var(--iui-text-input-error-color)}.iui-text-input__helper-row{padding-top:8px}.iui-text-input__helper{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-helper-color)}.iui-text-input__error{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-error-color)}:host.iui-text-input_focused .iui-text-input__field{border-color:var(--iui-text-input-focus-border)}:host.iui-text-input_invalid .iui-text-input__field{border-color:var(--iui-text-input-error-border)}:host.iui-text-input_disabled .iui-text-input__field{cursor:default;pointer-events:none}:host.iui-text-input_disabled .iui-text-input__label,:host.iui-text-input_disabled .iui-text-input__counter{color:var(--iui-text-input-disabled-color)}:host.iui-text-input_disabled .iui-text-input__helper{color:var(--iui-text-input-disabled-color)}:host.iui-text-input_layer-set-02 .iui-text-input__field{background:var(--iui-text-input-bg-layer-02)}.iui-text-input__skeleton-field{height:44px;border-radius:var(--iui-border-radius-medium);background:var(--iui-text-input-skeleton-bg)}.iui-text-input__skeleton-helper{margin-top:8px;width:40px;height:8px;background:var(--iui-text-input-skeleton-bg)}:host.iui-text-input_size_m .iui-text-input__skeleton-field{height:36px}:host.iui-text-input_size_s .iui-text-input__skeleton-field{height:28px;border-radius:var(--iui-border-radius)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: CloseEmptyIconComponent, selector: "iui-close-empty-icon" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTextInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-text-input', standalone: true, imports: [CommonModule, FormsModule, CloseEmptyIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiTextInputComponent),
                            multi: true
                        }
                    ], host: {
                        class: 'iui-text-input',
                        '[class.iui-text-input_size_l]': 'size === "l"',
                        '[class.iui-text-input_size_m]': 'size === "m"',
                        '[class.iui-text-input_size_s]': 'size === "s"',
                        '[class.iui-text-input_layer-set-02]': 'layerSet === "set-02"',
                        '[class.iui-text-input_required]': 'required',
                        '[class.iui-text-input_disabled]': 'disabled',
                        '[class.iui-text-input_invalid]': '_errorState',
                        '[class.iui-text-input_focused]': '_focused',
                        '[class.iui-text-input_filled]': '!empty',
                        '[class.iui-text-input_skeleton]': 'skeleton',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\n\t<div class=\"iui-text-input__skeleton-field\"></div>\n\t<div class=\"iui-text-input__skeleton-helper\"></div>\n</ng-container>\n\n<ng-template #normalTemplate>\n\t<div class=\"iui-text-input__label-row\" *ngIf=\"label || showCounter\">\n\t\t<label *ngIf=\"label\" class=\"iui-text-input__label\" [attr.for]=\"_inputId\" [id]=\"_labelId\">\n\t\t\t{{ label }}<span class=\"iui-text-input__required\" *ngIf=\"required\">*</span>\n\t\t</label>\n\t\t<span class=\"iui-text-input__counter\" *ngIf=\"showCounter\">{{ _counterText }}</span>\n\t</div>\n\n\t<div class=\"iui-text-input__field\" (click)=\"_focusInput(inputElement)\">\n\t\t<span class=\"iui-text-input__prefix\">\n\t\t\t<ng-content select=\"[iui-prefix]\"></ng-content>\n\t\t</span>\n\n\t\t<input\n\t\t\t#inputElement\n\t\t\tclass=\"iui-text-input__input\"\n\t\t\t[required]=\"required\"\n\t\t\t[disabled]=\"disabled\"\n\t\t\t[attr.aria-invalid]=\"_errorState\"\n\t\t\t[attr.aria-disabled]=\"disabled.toString()\"\n\t\t\t[attr.aria-labelledby]=\"label ? _labelId : null\"\n\t\t\t[attr.autocomplete]=\"autocomplete\"\n\t\t\t[attr.maxlength]=\"maxLength\"\n\t\t\t[placeholder]=\"placeholder\"\n\t\t\t[name]=\"name\"\n\t\t\t[attr.name]=\"name\"\n\t\t\t[type]=\"type\"\n\t\t\t[id]=\"_inputId\"\n\t\t\t[value]=\"_value\"\n\t\t\t[ngModel]=\"_value\"\n\t\t\t(ngModelChange)=\"modelChangeHandler($event)\"\n\t\t\t(focus)=\"_onFocus()\"\n\t\t\t(blur)=\"_onBlur()\"\n\t\t/>\n\n\t\t<iui-close-empty-icon\n\t\t\t*ngIf=\"cancelable && !empty && !disabled\"\n\t\t\t(click)=\"_cancelSelection($event)\"\n\t\t\tclass=\"iui-text-input__clear-icon iui-icon iui-icon_size_s\"\n\t\t\t[attr.aria-label]=\"'Clear'\"\n\t\t></iui-close-empty-icon>\n\n\t\t<span class=\"iui-text-input__suffix\">\n\t\t\t<ng-content select=\"[iui-suffix]\"></ng-content>\n\t\t</span>\n\t</div>\n\n\t<div class=\"iui-text-input__helper-row\">\n\t\t<span *ngIf=\"_errorState\" class=\"iui-text-input__error\">\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\n\t\t</span>\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-text-input__helper\">\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\n\t\t</span>\n\t</div>\n</ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;min-width:206px;max-width:100%}.iui-text-input__label-row{display:flex;align-items:flex-start;justify-content:space-between;padding-bottom:8px}.iui-text-input__label{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-label-color);flex:1;min-width:1px}.iui-text-input__required{color:var(--iui-text-input-error-color);margin-left:4px}.iui-text-input__counter{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-label-color);padding-left:8px;flex-shrink:0;white-space:nowrap}.iui-text-input__field{display:flex;align-items:center;gap:8px;overflow:hidden;background:var(--iui-text-input-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:text}:host.iui-text-input_size_l .iui-text-input__field{padding:12px 16px;border-radius:var(--iui-border-radius-medium)}:host.iui-text-input_size_m .iui-text-input__field{padding:8px 12px;border-radius:var(--iui-border-radius-medium)}:host.iui-text-input_size_s .iui-text-input__field{padding:4px 8px;border-radius:var(--iui-border-radius)}.iui-text-input__input{flex:1;min-width:0;height:20px;font:var(--iui-tp-body-01-font);color:var(--iui-text-input-color);background:transparent;border:none;outline:none;padding:0;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.iui-text-input__input::placeholder{color:var(--iui-text-input-placeholder-color)}.iui-text-input__input:disabled{color:var(--iui-text-input-disabled-color)}.iui-text-input__input:disabled::placeholder{color:var(--iui-text-input-disabled-color)}.iui-text-input__prefix,.iui-text-input__suffix{display:inline-flex;align-items:center;flex-shrink:0}.iui-text-input__prefix:empty,.iui-text-input__suffix:empty{display:none}.iui-text-input__clear-icon{flex-shrink:0;cursor:pointer;color:inherit;pointer-events:auto}:host.iui-text-input_invalid .iui-text-input__clear-icon{color:var(--iui-text-input-error-color)}.iui-text-input__helper-row{padding-top:8px}.iui-text-input__helper{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-helper-color)}.iui-text-input__error{font:var(--iui-tp-label-01-font);color:var(--iui-text-input-error-color)}:host.iui-text-input_focused .iui-text-input__field{border-color:var(--iui-text-input-focus-border)}:host.iui-text-input_invalid .iui-text-input__field{border-color:var(--iui-text-input-error-border)}:host.iui-text-input_disabled .iui-text-input__field{cursor:default;pointer-events:none}:host.iui-text-input_disabled .iui-text-input__label,:host.iui-text-input_disabled .iui-text-input__counter{color:var(--iui-text-input-disabled-color)}:host.iui-text-input_disabled .iui-text-input__helper{color:var(--iui-text-input-disabled-color)}:host.iui-text-input_layer-set-02 .iui-text-input__field{background:var(--iui-text-input-bg-layer-02)}.iui-text-input__skeleton-field{height:44px;border-radius:var(--iui-border-radius-medium);background:var(--iui-text-input-skeleton-bg)}.iui-text-input__skeleton-helper{margin-top:8px;width:40px;height:8px;background:var(--iui-text-input-skeleton-bg)}:host.iui-text-input_size_m .iui-text-input__skeleton-field{height:36px}:host.iui-text-input_size_s .iui-text-input__skeleton-field{height:28px;border-radius:var(--iui-border-radius)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { inputElement: [{
                type: ViewChildren,
                args: ['inputElement']
            }], id: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], cancelable: [{
                type: Input
            }], name: [{
                type: Input
            }], autocomplete: [{
                type: Input
            }], type: [{
                type: Input
            }], size: [{
                type: Input
            }], layerSet: [{
                type: Input
            }], showCounter: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], required: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLXRleHQtaW5wdXQuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvdGV4dC1pbnB1dC9zcmMvaXVpLXRleHQtaW5wdXQuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvdGV4dC1pbnB1dC9zcmMvaXVpLXRleHQtaW5wdXQuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNOLHVCQUF1QixFQUN2QixpQkFBaUIsRUFDakIsU0FBUyxFQUNULFVBQVUsRUFDVixLQUFLLEVBQ0wsSUFBSSxFQUNKLFlBQVksRUFDWixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDL0MsT0FBTyxFQUFFLGtCQUFrQixFQUFFLDZCQUE2QixFQUFFLHNCQUFzQixFQUFFLE1BQU0sbUNBQW1DLENBQUM7QUFDOUgsT0FBTyxFQUF3QixXQUFXLEVBQUUsaUJBQWlCLEVBQUUsVUFBVSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDbEcsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDOUQsT0FBTyxFQUFFLHVCQUF1QixFQUFFLE1BQU0sb0NBQW9DLENBQUM7Ozs7O0FBSzdFLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztBQStDckIsTUFBTSxPQUFPLHFCQUFxQjtJQUtqQywrQkFBK0I7SUFDL0IsSUFDSSxFQUFFLENBQUMsS0FBYTtRQUNuQixJQUFJLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQztJQUNsQixDQUFDO0lBRUQsSUFBSSxFQUFFO1FBQ0wsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ2pCLENBQUM7SUE2Q0QseUNBQXlDO0lBQ3pDLElBQ0ksUUFBUTtRQUNYLE9BQU8sSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLFlBQVksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksS0FBSyxDQUFDO0lBQ3RHLENBQUM7SUFFRCxJQUFJLFFBQVEsQ0FBQyxLQUEwQztRQUN0RCxJQUFJLENBQUMsU0FBUyxHQUFHLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRCxJQUFJLFFBQVE7UUFDWCxPQUFPLElBQUksQ0FBQyxFQUFFLEdBQUcsUUFBUSxDQUFDO0lBQzNCLENBQUM7SUFFRCxJQUFJLFFBQVE7UUFDWCxPQUFPLElBQUksQ0FBQyxFQUFFLEdBQUcsUUFBUSxDQUFDO0lBQzNCLENBQUM7SUFFRCxJQUFJLFFBQVE7UUFDWCxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVLENBQUM7SUFDNUMsQ0FBQztJQUVELElBQUksV0FBVztRQUNkLE9BQU8sSUFBSSxDQUFDLDBCQUEwQixDQUFDLFVBQVUsQ0FBQztJQUNuRCxDQUFDO0lBRUQsSUFBSSxLQUFLO1FBQ1IsT0FBTyxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQztJQUNqRCxDQUFDO0lBRUQsSUFBSSxZQUFZO1FBQ2YsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLElBQUksQ0FBQyxDQUFDO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO0lBQy9ELENBQUM7SUFFRCxZQUNXLGtCQUFxQyxFQUM3QixrQkFBaUQsRUFDakQsMEJBQXlELEVBQ3pELG1CQUEyQztRQUhuRCx1QkFBa0IsR0FBbEIsa0JBQWtCLENBQW1CO1FBQzdCLHVCQUFrQixHQUFsQixrQkFBa0IsQ0FBK0I7UUFDakQsK0JBQTBCLEdBQTFCLDBCQUEwQixDQUErQjtRQUN6RCx3QkFBbUIsR0FBbkIsbUJBQW1CLENBQXdCO1FBbEY5RCwyRUFBMkU7UUFFM0UsVUFBSyxHQUFHLEVBQUUsQ0FBQztRQUVYLDRGQUE0RjtRQUU1RixnQkFBVyxHQUFHLEVBQUUsQ0FBQztRQUVqQiw2REFBNkQ7UUFFN0QsZUFBVSxHQUFHLEtBQUssQ0FBQztRQUVuQiw0Q0FBNEM7UUFFNUMsU0FBSSxHQUFHLEVBQUUsQ0FBQztRQUdWLGlCQUFZLEdBQWtCLElBQUksQ0FBQztRQUVuQyw4REFBOEQ7UUFFOUQsU0FBSSxHQUFjLE1BQU0sQ0FBQztRQUV6Qiw4REFBOEQ7UUFFOUQsU0FBSSxHQUFrQixHQUFHLENBQUM7UUFFMUIsZ0VBQWdFO1FBRWhFLGFBQVEsR0FBc0IsUUFBUSxDQUFDO1FBRXZDLHlEQUF5RDtRQUV6RCxnQkFBVyxHQUFHLEtBQUssQ0FBQztRQUVwQixnRUFBZ0U7UUFFaEUsY0FBUyxHQUFrQixJQUFJLENBQUM7UUFFaEMsaURBQWlEO1FBRWpELGFBQVEsR0FBRyxLQUFLLENBQUM7UUE0RFQsY0FBUyxHQUFHLEtBQUssQ0FBQztRQUUxQixRQUFHLEdBQUcsa0JBQWtCLFlBQVksRUFBRSxFQUFFLENBQUM7UUFFekMseURBQXlEO1FBQ3pELGNBQVMsR0FBK0IsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO1FBRWpELG1FQUFtRTtRQUNuRSxlQUFVLEdBQUcsR0FBRyxFQUFFLEdBQUUsQ0FBQyxDQUFDO0lBMUJuQixDQUFDO0lBSUosbUNBQW1DO0lBQ25DLElBQUksTUFBTTtRQUNULE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUNyQixDQUFDO0lBRUQsSUFBSSxNQUFNLENBQUMsUUFBbUI7UUFDN0IsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVoRCxJQUFJLFdBQVcsRUFBRSxDQUFDO1lBQ2pCLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDMUIsQ0FBQztJQUNGLENBQUM7SUFhRCxxQ0FBcUM7SUFDckMsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUM7SUFFRCxRQUFRO1FBQ1AsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztRQUN2QixDQUFDO0lBQ0YsQ0FBQztJQUVELE9BQU87UUFDTixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN2QixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNsQixJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDeEMsQ0FBQztJQUNGLENBQUM7SUFFRCxXQUFXLENBQUMsS0FBdUI7UUFDbEMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNwQixLQUFLLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDZixDQUFDO0lBQ0YsQ0FBQztJQUVELGdCQUFnQixDQUFDLEtBQWlCO1FBQ2pDLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUV4QixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2xCLENBQUM7SUFDRixDQUFDO0lBRUQsVUFBVSxDQUFDLEtBQWdCO1FBQzFCLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDMUIsQ0FBQztJQUVELGdCQUFnQixDQUFDLEVBQThCO1FBQzlDLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxFQUFjO1FBQy9CLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO0lBQ3RCLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxVQUFtQjtRQUNuQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDdEQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ3hDLENBQUM7SUFFRCxrQkFBa0IsQ0FBQyxLQUFnQjtRQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3pCLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDdkIsQ0FBQztJQUVPLFlBQVksQ0FBQyxRQUFtQjtRQUN2QyxJQUFJLFFBQVEsS0FBSyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDL0IsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUM7WUFDeEIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksRUFBRSxDQUFDO1lBRXZDLE9BQU8sSUFBSSxDQUFDO1FBQ2IsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2QsQ0FBQzsrR0E5TFcscUJBQXFCO21HQUFyQixxQkFBcUIsNDVCQXZCdEI7WUFDVjtnQkFDQyxPQUFPLEVBQUUsaUJBQWlCO2dCQUMxQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLHFCQUFxQixDQUFDO2dCQUNwRCxLQUFLLEVBQUUsSUFBSTthQUNYO1NBQ0QsK1pDaERGLHFxRUE2REEsNHpHRG5DVyxZQUFZLGtJQUFFLFdBQVcsNDBCQUFFLHVCQUF1Qjs7NEZBdUNoRCxxQkFBcUI7a0JBMUNqQyxTQUFTOytCQUNDLGdCQUFnQixjQUNkLElBQUksV0FDUCxDQUFDLFlBQVksRUFBRSxXQUFXLEVBQUUsdUJBQXVCLENBQUMsbUJBRzVDLHVCQUF1QixDQUFDLE1BQU0sa0JBQy9CO3dCQUNmLGtCQUFrQjt3QkFDbEI7NEJBQ0MsU0FBUyxFQUFFLDZCQUE2Qjs0QkFDeEMsTUFBTSxFQUFFLENBQUMsbUJBQW1CLENBQUM7eUJBQzdCO3dCQUNEOzRCQUNDLFNBQVMsRUFBRSxzQkFBc0I7NEJBQ2pDLE1BQU0sRUFBRSxDQUFDLFlBQVksQ0FBQzs0QkFDdEIsT0FBTyxFQUFFLENBQUMsb0JBQW9CLENBQUM7eUJBQy9CO3FCQUNELGFBQ1U7d0JBQ1Y7NEJBQ0MsT0FBTyxFQUFFLGlCQUFpQjs0QkFDMUIsV0FBVyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsc0JBQXNCLENBQUM7NEJBQ3BELEtBQUssRUFBRSxJQUFJO3lCQUNYO3FCQUNELFFBQ0s7d0JBQ0wsS0FBSyxFQUFFLGdCQUFnQjt3QkFDdkIsK0JBQStCLEVBQUUsY0FBYzt3QkFDL0MsK0JBQStCLEVBQUUsY0FBYzt3QkFDL0MsK0JBQStCLEVBQUUsY0FBYzt3QkFDL0MscUNBQXFDLEVBQUUsdUJBQXVCO3dCQUM5RCxpQ0FBaUMsRUFBRSxVQUFVO3dCQUM3QyxpQ0FBaUMsRUFBRSxVQUFVO3dCQUM3QyxnQ0FBZ0MsRUFBRSxhQUFhO3dCQUMvQyxnQ0FBZ0MsRUFBRSxVQUFVO3dCQUM1QywrQkFBK0IsRUFBRSxRQUFRO3dCQUN6QyxpQ0FBaUMsRUFBRSxVQUFVO3dCQUM3QyxXQUFXLEVBQUUsSUFBSTt3QkFDakIsb0JBQW9CLEVBQUUsSUFBSTtxQkFDMUI7OzBCQWlHQyxJQUFJOzswQkFDSixJQUFJOzswQkFDSixJQUFJO3lDQTlGd0IsWUFBWTtzQkFBekMsWUFBWTt1QkFBQyxjQUFjO2dCQUl4QixFQUFFO3NCQURMLEtBQUs7Z0JBV04sS0FBSztzQkFESixLQUFLO2dCQUtOLFdBQVc7c0JBRFYsS0FBSztnQkFLTixVQUFVO3NCQURULEtBQUs7Z0JBS04sSUFBSTtzQkFESCxLQUFLO2dCQUlOLFlBQVk7c0JBRFgsS0FBSztnQkFLTixJQUFJO3NCQURILEtBQUs7Z0JBS04sSUFBSTtzQkFESCxLQUFLO2dCQUtOLFFBQVE7c0JBRFAsS0FBSztnQkFLTixXQUFXO3NCQURWLEtBQUs7Z0JBS04sU0FBUztzQkFEUixLQUFLO2dCQUtOLFFBQVE7c0JBRFAsS0FBSztnQkFLRixRQUFRO3NCQURYLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuXHRDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcblx0Q2hhbmdlRGV0ZWN0b3JSZWYsXG5cdENvbXBvbmVudCwgRWxlbWVudFJlZixcblx0Zm9yd2FyZFJlZixcblx0SW5wdXQsXG5cdFNlbGYsXG5cdFZpZXdDaGlsZHJlblxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBOZ0NvbnRyb2xEaXJlY3RpdmUsIEl1aUVycm9yU3RhdGVNYXRjaGVyRGlyZWN0aXZlLCBJdWlJc0Rpc2FibGVkRGlyZWN0aXZlIH0gZnJvbSAnQGl0ZXJvL3VpLWNvbXBvbmVudHMtYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBGb3Jtc01vZHVsZSwgTkdfVkFMVUVfQUNDRVNTT1IsIFZhbGlkYXRvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBjb2VyY2VCb29sZWFuUHJvcGVydHkgfSBmcm9tICdAYW5ndWxhci9jZGsvY29lcmNpb24nO1xuaW1wb3J0IHsgQ2xvc2VFbXB0eUljb25Db21wb25lbnQgfSBmcm9tICdAaXRlcm8vdWktY29tcG9uZW50cy1hbmd1bGFyL2ljb25zJztcblxuZXhwb3J0IHR5cGUgVGV4dElucHV0U2l6ZSA9ICdsJyB8ICdtJyB8ICdzJztcbmV4cG9ydCB0eXBlIFRleHRJbnB1dExheWVyU2V0ID0gJ3NldC0wMScgfCAnc2V0LTAyJztcblxubGV0IG5leHRVbmlxdWVJZCA9IDA7XG5cbnR5cGUgVmFsdWVUeXBlID0gc3RyaW5nIHwgbnVsbDsgLy8gY2FuIGJlIGNoYW5nZWQgaW4gZnV0dXJlXG50eXBlIElucHV0VHlwZSA9ICd0ZXh0JyB8ICdwYXNzd29yZCcgfCAnZW1haWwnO1xuXG5AQ29tcG9uZW50KHtcblx0c2VsZWN0b3I6ICdpdWktdGV4dC1pbnB1dCcsXG5cdHN0YW5kYWxvbmU6IHRydWUsXG5cdGltcG9ydHM6IFtDb21tb25Nb2R1bGUsIEZvcm1zTW9kdWxlLCBDbG9zZUVtcHR5SWNvbkNvbXBvbmVudF0sXG5cdHRlbXBsYXRlVXJsOiAnLi9pdWktdGV4dC1pbnB1dC5jb21wb25lbnQuaHRtbCcsXG5cdHN0eWxlVXJsczogWycuL2l1aS10ZXh0LWlucHV0LmNvbXBvbmVudC5zY3NzJ10sXG5cdGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxuXHRob3N0RGlyZWN0aXZlczogW1xuXHRcdE5nQ29udHJvbERpcmVjdGl2ZSxcblx0XHR7XG5cdFx0XHRkaXJlY3RpdmU6IEl1aUVycm9yU3RhdGVNYXRjaGVyRGlyZWN0aXZlLFxuXHRcdFx0aW5wdXRzOiBbJ2Vycm9yU3RhdGVNYXRjaGVyJ11cblx0XHR9LFxuXHRcdHtcblx0XHRcdGRpcmVjdGl2ZTogSXVpSXNEaXNhYmxlZERpcmVjdGl2ZSxcblx0XHRcdGlucHV0czogWydpc0Rpc2FibGVkJ10sXG5cdFx0XHRvdXRwdXRzOiBbJ2Rpc2FibGVDaGFuZ2VFdmVudCddXG5cdFx0fVxuXHRdLFxuXHRwcm92aWRlcnM6IFtcblx0XHR7XG5cdFx0XHRwcm92aWRlOiBOR19WQUxVRV9BQ0NFU1NPUixcblx0XHRcdHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IEl1aVRleHRJbnB1dENvbXBvbmVudCksXG5cdFx0XHRtdWx0aTogdHJ1ZVxuXHRcdH1cblx0XSxcblx0aG9zdDoge1xuXHRcdGNsYXNzOiAnaXVpLXRleHQtaW5wdXQnLFxuXHRcdCdbY2xhc3MuaXVpLXRleHQtaW5wdXRfc2l6ZV9sXSc6ICdzaXplID09PSBcImxcIicsXG5cdFx0J1tjbGFzcy5pdWktdGV4dC1pbnB1dF9zaXplX21dJzogJ3NpemUgPT09IFwibVwiJyxcblx0XHQnW2NsYXNzLml1aS10ZXh0LWlucHV0X3NpemVfc10nOiAnc2l6ZSA9PT0gXCJzXCInLFxuXHRcdCdbY2xhc3MuaXVpLXRleHQtaW5wdXRfbGF5ZXItc2V0LTAyXSc6ICdsYXllclNldCA9PT0gXCJzZXQtMDJcIicsXG5cdFx0J1tjbGFzcy5pdWktdGV4dC1pbnB1dF9yZXF1aXJlZF0nOiAncmVxdWlyZWQnLFxuXHRcdCdbY2xhc3MuaXVpLXRleHQtaW5wdXRfZGlzYWJsZWRdJzogJ2Rpc2FibGVkJyxcblx0XHQnW2NsYXNzLml1aS10ZXh0LWlucHV0X2ludmFsaWRdJzogJ19lcnJvclN0YXRlJyxcblx0XHQnW2NsYXNzLml1aS10ZXh0LWlucHV0X2ZvY3VzZWRdJzogJ19mb2N1c2VkJyxcblx0XHQnW2NsYXNzLml1aS10ZXh0LWlucHV0X2ZpbGxlZF0nOiAnIWVtcHR5Jyxcblx0XHQnW2NsYXNzLml1aS10ZXh0LWlucHV0X3NrZWxldG9uXSc6ICdza2VsZXRvbicsXG5cdFx0J1thdHRyLmlkXSc6ICdpZCcsXG5cdFx0J1thdHRyLmRhdGEtdGVzdGlkXSc6ICdpZCdcblx0fVxufSlcbmV4cG9ydCBjbGFzcyBJdWlUZXh0SW5wdXRDb21wb25lbnQgaW1wbGVtZW50cyBDb250cm9sVmFsdWVBY2Nlc3NvciB7XG5cblx0LyoqIFRoZSByZWYgdG8gbmF0aXZlIGlucHV0IGVsZW1lbnQuIFlvdSBjYW4gdXNlIGl0IGFuZCBwYXNzIGF0dHJpYnV0ZXMgb3IgZXZlbnRzIHRvIG5hdGl2ZSBpbnB1dCAqL1xuXHRAVmlld0NoaWxkcmVuKCdpbnB1dEVsZW1lbnQnKSBpbnB1dEVsZW1lbnQ6IEVsZW1lbnRSZWYgfCB1bmRlZmluZWQ7XG5cblx0LyoqIFVuaXF1ZSBpZCBvZiB0aGUgZWxlbWVudCAqL1xuXHRASW5wdXQoKVxuXHRzZXQgaWQodmFsdWU6IHN0cmluZykge1xuXHRcdHRoaXMuX2lkID0gdmFsdWU7XG5cdH1cblxuXHRnZXQgaWQoKSB7XG5cdFx0cmV0dXJuIHRoaXMuX2lkO1xuXHR9XG5cblx0LyoqIExhYmVsIG9mIGNvbXBvbmVudCwgZGVmYXVsdCBpcyAnJywgc3Ryb25nbHkgcmVjb21tZW5kZWQgdG8gYmUgZmlsbGVkICovXG5cdEBJbnB1dCgpXG5cdGxhYmVsID0gJyc7XG5cblx0LyoqIFBsYWNlaG9sZGVyIG9mIGNvbXBvbmVudCwgcmVuZGVyZWQgaW4gdGhlIHBsYWNlIG9mIHRoZSB2YWx1ZSB3aGVuIG5vIHNlbGVjdGlvbnMvaW5wdXQgKi9cblx0QElucHV0KClcblx0cGxhY2Vob2xkZXIgPSAnJztcblxuXHQvKiogV2hldGhlciB0aGUgaW5wdXQgY29udGFpbnMgXCJYXCIgaWNvbiB0byBjbGVhciB0aGUgZmllbGQgKi9cblx0QElucHV0KClcblx0Y2FuY2VsYWJsZSA9IGZhbHNlO1xuXG5cdC8qKiBOYW1lIGFzc2lnbmVkIHRvIGlucHV0IGVsZW1lbnQgaW5zaWRlICovXG5cdEBJbnB1dCgpXG5cdG5hbWUgPSAnJztcblxuXHRASW5wdXQoKVxuXHRhdXRvY29tcGxldGU6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuXG5cdC8qKiBUeXBlIG9mIGlucHV0IGVsZW1lbnQsIHN1cHBvcnRlZDogdGV4dCwgcGFzc3dvcmQsIGVtYWlsICovXG5cdEBJbnB1dCgpXG5cdHR5cGU6IElucHV0VHlwZSA9ICd0ZXh0JztcblxuXHQvKiogU2l6ZSBvZiB0aGUgaW5wdXQgZmllbGQ6IGxhcmdlIChkZWZhdWx0KSwgbWVkaXVtLCBzbWFsbCAqL1xuXHRASW5wdXQoKVxuXHRzaXplOiBUZXh0SW5wdXRTaXplID0gJ2wnO1xuXG5cdC8qKiBMYXllciBzZXQ6IHNldC0wMSAod2hpdGUgYmcsIGRlZmF1bHQpIG9yIHNldC0wMiAoZ3JheSBiZykgKi9cblx0QElucHV0KClcblx0bGF5ZXJTZXQ6IFRleHRJbnB1dExheWVyU2V0ID0gJ3NldC0wMSc7XG5cblx0LyoqIFdoZXRoZXIgdG8gc2hvdyBjaGFyYWN0ZXIgY291bnRlciBpbiB0aGUgbGFiZWwgcm93ICovXG5cdEBJbnB1dCgpXG5cdHNob3dDb3VudGVyID0gZmFsc2U7XG5cblx0LyoqIE1heCBjaGFyYWN0ZXIgbGVuZ3RoOyBkaXNwbGF5ZWQgaW4gY291bnRlciBhcyBjdXJyZW50L21heCAqL1xuXHRASW5wdXQoKVxuXHRtYXhMZW5ndGg6IG51bWJlciB8IG51bGwgPSBudWxsO1xuXG5cdC8qKiBXaGV0aGVyIHRvIHNob3cgdGhlIHNrZWxldG9uIGxvYWRpbmcgc3RhdGUgKi9cblx0QElucHV0KClcblx0c2tlbGV0b24gPSBmYWxzZTtcblxuXHQvKiogV2hldGhlciB0aGUgY29tcG9uZW50IGlzIHJlcXVpcmVkLiAqL1xuXHRASW5wdXQoKVxuXHRnZXQgcmVxdWlyZWQoKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuX3JlcXVpcmVkID8/IHRoaXMubmdDb250cm9sRGlyZWN0aXZlLmNvbnRyb2w/Lmhhc1ZhbGlkYXRvcihWYWxpZGF0b3JzLnJlcXVpcmVkKSA/PyBmYWxzZTtcblx0fVxuXG5cdHNldCByZXF1aXJlZCh2YWx1ZTogc3RyaW5nIHwgYm9vbGVhbiB8IG51bGwgfCB1bmRlZmluZWQpIHtcblx0XHR0aGlzLl9yZXF1aXJlZCA9IGNvZXJjZUJvb2xlYW5Qcm9wZXJ0eSh2YWx1ZSk7XG5cdH1cblxuXHRnZXQgX2xhYmVsSWQoKSB7XG5cdFx0cmV0dXJuIHRoaXMuaWQgKyAnLWxhYmVsJztcblx0fVxuXG5cdGdldCBfaW5wdXRJZCgpIHtcblx0XHRyZXR1cm4gdGhpcy5pZCArICctaW5wdXQnO1xuXHR9XG5cblx0Z2V0IGRpc2FibGVkKCk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiB0aGlzLmlzRGlzYWJsZWREaXJlY3RpdmUuaXNEaXNhYmxlZDtcblx0fVxuXG5cdGdldCBfZXJyb3JTdGF0ZSgpIHtcblx0XHRyZXR1cm4gdGhpcy5lcnJvclN0YXRlTWF0Y2hlckRpcmVjdGl2ZS5lcnJvclN0YXRlO1xuXHR9XG5cblx0Z2V0IGVtcHR5KCkge1xuXHRcdHJldHVybiB0aGlzLl92YWx1ZSA9PSBudWxsIHx8IHRoaXMuX3ZhbHVlID09ICcnO1xuXHR9XG5cblx0Z2V0IF9jb3VudGVyVGV4dCgpOiBzdHJpbmcge1xuXHRcdGNvbnN0IGxlbiA9IHRoaXMuX3ZhbHVlPy5sZW5ndGggPz8gMDtcblx0XHRyZXR1cm4gdGhpcy5tYXhMZW5ndGggPyBgJHtsZW59LyR7dGhpcy5tYXhMZW5ndGh9YCA6IGAke2xlbn1gO1xuXHR9XG5cblx0Y29uc3RydWN0b3IoXG5cdFx0cHJvdGVjdGVkIF9jaGFuZ2VEZXRlY3RvclJlZjogQ2hhbmdlRGV0ZWN0b3JSZWYsXG5cdFx0QFNlbGYoKSBwcm90ZWN0ZWQgbmdDb250cm9sRGlyZWN0aXZlOiBOZ0NvbnRyb2xEaXJlY3RpdmU8VmFsdWVUeXBlPixcblx0XHRAU2VsZigpIHByb3RlY3RlZCBlcnJvclN0YXRlTWF0Y2hlckRpcmVjdGl2ZTogSXVpRXJyb3JTdGF0ZU1hdGNoZXJEaXJlY3RpdmUsXG5cdFx0QFNlbGYoKSBwcm90ZWN0ZWQgaXNEaXNhYmxlZERpcmVjdGl2ZTogSXVpSXNEaXNhYmxlZERpcmVjdGl2ZVxuXHQpIHt9XG5cblx0cHJpdmF0ZSBfX3ZhbHVlITogVmFsdWVUeXBlO1xuXG5cdC8qKiBWYWx1ZSBvZiB0aGUgc2VsZWN0IGNvbnRyb2wuICovXG5cdGdldCBfdmFsdWUoKTogVmFsdWVUeXBlIHtcblx0XHRyZXR1cm4gdGhpcy5fX3ZhbHVlO1xuXHR9XG5cblx0c2V0IF92YWx1ZShuZXdWYWx1ZTogVmFsdWVUeXBlKSB7XG5cdFx0Y29uc3QgaGFzQXNzaWduZWQgPSB0aGlzLl9hc3NpZ25WYWx1ZShuZXdWYWx1ZSk7XG5cblx0XHRpZiAoaGFzQXNzaWduZWQpIHtcblx0XHRcdHRoaXMuX29uQ2hhbmdlKG5ld1ZhbHVlKTtcblx0XHR9XG5cdH1cblxuXHRwcml2YXRlIF9yZXF1aXJlZDogYm9vbGVhbiB8IHVuZGVmaW5lZDtcblx0cHJpdmF0ZSBfX2ZvY3VzZWQgPSBmYWxzZTtcblxuXHRfaWQgPSBgaXVpLXRleHQtaW5wdXQtJHtuZXh0VW5pcXVlSWQrK31gO1xuXG5cdC8qKiBgVmlldyAtPiBtb2RlbCBjYWxsYmFjayBjYWxsZWQgd2hlbiB2YWx1ZSBjaGFuZ2VzYCAqL1xuXHRfb25DaGFuZ2U6ICh2YWx1ZTogVmFsdWVUeXBlKSA9PiB2b2lkID0gKCkgPT4ge307XG5cblx0LyoqIGBWaWV3IC0+IG1vZGVsIGNhbGxiYWNrIGNhbGxlZCB3aGVuIHNlbGVjdCBoYXMgYmVlbiB0b3VjaGVkYCAqL1xuXHRfb25Ub3VjaGVkID0gKCkgPT4ge307XG5cblx0LyoqIFdoZXRoZXIgdGhlIHNlbGVjdCBpcyBmb2N1c2VkLiAqL1xuXHRnZXQgX2ZvY3VzZWQoKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuX19mb2N1c2VkO1xuXHR9XG5cblx0X29uRm9jdXMoKSB7XG5cdFx0aWYgKCF0aGlzLmRpc2FibGVkKSB7XG5cdFx0XHR0aGlzLl9fZm9jdXNlZCA9IHRydWU7XG5cdFx0fVxuXHR9XG5cblx0X29uQmx1cigpIHtcblx0XHR0aGlzLl9fZm9jdXNlZCA9IGZhbHNlO1xuXHRcdGlmICghdGhpcy5kaXNhYmxlZCkge1xuXHRcdFx0dGhpcy5fb25Ub3VjaGVkKCk7XG5cdFx0XHR0aGlzLl9jaGFuZ2VEZXRlY3RvclJlZi5tYXJrRm9yQ2hlY2soKTtcblx0XHR9XG5cdH1cblxuXHRfZm9jdXNJbnB1dChpbnB1dDogSFRNTElucHV0RWxlbWVudCkge1xuXHRcdGlmICghdGhpcy5kaXNhYmxlZCkge1xuXHRcdFx0aW5wdXQuZm9jdXMoKTtcblx0XHR9XG5cdH1cblxuXHRfY2FuY2VsU2VsZWN0aW9uKGV2ZW50OiBNb3VzZUV2ZW50KSB7XG5cdFx0ZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG5cblx0XHRpZiAoIXRoaXMuZGlzYWJsZWQpIHtcblx0XHRcdHRoaXMuX3ZhbHVlID0gJyc7XG5cdFx0fVxuXHR9XG5cblx0d3JpdGVWYWx1ZSh2YWx1ZTogVmFsdWVUeXBlKTogdm9pZCB7XG5cdFx0dGhpcy5fYXNzaWduVmFsdWUodmFsdWUpO1xuXHR9XG5cblx0cmVnaXN0ZXJPbkNoYW5nZShmbjogKHZhbHVlOiBWYWx1ZVR5cGUpID0+IHZvaWQpOiB2b2lkIHtcblx0XHR0aGlzLl9vbkNoYW5nZSA9IGZuO1xuXHR9XG5cblx0cmVnaXN0ZXJPblRvdWNoZWQoZm46ICgpID0+IHZvaWQpOiB2b2lkIHtcblx0XHR0aGlzLl9vblRvdWNoZWQgPSBmbjtcblx0fVxuXG5cdHNldERpc2FibGVkU3RhdGUoaXNEaXNhYmxlZDogYm9vbGVhbik6IHZvaWQge1xuXHRcdHRoaXMuaXNEaXNhYmxlZERpcmVjdGl2ZS5zZXREaXNhYmxlZFN0YXRlKGlzRGlzYWJsZWQpO1xuXHRcdHRoaXMuX2NoYW5nZURldGVjdG9yUmVmLm1hcmtGb3JDaGVjaygpO1xuXHR9XG5cblx0bW9kZWxDaGFuZ2VIYW5kbGVyKHZhbHVlOiBWYWx1ZVR5cGUpIHtcblx0XHR0aGlzLl9hc3NpZ25WYWx1ZSh2YWx1ZSk7XG5cdFx0dGhpcy5fb25DaGFuZ2UodmFsdWUpO1xuXHR9XG5cblx0cHJpdmF0ZSBfYXNzaWduVmFsdWUobmV3VmFsdWU6IFZhbHVlVHlwZSk6IGJvb2xlYW4ge1xuXHRcdGlmIChuZXdWYWx1ZSAhPT0gdGhpcy5fX3ZhbHVlKSB7XG5cdFx0XHR0aGlzLl9fdmFsdWUgPSBuZXdWYWx1ZTtcblx0XHRcdHRoaXMuX2NoYW5nZURldGVjdG9yUmVmLm1hcmtGb3JDaGVjaygpO1xuXG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9XG5cblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cbn1cbiIsIjxuZy1jb250YWluZXIgKm5nSWY9XCJza2VsZXRvbjsgZWxzZSBub3JtYWxUZW1wbGF0ZVwiPlxuXHQ8ZGl2IGNsYXNzPVwiaXVpLXRleHQtaW5wdXRfX3NrZWxldG9uLWZpZWxkXCI+PC9kaXY+XG5cdDxkaXYgY2xhc3M9XCJpdWktdGV4dC1pbnB1dF9fc2tlbGV0b24taGVscGVyXCI+PC9kaXY+XG48L25nLWNvbnRhaW5lcj5cblxuPG5nLXRlbXBsYXRlICNub3JtYWxUZW1wbGF0ZT5cblx0PGRpdiBjbGFzcz1cIml1aS10ZXh0LWlucHV0X19sYWJlbC1yb3dcIiAqbmdJZj1cImxhYmVsIHx8IHNob3dDb3VudGVyXCI+XG5cdFx0PGxhYmVsICpuZ0lmPVwibGFiZWxcIiBjbGFzcz1cIml1aS10ZXh0LWlucHV0X19sYWJlbFwiIFthdHRyLmZvcl09XCJfaW5wdXRJZFwiIFtpZF09XCJfbGFiZWxJZFwiPlxuXHRcdFx0e3sgbGFiZWwgfX08c3BhbiBjbGFzcz1cIml1aS10ZXh0LWlucHV0X19yZXF1aXJlZFwiICpuZ0lmPVwicmVxdWlyZWRcIj4qPC9zcGFuPlxuXHRcdDwvbGFiZWw+XG5cdFx0PHNwYW4gY2xhc3M9XCJpdWktdGV4dC1pbnB1dF9fY291bnRlclwiICpuZ0lmPVwic2hvd0NvdW50ZXJcIj57eyBfY291bnRlclRleHQgfX08L3NwYW4+XG5cdDwvZGl2PlxuXG5cdDxkaXYgY2xhc3M9XCJpdWktdGV4dC1pbnB1dF9fZmllbGRcIiAoY2xpY2spPVwiX2ZvY3VzSW5wdXQoaW5wdXRFbGVtZW50KVwiPlxuXHRcdDxzcGFuIGNsYXNzPVwiaXVpLXRleHQtaW5wdXRfX3ByZWZpeFwiPlxuXHRcdFx0PG5nLWNvbnRlbnQgc2VsZWN0PVwiW2l1aS1wcmVmaXhdXCI+PC9uZy1jb250ZW50PlxuXHRcdDwvc3Bhbj5cblxuXHRcdDxpbnB1dFxuXHRcdFx0I2lucHV0RWxlbWVudFxuXHRcdFx0Y2xhc3M9XCJpdWktdGV4dC1pbnB1dF9faW5wdXRcIlxuXHRcdFx0W3JlcXVpcmVkXT1cInJlcXVpcmVkXCJcblx0XHRcdFtkaXNhYmxlZF09XCJkaXNhYmxlZFwiXG5cdFx0XHRbYXR0ci5hcmlhLWludmFsaWRdPVwiX2Vycm9yU3RhdGVcIlxuXHRcdFx0W2F0dHIuYXJpYS1kaXNhYmxlZF09XCJkaXNhYmxlZC50b1N0cmluZygpXCJcblx0XHRcdFthdHRyLmFyaWEtbGFiZWxsZWRieV09XCJsYWJlbCA/IF9sYWJlbElkIDogbnVsbFwiXG5cdFx0XHRbYXR0ci5hdXRvY29tcGxldGVdPVwiYXV0b2NvbXBsZXRlXCJcblx0XHRcdFthdHRyLm1heGxlbmd0aF09XCJtYXhMZW5ndGhcIlxuXHRcdFx0W3BsYWNlaG9sZGVyXT1cInBsYWNlaG9sZGVyXCJcblx0XHRcdFtuYW1lXT1cIm5hbWVcIlxuXHRcdFx0W2F0dHIubmFtZV09XCJuYW1lXCJcblx0XHRcdFt0eXBlXT1cInR5cGVcIlxuXHRcdFx0W2lkXT1cIl9pbnB1dElkXCJcblx0XHRcdFt2YWx1ZV09XCJfdmFsdWVcIlxuXHRcdFx0W25nTW9kZWxdPVwiX3ZhbHVlXCJcblx0XHRcdChuZ01vZGVsQ2hhbmdlKT1cIm1vZGVsQ2hhbmdlSGFuZGxlcigkZXZlbnQpXCJcblx0XHRcdChmb2N1cyk9XCJfb25Gb2N1cygpXCJcblx0XHRcdChibHVyKT1cIl9vbkJsdXIoKVwiXG5cdFx0Lz5cblxuXHRcdDxpdWktY2xvc2UtZW1wdHktaWNvblxuXHRcdFx0Km5nSWY9XCJjYW5jZWxhYmxlICYmICFlbXB0eSAmJiAhZGlzYWJsZWRcIlxuXHRcdFx0KGNsaWNrKT1cIl9jYW5jZWxTZWxlY3Rpb24oJGV2ZW50KVwiXG5cdFx0XHRjbGFzcz1cIml1aS10ZXh0LWlucHV0X19jbGVhci1pY29uIGl1aS1pY29uIGl1aS1pY29uX3NpemVfc1wiXG5cdFx0XHRbYXR0ci5hcmlhLWxhYmVsXT1cIidDbGVhcidcIlxuXHRcdD48L2l1aS1jbG9zZS1lbXB0eS1pY29uPlxuXG5cdFx0PHNwYW4gY2xhc3M9XCJpdWktdGV4dC1pbnB1dF9fc3VmZml4XCI+XG5cdFx0XHQ8bmctY29udGVudCBzZWxlY3Q9XCJbaXVpLXN1ZmZpeF1cIj48L25nLWNvbnRlbnQ+XG5cdFx0PC9zcGFuPlxuXHQ8L2Rpdj5cblxuXHQ8ZGl2IGNsYXNzPVwiaXVpLXRleHQtaW5wdXRfX2hlbHBlci1yb3dcIj5cblx0XHQ8c3BhbiAqbmdJZj1cIl9lcnJvclN0YXRlXCIgY2xhc3M9XCJpdWktdGV4dC1pbnB1dF9fZXJyb3JcIj5cblx0XHRcdDxuZy1jb250ZW50IHNlbGVjdD1cIltpdWktZXJyb3JdXCI+PC9uZy1jb250ZW50PlxuXHRcdDwvc3Bhbj5cblx0XHQ8c3BhbiAqbmdJZj1cIiFfZXJyb3JTdGF0ZVwiIGNsYXNzPVwiaXVpLXRleHQtaW5wdXRfX2hlbHBlclwiPlxuXHRcdFx0PG5nLWNvbnRlbnQgc2VsZWN0PVwiW2l1aS1oaW50XVwiPjwvbmctY29udGVudD5cblx0XHQ8L3NwYW4+XG5cdDwvZGl2PlxuPC9uZy10ZW1wbGF0ZT5cbiJdfQ==