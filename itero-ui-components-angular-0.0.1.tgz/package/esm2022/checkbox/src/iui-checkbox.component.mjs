import { Component, EventEmitter, forwardRef, inject, Input, Output } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgControlDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import { IuiCheckboxMarkComponent } from '@itero/ui-components-angular/checkbox-mark';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
import * as i2 from "@angular/common";
let nextUniqueId = 0;
export class IuiCheckboxComponent {
    constructor() {
        /** The unique id of the element */
        this.id = `iui-checkbox-${nextUniqueId++}`;
        this.showValue = true;
        this.skeleton = false;
        /**
         * @prop
         * @ignore
         */
        this._touched = false;
        /**
         * @prop
         * @ignore
         */
        this._checked = false;
        /**
         * @prop
         * @ignore
         */
        this._indeterminate = false;
        /**
         * @prop
         * @ignore
         */
        this.isDisabledDirective = inject(IuiIsDisabledDirective, { self: true });
        this.changeEvent = new EventEmitter();
        this.indeterminateChanged = new EventEmitter();
        /**
         * @prop
         * @ignore
         */
        this.propagateChange = () => undefined;
        /**
         * @prop
         * @ignore
         */
        this.propagateTouched = () => undefined;
    }
    /**
     * @prop
     * @ignore
     */
    get _markId() {
        return this.id + '-mark';
    }
    /**
     * @prop
     * @ignore
     */
    get _labelId() {
        return this.id + '-label';
    }
    /**
     * input where you can pass desirable state of checkbox "true" or "false".
     * Can be helpful when you don't use formControl, otherwise you can patchValue of formControl
     * */
    set checked(value) {
        this._checked = value;
        this.indeterminate = false;
    }
    get checked() {
        return this._checked;
    }
    set indeterminate(value) {
        const updateCheckedState = (newIndeterminateState) => {
            if (newIndeterminateState) {
                this._checked = false;
            }
        };
        this.setIndeterminateInternal(value, updateCheckedState);
    }
    get indeterminate() {
        return this._indeterminate;
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled || this.skeleton;
    }
    /**
     * @method
     * @ignore
     */
    _blurHandler() {
        if (this.disabled) {
            return;
        }
        this.markAsTouched();
    }
    /**
     * @method
     * @ignore
     */
    setIndeterminateInternal(value, cb) {
        const changed = value !== this._indeterminate;
        this._indeterminate = value;
        if (changed) {
            if (cb) {
                cb(this._indeterminate);
            }
            this.indeterminateChanged.emit(this._indeterminate);
        }
    }
    /**
     * @method
     * @ignore
     */
    markAsTouched() {
        if (!this._touched) {
            this.propagateTouched();
            this._touched = true;
        }
    }
    /**
     * @method
     * @ignore
     */
    _changeHandler(event) {
        if (this.disabled) {
            return;
        }
        this._checked = !this.checked;
        this.setIndeterminateInternal(false);
        this.markAsTouched();
        this.propagateChange(this._checked);
        this.changeEvent.emit({
            event,
            checked: this._checked
        });
    }
    writeValue(val) {
        this._checked = val;
        this.setIndeterminateInternal(false);
    }
    registerOnChange(fn) {
        this.propagateChange = fn;
    }
    registerOnTouched(fn) {
        this.propagateTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiCheckboxComponent, isStandalone: true, selector: "iui-checkbox", inputs: { id: "id", showValue: "showValue", skeleton: "skeleton", checked: "checked", indeterminate: "indeterminate" }, outputs: { changeEvent: "changeEvent", indeterminateChanged: "indeterminateChanged" }, host: { properties: { "class.iui-checkbox_checked": "checked", "class.iui-checkbox_indeterminate": "indeterminate", "class.iui-checkbox_disabled": "disabled", "class.iui-checkbox_skeleton": "skeleton", "class.iui-checkbox_hide-value": "!showValue", "attr.id": "id", "attr.data-testid": "id" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiCheckboxComponent),
                multi: true
            }
        ], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<label class=\"iui-checkbox__container\"\n\t[attr.data-testid]=\"_labelId\"\n\t[attr.id]=\"_labelId\">\n\t<iui-checkbox-mark\n\t\tclass=\"iui-checkbox__trigger\"\n\t\t[id]=\"_markId\"\n\t\t[isDisabled]=\"disabled\"\n\t\t[skeleton]=\"skeleton\"\n\t\t(change)=\"_changeHandler($event)\"\n\t\t(blurEvent)=\"_blurHandler()\"\n\t\t[checked]=\"checked\"\n\t\t[indeterminate]=\"indeterminate\"\n\t></iui-checkbox-mark>\n\n\t<div class=\"iui-checkbox__label-text\" *ngIf=\"showValue && !skeleton\">\n\t\t<ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container>\n\t</div>\n\n\t<div class=\"iui-checkbox__skeleton-box\" *ngIf=\"skeleton\"></div>\n</label>\n\n<ng-template #contentTpl>\n\t<div>\n\t\t<ng-content></ng-content>\n\t</div>\n\t<div class=\"iui-checkbox__label-desc\">\n\t\t<ng-content select=\"[description]\"></ng-content>\n\t</div>\n</ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:block}.iui-checkbox__container{display:flex;align-items:flex-start;gap:8px;cursor:pointer;padding:0}:host(.iui-checkbox_disabled) .iui-checkbox__container{pointer-events:none;cursor:default}:host(.iui-checkbox_skeleton) .iui-checkbox__container{align-items:center;pointer-events:none;cursor:default}.iui-checkbox__trigger{flex-shrink:0;margin:0}.iui-checkbox__label-text{font:var(--iui-tp-body-01-font);color:var(--iui-checkbox-label-color)}:host(.iui-checkbox_disabled) .iui-checkbox__label-text{color:var(--iui-checkbox-label-disabled-color)}.iui-checkbox__label-desc{font:var(--iui-tp-label-01-font);color:var(--iui-checkbox-label-color)}:host(.iui-checkbox_disabled) .iui-checkbox__label-desc{color:var(--iui-checkbox-label-disabled-color)}.iui-checkbox__skeleton-box{width:40px;height:8px;background-color:var(--iui-checkbox-skeleton-bg);flex-shrink:0}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: IuiCheckboxMarkComponent, selector: "iui-checkbox-mark", inputs: ["id", "skeleton", "checked", "indeterminate"], outputs: ["blurEvent", "changeEvent", "indeterminateChanged"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-checkbox', standalone: true, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiCheckboxComponent),
                            multi: true
                        }
                    ], imports: [CommonModule, IuiCheckboxMarkComponent], hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiIsDisabledDirective,
                            // eslint-disable-next-line @angular-eslint/no-inputs-metadata-property
                            inputs: ['isDisabled'],
                            // eslint-disable-next-line @angular-eslint/no-outputs-metadata-property
                            outputs: ['disableChangeEvent']
                        }
                    ], host: {
                        '[class.iui-checkbox_checked]': 'checked',
                        '[class.iui-checkbox_indeterminate]': 'indeterminate',
                        '[class.iui-checkbox_disabled]': 'disabled',
                        '[class.iui-checkbox_skeleton]': 'skeleton',
                        '[class.iui-checkbox_hide-value]': '!showValue',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<label class=\"iui-checkbox__container\"\n\t[attr.data-testid]=\"_labelId\"\n\t[attr.id]=\"_labelId\">\n\t<iui-checkbox-mark\n\t\tclass=\"iui-checkbox__trigger\"\n\t\t[id]=\"_markId\"\n\t\t[isDisabled]=\"disabled\"\n\t\t[skeleton]=\"skeleton\"\n\t\t(change)=\"_changeHandler($event)\"\n\t\t(blurEvent)=\"_blurHandler()\"\n\t\t[checked]=\"checked\"\n\t\t[indeterminate]=\"indeterminate\"\n\t></iui-checkbox-mark>\n\n\t<div class=\"iui-checkbox__label-text\" *ngIf=\"showValue && !skeleton\">\n\t\t<ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container>\n\t</div>\n\n\t<div class=\"iui-checkbox__skeleton-box\" *ngIf=\"skeleton\"></div>\n</label>\n\n<ng-template #contentTpl>\n\t<div>\n\t\t<ng-content></ng-content>\n\t</div>\n\t<div class=\"iui-checkbox__label-desc\">\n\t\t<ng-content select=\"[description]\"></ng-content>\n\t</div>\n</ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:block}.iui-checkbox__container{display:flex;align-items:flex-start;gap:8px;cursor:pointer;padding:0}:host(.iui-checkbox_disabled) .iui-checkbox__container{pointer-events:none;cursor:default}:host(.iui-checkbox_skeleton) .iui-checkbox__container{align-items:center;pointer-events:none;cursor:default}.iui-checkbox__trigger{flex-shrink:0;margin:0}.iui-checkbox__label-text{font:var(--iui-tp-body-01-font);color:var(--iui-checkbox-label-color)}:host(.iui-checkbox_disabled) .iui-checkbox__label-text{color:var(--iui-checkbox-label-disabled-color)}.iui-checkbox__label-desc{font:var(--iui-tp-label-01-font);color:var(--iui-checkbox-label-color)}:host(.iui-checkbox_disabled) .iui-checkbox__label-desc{color:var(--iui-checkbox-label-disabled-color)}.iui-checkbox__skeleton-box{width:40px;height:8px;background-color:var(--iui-checkbox-skeleton-bg);flex-shrink:0}\n"] }]
        }], propDecorators: { id: [{
                type: Input
            }], showValue: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], checked: [{
                type: Input
            }], indeterminate: [{
                type: Input
            }], changeEvent: [{
                type: Output
            }], indeterminateChanged: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLWNoZWNrYm94LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL2xpYnMvdWktY29tcG9uZW50cy1hbmd1bGFyLXB1Ymxpc2hhYmxlL2NoZWNrYm94L3NyYy9pdWktY2hlY2tib3guY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvY2hlY2tib3gvc3JjL2l1aS1jaGVja2JveC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0YsT0FBTyxFQUF3QixpQkFBaUIsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3pFLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMvQyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQztBQUMvRixPQUFPLEVBQUUsd0JBQXdCLEVBQUUsTUFBTSw0Q0FBNEMsQ0FBQzs7OztBQVV0RixJQUFJLFlBQVksR0FBRyxDQUFDLENBQUM7QUFtQ3JCLE1BQU0sT0FBTyxvQkFBb0I7SUFqQ2pDO1FBa0NDLG1DQUFtQztRQUVuQyxPQUFFLEdBQUcsZ0JBQWdCLFlBQVksRUFBRSxFQUFFLENBQUM7UUFHdEMsY0FBUyxHQUFHLElBQUksQ0FBQztRQUdqQixhQUFRLEdBQUcsS0FBSyxDQUFDO1FBa0RqQjs7O1dBR0c7UUFDSyxhQUFRLEdBQUcsS0FBSyxDQUFDO1FBRXpCOzs7V0FHRztRQUNLLGFBQVEsR0FBRyxLQUFLLENBQUM7UUFFekI7OztXQUdHO1FBQ0ssbUJBQWMsR0FBRyxLQUFLLENBQUM7UUFFL0I7OztXQUdHO1FBQ0ssd0JBQW1CLEdBQUcsTUFBTSxDQUFDLHNCQUFzQixFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7UUFHN0UsZ0JBQVcsR0FBRyxJQUFJLFlBQVksRUFBb0IsQ0FBQztRQUduRCx5QkFBb0IsR0FBRyxJQUFJLFlBQVksRUFBVyxDQUFDO1FBMENuRDs7O1dBR0c7UUFDSyxvQkFBZSxHQUFtQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUM7UUFFMUU7OztXQUdHO1FBQ0sscUJBQWdCLEdBQW9DLEdBQUcsRUFBRSxDQUFDLFNBQVMsQ0FBQztLQXFDNUU7SUFyS0E7OztPQUdHO0lBQ0gsSUFBSSxPQUFPO1FBQ1YsT0FBTyxJQUFJLENBQUMsRUFBRSxHQUFHLE9BQU8sQ0FBQztJQUMxQixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsRUFBRSxHQUFHLFFBQVEsQ0FBQztJQUMzQixDQUFDO0lBQ0Q7OztTQUdLO0lBQ0wsSUFDSSxPQUFPLENBQUMsS0FBYztRQUN6QixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztRQUN0QixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztJQUM1QixDQUFDO0lBRUQsSUFBSSxPQUFPO1FBQ1YsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3RCLENBQUM7SUFFRCxJQUNJLGFBQWEsQ0FBQyxLQUFjO1FBQy9CLE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxxQkFBOEIsRUFBRSxFQUFFO1lBQzdELElBQUkscUJBQXFCLEVBQUUsQ0FBQztnQkFDM0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7WUFDdkIsQ0FBQztRQUNGLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBRUQsSUFBSSxhQUFhO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUM1QixDQUFDO0lBRUQsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDN0QsQ0FBQztJQWdDRDs7O09BR0c7SUFDSCxZQUFZO1FBQ1gsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDbkIsT0FBTztRQUNSLENBQUM7UUFFRCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVEOzs7T0FHRztJQUNLLHdCQUF3QixDQUFDLEtBQWMsRUFBRSxFQUE2QztRQUM3RixNQUFNLE9BQU8sR0FBRyxLQUFLLEtBQUssSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUU5QyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztRQUU1QixJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQ2IsSUFBSSxFQUFFLEVBQUUsQ0FBQztnQkFDUixFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ3pCLENBQUM7WUFDRCxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUNyRCxDQUFDO0lBQ0YsQ0FBQztJQUVEOzs7T0FHRztJQUNLLGFBQWE7UUFDcEIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztRQUN0QixDQUFDO0lBQ0YsQ0FBQztJQWNEOzs7T0FHRztJQUNILGNBQWMsQ0FBQyxLQUFZO1FBQzFCLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ25CLE9BQU87UUFDUixDQUFDO1FBQ0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7UUFFOUIsSUFBSSxDQUFDLHdCQUF3QixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNwQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQztZQUNyQixLQUFLO1lBQ0wsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRO1NBQ3RCLENBQUMsQ0FBQztJQUNKLENBQUM7SUFFRCxVQUFVLENBQUMsR0FBWTtRQUN0QixJQUFJLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQztRQUNwQixJQUFJLENBQUMsd0JBQXdCLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVELGdCQUFnQixDQUFDLEVBQWtDO1FBQ2xELElBQUksQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxFQUFtQztRQUNwRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxVQUFtQjtRQUNuQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkQsQ0FBQzsrR0EvS1csb0JBQW9CO21HQUFwQixvQkFBb0Isa2pCQTVCckI7WUFDVjtnQkFDQyxPQUFPLEVBQUUsaUJBQWlCO2dCQUMxQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLG9CQUFvQixDQUFDO2dCQUNuRCxLQUFLLEVBQUUsSUFBSTthQUNYO1NBQ0QseU5DM0JGLDQxQkE2QkEsaStCRERXLFlBQVksMFNBQUUsd0JBQXdCOzs0RkFxQnBDLG9CQUFvQjtrQkFqQ2hDLFNBQVM7K0JBQ0MsY0FBYyxjQUNaLElBQUksYUFHTDt3QkFDVjs0QkFDQyxPQUFPLEVBQUUsaUJBQWlCOzRCQUMxQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxxQkFBcUIsQ0FBQzs0QkFDbkQsS0FBSyxFQUFFLElBQUk7eUJBQ1g7cUJBQ0QsV0FDUSxDQUFDLFlBQVksRUFBRSx3QkFBd0IsQ0FBQyxrQkFDakM7d0JBQ2Ysa0JBQWtCO3dCQUNsQjs0QkFDQyxTQUFTLEVBQUUsc0JBQXNCOzRCQUNqQyx1RUFBdUU7NEJBQ3ZFLE1BQU0sRUFBRSxDQUFDLFlBQVksQ0FBQzs0QkFDdEIsd0VBQXdFOzRCQUN4RSxPQUFPLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQzt5QkFDL0I7cUJBQ0QsUUFDSzt3QkFDTCw4QkFBOEIsRUFBRSxTQUFTO3dCQUN6QyxvQ0FBb0MsRUFBRSxlQUFlO3dCQUNyRCwrQkFBK0IsRUFBRSxVQUFVO3dCQUMzQywrQkFBK0IsRUFBRSxVQUFVO3dCQUMzQyxpQ0FBaUMsRUFBRSxZQUFZO3dCQUMvQyxXQUFXLEVBQUUsSUFBSTt3QkFDakIsb0JBQW9CLEVBQUUsSUFBSTtxQkFDMUI7OEJBS0QsRUFBRTtzQkFERCxLQUFLO2dCQUlOLFNBQVM7c0JBRFIsS0FBSztnQkFJTixRQUFRO3NCQURQLEtBQUs7Z0JBdUJGLE9BQU87c0JBRFYsS0FBSztnQkFXRixhQUFhO3NCQURoQixLQUFLO2dCQTRDTixXQUFXO3NCQURWLE1BQU07Z0JBSVAsb0JBQW9CO3NCQURuQixNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBFdmVudEVtaXR0ZXIsIGZvcndhcmRSZWYsIGluamVjdCwgSW5wdXQsIE91dHB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIE5HX1ZBTFVFX0FDQ0VTU09SIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IE5nQ29udHJvbERpcmVjdGl2ZSwgSXVpSXNEaXNhYmxlZERpcmVjdGl2ZSB9IGZyb20gJ0BpdGVyby91aS1jb21wb25lbnRzLWFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJdWlDaGVja2JveE1hcmtDb21wb25lbnQgfSBmcm9tICdAaXRlcm8vdWktY29tcG9uZW50cy1hbmd1bGFyL2NoZWNrYm94LW1hcmsnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEl1aUNoZWNrYm94RXZlbnQge1xuXHRldmVudDogRXZlbnQ7XG5cdGNoZWNrZWQ6IGJvb2xlYW47XG59XG5cbnR5cGUgSXVpQ2hlY2tib3hQcm9wYWdhdGVDaGFuZ2VUeXBlID0gKF86IGJvb2xlYW4pID0+IHZvaWQ7XG50eXBlIEl1aUNoZWNrYm94UHJvcGFnYXRlVG91Y2hlZFR5cGUgPSAoKSA9PiB2b2lkO1xuXG5sZXQgbmV4dFVuaXF1ZUlkID0gMDtcblxuQENvbXBvbmVudCh7XG5cdHNlbGVjdG9yOiAnaXVpLWNoZWNrYm94Jyxcblx0c3RhbmRhbG9uZTogdHJ1ZSxcblx0dGVtcGxhdGVVcmw6ICcuL2l1aS1jaGVja2JveC5jb21wb25lbnQuaHRtbCcsXG5cdHN0eWxlVXJsczogWycuL2l1aS1jaGVja2JveC5jb21wb25lbnQuc2NzcyddLFxuXHRwcm92aWRlcnM6IFtcblx0XHR7XG5cdFx0XHRwcm92aWRlOiBOR19WQUxVRV9BQ0NFU1NPUixcblx0XHRcdHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IEl1aUNoZWNrYm94Q29tcG9uZW50KSxcblx0XHRcdG11bHRpOiB0cnVlXG5cdFx0fVxuXHRdLFxuXHRpbXBvcnRzOiBbQ29tbW9uTW9kdWxlLCBJdWlDaGVja2JveE1hcmtDb21wb25lbnRdLFxuXHRob3N0RGlyZWN0aXZlczogW1xuXHRcdE5nQ29udHJvbERpcmVjdGl2ZSxcblx0XHR7XG5cdFx0XHRkaXJlY3RpdmU6IEl1aUlzRGlzYWJsZWREaXJlY3RpdmUsXG5cdFx0XHQvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQGFuZ3VsYXItZXNsaW50L25vLWlucHV0cy1tZXRhZGF0YS1wcm9wZXJ0eVxuXHRcdFx0aW5wdXRzOiBbJ2lzRGlzYWJsZWQnXSxcblx0XHRcdC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAYW5ndWxhci1lc2xpbnQvbm8tb3V0cHV0cy1tZXRhZGF0YS1wcm9wZXJ0eVxuXHRcdFx0b3V0cHV0czogWydkaXNhYmxlQ2hhbmdlRXZlbnQnXVxuXHRcdH1cblx0XSxcblx0aG9zdDoge1xuXHRcdCdbY2xhc3MuaXVpLWNoZWNrYm94X2NoZWNrZWRdJzogJ2NoZWNrZWQnLFxuXHRcdCdbY2xhc3MuaXVpLWNoZWNrYm94X2luZGV0ZXJtaW5hdGVdJzogJ2luZGV0ZXJtaW5hdGUnLFxuXHRcdCdbY2xhc3MuaXVpLWNoZWNrYm94X2Rpc2FibGVkXSc6ICdkaXNhYmxlZCcsXG5cdFx0J1tjbGFzcy5pdWktY2hlY2tib3hfc2tlbGV0b25dJzogJ3NrZWxldG9uJyxcblx0XHQnW2NsYXNzLml1aS1jaGVja2JveF9oaWRlLXZhbHVlXSc6ICchc2hvd1ZhbHVlJyxcblx0XHQnW2F0dHIuaWRdJzogJ2lkJyxcblx0XHQnW2F0dHIuZGF0YS10ZXN0aWRdJzogJ2lkJ1xuXHR9XG59KVxuZXhwb3J0IGNsYXNzIEl1aUNoZWNrYm94Q29tcG9uZW50IGltcGxlbWVudHMgQ29udHJvbFZhbHVlQWNjZXNzb3Ige1xuXHQvKiogVGhlIHVuaXF1ZSBpZCBvZiB0aGUgZWxlbWVudCAqL1xuXHRASW5wdXQoKVxuXHRpZCA9IGBpdWktY2hlY2tib3gtJHtuZXh0VW5pcXVlSWQrK31gO1xuXG5cdEBJbnB1dCgpXG5cdHNob3dWYWx1ZSA9IHRydWU7XG5cblx0QElucHV0KClcblx0c2tlbGV0b24gPSBmYWxzZTtcblxuXHQvKipcblx0ICogQHByb3Bcblx0ICogQGlnbm9yZVxuXHQgKi9cblx0Z2V0IF9tYXJrSWQoKSB7XG5cdFx0cmV0dXJuIHRoaXMuaWQgKyAnLW1hcmsnO1xuXHR9XG5cblx0LyoqXG5cdCAqIEBwcm9wXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdGdldCBfbGFiZWxJZCgpIHtcblx0XHRyZXR1cm4gdGhpcy5pZCArICctbGFiZWwnO1xuXHR9XG5cdC8qKlxuXHQgKiBpbnB1dCB3aGVyZSB5b3UgY2FuIHBhc3MgZGVzaXJhYmxlIHN0YXRlIG9mIGNoZWNrYm94IFwidHJ1ZVwiIG9yIFwiZmFsc2VcIi5cblx0ICogQ2FuIGJlIGhlbHBmdWwgd2hlbiB5b3UgZG9uJ3QgdXNlIGZvcm1Db250cm9sLCBvdGhlcndpc2UgeW91IGNhbiBwYXRjaFZhbHVlIG9mIGZvcm1Db250cm9sXG5cdCAqICovXG5cdEBJbnB1dCgpXG5cdHNldCBjaGVja2VkKHZhbHVlOiBib29sZWFuKSB7XG5cdFx0dGhpcy5fY2hlY2tlZCA9IHZhbHVlO1xuXHRcdHRoaXMuaW5kZXRlcm1pbmF0ZSA9IGZhbHNlO1xuXHR9XG5cblx0Z2V0IGNoZWNrZWQoKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuX2NoZWNrZWQ7XG5cdH1cblxuXHRASW5wdXQoKVxuXHRzZXQgaW5kZXRlcm1pbmF0ZSh2YWx1ZTogYm9vbGVhbikge1xuXHRcdGNvbnN0IHVwZGF0ZUNoZWNrZWRTdGF0ZSA9IChuZXdJbmRldGVybWluYXRlU3RhdGU6IGJvb2xlYW4pID0+IHtcblx0XHRcdGlmIChuZXdJbmRldGVybWluYXRlU3RhdGUpIHtcblx0XHRcdFx0dGhpcy5fY2hlY2tlZCA9IGZhbHNlO1xuXHRcdFx0fVxuXHRcdH07XG5cblx0XHR0aGlzLnNldEluZGV0ZXJtaW5hdGVJbnRlcm5hbCh2YWx1ZSwgdXBkYXRlQ2hlY2tlZFN0YXRlKTtcblx0fVxuXG5cdGdldCBpbmRldGVybWluYXRlKCk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiB0aGlzLl9pbmRldGVybWluYXRlO1xuXHR9XG5cblx0Z2V0IGRpc2FibGVkKCkge1xuXHRcdHJldHVybiB0aGlzLmlzRGlzYWJsZWREaXJlY3RpdmUuaXNEaXNhYmxlZCB8fCB0aGlzLnNrZWxldG9uO1xuXHR9XG5cblx0LyoqXG5cdCAqIEBwcm9wXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdHByaXZhdGUgX3RvdWNoZWQgPSBmYWxzZTtcblxuXHQvKipcblx0ICogQHByb3Bcblx0ICogQGlnbm9yZVxuXHQgKi9cblx0cHJpdmF0ZSBfY2hlY2tlZCA9IGZhbHNlO1xuXG5cdC8qKlxuXHQgKiBAcHJvcFxuXHQgKiBAaWdub3JlXG5cdCAqL1xuXHRwcml2YXRlIF9pbmRldGVybWluYXRlID0gZmFsc2U7XG5cblx0LyoqXG5cdCAqIEBwcm9wXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdHByaXZhdGUgaXNEaXNhYmxlZERpcmVjdGl2ZSA9IGluamVjdChJdWlJc0Rpc2FibGVkRGlyZWN0aXZlLCB7IHNlbGY6IHRydWUgfSk7XG5cblx0QE91dHB1dCgpXG5cdGNoYW5nZUV2ZW50ID0gbmV3IEV2ZW50RW1pdHRlcjxJdWlDaGVja2JveEV2ZW50PigpO1xuXG5cdEBPdXRwdXQoKVxuXHRpbmRldGVybWluYXRlQ2hhbmdlZCA9IG5ldyBFdmVudEVtaXR0ZXI8Ym9vbGVhbj4oKTtcblxuXHQvKipcblx0ICogQG1ldGhvZFxuXHQgKiBAaWdub3JlXG5cdCAqL1xuXHRfYmx1ckhhbmRsZXIoKSB7XG5cdFx0aWYgKHRoaXMuZGlzYWJsZWQpIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHR0aGlzLm1hcmtBc1RvdWNoZWQoKTtcblx0fVxuXG5cdC8qKlxuXHQgKiBAbWV0aG9kXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdHByaXZhdGUgc2V0SW5kZXRlcm1pbmF0ZUludGVybmFsKHZhbHVlOiBib29sZWFuLCBjYj86IChuZXdJbmRldGVybWluYXRlU3RhdGU6IGJvb2xlYW4pID0+IHZvaWQpIHtcblx0XHRjb25zdCBjaGFuZ2VkID0gdmFsdWUgIT09IHRoaXMuX2luZGV0ZXJtaW5hdGU7XG5cblx0XHR0aGlzLl9pbmRldGVybWluYXRlID0gdmFsdWU7XG5cblx0XHRpZiAoY2hhbmdlZCkge1xuXHRcdFx0aWYgKGNiKSB7XG5cdFx0XHRcdGNiKHRoaXMuX2luZGV0ZXJtaW5hdGUpO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy5pbmRldGVybWluYXRlQ2hhbmdlZC5lbWl0KHRoaXMuX2luZGV0ZXJtaW5hdGUpO1xuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBAbWV0aG9kXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdHByaXZhdGUgbWFya0FzVG91Y2hlZCgpIHtcblx0XHRpZiAoIXRoaXMuX3RvdWNoZWQpIHtcblx0XHRcdHRoaXMucHJvcGFnYXRlVG91Y2hlZCgpO1xuXHRcdFx0dGhpcy5fdG91Y2hlZCA9IHRydWU7XG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIEBwcm9wXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdHByaXZhdGUgcHJvcGFnYXRlQ2hhbmdlOiBJdWlDaGVja2JveFByb3BhZ2F0ZUNoYW5nZVR5cGUgPSAoKSA9PiB1bmRlZmluZWQ7XG5cblx0LyoqXG5cdCAqIEBwcm9wXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdHByaXZhdGUgcHJvcGFnYXRlVG91Y2hlZDogSXVpQ2hlY2tib3hQcm9wYWdhdGVUb3VjaGVkVHlwZSA9ICgpID0+IHVuZGVmaW5lZDtcblxuXHQvKipcblx0ICogQG1ldGhvZFxuXHQgKiBAaWdub3JlXG5cdCAqL1xuXHRfY2hhbmdlSGFuZGxlcihldmVudDogRXZlbnQpIHtcblx0XHRpZiAodGhpcy5kaXNhYmxlZCkge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHR0aGlzLl9jaGVja2VkID0gIXRoaXMuY2hlY2tlZDtcblxuXHRcdHRoaXMuc2V0SW5kZXRlcm1pbmF0ZUludGVybmFsKGZhbHNlKTtcblx0XHR0aGlzLm1hcmtBc1RvdWNoZWQoKTtcblx0XHR0aGlzLnByb3BhZ2F0ZUNoYW5nZSh0aGlzLl9jaGVja2VkKTtcblx0XHR0aGlzLmNoYW5nZUV2ZW50LmVtaXQoe1xuXHRcdFx0ZXZlbnQsXG5cdFx0XHRjaGVja2VkOiB0aGlzLl9jaGVja2VkXG5cdFx0fSk7XG5cdH1cblxuXHR3cml0ZVZhbHVlKHZhbDogYm9vbGVhbikge1xuXHRcdHRoaXMuX2NoZWNrZWQgPSB2YWw7XG5cdFx0dGhpcy5zZXRJbmRldGVybWluYXRlSW50ZXJuYWwoZmFsc2UpO1xuXHR9XG5cblx0cmVnaXN0ZXJPbkNoYW5nZShmbjogSXVpQ2hlY2tib3hQcm9wYWdhdGVDaGFuZ2VUeXBlKSB7XG5cdFx0dGhpcy5wcm9wYWdhdGVDaGFuZ2UgPSBmbjtcblx0fVxuXG5cdHJlZ2lzdGVyT25Ub3VjaGVkKGZuOiBJdWlDaGVja2JveFByb3BhZ2F0ZVRvdWNoZWRUeXBlKSB7XG5cdFx0dGhpcy5wcm9wYWdhdGVUb3VjaGVkID0gZm47XG5cdH1cblxuXHRzZXREaXNhYmxlZFN0YXRlKGlzRGlzYWJsZWQ6IGJvb2xlYW4pIHtcblx0XHR0aGlzLmlzRGlzYWJsZWREaXJlY3RpdmUuc2V0RGlzYWJsZWRTdGF0ZShpc0Rpc2FibGVkKTtcblx0fVxufVxuIiwiPGxhYmVsIGNsYXNzPVwiaXVpLWNoZWNrYm94X19jb250YWluZXJcIlxuXHRbYXR0ci5kYXRhLXRlc3RpZF09XCJfbGFiZWxJZFwiXG5cdFthdHRyLmlkXT1cIl9sYWJlbElkXCI+XG5cdDxpdWktY2hlY2tib3gtbWFya1xuXHRcdGNsYXNzPVwiaXVpLWNoZWNrYm94X190cmlnZ2VyXCJcblx0XHRbaWRdPVwiX21hcmtJZFwiXG5cdFx0W2lzRGlzYWJsZWRdPVwiZGlzYWJsZWRcIlxuXHRcdFtza2VsZXRvbl09XCJza2VsZXRvblwiXG5cdFx0KGNoYW5nZSk9XCJfY2hhbmdlSGFuZGxlcigkZXZlbnQpXCJcblx0XHQoYmx1ckV2ZW50KT1cIl9ibHVySGFuZGxlcigpXCJcblx0XHRbY2hlY2tlZF09XCJjaGVja2VkXCJcblx0XHRbaW5kZXRlcm1pbmF0ZV09XCJpbmRldGVybWluYXRlXCJcblx0PjwvaXVpLWNoZWNrYm94LW1hcms+XG5cblx0PGRpdiBjbGFzcz1cIml1aS1jaGVja2JveF9fbGFiZWwtdGV4dFwiICpuZ0lmPVwic2hvd1ZhbHVlICYmICFza2VsZXRvblwiPlxuXHRcdDxuZy1jb250YWluZXIgKm5nVGVtcGxhdGVPdXRsZXQ9XCJjb250ZW50VHBsXCI+PC9uZy1jb250YWluZXI+XG5cdDwvZGl2PlxuXG5cdDxkaXYgY2xhc3M9XCJpdWktY2hlY2tib3hfX3NrZWxldG9uLWJveFwiICpuZ0lmPVwic2tlbGV0b25cIj48L2Rpdj5cbjwvbGFiZWw+XG5cbjxuZy10ZW1wbGF0ZSAjY29udGVudFRwbD5cblx0PGRpdj5cblx0XHQ8bmctY29udGVudD48L25nLWNvbnRlbnQ+XG5cdDwvZGl2PlxuXHQ8ZGl2IGNsYXNzPVwiaXVpLWNoZWNrYm94X19sYWJlbC1kZXNjXCI+XG5cdFx0PG5nLWNvbnRlbnQgc2VsZWN0PVwiW2Rlc2NyaXB0aW9uXVwiPjwvbmctY29udGVudD5cblx0PC9kaXY+XG48L25nLXRlbXBsYXRlPlxuIl19