import { CdkListbox } from '@angular/cdk/listbox';
import { CommonModule } from '@angular/common';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { ChangeDetectorRef, Component, forwardRef, inject, Input } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i0 from "@angular/core";
export class IuiListboxComponent extends CdkListbox {
    constructor() {
        super(...arguments);
        this.size = 'l';
        this.hideSelectionIndicator = false;
        this.togglePosition = 'after';
        this._changeDetectorRef = inject(ChangeDetectorRef);
    }
    get multipleSelection() {
        return super.multiple;
    }
    set multipleSelection(value) {
        const newValue = coerceBooleanProperty(value);
        if (newValue !== super.multiple) {
            super.multiple = newValue;
        }
    }
    /**
     * @method
     * @ignore
     */
    ngOnChanges(changes) {
        const size = changes['size'];
        if (size && size.currentValue !== size.previousValue) {
            this.updateChildren();
        }
    }
    /**
     * @method
     * @ignore
     */
    ngAfterContentInit() {
        super.ngAfterContentInit();
        this.updateChildren();
    }
    /**
     * @method
     * @ignore
     */
    updateChildren() {
        this.options?.forEach(option => {
            option.size = this.size;
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiListboxComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiListboxComponent, isStandalone: true, selector: "iui-listbox", inputs: { size: "size", multipleSelection: ["multiple", "multipleSelection"], hideSelectionIndicator: "hideSelectionIndicator", togglePosition: "togglePosition" }, host: { properties: { "class.iui-listbox": "true", "attr.disabled": "disabled ? true : null" } }, providers: [
            { provide: CdkListbox, useExisting: IuiListboxComponent },
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiListboxComponent),
                multi: true
            }
        ], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '<ng-content select="iui-listbox-option"></ng-content>', isInline: true, styles: [":host{display:flex;flex-direction:column;-webkit-user-select:none;user-select:none;outline:none;border:none;text-decoration:none;-webkit-tap-highlight-color:transparent;transition:background-color .2s ease-out}:host::-moz-focus-inner{border:0}:host.iui-listbox_disabled{border-color:var(--iui-listbox-disabled-border);color:var(--iui-listbox-disabled-color);cursor:auto}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiListboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-listbox', template: '<ng-content select="iui-listbox-option"></ng-content>', imports: [CommonModule], providers: [
                        { provide: CdkListbox, useExisting: IuiListboxComponent },
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiListboxComponent),
                            multi: true
                        }
                    ], standalone: true, host: {
                        '[class.iui-listbox]': 'true',
                        '[attr.disabled]': 'disabled ? true : null'
                    }, styles: [":host{display:flex;flex-direction:column;-webkit-user-select:none;user-select:none;outline:none;border:none;text-decoration:none;-webkit-tap-highlight-color:transparent;transition:background-color .2s ease-out}:host::-moz-focus-inner{border:0}:host.iui-listbox_disabled{border-color:var(--iui-listbox-disabled-border);color:var(--iui-listbox-disabled-color);cursor:auto}\n"] }]
        }], propDecorators: { size: [{
                type: Input
            }], multipleSelection: [{
                type: Input,
                args: ['multiple']
            }], hideSelectionIndicator: [{
                type: Input
            }], togglePosition: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLWxpc3Rib3guY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvbGlzdGJveC9zcmMvaXVpLWxpc3Rib3guY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUNsRCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDL0MsT0FBTyxFQUFnQixxQkFBcUIsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQzVFLE9BQU8sRUFBb0IsaUJBQWlCLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUF1QyxNQUFNLGVBQWUsQ0FBQztBQUMvSSxPQUFPLEVBQXdCLGlCQUFpQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7O0FBd0J6RSxNQUFNLE9BQU8sbUJBQW9CLFNBQVEsVUFBcUM7SUFuQjlFOztRQW9CVSxTQUFJLEdBQXlCLEdBQUcsQ0FBQztRQWNqQywyQkFBc0IsR0FBRyxLQUFLLENBQUM7UUFDL0IsbUJBQWMsR0FBZ0MsT0FBTyxDQUFDO1FBRXZELHVCQUFrQixHQUFHLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0tBNkJ2RDtJQTdDQSxJQUNJLGlCQUFpQjtRQUNwQixPQUFPLEtBQUssQ0FBQyxRQUFRLENBQUM7SUFDdkIsQ0FBQztJQUVELElBQUksaUJBQWlCLENBQUMsS0FBbUI7UUFDeEMsTUFBTSxRQUFRLEdBQUcscUJBQXFCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFOUMsSUFBSSxRQUFRLEtBQUssS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ2pDLEtBQUssQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO1FBQzNCLENBQUM7SUFDRixDQUFDO0lBTUQ7OztPQUdHO0lBQ0gsV0FBVyxDQUFDLE9BQXNCO1FBQ2pDLE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUU3QixJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsWUFBWSxLQUFLLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN0RCxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdkIsQ0FBQztJQUNGLENBQUM7SUFDRDs7O09BR0c7SUFDTSxrQkFBa0I7UUFDMUIsS0FBSyxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDM0IsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFDRDs7O09BR0c7SUFDSyxjQUFjO1FBQ3JCLElBQUksQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQzdCLE1BQW9DLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDeEQsQ0FBQyxDQUFDLENBQUM7SUFDSixDQUFDOytHQTlDVyxtQkFBbUI7bUdBQW5CLG1CQUFtQixnVUFkcEI7WUFDVixFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsV0FBVyxFQUFFLG1CQUFtQixFQUFFO1lBQ3pEO2dCQUNDLE9BQU8sRUFBRSxpQkFBaUI7Z0JBQzFCLFdBQVcsRUFBRSxVQUFVLENBQUMsR0FBRyxFQUFFLENBQUMsbUJBQW1CLENBQUM7Z0JBQ2xELEtBQUssRUFBRSxJQUFJO2FBQ1g7U0FDRCxzRUFWUyx1REFBdUQsNmJBRXZELFlBQVk7OzRGQWVWLG1CQUFtQjtrQkFuQi9CLFNBQVM7K0JBQ0MsYUFBYSxZQUNiLHVEQUF1RCxXQUV4RCxDQUFDLFlBQVksQ0FBQyxhQUNaO3dCQUNWLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxXQUFXLHFCQUFxQixFQUFFO3dCQUN6RDs0QkFDQyxPQUFPLEVBQUUsaUJBQWlCOzRCQUMxQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxvQkFBb0IsQ0FBQzs0QkFDbEQsS0FBSyxFQUFFLElBQUk7eUJBQ1g7cUJBQ0QsY0FDVyxJQUFJLFFBQ1Y7d0JBQ0wscUJBQXFCLEVBQUUsTUFBTTt3QkFDN0IsaUJBQWlCLEVBQUUsd0JBQXdCO3FCQUMzQzs4QkFHUSxJQUFJO3NCQUFaLEtBQUs7Z0JBRUYsaUJBQWlCO3NCQURwQixLQUFLO3VCQUFDLFVBQVU7Z0JBYVIsc0JBQXNCO3NCQUE5QixLQUFLO2dCQUNHLGNBQWM7c0JBQXRCLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDZGtMaXN0Ym94IH0gZnJvbSAnQGFuZ3VsYXIvY2RrL2xpc3Rib3gnO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IEJvb2xlYW5JbnB1dCwgY29lcmNlQm9vbGVhblByb3BlcnR5IH0gZnJvbSAnQGFuZ3VsYXIvY2RrL2NvZXJjaW9uJztcbmltcG9ydCB7IEFmdGVyQ29udGVudEluaXQsIENoYW5nZURldGVjdG9yUmVmLCBDb21wb25lbnQsIGZvcndhcmRSZWYsIGluamVjdCwgSW5wdXQsIE9uQ2hhbmdlcywgUXVlcnlMaXN0LCBTaW1wbGVDaGFuZ2VzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb250cm9sVmFsdWVBY2Nlc3NvciwgTkdfVkFMVUVfQUNDRVNTT1IgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBJdWlMaXN0Ym94T3B0aW9uQ29tcG9uZW50LCBJdWlMaXN0Ym94T3B0aW9uU2l6ZSB9IGZyb20gJy4vb3B0aW9uL2l1aS1saXN0Ym94LW9wdGlvbi5jb21wb25lbnQnO1xuXG5leHBvcnQgdHlwZSBJdWlMaXN0T3B0aW9uVG9nZ2xlUG9zaXRpb24gPSAnYmVmb3JlJyB8ICdhZnRlcic7XG5cbkBDb21wb25lbnQoe1xuXHRzZWxlY3RvcjogJ2l1aS1saXN0Ym94Jyxcblx0dGVtcGxhdGU6ICc8bmctY29udGVudCBzZWxlY3Q9XCJpdWktbGlzdGJveC1vcHRpb25cIj48L25nLWNvbnRlbnQ+Jyxcblx0c3R5bGVVcmxzOiBbJ2l1aS1saXN0Ym94LmNvbXBvbmVudC5zY3NzJ10sXG5cdGltcG9ydHM6IFtDb21tb25Nb2R1bGVdLFxuXHRwcm92aWRlcnM6IFtcblx0XHR7IHByb3ZpZGU6IENka0xpc3Rib3gsIHVzZUV4aXN0aW5nOiBJdWlMaXN0Ym94Q29tcG9uZW50IH0sXG5cdFx0e1xuXHRcdFx0cHJvdmlkZTogTkdfVkFMVUVfQUNDRVNTT1IsXG5cdFx0XHR1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBJdWlMaXN0Ym94Q29tcG9uZW50KSxcblx0XHRcdG11bHRpOiB0cnVlXG5cdFx0fVxuXHRdLFxuXHRzdGFuZGFsb25lOiB0cnVlLFxuXHRob3N0OiB7XG5cdFx0J1tjbGFzcy5pdWktbGlzdGJveF0nOiAndHJ1ZScsXG5cdFx0J1thdHRyLmRpc2FibGVkXSc6ICdkaXNhYmxlZCA/IHRydWUgOiBudWxsJ1xuXHR9XG59KVxuZXhwb3J0IGNsYXNzIEl1aUxpc3Rib3hDb21wb25lbnQgZXh0ZW5kcyBDZGtMaXN0Ym94PEl1aUxpc3Rib3hPcHRpb25Db21wb25lbnQ+IGltcGxlbWVudHMgT25DaGFuZ2VzLCBBZnRlckNvbnRlbnRJbml0LCBDb250cm9sVmFsdWVBY2Nlc3NvciB7XG5cdEBJbnB1dCgpIHNpemU6IEl1aUxpc3Rib3hPcHRpb25TaXplID0gJ2wnO1xuXHRASW5wdXQoJ211bHRpcGxlJylcblx0Z2V0IG11bHRpcGxlU2VsZWN0aW9uKCk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiBzdXBlci5tdWx0aXBsZTtcblx0fVxuXG5cdHNldCBtdWx0aXBsZVNlbGVjdGlvbih2YWx1ZTogQm9vbGVhbklucHV0KSB7XG5cdFx0Y29uc3QgbmV3VmFsdWUgPSBjb2VyY2VCb29sZWFuUHJvcGVydHkodmFsdWUpO1xuXG5cdFx0aWYgKG5ld1ZhbHVlICE9PSBzdXBlci5tdWx0aXBsZSkge1xuXHRcdFx0c3VwZXIubXVsdGlwbGUgPSBuZXdWYWx1ZTtcblx0XHR9XG5cdH1cblxuXHRASW5wdXQoKSBoaWRlU2VsZWN0aW9uSW5kaWNhdG9yID0gZmFsc2U7XG5cdEBJbnB1dCgpIHRvZ2dsZVBvc2l0aW9uOiBJdWlMaXN0T3B0aW9uVG9nZ2xlUG9zaXRpb24gPSAnYWZ0ZXInO1xuXG5cdHByaXZhdGUgX2NoYW5nZURldGVjdG9yUmVmID0gaW5qZWN0KENoYW5nZURldGVjdG9yUmVmKTtcblx0LyoqXG5cdCAqIEBtZXRob2Rcblx0ICogQGlnbm9yZVxuXHQgKi9cblx0bmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xuXHRcdGNvbnN0IHNpemUgPSBjaGFuZ2VzWydzaXplJ107XG5cblx0XHRpZiAoc2l6ZSAmJiBzaXplLmN1cnJlbnRWYWx1ZSAhPT0gc2l6ZS5wcmV2aW91c1ZhbHVlKSB7XG5cdFx0XHR0aGlzLnVwZGF0ZUNoaWxkcmVuKCk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQgKiBAbWV0aG9kXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdG92ZXJyaWRlIG5nQWZ0ZXJDb250ZW50SW5pdCgpIHtcblx0XHRzdXBlci5uZ0FmdGVyQ29udGVudEluaXQoKTtcblx0XHR0aGlzLnVwZGF0ZUNoaWxkcmVuKCk7XG5cdH1cblx0LyoqXG5cdCAqIEBtZXRob2Rcblx0ICogQGlnbm9yZVxuXHQgKi9cblx0cHJpdmF0ZSB1cGRhdGVDaGlsZHJlbigpOiB2b2lkIHtcblx0XHR0aGlzLm9wdGlvbnM/LmZvckVhY2gob3B0aW9uID0+IHtcblx0XHRcdChvcHRpb24gYXMgSXVpTGlzdGJveE9wdGlvbkNvbXBvbmVudCkuc2l6ZSA9IHRoaXMuc2l6ZTtcblx0XHR9KTtcblx0fVxufVxuIl19