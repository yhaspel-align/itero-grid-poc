import { Component, EventEmitter, forwardRef, inject, Input, Output } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgControlDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
import * as i2 from "@angular/common";
let nextUniqueId = 0;
export class IuiSlideToggleComponent {
    constructor() {
        /** The unique id of the element */
        this.id = `iui-slide-toggle-${nextUniqueId++}`;
        /** Position of the label rendered with slide-toggle can be 'left' or right'. Default is left */
        this.labelPosition = 'left';
        /** Whether to show the skeleton loading state */
        this.skeleton = false;
        /** Whether to show the value/label text. Default: true */
        this.showValue = true;
        this._touched = false;
        this._checked = false;
        this.isDisabledDirective = inject(IuiIsDisabledDirective, { self: true });
        this.changeEvent = new EventEmitter();
        this._propagateChange = (_) => { };
        this._propagateTouched = () => { };
    }
    get _inputId() {
        return this.id + '-input';
    }
    get _labelId() {
        return this.id + '-label';
    }
    /**
     * input where you can pass desirable state of slide-toggle "true" or "false".
     * Can be helpful when you don't use formControl, otherwise you can patchValue of formControl
     * */
    set checked(value) {
        this._checked = value;
    }
    get checked() {
        return this._checked;
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get effectivelyDisabled() {
        return this.disabled || this.skeleton;
    }
    _blurHandler() {
        if (this.effectivelyDisabled) {
            return;
        }
        this._markAsTouched();
    }
    _markAsTouched() {
        if (!this._touched) {
            this._propagateTouched();
            this._touched = true;
        }
    }
    _changeHandler(event) {
        if (this.effectivelyDisabled) {
            return;
        }
        this._checked = !this.checked;
        this._markAsTouched();
        this._propagateChange(this._checked);
        this.changeEvent.emit({
            event,
            checked: this._checked
        });
    }
    writeValue(val) {
        this._checked = val;
    }
    registerOnChange(fn) {
        this._propagateChange = fn;
    }
    registerOnTouched(fn) {
        this._propagateTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiSlideToggleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.12", type: IuiSlideToggleComponent, isStandalone: true, selector: "iui-slide-toggle", inputs: { id: "id", checked: "checked", labelPosition: "labelPosition", skeleton: "skeleton", showValue: "showValue" }, outputs: { changeEvent: "changeEvent" }, host: { properties: { "class.iui-slide-toggle_checked": "checked", "class.iui-slide-toggle_disabled": "disabled", "class.iui-slide-toggle_skeleton": "skeleton", "attr.id": "id", "attr.data-testid": "id" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiSlideToggleComponent),
                multi: true
            }
        ], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<label [for]=\"_inputId\" [attr.data-testid]=\"_labelId\" [attr.id]=\"_labelId\">\n\t@if (labelPosition === 'left' && showValue && !skeleton) {\n\t\t<span class=\"iui-slide-toggle__label-text\"><ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container></span>\n\t}\n\n\t<input\n\t\t[attr.id]=\"_inputId\"\n\t\t[attr.data-testid]=\"_inputId\"\n\t\tclass=\"iui-slide-toggle__input_hidden\"\n\t\t[disabled]=\"effectivelyDisabled\"\n\t\t(change)=\"_changeHandler($event)\"\n\t\t(blur)=\"_blurHandler()\"\n\t\t[checked]=\"checked\"\n\t\trole=\"switch\"\n\t\ttype=\"checkbox\"\n\t/>\n\t<div class=\"iui-slide-toggle__trigger\">\n\t\t<div class=\"iui-slide-toggle__handle\"></div>\n\t</div>\n\n\t@if (labelPosition === 'right' && showValue && !skeleton) {\n\t\t<span class=\"iui-slide-toggle__label-text\"><ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container></span>\n\t}\n\n\t@if (skeleton) {\n\t\t<span class=\"iui-slide-toggle__skeleton-placeholder\"></span>\n\t}\n</label>\n\n<ng-template #contentTpl><ng-content></ng-content></ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:inline-block}label{display:inline-flex;align-items:center;gap:8px;cursor:pointer}:host(.iui-slide-toggle_disabled) label,:host(.iui-slide-toggle_skeleton) label{cursor:default}.iui-slide-toggle__label-text{font:var(--iui-tp-body-01-font, 400 14px/20px var(--iui-font-family));color:var(--iui-slide-toggle-label-color);white-space:nowrap;-webkit-user-select:none;user-select:none;cursor:pointer}:host.iui-slide-toggle_disabled ::ng-deep .iui-slide-toggle__label-text{color:var(--iui-slide-toggle-label-disabled-color);cursor:default}.iui-slide-toggle__input_hidden{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.iui-slide-toggle__trigger{position:relative;width:32px;height:20px;flex-shrink:0;border-radius:10000px;background-color:var(--iui-slide-toggle-track-off);cursor:pointer;transition:background-color .1s ease-in;outline:none;border:none;padding:0}.iui-slide-toggle__trigger:hover{background-color:var(--iui-slide-toggle-track-off-hover)}.iui-slide-toggle__trigger:active{background-color:var(--iui-slide-toggle-track-off-active)}.iui-slide-toggle__trigger:before{content:\"\";position:absolute;inset:-2px;border:2px solid transparent;border-radius:10000px;pointer-events:none;transition:border-color .1s ease-in}.iui-slide-toggle__input_hidden:focus-visible~.iui-slide-toggle__trigger:before{border-color:var(--iui-slide-toggle-focus-border)}.iui-slide-toggle__handle{position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background-color:var(--iui-slide-toggle-handle);transition:transform 75ms cubic-bezier(.4,0,.2,1)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__trigger{background-color:var(--iui-slide-toggle-track-on)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__trigger:hover{background-color:var(--iui-slide-toggle-track-on-hover)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__trigger:active{background-color:var(--iui-slide-toggle-track-on-active)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__handle{transform:translate(12px)}:host(.iui-slide-toggle_disabled){pointer-events:none;cursor:default}:host(.iui-slide-toggle_disabled) .iui-slide-toggle__trigger{background-color:var(--iui-slide-toggle-track-disabled)}:host(.iui-slide-toggle_disabled) .iui-slide-toggle__trigger:hover,:host(.iui-slide-toggle_disabled) .iui-slide-toggle__trigger:active{background-color:var(--iui-slide-toggle-track-disabled)}:host(.iui-slide-toggle_skeleton){pointer-events:none}:host(.iui-slide-toggle_skeleton) .iui-slide-toggle__trigger{background-color:var(--iui-slide-toggle-track-disabled)}.iui-slide-toggle__skeleton-placeholder{width:40px;height:8px;border-radius:4px;background-color:var(--iui-slide-toggle-skeleton-bg)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiSlideToggleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-slide-toggle', standalone: true, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiSlideToggleComponent),
                            multi: true
                        }
                    ], imports: [CommonModule], hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], host: {
                        '[class.iui-slide-toggle_checked]': 'checked',
                        '[class.iui-slide-toggle_disabled]': 'disabled',
                        '[class.iui-slide-toggle_skeleton]': 'skeleton',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<label [for]=\"_inputId\" [attr.data-testid]=\"_labelId\" [attr.id]=\"_labelId\">\n\t@if (labelPosition === 'left' && showValue && !skeleton) {\n\t\t<span class=\"iui-slide-toggle__label-text\"><ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container></span>\n\t}\n\n\t<input\n\t\t[attr.id]=\"_inputId\"\n\t\t[attr.data-testid]=\"_inputId\"\n\t\tclass=\"iui-slide-toggle__input_hidden\"\n\t\t[disabled]=\"effectivelyDisabled\"\n\t\t(change)=\"_changeHandler($event)\"\n\t\t(blur)=\"_blurHandler()\"\n\t\t[checked]=\"checked\"\n\t\trole=\"switch\"\n\t\ttype=\"checkbox\"\n\t/>\n\t<div class=\"iui-slide-toggle__trigger\">\n\t\t<div class=\"iui-slide-toggle__handle\"></div>\n\t</div>\n\n\t@if (labelPosition === 'right' && showValue && !skeleton) {\n\t\t<span class=\"iui-slide-toggle__label-text\"><ng-container *ngTemplateOutlet=\"contentTpl\"></ng-container></span>\n\t}\n\n\t@if (skeleton) {\n\t\t<span class=\"iui-slide-toggle__skeleton-placeholder\"></span>\n\t}\n</label>\n\n<ng-template #contentTpl><ng-content></ng-content></ng-template>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:inline-block}label{display:inline-flex;align-items:center;gap:8px;cursor:pointer}:host(.iui-slide-toggle_disabled) label,:host(.iui-slide-toggle_skeleton) label{cursor:default}.iui-slide-toggle__label-text{font:var(--iui-tp-body-01-font, 400 14px/20px var(--iui-font-family));color:var(--iui-slide-toggle-label-color);white-space:nowrap;-webkit-user-select:none;user-select:none;cursor:pointer}:host.iui-slide-toggle_disabled ::ng-deep .iui-slide-toggle__label-text{color:var(--iui-slide-toggle-label-disabled-color);cursor:default}.iui-slide-toggle__input_hidden{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.iui-slide-toggle__trigger{position:relative;width:32px;height:20px;flex-shrink:0;border-radius:10000px;background-color:var(--iui-slide-toggle-track-off);cursor:pointer;transition:background-color .1s ease-in;outline:none;border:none;padding:0}.iui-slide-toggle__trigger:hover{background-color:var(--iui-slide-toggle-track-off-hover)}.iui-slide-toggle__trigger:active{background-color:var(--iui-slide-toggle-track-off-active)}.iui-slide-toggle__trigger:before{content:\"\";position:absolute;inset:-2px;border:2px solid transparent;border-radius:10000px;pointer-events:none;transition:border-color .1s ease-in}.iui-slide-toggle__input_hidden:focus-visible~.iui-slide-toggle__trigger:before{border-color:var(--iui-slide-toggle-focus-border)}.iui-slide-toggle__handle{position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background-color:var(--iui-slide-toggle-handle);transition:transform 75ms cubic-bezier(.4,0,.2,1)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__trigger{background-color:var(--iui-slide-toggle-track-on)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__trigger:hover{background-color:var(--iui-slide-toggle-track-on-hover)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__trigger:active{background-color:var(--iui-slide-toggle-track-on-active)}:host(.iui-slide-toggle_checked) .iui-slide-toggle__handle{transform:translate(12px)}:host(.iui-slide-toggle_disabled){pointer-events:none;cursor:default}:host(.iui-slide-toggle_disabled) .iui-slide-toggle__trigger{background-color:var(--iui-slide-toggle-track-disabled)}:host(.iui-slide-toggle_disabled) .iui-slide-toggle__trigger:hover,:host(.iui-slide-toggle_disabled) .iui-slide-toggle__trigger:active{background-color:var(--iui-slide-toggle-track-disabled)}:host(.iui-slide-toggle_skeleton){pointer-events:none}:host(.iui-slide-toggle_skeleton) .iui-slide-toggle__trigger{background-color:var(--iui-slide-toggle-track-disabled)}.iui-slide-toggle__skeleton-placeholder{width:40px;height:8px;border-radius:4px;background-color:var(--iui-slide-toggle-skeleton-bg)}\n"] }]
        }], propDecorators: { id: [{
                type: Input
            }], checked: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], showValue: [{
                type: Input
            }], changeEvent: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLXNsaWRlLXRvZ2dsZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS9zbGlkZS10b2dnbGUvc3JjL2l1aS1zbGlkZS10b2dnbGUuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvc2xpZGUtdG9nZ2xlL3NyYy9pdWktc2xpZGUtdG9nZ2xlLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzRixPQUFPLEVBQXdCLGlCQUFpQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDekUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxzQkFBc0IsRUFBRSxNQUFNLG1DQUFtQyxDQUFDOzs7O0FBTy9GLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztBQStCckIsTUFBTSxPQUFPLHVCQUF1QjtJQTdCcEM7UUE4QkMsbUNBQW1DO1FBRW5DLE9BQUUsR0FBRyxvQkFBb0IsWUFBWSxFQUFFLEVBQUUsQ0FBQztRQXFCMUMsZ0dBQWdHO1FBRWhHLGtCQUFhLEdBQXFCLE1BQU0sQ0FBQztRQUV6QyxpREFBaUQ7UUFFakQsYUFBUSxHQUFHLEtBQUssQ0FBQztRQUVqQiwwREFBMEQ7UUFFMUQsY0FBUyxHQUFHLElBQUksQ0FBQztRQVVULGFBQVEsR0FBRyxLQUFLLENBQUM7UUFDakIsYUFBUSxHQUFHLEtBQUssQ0FBQztRQUNqQix3QkFBbUIsR0FBRyxNQUFNLENBQUMsc0JBQXNCLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUc3RSxnQkFBVyxHQUFHLElBQUksWUFBWSxFQUF1QixDQUFDO1FBaUI5QyxxQkFBZ0IsR0FBRyxDQUFDLENBQU0sRUFBRSxFQUFFLEdBQUUsQ0FBQyxDQUFDO1FBQ2xDLHNCQUFpQixHQUFHLEdBQUcsRUFBRSxHQUFFLENBQUMsQ0FBQztLQStCckM7SUE3RkEsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsRUFBRSxHQUFHLFFBQVEsQ0FBQztJQUMzQixDQUFDO0lBQ0QsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsRUFBRSxHQUFHLFFBQVEsQ0FBQztJQUMzQixDQUFDO0lBQ0Q7OztTQUdLO0lBQ0wsSUFDSSxPQUFPLENBQUMsS0FBYztRQUN6QixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztJQUN2QixDQUFDO0lBRUQsSUFBSSxPQUFPO1FBQ1YsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3RCLENBQUM7SUFjRCxJQUFJLFFBQVE7UUFDWCxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVLENBQUM7SUFDNUMsQ0FBQztJQUVELElBQUksbUJBQW1CO1FBQ3RCLE9BQU8sSUFBSSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3ZDLENBQUM7SUFTRCxZQUFZO1FBQ1gsSUFBSSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztZQUM5QixPQUFPO1FBQ1IsQ0FBQztRQUVELElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUN2QixDQUFDO0lBRU8sY0FBYztRQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ3RCLENBQUM7SUFDRixDQUFDO0lBS0QsY0FBYyxDQUFDLEtBQVk7UUFDMUIsSUFBSSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztZQUM5QixPQUFPO1FBQ1IsQ0FBQztRQUNELElBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1FBRTlCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDO1lBQ3JCLEtBQUs7WUFDTCxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVE7U0FDdEIsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQUVELFVBQVUsQ0FBQyxHQUFRO1FBQ2xCLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDO0lBQ3JCLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxFQUFPO1FBQ3ZCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVELGlCQUFpQixDQUFDLEVBQU87UUFDeEIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztJQUM3QixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsVUFBbUI7UUFDbkMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7K0dBakdXLHVCQUF1QjttR0FBdkIsdUJBQXVCLGdiQXhCeEI7WUFDVjtnQkFDQyxPQUFPLEVBQUUsaUJBQWlCO2dCQUMxQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLHVCQUF1QixDQUFDO2dCQUN0RCxLQUFLLEVBQUUsSUFBSTthQUNYO1NBQ0QseU5DdkJGLDhoQ0E4QkEsczBGRE5XLFlBQVk7OzRGQWlCVix1QkFBdUI7a0JBN0JuQyxTQUFTOytCQUNDLGtCQUFrQixjQUNoQixJQUFJLGFBR0w7d0JBQ1Y7NEJBQ0MsT0FBTyxFQUFFLGlCQUFpQjs0QkFDMUIsV0FBVyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsd0JBQXdCLENBQUM7NEJBQ3RELEtBQUssRUFBRSxJQUFJO3lCQUNYO3FCQUNELFdBQ1EsQ0FBQyxZQUFZLENBQUMsa0JBQ1A7d0JBQ2Ysa0JBQWtCO3dCQUNsQjs0QkFDQyxTQUFTLEVBQUUsc0JBQXNCOzRCQUNqQyxNQUFNLEVBQUUsQ0FBQyxZQUFZLENBQUM7NEJBQ3RCLE9BQU8sRUFBRSxDQUFDLG9CQUFvQixDQUFDO3lCQUMvQjtxQkFDRCxRQUNLO3dCQUNMLGtDQUFrQyxFQUFFLFNBQVM7d0JBQzdDLG1DQUFtQyxFQUFFLFVBQVU7d0JBQy9DLG1DQUFtQyxFQUFFLFVBQVU7d0JBQy9DLFdBQVcsRUFBRSxJQUFJO3dCQUNqQixvQkFBb0IsRUFBRSxJQUFJO3FCQUMxQjs4QkFLRCxFQUFFO3NCQURELEtBQUs7Z0JBY0YsT0FBTztzQkFEVixLQUFLO2dCQVdOLGFBQWE7c0JBRFosS0FBSztnQkFLTixRQUFRO3NCQURQLEtBQUs7Z0JBS04sU0FBUztzQkFEUixLQUFLO2dCQWdCTixXQUFXO3NCQURWLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgZm9yd2FyZFJlZiwgaW5qZWN0LCBJbnB1dCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb250cm9sVmFsdWVBY2Nlc3NvciwgTkdfVkFMVUVfQUNDRVNTT1IgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgTmdDb250cm9sRGlyZWN0aXZlLCBJdWlJc0Rpc2FibGVkRGlyZWN0aXZlIH0gZnJvbSAnQGl0ZXJvL3VpLWNvbXBvbmVudHMtYW5ndWxhci9jb3JlJztcblxuZXhwb3J0IGludGVyZmFjZSBJdWlTbGlkZVRvZ2dsZUV2ZW50IHtcblx0ZXZlbnQ6IEV2ZW50O1xuXHRjaGVja2VkOiBib29sZWFuO1xufVxuXG5sZXQgbmV4dFVuaXF1ZUlkID0gMDtcblxuQENvbXBvbmVudCh7XG5cdHNlbGVjdG9yOiAnaXVpLXNsaWRlLXRvZ2dsZScsXG5cdHN0YW5kYWxvbmU6IHRydWUsXG5cdHRlbXBsYXRlVXJsOiAnLi9pdWktc2xpZGUtdG9nZ2xlLmNvbXBvbmVudC5odG1sJyxcblx0c3R5bGVVcmxzOiBbJy4vaXVpLXNsaWRlLXRvZ2dsZS5jb21wb25lbnQuc2NzcyddLFxuXHRwcm92aWRlcnM6IFtcblx0XHR7XG5cdFx0XHRwcm92aWRlOiBOR19WQUxVRV9BQ0NFU1NPUixcblx0XHRcdHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IEl1aVNsaWRlVG9nZ2xlQ29tcG9uZW50KSxcblx0XHRcdG11bHRpOiB0cnVlXG5cdFx0fVxuXHRdLFxuXHRpbXBvcnRzOiBbQ29tbW9uTW9kdWxlXSxcblx0aG9zdERpcmVjdGl2ZXM6IFtcblx0XHROZ0NvbnRyb2xEaXJlY3RpdmUsXG5cdFx0e1xuXHRcdFx0ZGlyZWN0aXZlOiBJdWlJc0Rpc2FibGVkRGlyZWN0aXZlLFxuXHRcdFx0aW5wdXRzOiBbJ2lzRGlzYWJsZWQnXSxcblx0XHRcdG91dHB1dHM6IFsnZGlzYWJsZUNoYW5nZUV2ZW50J11cblx0XHR9XG5cdF0sXG5cdGhvc3Q6IHtcblx0XHQnW2NsYXNzLml1aS1zbGlkZS10b2dnbGVfY2hlY2tlZF0nOiAnY2hlY2tlZCcsXG5cdFx0J1tjbGFzcy5pdWktc2xpZGUtdG9nZ2xlX2Rpc2FibGVkXSc6ICdkaXNhYmxlZCcsXG5cdFx0J1tjbGFzcy5pdWktc2xpZGUtdG9nZ2xlX3NrZWxldG9uXSc6ICdza2VsZXRvbicsXG5cdFx0J1thdHRyLmlkXSc6ICdpZCcsXG5cdFx0J1thdHRyLmRhdGEtdGVzdGlkXSc6ICdpZCdcblx0fVxufSlcbmV4cG9ydCBjbGFzcyBJdWlTbGlkZVRvZ2dsZUNvbXBvbmVudCBpbXBsZW1lbnRzIENvbnRyb2xWYWx1ZUFjY2Vzc29yIHtcblx0LyoqIFRoZSB1bmlxdWUgaWQgb2YgdGhlIGVsZW1lbnQgKi9cblx0QElucHV0KClcblx0aWQgPSBgaXVpLXNsaWRlLXRvZ2dsZS0ke25leHRVbmlxdWVJZCsrfWA7XG5cblx0Z2V0IF9pbnB1dElkKCkge1xuXHRcdHJldHVybiB0aGlzLmlkICsgJy1pbnB1dCc7XG5cdH1cblx0Z2V0IF9sYWJlbElkKCkge1xuXHRcdHJldHVybiB0aGlzLmlkICsgJy1sYWJlbCc7XG5cdH1cblx0LyoqXG5cdCAqIGlucHV0IHdoZXJlIHlvdSBjYW4gcGFzcyBkZXNpcmFibGUgc3RhdGUgb2Ygc2xpZGUtdG9nZ2xlIFwidHJ1ZVwiIG9yIFwiZmFsc2VcIi5cblx0ICogQ2FuIGJlIGhlbHBmdWwgd2hlbiB5b3UgZG9uJ3QgdXNlIGZvcm1Db250cm9sLCBvdGhlcndpc2UgeW91IGNhbiBwYXRjaFZhbHVlIG9mIGZvcm1Db250cm9sXG5cdCAqICovXG5cdEBJbnB1dCgpXG5cdHNldCBjaGVja2VkKHZhbHVlOiBib29sZWFuKSB7XG5cdFx0dGhpcy5fY2hlY2tlZCA9IHZhbHVlO1xuXHR9XG5cblx0Z2V0IGNoZWNrZWQoKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuX2NoZWNrZWQ7XG5cdH1cblxuXHQvKiogUG9zaXRpb24gb2YgdGhlIGxhYmVsIHJlbmRlcmVkIHdpdGggc2xpZGUtdG9nZ2xlIGNhbiBiZSAnbGVmdCcgb3IgcmlnaHQnLiBEZWZhdWx0IGlzIGxlZnQgKi9cblx0QElucHV0KClcblx0bGFiZWxQb3NpdGlvbjogJ2xlZnQnIHwgJ3JpZ2h0JyA9ICdsZWZ0JztcblxuXHQvKiogV2hldGhlciB0byBzaG93IHRoZSBza2VsZXRvbiBsb2FkaW5nIHN0YXRlICovXG5cdEBJbnB1dCgpXG5cdHNrZWxldG9uID0gZmFsc2U7XG5cblx0LyoqIFdoZXRoZXIgdG8gc2hvdyB0aGUgdmFsdWUvbGFiZWwgdGV4dC4gRGVmYXVsdDogdHJ1ZSAqL1xuXHRASW5wdXQoKVxuXHRzaG93VmFsdWUgPSB0cnVlO1xuXG5cdGdldCBkaXNhYmxlZCgpIHtcblx0XHRyZXR1cm4gdGhpcy5pc0Rpc2FibGVkRGlyZWN0aXZlLmlzRGlzYWJsZWQ7XG5cdH1cblxuXHRnZXQgZWZmZWN0aXZlbHlEaXNhYmxlZCgpOiBib29sZWFuIHtcblx0XHRyZXR1cm4gdGhpcy5kaXNhYmxlZCB8fCB0aGlzLnNrZWxldG9uO1xuXHR9XG5cblx0cHJpdmF0ZSBfdG91Y2hlZCA9IGZhbHNlO1xuXHRwcml2YXRlIF9jaGVja2VkID0gZmFsc2U7XG5cdHByaXZhdGUgaXNEaXNhYmxlZERpcmVjdGl2ZSA9IGluamVjdChJdWlJc0Rpc2FibGVkRGlyZWN0aXZlLCB7IHNlbGY6IHRydWUgfSk7XG5cblx0QE91dHB1dCgpXG5cdGNoYW5nZUV2ZW50ID0gbmV3IEV2ZW50RW1pdHRlcjxJdWlTbGlkZVRvZ2dsZUV2ZW50PigpO1xuXG5cdF9ibHVySGFuZGxlcigpOiB2b2lkIHtcblx0XHRpZiAodGhpcy5lZmZlY3RpdmVseURpc2FibGVkKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0dGhpcy5fbWFya0FzVG91Y2hlZCgpO1xuXHR9XG5cblx0cHJpdmF0ZSBfbWFya0FzVG91Y2hlZCgpOiB2b2lkIHtcblx0XHRpZiAoIXRoaXMuX3RvdWNoZWQpIHtcblx0XHRcdHRoaXMuX3Byb3BhZ2F0ZVRvdWNoZWQoKTtcblx0XHRcdHRoaXMuX3RvdWNoZWQgPSB0cnVlO1xuXHRcdH1cblx0fVxuXG5cdHByaXZhdGUgX3Byb3BhZ2F0ZUNoYW5nZSA9IChfOiBhbnkpID0+IHt9O1xuXHRwcml2YXRlIF9wcm9wYWdhdGVUb3VjaGVkID0gKCkgPT4ge307XG5cblx0X2NoYW5nZUhhbmRsZXIoZXZlbnQ6IEV2ZW50KSB7XG5cdFx0aWYgKHRoaXMuZWZmZWN0aXZlbHlEaXNhYmxlZCkge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHR0aGlzLl9jaGVja2VkID0gIXRoaXMuY2hlY2tlZDtcblxuXHRcdHRoaXMuX21hcmtBc1RvdWNoZWQoKTtcblx0XHR0aGlzLl9wcm9wYWdhdGVDaGFuZ2UodGhpcy5fY2hlY2tlZCk7XG5cdFx0dGhpcy5jaGFuZ2VFdmVudC5lbWl0KHtcblx0XHRcdGV2ZW50LFxuXHRcdFx0Y2hlY2tlZDogdGhpcy5fY2hlY2tlZFxuXHRcdH0pO1xuXHR9XG5cblx0d3JpdGVWYWx1ZSh2YWw6IGFueSk6IHZvaWQge1xuXHRcdHRoaXMuX2NoZWNrZWQgPSB2YWw7XG5cdH1cblxuXHRyZWdpc3Rlck9uQ2hhbmdlKGZuOiBhbnkpOiB2b2lkIHtcblx0XHR0aGlzLl9wcm9wYWdhdGVDaGFuZ2UgPSBmbjtcblx0fVxuXG5cdHJlZ2lzdGVyT25Ub3VjaGVkKGZuOiBhbnkpOiB2b2lkIHtcblx0XHR0aGlzLl9wcm9wYWdhdGVUb3VjaGVkID0gZm47XG5cdH1cblxuXHRzZXREaXNhYmxlZFN0YXRlKGlzRGlzYWJsZWQ6IGJvb2xlYW4pOiB2b2lkIHtcblx0XHR0aGlzLmlzRGlzYWJsZWREaXJlY3RpdmUuc2V0RGlzYWJsZWRTdGF0ZShpc0Rpc2FibGVkKTtcblx0fVxufVxuIiwiPGxhYmVsIFtmb3JdPVwiX2lucHV0SWRcIiBbYXR0ci5kYXRhLXRlc3RpZF09XCJfbGFiZWxJZFwiIFthdHRyLmlkXT1cIl9sYWJlbElkXCI+XG5cdEBpZiAobGFiZWxQb3NpdGlvbiA9PT0gJ2xlZnQnICYmIHNob3dWYWx1ZSAmJiAhc2tlbGV0b24pIHtcblx0XHQ8c3BhbiBjbGFzcz1cIml1aS1zbGlkZS10b2dnbGVfX2xhYmVsLXRleHRcIj48bmctY29udGFpbmVyICpuZ1RlbXBsYXRlT3V0bGV0PVwiY29udGVudFRwbFwiPjwvbmctY29udGFpbmVyPjwvc3Bhbj5cblx0fVxuXG5cdDxpbnB1dFxuXHRcdFthdHRyLmlkXT1cIl9pbnB1dElkXCJcblx0XHRbYXR0ci5kYXRhLXRlc3RpZF09XCJfaW5wdXRJZFwiXG5cdFx0Y2xhc3M9XCJpdWktc2xpZGUtdG9nZ2xlX19pbnB1dF9oaWRkZW5cIlxuXHRcdFtkaXNhYmxlZF09XCJlZmZlY3RpdmVseURpc2FibGVkXCJcblx0XHQoY2hhbmdlKT1cIl9jaGFuZ2VIYW5kbGVyKCRldmVudClcIlxuXHRcdChibHVyKT1cIl9ibHVySGFuZGxlcigpXCJcblx0XHRbY2hlY2tlZF09XCJjaGVja2VkXCJcblx0XHRyb2xlPVwic3dpdGNoXCJcblx0XHR0eXBlPVwiY2hlY2tib3hcIlxuXHQvPlxuXHQ8ZGl2IGNsYXNzPVwiaXVpLXNsaWRlLXRvZ2dsZV9fdHJpZ2dlclwiPlxuXHRcdDxkaXYgY2xhc3M9XCJpdWktc2xpZGUtdG9nZ2xlX19oYW5kbGVcIj48L2Rpdj5cblx0PC9kaXY+XG5cblx0QGlmIChsYWJlbFBvc2l0aW9uID09PSAncmlnaHQnICYmIHNob3dWYWx1ZSAmJiAhc2tlbGV0b24pIHtcblx0XHQ8c3BhbiBjbGFzcz1cIml1aS1zbGlkZS10b2dnbGVfX2xhYmVsLXRleHRcIj48bmctY29udGFpbmVyICpuZ1RlbXBsYXRlT3V0bGV0PVwiY29udGVudFRwbFwiPjwvbmctY29udGFpbmVyPjwvc3Bhbj5cblx0fVxuXG5cdEBpZiAoc2tlbGV0b24pIHtcblx0XHQ8c3BhbiBjbGFzcz1cIml1aS1zbGlkZS10b2dnbGVfX3NrZWxldG9uLXBsYWNlaG9sZGVyXCI+PC9zcGFuPlxuXHR9XG48L2xhYmVsPlxuXG48bmctdGVtcGxhdGUgI2NvbnRlbnRUcGw+PG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PjwvbmctdGVtcGxhdGU+XG4iXX0=