import { ChangeDetectionStrategy, ChangeDetectorRef, Component, forwardRef, Input, Self, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR, Validators } from '@angular/forms';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import { IuiButtonComponent } from '@itero/ui-components-angular/button';
import { SubtractEmptyIconComponent, AddEmptyIconComponent } from '@itero/ui-components-angular/icons';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
import * as i2 from "@angular/common";
let nextUniqueId = 0;
/**
 * @deprecated Use `IuiNumberInputComponent` from `@itero/ui-components-angular/number-input` instead.
 * This component will be removed in the next major version.
 */
export class IuiIncrementalNumberInputComponent {
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    get required() {
        return this._required ?? this.ngControlDirective.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get _focused() {
        return this.__focused;
    }
    get _inputId() {
        return this.id + '-input';
    }
    get _isAtMin() {
        return this.__value != null && this.__value <= this.min;
    }
    get _isAtMax() {
        return this.__value != null && this.__value >= this.max;
    }
    get _inputSize() {
        const len = this._displayValue.length;
        return len > 0 ? len : 1;
    }
    get _ariaValueMin() {
        return isFinite(this.min) ? this.min : null;
    }
    get _ariaValueMax() {
        return isFinite(this.max) ? this.max : null;
    }
    get _displayValue() {
        if (this._rawInput != null) {
            return this._rawInput;
        }
        return this.__value != null ? String(this.__value) : '';
    }
    get _value() {
        return this.__value;
    }
    constructor(_changeDetectorRef, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._changeDetectorRef = _changeDetectorRef;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        this._id = `iui-incremental-number-input-${nextUniqueId++}`;
        this.label = '';
        this.helperText = '';
        this.name = '';
        this.min = -Infinity;
        this.max = Infinity;
        this.step = 1;
        this.__value = null;
        this.__focused = false;
        this._rawInput = null;
        this._onChange = () => { };
        this._onTouched = () => { };
    }
    _increment() {
        const current = this.__value ?? 0;
        const newValue = Math.min(current + this.step, this.max);
        this._setValue(newValue);
    }
    _decrement() {
        const current = this.__value ?? 0;
        const newValue = Math.max(current - this.step, this.min);
        this._setValue(newValue);
    }
    _onKeydown(event) {
        if (event.key === 'ArrowUp') {
            event.preventDefault();
            this._increment();
        }
        else if (event.key === 'ArrowDown') {
            event.preventDefault();
            this._decrement();
        }
    }
    _onInputChange(event) {
        const raw = event.target.value;
        this._rawInput = raw;
        if (raw === '') {
            this._assignValue(null);
            return;
        }
        if (raw === '-') {
            return;
        }
        const parsed = Number(raw);
        if (!isNaN(parsed)) {
            this._setValue(this._clamp(parsed));
        }
    }
    _onFocus() {
        if (!this.disabled) {
            this.__focused = true;
            this._rawInput = this._displayValue;
        }
    }
    _onBlur() {
        this.__focused = false;
        this._rawInput = null;
        if (this.__value == null) {
            const resolved = isFinite(this.min) ? this.min : 0;
            this._setValue(resolved);
        }
        else {
            this._setValue(this._clamp(this.__value));
        }
        if (!this.disabled) {
            this._onTouched();
            this._changeDetectorRef.markForCheck();
        }
    }
    writeValue(value) {
        this._assignValue(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._changeDetectorRef.markForCheck();
    }
    _setValue(value) {
        const hasAssigned = this._assignValue(value);
        if (hasAssigned) {
            this._onChange(value);
        }
    }
    _assignValue(newValue) {
        if (newValue !== this.__value) {
            this.__value = newValue;
            this._changeDetectorRef.markForCheck();
            return true;
        }
        return false;
    }
    _clamp(value) {
        return Math.min(Math.max(value, this.min), this.max);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiIncrementalNumberInputComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.NgControlDirective, self: true }, { token: i1.IuiErrorStateMatcherDirective, self: true }, { token: i1.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiIncrementalNumberInputComponent, isStandalone: true, selector: "iui-incremental-number-input", inputs: { id: "id", label: "label", helperText: "helperText", name: "name", min: "min", max: "max", step: "step", required: "required" }, host: { properties: { "class.iui-incremental-number-input_focused": "_focused", "class.iui-incremental-number-input_required": "required", "class.iui-incremental-number-input_disabled": "disabled", "class.iui-incremental-number-input_invalid": "_errorState", "attr.id": "id" }, classAttribute: "iui-incremental-number-input" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiIncrementalNumberInputComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true }], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<div class=\"iui-incremental-number-input__label-group\">\n\t<div class=\"iui-incremental-number-input__label\">\n\t\t<span class=\"iui-incremental-number-input__label-text\">{{ label }}</span>\n\t\t<span *ngIf=\"required\" class=\"iui-incremental-number-input__asterisk\">*</span>\n\t</div>\n\t<span *ngIf=\"helperText\" class=\"iui-incremental-number-input__helper-text\">{{ helperText }}</span>\n</div>\n\n<div class=\"iui-incremental-number-input__field\">\n\t<button\n\t\tiuiButton\n\t\temphasis=\"ghost\"\n\t\tsize=\"m\"\n\t\t[attr.type]=\"'button'\"\n\t\tclass=\"iui-incremental-number-input__button iui-incremental-number-input__button_decrement\"\n\t\t[disabled]=\"disabled || _isAtMin\"\n\t\t(click)=\"_decrement()\"\n\t\ttabindex=\"-1\"\n\t\taria-label=\"Decrease value\"\n\t>\n\t\t<iui-subtract-empty-icon class=\"iui-icon iui-icon_size_m\"></iui-subtract-empty-icon>\n\t</button>\n\n\t<div class=\"iui-incremental-number-input__value-container\">\n\t\t<input\n\t\t\t#inputElement\n\t\t\ttype=\"text\"\n\t\t\tinputmode=\"numeric\"\n\t\t\tclass=\"iui-incremental-number-input__input\"\n\t\t\t[attr.id]=\"_inputId\"\n\t\t\t[attr.name]=\"name\"\n\t\t\trole=\"spinbutton\"\n\t\t\t[attr.aria-label]=\"label\"\n\t\t\t[attr.aria-valuemin]=\"_ariaValueMin\"\n\t\t\t[attr.aria-valuemax]=\"_ariaValueMax\"\n\t\t\t[attr.aria-valuenow]=\"_value ?? null\"\n\t\t\t[attr.size]=\"_inputSize\"\n\t\t\t[disabled]=\"disabled\"\n\t\t\t[value]=\"_displayValue\"\n\t\t\t(input)=\"_onInputChange($event)\"\n\t\t\t(focus)=\"_onFocus()\"\n\t\t\t(blur)=\"_onBlur()\"\n\t\t\t(keydown)=\"_onKeydown($event)\"\n\t\t/>\n\t</div>\n\n\t<button\n\t\tiuiButton\n\t\temphasis=\"ghost\"\n\t\tsize=\"m\"\n\t\t[attr.type]=\"'button'\"\n\t\tclass=\"iui-incremental-number-input__button iui-incremental-number-input__button_increment\"\n\t\t[disabled]=\"disabled || _isAtMax\"\n\t\t(click)=\"_increment()\"\n\t\ttabindex=\"-1\"\n\t\taria-label=\"Increase value\"\n\t>\n\t\t<iui-add-empty-icon class=\"iui-icon iui-icon_size_m\"></iui-add-empty-icon>\n\t</button>\n\n</div>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;gap:8px;align-items:flex-start}.iui-incremental-number-input__label-group{display:flex;flex-direction:column;justify-content:center;align-self:stretch;min-height:52px}.iui-incremental-number-input__label{display:flex;gap:0;align-items:center;font:var(--iui-tp-body-01-font);color:var(--iui-incremental-input-color)}.iui-incremental-number-input__asterisk{font:var(--iui-tp-label-01-font);margin-left:8px;color:var(--iui-incremental-input-error-color)}.iui-incremental-number-input__helper-text{font:var(--iui-tp-label-01-font);color:var(--iui-incremental-input-color)}.iui-incremental-number-input__field{display:flex;align-items:center;height:52px;flex-shrink:0;width:fit-content;border-bottom:1px solid var(--iui-incremental-input-border);transition:border-color .2s ease-out,border-bottom-width .2s ease-out}.iui-incremental-number-input__button{flex-shrink:0}.iui-incremental-number-input__value-container{display:flex;align-items:center;justify-content:center;height:100%;padding:0 calc(var(--iui-main-unit) * 3)}.iui-incremental-number-input__value-container:hover{background:var(--iui-incremental-input-hover-bg);border-radius:var(--iui-border-radius)}.iui-incremental-number-input__input{text-align:center;border:none;outline:none;background:transparent;font:var(--iui-tp-body-01-font);color:var(--iui-incremental-input-color);min-width:1ch;padding:0}:host.iui-incremental-number-input_focused .iui-incremental-number-input__field{border-bottom-width:2px}:host.iui-incremental-number-input_invalid .iui-incremental-number-input__field{border-bottom-width:2px;border-bottom-color:var(--iui-incremental-input-error-color)}:host.iui-incremental-number-input_disabled .iui-incremental-number-input__label,:host.iui-incremental-number-input_disabled .iui-incremental-number-input__helper-text,:host.iui-incremental-number-input_disabled .iui-incremental-number-input__input{color:var(--iui-incremental-input-disabled-color)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IuiButtonComponent, selector: "button[iuiButton]", inputs: ["type", "emphasis", "size", "disabled", "loading", "menu"] }, { kind: "component", type: SubtractEmptyIconComponent, selector: "iui-subtract-empty-icon" }, { kind: "component", type: AddEmptyIconComponent, selector: "iui-add-empty-icon" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiIncrementalNumberInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-incremental-number-input', standalone: true, imports: [CommonModule, IuiButtonComponent, SubtractEmptyIconComponent, AddEmptyIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiIncrementalNumberInputComponent),
                            multi: true
                        }
                    ], host: {
                        class: 'iui-incremental-number-input',
                        '[class.iui-incremental-number-input_focused]': '_focused',
                        '[class.iui-incremental-number-input_required]': 'required',
                        '[class.iui-incremental-number-input_disabled]': 'disabled',
                        '[class.iui-incremental-number-input_invalid]': '_errorState',
                        '[attr.id]': 'id'
                    }, template: "<div class=\"iui-incremental-number-input__label-group\">\n\t<div class=\"iui-incremental-number-input__label\">\n\t\t<span class=\"iui-incremental-number-input__label-text\">{{ label }}</span>\n\t\t<span *ngIf=\"required\" class=\"iui-incremental-number-input__asterisk\">*</span>\n\t</div>\n\t<span *ngIf=\"helperText\" class=\"iui-incremental-number-input__helper-text\">{{ helperText }}</span>\n</div>\n\n<div class=\"iui-incremental-number-input__field\">\n\t<button\n\t\tiuiButton\n\t\temphasis=\"ghost\"\n\t\tsize=\"m\"\n\t\t[attr.type]=\"'button'\"\n\t\tclass=\"iui-incremental-number-input__button iui-incremental-number-input__button_decrement\"\n\t\t[disabled]=\"disabled || _isAtMin\"\n\t\t(click)=\"_decrement()\"\n\t\ttabindex=\"-1\"\n\t\taria-label=\"Decrease value\"\n\t>\n\t\t<iui-subtract-empty-icon class=\"iui-icon iui-icon_size_m\"></iui-subtract-empty-icon>\n\t</button>\n\n\t<div class=\"iui-incremental-number-input__value-container\">\n\t\t<input\n\t\t\t#inputElement\n\t\t\ttype=\"text\"\n\t\t\tinputmode=\"numeric\"\n\t\t\tclass=\"iui-incremental-number-input__input\"\n\t\t\t[attr.id]=\"_inputId\"\n\t\t\t[attr.name]=\"name\"\n\t\t\trole=\"spinbutton\"\n\t\t\t[attr.aria-label]=\"label\"\n\t\t\t[attr.aria-valuemin]=\"_ariaValueMin\"\n\t\t\t[attr.aria-valuemax]=\"_ariaValueMax\"\n\t\t\t[attr.aria-valuenow]=\"_value ?? null\"\n\t\t\t[attr.size]=\"_inputSize\"\n\t\t\t[disabled]=\"disabled\"\n\t\t\t[value]=\"_displayValue\"\n\t\t\t(input)=\"_onInputChange($event)\"\n\t\t\t(focus)=\"_onFocus()\"\n\t\t\t(blur)=\"_onBlur()\"\n\t\t\t(keydown)=\"_onKeydown($event)\"\n\t\t/>\n\t</div>\n\n\t<button\n\t\tiuiButton\n\t\temphasis=\"ghost\"\n\t\tsize=\"m\"\n\t\t[attr.type]=\"'button'\"\n\t\tclass=\"iui-incremental-number-input__button iui-incremental-number-input__button_increment\"\n\t\t[disabled]=\"disabled || _isAtMax\"\n\t\t(click)=\"_increment()\"\n\t\ttabindex=\"-1\"\n\t\taria-label=\"Increase value\"\n\t>\n\t\t<iui-add-empty-icon class=\"iui-icon iui-icon_size_m\"></iui-add-empty-icon>\n\t</button>\n\n</div>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;gap:8px;align-items:flex-start}.iui-incremental-number-input__label-group{display:flex;flex-direction:column;justify-content:center;align-self:stretch;min-height:52px}.iui-incremental-number-input__label{display:flex;gap:0;align-items:center;font:var(--iui-tp-body-01-font);color:var(--iui-incremental-input-color)}.iui-incremental-number-input__asterisk{font:var(--iui-tp-label-01-font);margin-left:8px;color:var(--iui-incremental-input-error-color)}.iui-incremental-number-input__helper-text{font:var(--iui-tp-label-01-font);color:var(--iui-incremental-input-color)}.iui-incremental-number-input__field{display:flex;align-items:center;height:52px;flex-shrink:0;width:fit-content;border-bottom:1px solid var(--iui-incremental-input-border);transition:border-color .2s ease-out,border-bottom-width .2s ease-out}.iui-incremental-number-input__button{flex-shrink:0}.iui-incremental-number-input__value-container{display:flex;align-items:center;justify-content:center;height:100%;padding:0 calc(var(--iui-main-unit) * 3)}.iui-incremental-number-input__value-container:hover{background:var(--iui-incremental-input-hover-bg);border-radius:var(--iui-border-radius)}.iui-incremental-number-input__input{text-align:center;border:none;outline:none;background:transparent;font:var(--iui-tp-body-01-font);color:var(--iui-incremental-input-color);min-width:1ch;padding:0}:host.iui-incremental-number-input_focused .iui-incremental-number-input__field{border-bottom-width:2px}:host.iui-incremental-number-input_invalid .iui-incremental-number-input__field{border-bottom-width:2px;border-bottom-color:var(--iui-incremental-input-error-color)}:host.iui-incremental-number-input_disabled .iui-incremental-number-input__label,:host.iui-incremental-number-input_disabled .iui-incremental-number-input__helper-text,:host.iui-incremental-number-input_disabled .iui-incremental-number-input__input{color:var(--iui-incremental-input-disabled-color)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { inputElement: [{
                type: ViewChild,
                args: ['inputElement']
            }], id: [{
                type: Input
            }], label: [{
                type: Input
            }], helperText: [{
                type: Input
            }], name: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], step: [{
                type: Input
            }], required: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLWluY3JlbWVudGFsLW51bWJlci1pbnB1dC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS9pbmNyZW1lbnRhbC1udW1iZXItaW5wdXQvc3JjL2l1aS1pbmNyZW1lbnRhbC1udW1iZXItaW5wdXQuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvaW5jcmVtZW50YWwtbnVtYmVyLWlucHV0L3NyYy9pdWktaW5jcmVtZW50YWwtbnVtYmVyLWlucHV0LmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxpQkFBaUIsRUFBRSxTQUFTLEVBQWMsVUFBVSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3RJLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMvQyxPQUFPLEVBQXdCLGlCQUFpQixFQUFFLFVBQVUsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3JGLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQzlELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSw2QkFBNkIsRUFBRSxzQkFBc0IsRUFBRSxNQUFNLG1DQUFtQyxDQUFDO0FBQzlILE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLHFDQUFxQyxDQUFDO0FBQ3pFLE9BQU8sRUFBRSwwQkFBMEIsRUFBRSxxQkFBcUIsRUFBRSxNQUFNLG9DQUFvQyxDQUFDOzs7O0FBRXZHLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztBQUlyQjs7O0dBR0c7QUFvQ0gsTUFBTSxPQUFPLGtDQUFrQztJQUc5QyxJQUNJLEVBQUUsQ0FBQyxLQUFhO1FBQ25CLElBQUksQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDO0lBQ2xCLENBQUM7SUFFRCxJQUFJLEVBQUU7UUFDTCxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDakIsQ0FBQztJQWdCRCxJQUNJLFFBQVE7UUFDWCxPQUFPLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEtBQUssQ0FBQztJQUN0RyxDQUFDO0lBRUQsSUFBSSxRQUFRLENBQUMsS0FBMEM7UUFDdEQsSUFBSSxDQUFDLFNBQVMsR0FBRyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsVUFBVSxDQUFDO0lBQzVDLENBQUM7SUFFRCxJQUFJLFdBQVc7UUFDZCxPQUFPLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxVQUFVLENBQUM7SUFDbkQsQ0FBQztJQUVELElBQUksUUFBUTtRQUNYLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUN2QixDQUFDO0lBRUQsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsRUFBRSxHQUFHLFFBQVEsQ0FBQztJQUMzQixDQUFDO0lBRUQsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDekQsQ0FBQztJQUVELElBQUksUUFBUTtRQUNYLE9BQU8sSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ3pELENBQUM7SUFFRCxJQUFJLFVBQVU7UUFDYixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQztRQUV0QyxPQUFPLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzFCLENBQUM7SUFFRCxJQUFJLGFBQWE7UUFDaEIsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDN0MsQ0FBQztJQUVELElBQUksYUFBYTtRQUNoQixPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUM3QyxDQUFDO0lBRUQsSUFBSSxhQUFhO1FBQ2hCLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUM1QixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUM7UUFDdkIsQ0FBQztRQUVELE9BQU8sSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUN6RCxDQUFDO0lBRUQsSUFBSSxNQUFNO1FBQ1QsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBQ3JCLENBQUM7SUFFRCxZQUNXLGtCQUFxQyxFQUM3QixrQkFBaUQsRUFDakQsMEJBQXlELEVBQ3pELG1CQUEyQztRQUhuRCx1QkFBa0IsR0FBbEIsa0JBQWtCLENBQW1CO1FBQzdCLHVCQUFrQixHQUFsQixrQkFBa0IsQ0FBK0I7UUFDakQsK0JBQTBCLEdBQTFCLDBCQUEwQixDQUErQjtRQUN6RCx3QkFBbUIsR0FBbkIsbUJBQW1CLENBQXdCO1FBN0U5RCxRQUFHLEdBQUcsZ0NBQWdDLFlBQVksRUFBRSxFQUFFLENBQUM7UUFFOUMsVUFBSyxHQUFHLEVBQUUsQ0FBQztRQUNYLGVBQVUsR0FBRyxFQUFFLENBQUM7UUFDaEIsU0FBSSxHQUFHLEVBQUUsQ0FBQztRQUNWLFFBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQztRQUNoQixRQUFHLEdBQUcsUUFBUSxDQUFDO1FBQ2YsU0FBSSxHQUFHLENBQUMsQ0FBQztRQUVWLFlBQU8sR0FBYyxJQUFJLENBQUM7UUFDMUIsY0FBUyxHQUFHLEtBQUssQ0FBQztRQUNsQixjQUFTLEdBQWtCLElBQUksQ0FBQztRQXFFeEMsY0FBUyxHQUErQixHQUFHLEVBQUUsR0FBRSxDQUFDLENBQUM7UUFDakQsZUFBVSxHQUFHLEdBQUcsRUFBRSxHQUFFLENBQUMsQ0FBQztJQUhuQixDQUFDO0lBS0osVUFBVTtRQUNULE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxDQUFDO1FBQ2xDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXpELElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDMUIsQ0FBQztJQUVELFVBQVU7UUFDVCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQztRQUNsQyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUV6RCxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzFCLENBQUM7SUFFRCxVQUFVLENBQUMsS0FBb0I7UUFDOUIsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQzdCLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUN2QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbkIsQ0FBQzthQUFNLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxXQUFXLEVBQUUsQ0FBQztZQUN0QyxLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ25CLENBQUM7SUFDRixDQUFDO0lBRUQsY0FBYyxDQUFDLEtBQVk7UUFDMUIsTUFBTSxHQUFHLEdBQUksS0FBSyxDQUFDLE1BQTJCLENBQUMsS0FBSyxDQUFDO1FBRXJELElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO1FBRXJCLElBQUksR0FBRyxLQUFLLEVBQUUsRUFBRSxDQUFDO1lBQ2hCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFeEIsT0FBTztRQUNSLENBQUM7UUFFRCxJQUFJLEdBQUcsS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUNqQixPQUFPO1FBQ1IsQ0FBQztRQUVELE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUUzQixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7WUFDcEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDckMsQ0FBQztJQUNGLENBQUM7SUFFRCxRQUFRO1FBQ1AsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztZQUN0QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7UUFDckMsQ0FBQztJQUNGLENBQUM7SUFFRCxPQUFPO1FBQ04sSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFFdEIsSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksRUFBRSxDQUFDO1lBQzFCLE1BQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVuRCxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzFCLENBQUM7YUFBTSxDQUFDO1lBQ1AsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQzNDLENBQUM7UUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNsQixJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDeEMsQ0FBQztJQUNGLENBQUM7SUFFRCxVQUFVLENBQUMsS0FBZ0I7UUFDMUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsRUFBOEI7UUFDOUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7SUFDckIsQ0FBQztJQUVELGlCQUFpQixDQUFDLEVBQWM7UUFDL0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVELGdCQUFnQixDQUFDLFVBQW1CO1FBQ25DLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN0RCxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDeEMsQ0FBQztJQUVPLFNBQVMsQ0FBQyxLQUFhO1FBQzlCLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFN0MsSUFBSSxXQUFXLEVBQUUsQ0FBQztZQUNqQixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZCLENBQUM7SUFDRixDQUFDO0lBRU8sWUFBWSxDQUFDLFFBQW1CO1FBQ3ZDLElBQUksUUFBUSxLQUFLLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUMvQixJQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQztZQUN4QixJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFLENBQUM7WUFFdkMsT0FBTyxJQUFJLENBQUM7UUFDYixDQUFDO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZCxDQUFDO0lBRU8sTUFBTSxDQUFDLEtBQWE7UUFDM0IsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDdEQsQ0FBQzsrR0E1TVcsa0NBQWtDO21HQUFsQyxrQ0FBa0MsNmhCQWhCbkM7WUFDVjtnQkFDQyxPQUFPLEVBQUUsaUJBQWlCO2dCQUMxQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLGtDQUFrQyxDQUFDO2dCQUNqRSxLQUFLLEVBQUUsSUFBSTthQUNYO1NBQ0QsNGFDekNGLGdnRUE2REEsb2hFRDFDVyxZQUFZLG1JQUFFLGtCQUFrQixtSUFBRSwwQkFBMEIsb0VBQUUscUJBQXFCOzs0RkFnQ2pGLGtDQUFrQztrQkFuQzlDLFNBQVM7K0JBQ0MsOEJBQThCLGNBQzVCLElBQUksV0FDUCxDQUFDLFlBQVksRUFBRSxrQkFBa0IsRUFBRSwwQkFBMEIsRUFBRSxxQkFBcUIsQ0FBQyxtQkFHN0UsdUJBQXVCLENBQUMsTUFBTSxrQkFDL0I7d0JBQ2Ysa0JBQWtCO3dCQUNsQjs0QkFDQyxTQUFTLEVBQUUsNkJBQTZCOzRCQUN4QyxNQUFNLEVBQUUsQ0FBQyxtQkFBbUIsQ0FBQzt5QkFDN0I7d0JBQ0Q7NEJBQ0MsU0FBUyxFQUFFLHNCQUFzQjs0QkFDakMsTUFBTSxFQUFFLENBQUMsWUFBWSxDQUFDOzRCQUN0QixPQUFPLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQzt5QkFDL0I7cUJBQ0QsYUFDVTt3QkFDVjs0QkFDQyxPQUFPLEVBQUUsaUJBQWlCOzRCQUMxQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxtQ0FBbUMsQ0FBQzs0QkFDakUsS0FBSyxFQUFFLElBQUk7eUJBQ1g7cUJBQ0QsUUFDSzt3QkFDTCxLQUFLLEVBQUUsOEJBQThCO3dCQUNyQyw4Q0FBOEMsRUFBRSxVQUFVO3dCQUMxRCwrQ0FBK0MsRUFBRSxVQUFVO3dCQUMzRCwrQ0FBK0MsRUFBRSxVQUFVO3dCQUMzRCw4Q0FBOEMsRUFBRSxhQUFhO3dCQUM3RCxXQUFXLEVBQUUsSUFBSTtxQkFDakI7OzBCQXlGQyxJQUFJOzswQkFDSixJQUFJOzswQkFDSixJQUFJO3lDQXhGcUIsWUFBWTtzQkFBdEMsU0FBUzt1QkFBQyxjQUFjO2dCQUdyQixFQUFFO3NCQURMLEtBQUs7Z0JBV0csS0FBSztzQkFBYixLQUFLO2dCQUNHLFVBQVU7c0JBQWxCLEtBQUs7Z0JBQ0csSUFBSTtzQkFBWixLQUFLO2dCQUNHLEdBQUc7c0JBQVgsS0FBSztnQkFDRyxHQUFHO3NCQUFYLEtBQUs7Z0JBQ0csSUFBSTtzQkFBWixLQUFLO2dCQVFGLFFBQVE7c0JBRFgsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENoYW5nZURldGVjdGlvblN0cmF0ZWd5LCBDaGFuZ2VEZXRlY3RvclJlZiwgQ29tcG9uZW50LCBFbGVtZW50UmVmLCBmb3J3YXJkUmVmLCBJbnB1dCwgU2VsZiwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIE5HX1ZBTFVFX0FDQ0VTU09SLCBWYWxpZGF0b3JzIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgY29lcmNlQm9vbGVhblByb3BlcnR5IH0gZnJvbSAnQGFuZ3VsYXIvY2RrL2NvZXJjaW9uJztcbmltcG9ydCB7IE5nQ29udHJvbERpcmVjdGl2ZSwgSXVpRXJyb3JTdGF0ZU1hdGNoZXJEaXJlY3RpdmUsIEl1aUlzRGlzYWJsZWREaXJlY3RpdmUgfSBmcm9tICdAaXRlcm8vdWktY29tcG9uZW50cy1hbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSXVpQnV0dG9uQ29tcG9uZW50IH0gZnJvbSAnQGl0ZXJvL3VpLWNvbXBvbmVudHMtYW5ndWxhci9idXR0b24nO1xuaW1wb3J0IHsgU3VidHJhY3RFbXB0eUljb25Db21wb25lbnQsIEFkZEVtcHR5SWNvbkNvbXBvbmVudCB9IGZyb20gJ0BpdGVyby91aS1jb21wb25lbnRzLWFuZ3VsYXIvaWNvbnMnO1xuXG5sZXQgbmV4dFVuaXF1ZUlkID0gMDtcblxudHlwZSBWYWx1ZVR5cGUgPSBudW1iZXIgfCBudWxsO1xuXG4vKipcbiAqIEBkZXByZWNhdGVkIFVzZSBgSXVpTnVtYmVySW5wdXRDb21wb25lbnRgIGZyb20gYEBpdGVyby91aS1jb21wb25lbnRzLWFuZ3VsYXIvbnVtYmVyLWlucHV0YCBpbnN0ZWFkLlxuICogVGhpcyBjb21wb25lbnQgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24uXG4gKi9cbkBDb21wb25lbnQoe1xuXHRzZWxlY3RvcjogJ2l1aS1pbmNyZW1lbnRhbC1udW1iZXItaW5wdXQnLFxuXHRzdGFuZGFsb25lOiB0cnVlLFxuXHRpbXBvcnRzOiBbQ29tbW9uTW9kdWxlLCBJdWlCdXR0b25Db21wb25lbnQsIFN1YnRyYWN0RW1wdHlJY29uQ29tcG9uZW50LCBBZGRFbXB0eUljb25Db21wb25lbnRdLFxuXHR0ZW1wbGF0ZVVybDogJy4vaXVpLWluY3JlbWVudGFsLW51bWJlci1pbnB1dC5jb21wb25lbnQuaHRtbCcsXG5cdHN0eWxlVXJsczogWycuL2l1aS1pbmNyZW1lbnRhbC1udW1iZXItaW5wdXQuY29tcG9uZW50LnNjc3MnXSxcblx0Y2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG5cdGhvc3REaXJlY3RpdmVzOiBbXG5cdFx0TmdDb250cm9sRGlyZWN0aXZlLFxuXHRcdHtcblx0XHRcdGRpcmVjdGl2ZTogSXVpRXJyb3JTdGF0ZU1hdGNoZXJEaXJlY3RpdmUsXG5cdFx0XHRpbnB1dHM6IFsnZXJyb3JTdGF0ZU1hdGNoZXInXVxuXHRcdH0sXG5cdFx0e1xuXHRcdFx0ZGlyZWN0aXZlOiBJdWlJc0Rpc2FibGVkRGlyZWN0aXZlLFxuXHRcdFx0aW5wdXRzOiBbJ2lzRGlzYWJsZWQnXSxcblx0XHRcdG91dHB1dHM6IFsnZGlzYWJsZUNoYW5nZUV2ZW50J11cblx0XHR9XG5cdF0sXG5cdHByb3ZpZGVyczogW1xuXHRcdHtcblx0XHRcdHByb3ZpZGU6IE5HX1ZBTFVFX0FDQ0VTU09SLFxuXHRcdFx0dXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gSXVpSW5jcmVtZW50YWxOdW1iZXJJbnB1dENvbXBvbmVudCksXG5cdFx0XHRtdWx0aTogdHJ1ZVxuXHRcdH1cblx0XSxcblx0aG9zdDoge1xuXHRcdGNsYXNzOiAnaXVpLWluY3JlbWVudGFsLW51bWJlci1pbnB1dCcsXG5cdFx0J1tjbGFzcy5pdWktaW5jcmVtZW50YWwtbnVtYmVyLWlucHV0X2ZvY3VzZWRdJzogJ19mb2N1c2VkJyxcblx0XHQnW2NsYXNzLml1aS1pbmNyZW1lbnRhbC1udW1iZXItaW5wdXRfcmVxdWlyZWRdJzogJ3JlcXVpcmVkJyxcblx0XHQnW2NsYXNzLml1aS1pbmNyZW1lbnRhbC1udW1iZXItaW5wdXRfZGlzYWJsZWRdJzogJ2Rpc2FibGVkJyxcblx0XHQnW2NsYXNzLml1aS1pbmNyZW1lbnRhbC1udW1iZXItaW5wdXRfaW52YWxpZF0nOiAnX2Vycm9yU3RhdGUnLFxuXHRcdCdbYXR0ci5pZF0nOiAnaWQnXG5cdH1cbn0pXG5leHBvcnQgY2xhc3MgSXVpSW5jcmVtZW50YWxOdW1iZXJJbnB1dENvbXBvbmVudCBpbXBsZW1lbnRzIENvbnRyb2xWYWx1ZUFjY2Vzc29yIHtcblx0QFZpZXdDaGlsZCgnaW5wdXRFbGVtZW50JykgaW5wdXRFbGVtZW50OiBFbGVtZW50UmVmPEhUTUxJbnB1dEVsZW1lbnQ+IHwgdW5kZWZpbmVkO1xuXG5cdEBJbnB1dCgpXG5cdHNldCBpZCh2YWx1ZTogc3RyaW5nKSB7XG5cdFx0dGhpcy5faWQgPSB2YWx1ZTtcblx0fVxuXG5cdGdldCBpZCgpIHtcblx0XHRyZXR1cm4gdGhpcy5faWQ7XG5cdH1cblxuXHRfaWQgPSBgaXVpLWluY3JlbWVudGFsLW51bWJlci1pbnB1dC0ke25leHRVbmlxdWVJZCsrfWA7XG5cblx0QElucHV0KCkgbGFiZWwgPSAnJztcblx0QElucHV0KCkgaGVscGVyVGV4dCA9ICcnO1xuXHRASW5wdXQoKSBuYW1lID0gJyc7XG5cdEBJbnB1dCgpIG1pbiA9IC1JbmZpbml0eTtcblx0QElucHV0KCkgbWF4ID0gSW5maW5pdHk7XG5cdEBJbnB1dCgpIHN0ZXAgPSAxO1xuXG5cdHByaXZhdGUgX192YWx1ZTogVmFsdWVUeXBlID0gbnVsbDtcblx0cHJpdmF0ZSBfX2ZvY3VzZWQgPSBmYWxzZTtcblx0cHJpdmF0ZSBfcmF3SW5wdXQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuXHRwcml2YXRlIF9yZXF1aXJlZDogYm9vbGVhbiB8IHVuZGVmaW5lZDtcblxuXHRASW5wdXQoKVxuXHRnZXQgcmVxdWlyZWQoKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuX3JlcXVpcmVkID8/IHRoaXMubmdDb250cm9sRGlyZWN0aXZlLmNvbnRyb2w/Lmhhc1ZhbGlkYXRvcihWYWxpZGF0b3JzLnJlcXVpcmVkKSA/PyBmYWxzZTtcblx0fVxuXG5cdHNldCByZXF1aXJlZCh2YWx1ZTogc3RyaW5nIHwgYm9vbGVhbiB8IG51bGwgfCB1bmRlZmluZWQpIHtcblx0XHR0aGlzLl9yZXF1aXJlZCA9IGNvZXJjZUJvb2xlYW5Qcm9wZXJ0eSh2YWx1ZSk7XG5cdH1cblxuXHRnZXQgZGlzYWJsZWQoKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuaXNEaXNhYmxlZERpcmVjdGl2ZS5pc0Rpc2FibGVkO1xuXHR9XG5cblx0Z2V0IF9lcnJvclN0YXRlKCkge1xuXHRcdHJldHVybiB0aGlzLmVycm9yU3RhdGVNYXRjaGVyRGlyZWN0aXZlLmVycm9yU3RhdGU7XG5cdH1cblxuXHRnZXQgX2ZvY3VzZWQoKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuX19mb2N1c2VkO1xuXHR9XG5cblx0Z2V0IF9pbnB1dElkKCkge1xuXHRcdHJldHVybiB0aGlzLmlkICsgJy1pbnB1dCc7XG5cdH1cblxuXHRnZXQgX2lzQXRNaW4oKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuX192YWx1ZSAhPSBudWxsICYmIHRoaXMuX192YWx1ZSA8PSB0aGlzLm1pbjtcblx0fVxuXG5cdGdldCBfaXNBdE1heCgpOiBib29sZWFuIHtcblx0XHRyZXR1cm4gdGhpcy5fX3ZhbHVlICE9IG51bGwgJiYgdGhpcy5fX3ZhbHVlID49IHRoaXMubWF4O1xuXHR9XG5cblx0Z2V0IF9pbnB1dFNpemUoKTogbnVtYmVyIHtcblx0XHRjb25zdCBsZW4gPSB0aGlzLl9kaXNwbGF5VmFsdWUubGVuZ3RoO1xuXG5cdFx0cmV0dXJuIGxlbiA+IDAgPyBsZW4gOiAxO1xuXHR9XG5cblx0Z2V0IF9hcmlhVmFsdWVNaW4oKTogbnVtYmVyIHwgbnVsbCB7XG5cdFx0cmV0dXJuIGlzRmluaXRlKHRoaXMubWluKSA/IHRoaXMubWluIDogbnVsbDtcblx0fVxuXG5cdGdldCBfYXJpYVZhbHVlTWF4KCk6IG51bWJlciB8IG51bGwge1xuXHRcdHJldHVybiBpc0Zpbml0ZSh0aGlzLm1heCkgPyB0aGlzLm1heCA6IG51bGw7XG5cdH1cblxuXHRnZXQgX2Rpc3BsYXlWYWx1ZSgpOiBzdHJpbmcge1xuXHRcdGlmICh0aGlzLl9yYXdJbnB1dCAhPSBudWxsKSB7XG5cdFx0XHRyZXR1cm4gdGhpcy5fcmF3SW5wdXQ7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIHRoaXMuX192YWx1ZSAhPSBudWxsID8gU3RyaW5nKHRoaXMuX192YWx1ZSkgOiAnJztcblx0fVxuXG5cdGdldCBfdmFsdWUoKTogVmFsdWVUeXBlIHtcblx0XHRyZXR1cm4gdGhpcy5fX3ZhbHVlO1xuXHR9XG5cblx0Y29uc3RydWN0b3IoXG5cdFx0cHJvdGVjdGVkIF9jaGFuZ2VEZXRlY3RvclJlZjogQ2hhbmdlRGV0ZWN0b3JSZWYsXG5cdFx0QFNlbGYoKSBwcm90ZWN0ZWQgbmdDb250cm9sRGlyZWN0aXZlOiBOZ0NvbnRyb2xEaXJlY3RpdmU8VmFsdWVUeXBlPixcblx0XHRAU2VsZigpIHByb3RlY3RlZCBlcnJvclN0YXRlTWF0Y2hlckRpcmVjdGl2ZTogSXVpRXJyb3JTdGF0ZU1hdGNoZXJEaXJlY3RpdmUsXG5cdFx0QFNlbGYoKSBwcm90ZWN0ZWQgaXNEaXNhYmxlZERpcmVjdGl2ZTogSXVpSXNEaXNhYmxlZERpcmVjdGl2ZVxuXHQpIHt9XG5cblx0X29uQ2hhbmdlOiAodmFsdWU6IFZhbHVlVHlwZSkgPT4gdm9pZCA9ICgpID0+IHt9O1xuXHRfb25Ub3VjaGVkID0gKCkgPT4ge307XG5cblx0X2luY3JlbWVudCgpOiB2b2lkIHtcblx0XHRjb25zdCBjdXJyZW50ID0gdGhpcy5fX3ZhbHVlID8/IDA7XG5cdFx0Y29uc3QgbmV3VmFsdWUgPSBNYXRoLm1pbihjdXJyZW50ICsgdGhpcy5zdGVwLCB0aGlzLm1heCk7XG5cblx0XHR0aGlzLl9zZXRWYWx1ZShuZXdWYWx1ZSk7XG5cdH1cblxuXHRfZGVjcmVtZW50KCk6IHZvaWQge1xuXHRcdGNvbnN0IGN1cnJlbnQgPSB0aGlzLl9fdmFsdWUgPz8gMDtcblx0XHRjb25zdCBuZXdWYWx1ZSA9IE1hdGgubWF4KGN1cnJlbnQgLSB0aGlzLnN0ZXAsIHRoaXMubWluKTtcblxuXHRcdHRoaXMuX3NldFZhbHVlKG5ld1ZhbHVlKTtcblx0fVxuXG5cdF9vbktleWRvd24oZXZlbnQ6IEtleWJvYXJkRXZlbnQpOiB2b2lkIHtcblx0XHRpZiAoZXZlbnQua2V5ID09PSAnQXJyb3dVcCcpIHtcblx0XHRcdGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG5cdFx0XHR0aGlzLl9pbmNyZW1lbnQoKTtcblx0XHR9IGVsc2UgaWYgKGV2ZW50LmtleSA9PT0gJ0Fycm93RG93bicpIHtcblx0XHRcdGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG5cdFx0XHR0aGlzLl9kZWNyZW1lbnQoKTtcblx0XHR9XG5cdH1cblxuXHRfb25JbnB1dENoYW5nZShldmVudDogRXZlbnQpOiB2b2lkIHtcblx0XHRjb25zdCByYXcgPSAoZXZlbnQudGFyZ2V0IGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlO1xuXG5cdFx0dGhpcy5fcmF3SW5wdXQgPSByYXc7XG5cblx0XHRpZiAocmF3ID09PSAnJykge1xuXHRcdFx0dGhpcy5fYXNzaWduVmFsdWUobnVsbCk7XG5cblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRpZiAocmF3ID09PSAnLScpIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRjb25zdCBwYXJzZWQgPSBOdW1iZXIocmF3KTtcblxuXHRcdGlmICghaXNOYU4ocGFyc2VkKSkge1xuXHRcdFx0dGhpcy5fc2V0VmFsdWUodGhpcy5fY2xhbXAocGFyc2VkKSk7XG5cdFx0fVxuXHR9XG5cblx0X29uRm9jdXMoKTogdm9pZCB7XG5cdFx0aWYgKCF0aGlzLmRpc2FibGVkKSB7XG5cdFx0XHR0aGlzLl9fZm9jdXNlZCA9IHRydWU7XG5cdFx0XHR0aGlzLl9yYXdJbnB1dCA9IHRoaXMuX2Rpc3BsYXlWYWx1ZTtcblx0XHR9XG5cdH1cblxuXHRfb25CbHVyKCk6IHZvaWQge1xuXHRcdHRoaXMuX19mb2N1c2VkID0gZmFsc2U7XG5cdFx0dGhpcy5fcmF3SW5wdXQgPSBudWxsO1xuXG5cdFx0aWYgKHRoaXMuX192YWx1ZSA9PSBudWxsKSB7XG5cdFx0XHRjb25zdCByZXNvbHZlZCA9IGlzRmluaXRlKHRoaXMubWluKSA/IHRoaXMubWluIDogMDtcblxuXHRcdFx0dGhpcy5fc2V0VmFsdWUocmVzb2x2ZWQpO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHR0aGlzLl9zZXRWYWx1ZSh0aGlzLl9jbGFtcCh0aGlzLl9fdmFsdWUpKTtcblx0XHR9XG5cblx0XHRpZiAoIXRoaXMuZGlzYWJsZWQpIHtcblx0XHRcdHRoaXMuX29uVG91Y2hlZCgpO1xuXHRcdFx0dGhpcy5fY2hhbmdlRGV0ZWN0b3JSZWYubWFya0ZvckNoZWNrKCk7XG5cdFx0fVxuXHR9XG5cblx0d3JpdGVWYWx1ZSh2YWx1ZTogVmFsdWVUeXBlKTogdm9pZCB7XG5cdFx0dGhpcy5fYXNzaWduVmFsdWUodmFsdWUpO1xuXHR9XG5cblx0cmVnaXN0ZXJPbkNoYW5nZShmbjogKHZhbHVlOiBWYWx1ZVR5cGUpID0+IHZvaWQpOiB2b2lkIHtcblx0XHR0aGlzLl9vbkNoYW5nZSA9IGZuO1xuXHR9XG5cblx0cmVnaXN0ZXJPblRvdWNoZWQoZm46ICgpID0+IHZvaWQpOiB2b2lkIHtcblx0XHR0aGlzLl9vblRvdWNoZWQgPSBmbjtcblx0fVxuXG5cdHNldERpc2FibGVkU3RhdGUoaXNEaXNhYmxlZDogYm9vbGVhbik6IHZvaWQge1xuXHRcdHRoaXMuaXNEaXNhYmxlZERpcmVjdGl2ZS5zZXREaXNhYmxlZFN0YXRlKGlzRGlzYWJsZWQpO1xuXHRcdHRoaXMuX2NoYW5nZURldGVjdG9yUmVmLm1hcmtGb3JDaGVjaygpO1xuXHR9XG5cblx0cHJpdmF0ZSBfc2V0VmFsdWUodmFsdWU6IG51bWJlcik6IHZvaWQge1xuXHRcdGNvbnN0IGhhc0Fzc2lnbmVkID0gdGhpcy5fYXNzaWduVmFsdWUodmFsdWUpO1xuXG5cdFx0aWYgKGhhc0Fzc2lnbmVkKSB7XG5cdFx0XHR0aGlzLl9vbkNoYW5nZSh2YWx1ZSk7XG5cdFx0fVxuXHR9XG5cblx0cHJpdmF0ZSBfYXNzaWduVmFsdWUobmV3VmFsdWU6IFZhbHVlVHlwZSk6IGJvb2xlYW4ge1xuXHRcdGlmIChuZXdWYWx1ZSAhPT0gdGhpcy5fX3ZhbHVlKSB7XG5cdFx0XHR0aGlzLl9fdmFsdWUgPSBuZXdWYWx1ZTtcblx0XHRcdHRoaXMuX2NoYW5nZURldGVjdG9yUmVmLm1hcmtGb3JDaGVjaygpO1xuXG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9XG5cblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblxuXHRwcml2YXRlIF9jbGFtcCh2YWx1ZTogbnVtYmVyKTogbnVtYmVyIHtcblx0XHRyZXR1cm4gTWF0aC5taW4oTWF0aC5tYXgodmFsdWUsIHRoaXMubWluKSwgdGhpcy5tYXgpO1xuXHR9XG59XG4iLCI8ZGl2IGNsYXNzPVwiaXVpLWluY3JlbWVudGFsLW51bWJlci1pbnB1dF9fbGFiZWwtZ3JvdXBcIj5cblx0PGRpdiBjbGFzcz1cIml1aS1pbmNyZW1lbnRhbC1udW1iZXItaW5wdXRfX2xhYmVsXCI+XG5cdFx0PHNwYW4gY2xhc3M9XCJpdWktaW5jcmVtZW50YWwtbnVtYmVyLWlucHV0X19sYWJlbC10ZXh0XCI+e3sgbGFiZWwgfX08L3NwYW4+XG5cdFx0PHNwYW4gKm5nSWY9XCJyZXF1aXJlZFwiIGNsYXNzPVwiaXVpLWluY3JlbWVudGFsLW51bWJlci1pbnB1dF9fYXN0ZXJpc2tcIj4qPC9zcGFuPlxuXHQ8L2Rpdj5cblx0PHNwYW4gKm5nSWY9XCJoZWxwZXJUZXh0XCIgY2xhc3M9XCJpdWktaW5jcmVtZW50YWwtbnVtYmVyLWlucHV0X19oZWxwZXItdGV4dFwiPnt7IGhlbHBlclRleHQgfX08L3NwYW4+XG48L2Rpdj5cblxuPGRpdiBjbGFzcz1cIml1aS1pbmNyZW1lbnRhbC1udW1iZXItaW5wdXRfX2ZpZWxkXCI+XG5cdDxidXR0b25cblx0XHRpdWlCdXR0b25cblx0XHRlbXBoYXNpcz1cImdob3N0XCJcblx0XHRzaXplPVwibVwiXG5cdFx0W2F0dHIudHlwZV09XCInYnV0dG9uJ1wiXG5cdFx0Y2xhc3M9XCJpdWktaW5jcmVtZW50YWwtbnVtYmVyLWlucHV0X19idXR0b24gaXVpLWluY3JlbWVudGFsLW51bWJlci1pbnB1dF9fYnV0dG9uX2RlY3JlbWVudFwiXG5cdFx0W2Rpc2FibGVkXT1cImRpc2FibGVkIHx8IF9pc0F0TWluXCJcblx0XHQoY2xpY2spPVwiX2RlY3JlbWVudCgpXCJcblx0XHR0YWJpbmRleD1cIi0xXCJcblx0XHRhcmlhLWxhYmVsPVwiRGVjcmVhc2UgdmFsdWVcIlxuXHQ+XG5cdFx0PGl1aS1zdWJ0cmFjdC1lbXB0eS1pY29uIGNsYXNzPVwiaXVpLWljb24gaXVpLWljb25fc2l6ZV9tXCI+PC9pdWktc3VidHJhY3QtZW1wdHktaWNvbj5cblx0PC9idXR0b24+XG5cblx0PGRpdiBjbGFzcz1cIml1aS1pbmNyZW1lbnRhbC1udW1iZXItaW5wdXRfX3ZhbHVlLWNvbnRhaW5lclwiPlxuXHRcdDxpbnB1dFxuXHRcdFx0I2lucHV0RWxlbWVudFxuXHRcdFx0dHlwZT1cInRleHRcIlxuXHRcdFx0aW5wdXRtb2RlPVwibnVtZXJpY1wiXG5cdFx0XHRjbGFzcz1cIml1aS1pbmNyZW1lbnRhbC1udW1iZXItaW5wdXRfX2lucHV0XCJcblx0XHRcdFthdHRyLmlkXT1cIl9pbnB1dElkXCJcblx0XHRcdFthdHRyLm5hbWVdPVwibmFtZVwiXG5cdFx0XHRyb2xlPVwic3BpbmJ1dHRvblwiXG5cdFx0XHRbYXR0ci5hcmlhLWxhYmVsXT1cImxhYmVsXCJcblx0XHRcdFthdHRyLmFyaWEtdmFsdWVtaW5dPVwiX2FyaWFWYWx1ZU1pblwiXG5cdFx0XHRbYXR0ci5hcmlhLXZhbHVlbWF4XT1cIl9hcmlhVmFsdWVNYXhcIlxuXHRcdFx0W2F0dHIuYXJpYS12YWx1ZW5vd109XCJfdmFsdWUgPz8gbnVsbFwiXG5cdFx0XHRbYXR0ci5zaXplXT1cIl9pbnB1dFNpemVcIlxuXHRcdFx0W2Rpc2FibGVkXT1cImRpc2FibGVkXCJcblx0XHRcdFt2YWx1ZV09XCJfZGlzcGxheVZhbHVlXCJcblx0XHRcdChpbnB1dCk9XCJfb25JbnB1dENoYW5nZSgkZXZlbnQpXCJcblx0XHRcdChmb2N1cyk9XCJfb25Gb2N1cygpXCJcblx0XHRcdChibHVyKT1cIl9vbkJsdXIoKVwiXG5cdFx0XHQoa2V5ZG93bik9XCJfb25LZXlkb3duKCRldmVudClcIlxuXHRcdC8+XG5cdDwvZGl2PlxuXG5cdDxidXR0b25cblx0XHRpdWlCdXR0b25cblx0XHRlbXBoYXNpcz1cImdob3N0XCJcblx0XHRzaXplPVwibVwiXG5cdFx0W2F0dHIudHlwZV09XCInYnV0dG9uJ1wiXG5cdFx0Y2xhc3M9XCJpdWktaW5jcmVtZW50YWwtbnVtYmVyLWlucHV0X19idXR0b24gaXVpLWluY3JlbWVudGFsLW51bWJlci1pbnB1dF9fYnV0dG9uX2luY3JlbWVudFwiXG5cdFx0W2Rpc2FibGVkXT1cImRpc2FibGVkIHx8IF9pc0F0TWF4XCJcblx0XHQoY2xpY2spPVwiX2luY3JlbWVudCgpXCJcblx0XHR0YWJpbmRleD1cIi0xXCJcblx0XHRhcmlhLWxhYmVsPVwiSW5jcmVhc2UgdmFsdWVcIlxuXHQ+XG5cdFx0PGl1aS1hZGQtZW1wdHktaWNvbiBjbGFzcz1cIml1aS1pY29uIGl1aS1pY29uX3NpemVfbVwiPjwvaXVpLWFkZC1lbXB0eS1pY29uPlxuXHQ8L2J1dHRvbj5cblxuPC9kaXY+XG4iXX0=