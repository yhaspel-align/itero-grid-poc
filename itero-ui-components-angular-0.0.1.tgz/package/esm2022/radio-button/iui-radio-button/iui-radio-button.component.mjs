import { UniqueSelectionDispatcher } from '@angular/cdk/collections';
import { NgClass, NgIf } from '@angular/common';
import { ChangeDetectorRef, Component, EventEmitter, forwardRef, Inject, Input, Optional, Output } from '@angular/core';
import { IuiRadioGroupComponent } from '../iui-radio-group/iui-radio-group.component';
import { IuiRadioButtonUniqueIdService } from '../iui-radio-button-unique-id';
import * as i0 from "@angular/core";
import * as i1 from "../iui-radio-button-unique-id";
import * as i2 from "@angular/cdk/collections";
import * as i3 from "../iui-radio-group/iui-radio-group.component";
export class IuiRadioButtonComponent {
    set disabled(value) {
        this._disabled = value;
        this.markForCheck();
    }
    get disabled() {
        return this._disabled || this.skeleton || (this.radioGroup && this.radioGroup.disabled);
    }
    get change() {
        return this._change;
    }
    get checked() {
        return this._checked;
    }
    set checked(state) {
        if (this._checked !== state) {
            this._checked = state;
            if (state && this.radioGroup && this.radioGroup.value !== this.value) {
                this.radioGroup.selected = this;
            }
            else if (!state && this.radioGroup && this.radioGroup.value === this.value) {
                this.radioGroup.selected = null;
            }
            if (state) {
                this.radioDispatcher.notify(this.id, this.name);
            }
            this.changeDetector.markForCheck();
        }
    }
    get required() {
        return this._required || (this.radioGroup && this.radioGroup.required);
    }
    set required(value) {
        this._required = value;
    }
    constructor(radioGroup, changeDetector, nextUniqueId, radioDispatcher) {
        this.radioGroup = radioGroup;
        this.changeDetector = changeDetector;
        this.nextUniqueId = nextUniqueId;
        this.radioDispatcher = radioDispatcher;
        this.showValue = true;
        this.skeleton = false;
        this._required = false;
        this._checked = false;
        this._disabled = false;
        this._change = new EventEmitter(); // Event emitter for change
    }
    ngOnInit() {
        const uniqueId = this.nextUniqueId.getRadioButtonId();
        // Set unique ID if not provided
        if (!this.id) {
            this.id = `iui-radio-${uniqueId}`;
        }
        // If part of a radio group, inherit the group’s name and disabled state
        if (this.radioGroup) {
            this.name = this.radioGroup.name;
            this.disabled = this.radioGroup.disabled;
            this.checked = this.radioGroup.value === this.value;
        }
    }
    onChange(event) {
        const inputElement = event.target;
        this.checked = inputElement.checked;
        this._change.emit(this.value);
        // Notify the group of the change if part of a group
        if (this.radioGroup) {
            this.radioGroup.selectRadio(this);
        }
    }
    /** Marks the component for change detection */
    markForCheck() {
        this.changeDetector.markForCheck();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioButtonComponent, deps: [{ token: forwardRef(() => IuiRadioGroupComponent), optional: true }, { token: i0.ChangeDetectorRef }, { token: i1.IuiRadioButtonUniqueIdService }, { token: i2.UniqueSelectionDispatcher }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiRadioButtonComponent, isStandalone: true, selector: "iui-radio-button", inputs: { id: "id", value: "value", label: "label", description: "description", name: "name", arialabel: "arialabel", arialabelledby: "arialabelledby", showValue: "showValue", skeleton: "skeleton", disabled: "disabled", checked: "checked", required: "required" }, outputs: { _change: "_change" }, ngImport: i0, template: "<label class=\"iui-radio-button-container\" [ngClass]=\"{ disabled: disabled, skeleton: skeleton }\">\n\t<input\n\t\ttype=\"radio\"\n\t\t[attr.aria-label]=\"arialabel\"\n\t\t[attr.aria-labelledby]=\"arialabelledby\"\n\t\t[id]=\"id\"\n\t\t[name]=\"name\"\n\t\t[disabled]=\"disabled\"\n\t\t[checked]=\"checked\"\n\t\t[value]=\"value\"\n\t\t(change)=\"onChange($event)\"\n\t/>\n\t<div class=\"label-container\" *ngIf=\"showValue && !skeleton\">\n\t\t<p class=\"label-text\">{{ label }}</p>\n\t\t<p *ngIf=\"description\" class=\"label-description\">{{ description }}</p>\n\t</div>\n\t<div class=\"skeleton-value-box\" *ngIf=\"skeleton\"></div>\n</label>\n", styles: ["@charset \"UTF-8\";input[type=radio]{--radio-border-color: var(--iui-radio-border);--radio-checked-color: var(--iui-radio-checked);--radio-disabled-bg-color: var(--iui-radio-disabled-bg);--radio-focused-color: var(--iui-radio-focus);cursor:pointer;box-sizing:border-box;width:20px;height:20px;margin:0;padding:0;border:1px solid var(--radio-border-color);border-radius:50%;appearance:none;background-color:transparent;outline:none;flex-shrink:0}input[type=radio]:not(:disabled):checked{border-color:var(--radio-checked-color);background-color:var(--radio-checked-color);background-clip:content-box;padding:5.2px;background-image:radial-gradient(circle,var(--radio-checked-color) 0%,var(--radio-checked-color) 50%,transparent 60%,transparent 100%)}input[type=radio]:disabled{background-color:var(--radio-disabled-bg-color);border:1px solid var(--iui-radio-disabled-border);cursor:default}input[type=radio]:disabled:checked{border-color:var(--iui-radio-disabled-checked);background-clip:content-box;padding:5.2px;background-image:radial-gradient(circle,var(--iui-radio-disabled-checked) 0%,var(--iui-radio-disabled-checked) 50%,transparent 50%,transparent 100%)}input[type=radio]:focus-visible{outline:2px solid var(--radio-focused-color);outline-offset:1px}.iui-radio-button-container{display:flex;align-items:flex-start;gap:8px;padding:0}.iui-radio-button-container.skeleton{align-items:center}.iui-radio-button-container.disabled{color:var(--iui-radio-disabled-color)}.iui-radio-button-container input[type=radio].disabled{cursor:default}.iui-radio-button-container .label-container{display:flex;flex-direction:column;gap:4px}.iui-radio-button-container .label-container .label-text{margin:0;font:var(--iui-tp-body-01-font);color:var(--iui-radio-color);max-width:320px;white-space:nowrap}.iui-radio-button-container .label-container .label-description{margin:0;font:var(--iui-tp-label-01-font);color:var(--iui-radio-color);box-sizing:border-box;white-space:normal;word-wrap:break-word}.iui-radio-button-container .skeleton-value-box{width:40px;height:8px;background-color:var(--iui-radio-skeleton-bg);flex-shrink:0}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-radio-button', standalone: true, imports: [NgIf, NgClass], template: "<label class=\"iui-radio-button-container\" [ngClass]=\"{ disabled: disabled, skeleton: skeleton }\">\n\t<input\n\t\ttype=\"radio\"\n\t\t[attr.aria-label]=\"arialabel\"\n\t\t[attr.aria-labelledby]=\"arialabelledby\"\n\t\t[id]=\"id\"\n\t\t[name]=\"name\"\n\t\t[disabled]=\"disabled\"\n\t\t[checked]=\"checked\"\n\t\t[value]=\"value\"\n\t\t(change)=\"onChange($event)\"\n\t/>\n\t<div class=\"label-container\" *ngIf=\"showValue && !skeleton\">\n\t\t<p class=\"label-text\">{{ label }}</p>\n\t\t<p *ngIf=\"description\" class=\"label-description\">{{ description }}</p>\n\t</div>\n\t<div class=\"skeleton-value-box\" *ngIf=\"skeleton\"></div>\n</label>\n", styles: ["@charset \"UTF-8\";input[type=radio]{--radio-border-color: var(--iui-radio-border);--radio-checked-color: var(--iui-radio-checked);--radio-disabled-bg-color: var(--iui-radio-disabled-bg);--radio-focused-color: var(--iui-radio-focus);cursor:pointer;box-sizing:border-box;width:20px;height:20px;margin:0;padding:0;border:1px solid var(--radio-border-color);border-radius:50%;appearance:none;background-color:transparent;outline:none;flex-shrink:0}input[type=radio]:not(:disabled):checked{border-color:var(--radio-checked-color);background-color:var(--radio-checked-color);background-clip:content-box;padding:5.2px;background-image:radial-gradient(circle,var(--radio-checked-color) 0%,var(--radio-checked-color) 50%,transparent 60%,transparent 100%)}input[type=radio]:disabled{background-color:var(--radio-disabled-bg-color);border:1px solid var(--iui-radio-disabled-border);cursor:default}input[type=radio]:disabled:checked{border-color:var(--iui-radio-disabled-checked);background-clip:content-box;padding:5.2px;background-image:radial-gradient(circle,var(--iui-radio-disabled-checked) 0%,var(--iui-radio-disabled-checked) 50%,transparent 50%,transparent 100%)}input[type=radio]:focus-visible{outline:2px solid var(--radio-focused-color);outline-offset:1px}.iui-radio-button-container{display:flex;align-items:flex-start;gap:8px;padding:0}.iui-radio-button-container.skeleton{align-items:center}.iui-radio-button-container.disabled{color:var(--iui-radio-disabled-color)}.iui-radio-button-container input[type=radio].disabled{cursor:default}.iui-radio-button-container .label-container{display:flex;flex-direction:column;gap:4px}.iui-radio-button-container .label-container .label-text{margin:0;font:var(--iui-tp-body-01-font);color:var(--iui-radio-color);max-width:320px;white-space:nowrap}.iui-radio-button-container .label-container .label-description{margin:0;font:var(--iui-tp-label-01-font);color:var(--iui-radio-color);box-sizing:border-box;white-space:normal;word-wrap:break-word}.iui-radio-button-container .skeleton-value-box{width:40px;height:8px;background-color:var(--iui-radio-skeleton-bg);flex-shrink:0}\n"] }]
        }], ctorParameters: () => [{ type: i3.IuiRadioGroupComponent, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [forwardRef(() => IuiRadioGroupComponent)]
                }] }, { type: i0.ChangeDetectorRef }, { type: i1.IuiRadioButtonUniqueIdService }, { type: i2.UniqueSelectionDispatcher }], propDecorators: { id: [{
                type: Input
            }], value: [{
                type: Input
            }], label: [{
                type: Input
            }], description: [{
                type: Input
            }], name: [{
                type: Input
            }], arialabel: [{
                type: Input
            }], arialabelledby: [{
                type: Input
            }], showValue: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], disabled: [{
                type: Input
            }], _change: [{
                type: Output
            }], checked: [{
                type: Input
            }], required: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLXJhZGlvLWJ1dHRvbi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS9yYWRpby1idXR0b24vc3JjL2l1aS1yYWRpby1idXR0b24vaXVpLXJhZGlvLWJ1dHRvbi5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS9yYWRpby1idXR0b24vc3JjL2l1aS1yYWRpby1idXR0b24vaXVpLXJhZGlvLWJ1dHRvbi5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUseUJBQXlCLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUNyRSxPQUFPLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ2hELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFVLFFBQVEsRUFBRSxNQUFNLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDaEksT0FBTyxFQUFFLHNCQUFzQixFQUFFLE1BQU0sOENBQThDLENBQUM7QUFDdEYsT0FBTyxFQUFFLDZCQUE2QixFQUFFLE1BQU0sK0JBQStCLENBQUM7Ozs7O0FBUzlFLE1BQU0sT0FBTyx1QkFBdUI7SUFpQm5DLElBQ0ksUUFBUSxDQUFDLEtBQWM7UUFDMUIsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFDdkIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFRCxJQUFJLFFBQVE7UUFDWCxPQUFPLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN6RixDQUFDO0lBSUQsSUFBSSxNQUFNO1FBQ1QsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBQ3JCLENBQUM7SUFFRCxJQUNJLE9BQU87UUFDVixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDdEIsQ0FBQztJQUVELElBQUksT0FBTyxDQUFDLEtBQWM7UUFDekIsSUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLEtBQUssRUFBRSxDQUFDO1lBQzdCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1lBQ3RCLElBQUksS0FBSyxJQUFJLElBQUksQ0FBQyxVQUFVLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUN0RSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7WUFDakMsQ0FBQztpQkFBTSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxVQUFVLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUM5RSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7WUFDakMsQ0FBQztZQUVELElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ1gsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDakQsQ0FBQztZQUVELElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDcEMsQ0FBQztJQUNGLENBQUM7SUFFRCxJQUNJLFFBQVE7UUFDWCxPQUFPLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWM7UUFDMUIsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7SUFDeEIsQ0FBQztJQUVELFlBQ3VFLFVBQWtDLEVBQ2hHLGNBQWlDLEVBQ2pDLFlBQTJDLEVBQzNDLGVBQTBDO1FBSG9CLGVBQVUsR0FBVixVQUFVLENBQXdCO1FBQ2hHLG1CQUFjLEdBQWQsY0FBYyxDQUFtQjtRQUNqQyxpQkFBWSxHQUFaLFlBQVksQ0FBK0I7UUFDM0Msb0JBQWUsR0FBZixlQUFlLENBQTJCO1FBM0QxQyxjQUFTLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLGFBQVEsR0FBRyxLQUFLLENBQUM7UUFFbEIsY0FBUyxHQUFHLEtBQUssQ0FBQztRQUVsQixhQUFRLEdBQUcsS0FBSyxDQUFDO1FBRWpCLGNBQVMsR0FBRyxLQUFLLENBQUM7UUFZaEIsWUFBTyxHQUFHLElBQUksWUFBWSxFQUFPLENBQUMsQ0FBQywyQkFBMkI7SUF5Q3JFLENBQUM7SUFFSixRQUFRO1FBQ1AsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBRXRELGdDQUFnQztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQ2QsSUFBSSxDQUFDLEVBQUUsR0FBRyxhQUFhLFFBQVEsRUFBRSxDQUFDO1FBQ25DLENBQUM7UUFFRCx3RUFBd0U7UUFDeEUsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDckIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztZQUNqQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNyRCxDQUFDO0lBQ0YsQ0FBQztJQUVELFFBQVEsQ0FBQyxLQUFZO1FBQ3BCLE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQyxNQUEwQixDQUFDO1FBRXRELElBQUksQ0FBQyxPQUFPLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQztRQUNwQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFOUIsb0RBQW9EO1FBQ3BELElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ25DLENBQUM7SUFDRixDQUFDO0lBRUQsK0NBQStDO0lBQy9DLFlBQVk7UUFDWCxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ3BDLENBQUM7K0dBckdXLHVCQUF1QixrQkFnRWQsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLHNCQUFzQixDQUFDO21HQWhFakQsdUJBQXVCLHFYQ2JwQyw2b0JBa0JBLGdvRURQVyxJQUFJLDZGQUFFLE9BQU87OzRGQUVYLHVCQUF1QjtrQkFQbkMsU0FBUzsrQkFDQyxrQkFBa0IsY0FHaEIsSUFBSSxXQUNQLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQzs7MEJBa0V0QixRQUFROzswQkFBSSxNQUFNOzJCQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxzQkFBc0IsQ0FBQzs2SkEvRHBELEVBQUU7c0JBQVYsS0FBSztnQkFDRyxLQUFLO3NCQUFiLEtBQUs7Z0JBQ0csS0FBSztzQkFBYixLQUFLO2dCQUNHLFdBQVc7c0JBQW5CLEtBQUs7Z0JBQ0csSUFBSTtzQkFBWixLQUFLO2dCQUNHLFNBQVM7c0JBQWpCLEtBQUs7Z0JBQ0csY0FBYztzQkFBdEIsS0FBSztnQkFDRyxTQUFTO3NCQUFqQixLQUFLO2dCQUNHLFFBQVE7c0JBQWhCLEtBQUs7Z0JBU0YsUUFBUTtzQkFEWCxLQUFLO2dCQVVJLE9BQU87c0JBQWhCLE1BQU07Z0JBT0gsT0FBTztzQkFEVixLQUFLO2dCQXVCRixRQUFRO3NCQURYLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBVbmlxdWVTZWxlY3Rpb25EaXNwYXRjaGVyIH0gZnJvbSAnQGFuZ3VsYXIvY2RrL2NvbGxlY3Rpb25zJztcbmltcG9ydCB7IE5nQ2xhc3MsIE5nSWYgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0b3JSZWYsIENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBmb3J3YXJkUmVmLCBJbmplY3QsIElucHV0LCBPbkluaXQsIE9wdGlvbmFsLCBPdXRwdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEl1aVJhZGlvR3JvdXBDb21wb25lbnQgfSBmcm9tICcuLi9pdWktcmFkaW8tZ3JvdXAvaXVpLXJhZGlvLWdyb3VwLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBJdWlSYWRpb0J1dHRvblVuaXF1ZUlkU2VydmljZSB9IGZyb20gJy4uL2l1aS1yYWRpby1idXR0b24tdW5pcXVlLWlkJztcblxuQENvbXBvbmVudCh7XG5cdHNlbGVjdG9yOiAnaXVpLXJhZGlvLWJ1dHRvbicsXG5cdHRlbXBsYXRlVXJsOiAnLi9pdWktcmFkaW8tYnV0dG9uLmNvbXBvbmVudC5odG1sJyxcblx0c3R5bGVVcmxzOiBbJy4vaXVpLXJhZGlvLWJ1dHRvbi5jb21wb25lbnQuc2NzcyddLFxuXHRzdGFuZGFsb25lOiB0cnVlLFxuXHRpbXBvcnRzOiBbTmdJZiwgTmdDbGFzc11cbn0pXG5leHBvcnQgY2xhc3MgSXVpUmFkaW9CdXR0b25Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuXHRASW5wdXQoKSBpZCE6IHN0cmluZztcblx0QElucHV0KCkgdmFsdWUhOiBhbnk7XG5cdEBJbnB1dCgpIGxhYmVsITogc3RyaW5nO1xuXHRASW5wdXQoKSBkZXNjcmlwdGlvbiE6IHN0cmluZztcblx0QElucHV0KCkgbmFtZSE6IHN0cmluZztcblx0QElucHV0KCkgYXJpYWxhYmVsITogc3RyaW5nO1xuXHRASW5wdXQoKSBhcmlhbGFiZWxsZWRieSE6IHN0cmluZztcblx0QElucHV0KCkgc2hvd1ZhbHVlID0gdHJ1ZTtcblx0QElucHV0KCkgc2tlbGV0b24gPSBmYWxzZTtcblxuXHRwcml2YXRlIF9yZXF1aXJlZCA9IGZhbHNlO1xuXG5cdHByaXZhdGUgX2NoZWNrZWQgPSBmYWxzZTtcblxuXHRwcml2YXRlIF9kaXNhYmxlZCA9IGZhbHNlO1xuXG5cdEBJbnB1dCgpXG5cdHNldCBkaXNhYmxlZCh2YWx1ZTogYm9vbGVhbikge1xuXHRcdHRoaXMuX2Rpc2FibGVkID0gdmFsdWU7XG5cdFx0dGhpcy5tYXJrRm9yQ2hlY2soKTtcblx0fVxuXG5cdGdldCBkaXNhYmxlZCgpOiBib29sZWFuIHtcblx0XHRyZXR1cm4gdGhpcy5fZGlzYWJsZWQgfHwgdGhpcy5za2VsZXRvbiB8fCAodGhpcy5yYWRpb0dyb3VwICYmIHRoaXMucmFkaW9Hcm91cC5kaXNhYmxlZCk7XG5cdH1cblxuXHRAT3V0cHV0KCkgX2NoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpOyAvLyBFdmVudCBlbWl0dGVyIGZvciBjaGFuZ2VcblxuXHRnZXQgY2hhbmdlKCk6IEV2ZW50RW1pdHRlcjxhbnk+IHtcblx0XHRyZXR1cm4gdGhpcy5fY2hhbmdlO1xuXHR9XG5cblx0QElucHV0KClcblx0Z2V0IGNoZWNrZWQoKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuX2NoZWNrZWQ7XG5cdH1cblxuXHRzZXQgY2hlY2tlZChzdGF0ZTogYm9vbGVhbikge1xuXHRcdGlmICh0aGlzLl9jaGVja2VkICE9PSBzdGF0ZSkge1xuXHRcdFx0dGhpcy5fY2hlY2tlZCA9IHN0YXRlO1xuXHRcdFx0aWYgKHN0YXRlICYmIHRoaXMucmFkaW9Hcm91cCAmJiB0aGlzLnJhZGlvR3JvdXAudmFsdWUgIT09IHRoaXMudmFsdWUpIHtcblx0XHRcdFx0dGhpcy5yYWRpb0dyb3VwLnNlbGVjdGVkID0gdGhpcztcblx0XHRcdH0gZWxzZSBpZiAoIXN0YXRlICYmIHRoaXMucmFkaW9Hcm91cCAmJiB0aGlzLnJhZGlvR3JvdXAudmFsdWUgPT09IHRoaXMudmFsdWUpIHtcblx0XHRcdFx0dGhpcy5yYWRpb0dyb3VwLnNlbGVjdGVkID0gbnVsbDtcblx0XHRcdH1cblxuXHRcdFx0aWYgKHN0YXRlKSB7XG5cdFx0XHRcdHRoaXMucmFkaW9EaXNwYXRjaGVyLm5vdGlmeSh0aGlzLmlkLCB0aGlzLm5hbWUpO1xuXHRcdFx0fVxuXG5cdFx0XHR0aGlzLmNoYW5nZURldGVjdG9yLm1hcmtGb3JDaGVjaygpO1xuXHRcdH1cblx0fVxuXG5cdEBJbnB1dCgpXG5cdGdldCByZXF1aXJlZCgpOiBib29sZWFuIHtcblx0XHRyZXR1cm4gdGhpcy5fcmVxdWlyZWQgfHwgKHRoaXMucmFkaW9Hcm91cCAmJiB0aGlzLnJhZGlvR3JvdXAucmVxdWlyZWQpO1xuXHR9XG5cdHNldCByZXF1aXJlZCh2YWx1ZTogYm9vbGVhbikge1xuXHRcdHRoaXMuX3JlcXVpcmVkID0gdmFsdWU7XG5cdH1cblxuXHRjb25zdHJ1Y3Rvcihcblx0XHRAT3B0aW9uYWwoKSBASW5qZWN0KGZvcndhcmRSZWYoKCkgPT4gSXVpUmFkaW9Hcm91cENvbXBvbmVudCkpIHByaXZhdGUgcmFkaW9Hcm91cDogSXVpUmFkaW9Hcm91cENvbXBvbmVudCxcblx0XHRwcml2YXRlIGNoYW5nZURldGVjdG9yOiBDaGFuZ2VEZXRlY3RvclJlZixcblx0XHRwcml2YXRlIG5leHRVbmlxdWVJZDogSXVpUmFkaW9CdXR0b25VbmlxdWVJZFNlcnZpY2UsXG5cdFx0cHJpdmF0ZSByYWRpb0Rpc3BhdGNoZXI6IFVuaXF1ZVNlbGVjdGlvbkRpc3BhdGNoZXJcblx0KSB7fVxuXG5cdG5nT25Jbml0KCk6IHZvaWQge1xuXHRcdGNvbnN0IHVuaXF1ZUlkID0gdGhpcy5uZXh0VW5pcXVlSWQuZ2V0UmFkaW9CdXR0b25JZCgpO1xuXG5cdFx0Ly8gU2V0IHVuaXF1ZSBJRCBpZiBub3QgcHJvdmlkZWRcblx0XHRpZiAoIXRoaXMuaWQpIHtcblx0XHRcdHRoaXMuaWQgPSBgaXVpLXJhZGlvLSR7dW5pcXVlSWR9YDtcblx0XHR9XG5cblx0XHQvLyBJZiBwYXJ0IG9mIGEgcmFkaW8gZ3JvdXAsIGluaGVyaXQgdGhlIGdyb3Vw4oCZcyBuYW1lIGFuZCBkaXNhYmxlZCBzdGF0ZVxuXHRcdGlmICh0aGlzLnJhZGlvR3JvdXApIHtcblx0XHRcdHRoaXMubmFtZSA9IHRoaXMucmFkaW9Hcm91cC5uYW1lO1xuXHRcdFx0dGhpcy5kaXNhYmxlZCA9IHRoaXMucmFkaW9Hcm91cC5kaXNhYmxlZDtcblx0XHRcdHRoaXMuY2hlY2tlZCA9IHRoaXMucmFkaW9Hcm91cC52YWx1ZSA9PT0gdGhpcy52YWx1ZTtcblx0XHR9XG5cdH1cblxuXHRvbkNoYW5nZShldmVudDogRXZlbnQpIHtcblx0XHRjb25zdCBpbnB1dEVsZW1lbnQgPSBldmVudC50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudDtcblxuXHRcdHRoaXMuY2hlY2tlZCA9IGlucHV0RWxlbWVudC5jaGVja2VkO1xuXHRcdHRoaXMuX2NoYW5nZS5lbWl0KHRoaXMudmFsdWUpO1xuXG5cdFx0Ly8gTm90aWZ5IHRoZSBncm91cCBvZiB0aGUgY2hhbmdlIGlmIHBhcnQgb2YgYSBncm91cFxuXHRcdGlmICh0aGlzLnJhZGlvR3JvdXApIHtcblx0XHRcdHRoaXMucmFkaW9Hcm91cC5zZWxlY3RSYWRpbyh0aGlzKTtcblx0XHR9XG5cdH1cblxuXHQvKiogTWFya3MgdGhlIGNvbXBvbmVudCBmb3IgY2hhbmdlIGRldGVjdGlvbiAqL1xuXHRtYXJrRm9yQ2hlY2soKSB7XG5cdFx0dGhpcy5jaGFuZ2VEZXRlY3Rvci5tYXJrRm9yQ2hlY2soKTtcblx0fVxufVxuIiwiPGxhYmVsIGNsYXNzPVwiaXVpLXJhZGlvLWJ1dHRvbi1jb250YWluZXJcIiBbbmdDbGFzc109XCJ7IGRpc2FibGVkOiBkaXNhYmxlZCwgc2tlbGV0b246IHNrZWxldG9uIH1cIj5cblx0PGlucHV0XG5cdFx0dHlwZT1cInJhZGlvXCJcblx0XHRbYXR0ci5hcmlhLWxhYmVsXT1cImFyaWFsYWJlbFwiXG5cdFx0W2F0dHIuYXJpYS1sYWJlbGxlZGJ5XT1cImFyaWFsYWJlbGxlZGJ5XCJcblx0XHRbaWRdPVwiaWRcIlxuXHRcdFtuYW1lXT1cIm5hbWVcIlxuXHRcdFtkaXNhYmxlZF09XCJkaXNhYmxlZFwiXG5cdFx0W2NoZWNrZWRdPVwiY2hlY2tlZFwiXG5cdFx0W3ZhbHVlXT1cInZhbHVlXCJcblx0XHQoY2hhbmdlKT1cIm9uQ2hhbmdlKCRldmVudClcIlxuXHQvPlxuXHQ8ZGl2IGNsYXNzPVwibGFiZWwtY29udGFpbmVyXCIgKm5nSWY9XCJzaG93VmFsdWUgJiYgIXNrZWxldG9uXCI+XG5cdFx0PHAgY2xhc3M9XCJsYWJlbC10ZXh0XCI+e3sgbGFiZWwgfX08L3A+XG5cdFx0PHAgKm5nSWY9XCJkZXNjcmlwdGlvblwiIGNsYXNzPVwibGFiZWwtZGVzY3JpcHRpb25cIj57eyBkZXNjcmlwdGlvbiB9fTwvcD5cblx0PC9kaXY+XG5cdDxkaXYgY2xhc3M9XCJza2VsZXRvbi12YWx1ZS1ib3hcIiAqbmdJZj1cInNrZWxldG9uXCI+PC9kaXY+XG48L2xhYmVsPlxuIl19