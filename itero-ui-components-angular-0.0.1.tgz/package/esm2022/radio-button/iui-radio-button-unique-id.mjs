import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class IuiRadioButtonUniqueIdService {
    constructor() {
        this.nextUniqueId = 0;
    }
    getRadioButtonGroupId() {
        return this.nextUniqueId++;
    }
    getRadioButtonId() {
        return ++this.nextUniqueId;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioButtonUniqueIdService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioButtonUniqueIdService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioButtonUniqueIdService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLXJhZGlvLWJ1dHRvbi11bmlxdWUtaWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS9yYWRpby1idXR0b24vc3JjL2l1aS1yYWRpby1idXR0b24tdW5pcXVlLWlkLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBSzNDLE1BQU0sT0FBTyw2QkFBNkI7SUFIMUM7UUFJUyxpQkFBWSxHQUFHLENBQUMsQ0FBQztLQVN6QjtJQVBBLHFCQUFxQjtRQUNwQixPQUFPLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRUQsZ0JBQWdCO1FBQ2YsT0FBTyxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUM7SUFDNUIsQ0FBQzsrR0FUVyw2QkFBNkI7bUhBQTdCLDZCQUE2QixjQUY3QixNQUFNOzs0RkFFTiw2QkFBNkI7a0JBSHpDLFVBQVU7bUJBQUM7b0JBQ1gsVUFBVSxFQUFFLE1BQU07aUJBQ2xCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ASW5qZWN0YWJsZSh7XG5cdHByb3ZpZGVkSW46ICdyb290J1xufSlcbmV4cG9ydCBjbGFzcyBJdWlSYWRpb0J1dHRvblVuaXF1ZUlkU2VydmljZSB7XG5cdHByaXZhdGUgbmV4dFVuaXF1ZUlkID0gMDtcblxuXHRnZXRSYWRpb0J1dHRvbkdyb3VwSWQoKTogbnVtYmVyIHtcblx0XHRyZXR1cm4gdGhpcy5uZXh0VW5pcXVlSWQrKztcblx0fVxuXG5cdGdldFJhZGlvQnV0dG9uSWQoKTogbnVtYmVyIHtcblx0XHRyZXR1cm4gKyt0aGlzLm5leHRVbmlxdWVJZDtcblx0fVxufVxuIl19