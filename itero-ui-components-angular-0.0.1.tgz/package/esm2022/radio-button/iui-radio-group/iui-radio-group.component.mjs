import { Component, ContentChildren, QueryList, Input, Output, EventEmitter, ChangeDetectorRef, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { NgIf } from '@angular/common';
import { IuiRadioButtonComponent } from '../iui-radio-button/iui-radio-button.component';
import { IuiRadioButtonUniqueIdService } from '../iui-radio-button-unique-id';
import * as i0 from "@angular/core";
import * as i1 from "../iui-radio-button-unique-id";
export class IuiRadioGroupComponent {
    get selected() {
        return this._selected;
    }
    set selected(selected) {
        this._selected = selected;
        this.value = selected ? selected.value : null;
        this.checkSelectedRadioButton();
    }
    get required() {
        return this._required;
    }
    set required(value) {
        this._required = value;
        this._markRadiosForCheck();
    }
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = value;
        this._markRadiosForCheck();
    }
    constructor(_changeDetectorRef, nextUniqueId) {
        this._changeDetectorRef = _changeDetectorRef;
        this.nextUniqueId = nextUniqueId;
        this.orientation = 'vertical';
        this.label = '';
        this.showLabel = true;
        this.value = null;
        this._selected = null;
        this.radioButtonChangeSubscription = null;
        this._required = false;
        this._disabled = false;
        this._change = new EventEmitter();
        this._onChange = () => { };
        this._onTouched = () => { };
    }
    ngOnInit() {
        const uniqueId = this.nextUniqueId.getRadioButtonGroupId();
        if (!this.name) {
            this.name = `iui-radio-group-${uniqueId}`;
        }
    }
    ngAfterContentInit() {
        this.updateRadioButtonNames();
        this._subscribeToRadioButtonChanges();
    }
    ngOnDestroy() {
        this.radioButtonChangeSubscription?.unsubscribe();
    }
    writeValue(value) {
        this.value = value;
        this.updateSelectedRadioFromValue();
        this._changeDetectorRef.markForCheck();
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    updateRadioButtonNames() {
        this._radios.forEach(radioButton => {
            radioButton.name = this.name;
            radioButton.disabled = this.disabled;
        });
    }
    _subscribeToRadioButtonChanges() {
        this.radioButtonChangeSubscription = this._radios.changes.subscribe(() => {
            this.updateRadioButtonNames();
        });
        this._radios.forEach(radioButton => {
            radioButton.change.subscribe(() => {
                this.selectRadio(radioButton);
            });
        });
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        this._markRadiosForCheck();
    }
    updateSelectedRadioFromValue() {
        if (this._radios) {
            this._radios.forEach(radioButton => {
                radioButton.checked = this.value === radioButton.value;
            });
        }
    }
    selectRadio(selectedRadioButton) {
        this.value = selectedRadioButton.value;
        this._selected = selectedRadioButton;
        this.updateSelectedRadioFromValue();
        this._onChange(this.value);
        this._onTouched(this.value);
        this._change.emit(this.value);
    }
    _markRadiosForCheck() {
        if (this._radios) {
            this._radios.forEach(radioButton => radioButton.markForCheck());
        }
    }
    checkSelectedRadioButton() {
        if (this._selected && !this._selected.checked) {
            this._selected.checked = true;
        }
    }
    getGroupName() {
        return this.name ? this.name : null;
    }
    getCheckedValue() {
        return this.value !== null && this.value !== undefined ? this.value : null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioGroupComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.IuiRadioButtonUniqueIdService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiRadioGroupComponent, isStandalone: true, selector: "iui-radio-group", inputs: { orientation: "orientation", label: "label", showLabel: "showLabel", name: "name", selected: "selected", required: "required", disabled: "disabled" }, outputs: { _change: "_change" }, host: { classAttribute: "iui-radio-group" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: IuiRadioGroupComponent,
                multi: true
            }
        ], queries: [{ propertyName: "_radios", predicate: i0.forwardRef(() => IuiRadioButtonComponent), descendants: true }], ngImport: i0, template: "<div class=\"iui-radio-group-label\" *ngIf=\"showLabel && label\">\n\t<span class=\"iui-radio-group-label-text\">{{ label }}</span>\n\t<span class=\"iui-radio-group-required\" *ngIf=\"required\">*</span>\n</div>\n<div\n\tclass=\"iui-radio-group-items\"\n\t[class.iui-radio-group-items--horizontal]=\"orientation === 'horizontal'\"\n>\n\t<ng-content></ng-content>\n</div>\n", styles: [":host{display:flex;flex-direction:column;align-items:flex-start}.iui-radio-group-label{display:flex;gap:4px;align-items:flex-start;padding-bottom:8px}.iui-radio-group-label .iui-radio-group-label-text{font:var(--iui-tp-label-01-font);color:var(--iui-radio-group-label-color)}.iui-radio-group-label .iui-radio-group-required{font:var(--iui-tp-label-01-font);color:var(--iui-radio-group-required-color)}.iui-radio-group-items{display:flex;flex-direction:column;gap:8px;align-items:flex-start}.iui-radio-group-items--horizontal{flex-direction:row;gap:16px}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiRadioGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-radio-group', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: IuiRadioGroupComponent,
                            multi: true
                        }
                    ], standalone: true, imports: [NgIf], host: {
                        class: 'iui-radio-group'
                    }, template: "<div class=\"iui-radio-group-label\" *ngIf=\"showLabel && label\">\n\t<span class=\"iui-radio-group-label-text\">{{ label }}</span>\n\t<span class=\"iui-radio-group-required\" *ngIf=\"required\">*</span>\n</div>\n<div\n\tclass=\"iui-radio-group-items\"\n\t[class.iui-radio-group-items--horizontal]=\"orientation === 'horizontal'\"\n>\n\t<ng-content></ng-content>\n</div>\n", styles: [":host{display:flex;flex-direction:column;align-items:flex-start}.iui-radio-group-label{display:flex;gap:4px;align-items:flex-start;padding-bottom:8px}.iui-radio-group-label .iui-radio-group-label-text{font:var(--iui-tp-label-01-font);color:var(--iui-radio-group-label-color)}.iui-radio-group-label .iui-radio-group-required{font:var(--iui-tp-label-01-font);color:var(--iui-radio-group-required-color)}.iui-radio-group-items{display:flex;flex-direction:column;gap:8px;align-items:flex-start}.iui-radio-group-items--horizontal{flex-direction:row;gap:16px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.IuiRadioButtonUniqueIdService }], propDecorators: { _radios: [{
                type: ContentChildren,
                args: [forwardRef(() => IuiRadioButtonComponent), { descendants: true }]
            }], orientation: [{
                type: Input
            }], label: [{
                type: Input
            }], showLabel: [{
                type: Input
            }], _change: [{
                type: Output
            }], name: [{
                type: Input
            }], selected: [{
                type: Input
            }], required: [{
                type: Input
            }], disabled: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLXJhZGlvLWdyb3VwLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL2xpYnMvdWktY29tcG9uZW50cy1hbmd1bGFyLXB1Ymxpc2hhYmxlL3JhZGlvLWJ1dHRvbi9zcmMvaXVpLXJhZGlvLWdyb3VwL2l1aS1yYWRpby1ncm91cC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS9yYWRpby1idXR0b24vc3JjL2l1aS1yYWRpby1ncm91cC9pdWktcmFkaW8tZ3JvdXAuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNOLFNBQVMsRUFDVCxlQUFlLEVBQ2YsU0FBUyxFQUNULEtBQUssRUFDTCxNQUFNLEVBQ04sWUFBWSxFQUdaLGlCQUFpQixFQUVqQixVQUFVLEVBQ1YsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUF3QixpQkFBaUIsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3pFLE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUN2QyxPQUFPLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSxnREFBZ0QsQ0FBQztBQUV6RixPQUFPLEVBQUUsNkJBQTZCLEVBQUUsTUFBTSwrQkFBK0IsQ0FBQzs7O0FBbUI5RSxNQUFNLE9BQU8sc0JBQXNCO0lBbUJsQyxJQUNJLFFBQVE7UUFDWCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLFFBQVE7UUFDcEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUM7UUFDMUIsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUM5QyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQsSUFDSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUM7SUFDRCxJQUFJLFFBQVEsQ0FBQyxLQUFjO1FBQzFCLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCxJQUNJLFFBQVE7UUFDWCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUM7SUFDdkIsQ0FBQztJQUNELElBQUksUUFBUSxDQUFDLEtBQWM7UUFDMUIsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFDdkIsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVELFlBQ1Msa0JBQXFDLEVBQ3JDLFlBQTJDO1FBRDNDLHVCQUFrQixHQUFsQixrQkFBa0IsQ0FBbUI7UUFDckMsaUJBQVksR0FBWixZQUFZLENBQStCO1FBN0MzQyxnQkFBVyxHQUE4QixVQUFVLENBQUM7UUFDcEQsVUFBSyxHQUFHLEVBQUUsQ0FBQztRQUNYLGNBQVMsR0FBRyxJQUFJLENBQUM7UUFFMUIsVUFBSyxHQUFRLElBQUksQ0FBQztRQUVWLGNBQVMsR0FBbUMsSUFBSSxDQUFDO1FBQ2pELGtDQUE2QixHQUF3QixJQUFJLENBQUM7UUFDMUQsY0FBUyxHQUFHLEtBQUssQ0FBQztRQUNsQixjQUFTLEdBQUcsS0FBSyxDQUFDO1FBRVAsWUFBTyxHQUFzQixJQUFJLFlBQVksRUFBTyxDQUFDO1FBb0VoRSxjQUFTLEdBQXlCLEdBQUcsRUFBRSxHQUFFLENBQUMsQ0FBQztRQUMzQyxlQUFVLEdBQXlCLEdBQUcsRUFBRSxHQUFFLENBQUMsQ0FBQztJQWxDakQsQ0FBQztJQUVKLFFBQVE7UUFDUCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFFM0QsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNoQixJQUFJLENBQUMsSUFBSSxHQUFHLG1CQUFtQixRQUFRLEVBQUUsQ0FBQztRQUMzQyxDQUFDO0lBQ0YsQ0FBQztJQUVELGtCQUFrQjtRQUNqQixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUMsOEJBQThCLEVBQUUsQ0FBQztJQUN2QyxDQUFDO0lBRUQsV0FBVztRQUNWLElBQUksQ0FBQyw2QkFBNkIsRUFBRSxXQUFXLEVBQUUsQ0FBQztJQUNuRCxDQUFDO0lBRUQsVUFBVSxDQUFDLEtBQVU7UUFDcEIsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxDQUFDLDRCQUE0QixFQUFFLENBQUM7UUFDcEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ3hDLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxFQUFPO1FBQ3ZCLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxFQUFPO1FBQ3hCLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO0lBQ3RCLENBQUM7SUFLTyxzQkFBc0I7UUFDN0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDbEMsV0FBVyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQzdCLFdBQVcsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUN0QyxDQUFDLENBQUMsQ0FBQztJQUNKLENBQUM7SUFFTyw4QkFBOEI7UUFDckMsSUFBSSxDQUFDLDZCQUE2QixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7WUFDeEUsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDL0IsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNsQyxXQUFXLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7Z0JBQ2pDLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztJQUNKLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxVQUFtQjtRQUNuQyxJQUFJLENBQUMsUUFBUSxHQUFHLFVBQVUsQ0FBQztRQUMzQixJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRU8sNEJBQTRCO1FBQ25DLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2xCLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUNsQyxXQUFXLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxDQUFDLEtBQUssQ0FBQztZQUN4RCxDQUFDLENBQUMsQ0FBQztRQUNKLENBQUM7SUFDRixDQUFDO0lBRUQsV0FBVyxDQUFDLG1CQUE0QztRQUN2RCxJQUFJLENBQUMsS0FBSyxHQUFHLG1CQUFtQixDQUFDLEtBQUssQ0FBQztRQUN2QyxJQUFJLENBQUMsU0FBUyxHQUFHLG1CQUFtQixDQUFDO1FBQ3JDLElBQUksQ0FBQyw0QkFBNEIsRUFBRSxDQUFDO1FBQ3BDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBRU8sbUJBQW1CO1FBQzFCLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2xCLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUM7UUFDakUsQ0FBQztJQUNGLENBQUM7SUFFRCx3QkFBd0I7UUFDdkIsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUMvQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDL0IsQ0FBQztJQUNGLENBQUM7SUFFRCxZQUFZO1FBQ1gsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDckMsQ0FBQztJQUVELGVBQWU7UUFDZCxPQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDNUUsQ0FBQzsrR0FqSlcsc0JBQXNCO21HQUF0QixzQkFBc0IsNFNBYnZCO1lBQ1Y7Z0JBQ0MsT0FBTyxFQUFFLGlCQUFpQjtnQkFDMUIsV0FBVyxFQUFFLHNCQUFzQjtnQkFDbkMsS0FBSyxFQUFFLElBQUk7YUFDWDtTQUNELHNFQVFpQyx1QkFBdUIsaURDckMxRCxzWEFVQSxxbUJEcUJXLElBQUk7OzRGQUtGLHNCQUFzQjtrQkFqQmxDLFNBQVM7K0JBQ0MsaUJBQWlCLGFBR2hCO3dCQUNWOzRCQUNDLE9BQU8sRUFBRSxpQkFBaUI7NEJBQzFCLFdBQVcsd0JBQXdCOzRCQUNuQyxLQUFLLEVBQUUsSUFBSTt5QkFDWDtxQkFDRCxjQUNXLElBQUksV0FDUCxDQUFDLElBQUksQ0FBQyxRQUNUO3dCQUNMLEtBQUssRUFBRSxpQkFBaUI7cUJBQ3hCO2tJQUlELE9BQU87c0JBRE4sZUFBZTt1QkFBQyxVQUFVLENBQUMsR0FBRyxFQUFFLENBQUMsdUJBQXVCLENBQUMsRUFBRSxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUU7Z0JBR3hFLFdBQVc7c0JBQW5CLEtBQUs7Z0JBQ0csS0FBSztzQkFBYixLQUFLO2dCQUNHLFNBQVM7c0JBQWpCLEtBQUs7Z0JBU2EsT0FBTztzQkFBekIsTUFBTTtnQkFFRSxJQUFJO3NCQUFaLEtBQUs7Z0JBR0YsUUFBUTtzQkFEWCxLQUFLO2dCQVdGLFFBQVE7c0JBRFgsS0FBSztnQkFVRixRQUFRO3NCQURYLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuXHRDb21wb25lbnQsXG5cdENvbnRlbnRDaGlsZHJlbixcblx0UXVlcnlMaXN0LFxuXHRJbnB1dCxcblx0T3V0cHV0LFxuXHRFdmVudEVtaXR0ZXIsXG5cdEFmdGVyQ29udGVudEluaXQsXG5cdE9uRGVzdHJveSxcblx0Q2hhbmdlRGV0ZWN0b3JSZWYsXG5cdE9uSW5pdCxcblx0Zm9yd2FyZFJlZlxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBOR19WQUxVRV9BQ0NFU1NPUiB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IE5nSWYgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgSXVpUmFkaW9CdXR0b25Db21wb25lbnQgfSBmcm9tICcuLi9pdWktcmFkaW8tYnV0dG9uL2l1aS1yYWRpby1idXR0b24uY29tcG9uZW50JztcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgSXVpUmFkaW9CdXR0b25VbmlxdWVJZFNlcnZpY2UgfSBmcm9tICcuLi9pdWktcmFkaW8tYnV0dG9uLXVuaXF1ZS1pZCc7XG5cbkBDb21wb25lbnQoe1xuXHRzZWxlY3RvcjogJ2l1aS1yYWRpby1ncm91cCcsXG5cdHRlbXBsYXRlVXJsOiAnLi9pdWktcmFkaW8tZ3JvdXAuY29tcG9uZW50Lmh0bWwnLFxuXHRzdHlsZVVybHM6IFsnLi9pdWktcmFkaW8tZ3JvdXAuY29tcG9uZW50LnNjc3MnXSxcblx0cHJvdmlkZXJzOiBbXG5cdFx0e1xuXHRcdFx0cHJvdmlkZTogTkdfVkFMVUVfQUNDRVNTT1IsXG5cdFx0XHR1c2VFeGlzdGluZzogSXVpUmFkaW9Hcm91cENvbXBvbmVudCxcblx0XHRcdG11bHRpOiB0cnVlXG5cdFx0fVxuXHRdLFxuXHRzdGFuZGFsb25lOiB0cnVlLFxuXHRpbXBvcnRzOiBbTmdJZl0sXG5cdGhvc3Q6IHtcblx0XHRjbGFzczogJ2l1aS1yYWRpby1ncm91cCdcblx0fVxufSlcbmV4cG9ydCBjbGFzcyBJdWlSYWRpb0dyb3VwQ29tcG9uZW50IGltcGxlbWVudHMgQ29udHJvbFZhbHVlQWNjZXNzb3IsIEFmdGVyQ29udGVudEluaXQsIE9uRGVzdHJveSwgT25Jbml0IHtcblx0QENvbnRlbnRDaGlsZHJlbihmb3J3YXJkUmVmKCgpID0+IEl1aVJhZGlvQnV0dG9uQ29tcG9uZW50KSwgeyBkZXNjZW5kYW50czogdHJ1ZSB9KVxuXHRfcmFkaW9zITogUXVlcnlMaXN0PEl1aVJhZGlvQnV0dG9uQ29tcG9uZW50PjtcblxuXHRASW5wdXQoKSBvcmllbnRhdGlvbjogJ3ZlcnRpY2FsJyB8ICdob3Jpem9udGFsJyA9ICd2ZXJ0aWNhbCc7XG5cdEBJbnB1dCgpIGxhYmVsID0gJyc7XG5cdEBJbnB1dCgpIHNob3dMYWJlbCA9IHRydWU7XG5cblx0dmFsdWU6IGFueSA9IG51bGw7XG5cblx0cHJpdmF0ZSBfc2VsZWN0ZWQ6IEl1aVJhZGlvQnV0dG9uQ29tcG9uZW50IHwgbnVsbCA9IG51bGw7XG5cdHByaXZhdGUgcmFkaW9CdXR0b25DaGFuZ2VTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbiB8IG51bGwgPSBudWxsO1xuXHRwcml2YXRlIF9yZXF1aXJlZCA9IGZhbHNlO1xuXHRwcml2YXRlIF9kaXNhYmxlZCA9IGZhbHNlO1xuXG5cdEBPdXRwdXQoKSByZWFkb25seSBfY2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpO1xuXG5cdEBJbnB1dCgpIG5hbWUhOiBzdHJpbmc7XG5cblx0QElucHV0KClcblx0Z2V0IHNlbGVjdGVkKCkge1xuXHRcdHJldHVybiB0aGlzLl9zZWxlY3RlZDtcblx0fVxuXHRzZXQgc2VsZWN0ZWQoc2VsZWN0ZWQpIHtcblx0XHR0aGlzLl9zZWxlY3RlZCA9IHNlbGVjdGVkO1xuXHRcdHRoaXMudmFsdWUgPSBzZWxlY3RlZCA/IHNlbGVjdGVkLnZhbHVlIDogbnVsbDtcblx0XHR0aGlzLmNoZWNrU2VsZWN0ZWRSYWRpb0J1dHRvbigpO1xuXHR9XG5cblx0QElucHV0KClcblx0Z2V0IHJlcXVpcmVkKCk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiB0aGlzLl9yZXF1aXJlZDtcblx0fVxuXHRzZXQgcmVxdWlyZWQodmFsdWU6IGJvb2xlYW4pIHtcblx0XHR0aGlzLl9yZXF1aXJlZCA9IHZhbHVlO1xuXHRcdHRoaXMuX21hcmtSYWRpb3NGb3JDaGVjaygpO1xuXHR9XG5cblx0QElucHV0KClcblx0Z2V0IGRpc2FibGVkKCk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiB0aGlzLl9kaXNhYmxlZDtcblx0fVxuXHRzZXQgZGlzYWJsZWQodmFsdWU6IGJvb2xlYW4pIHtcblx0XHR0aGlzLl9kaXNhYmxlZCA9IHZhbHVlO1xuXHRcdHRoaXMuX21hcmtSYWRpb3NGb3JDaGVjaygpO1xuXHR9XG5cblx0Y29uc3RydWN0b3IoXG5cdFx0cHJpdmF0ZSBfY2hhbmdlRGV0ZWN0b3JSZWY6IENoYW5nZURldGVjdG9yUmVmLFxuXHRcdHByaXZhdGUgbmV4dFVuaXF1ZUlkOiBJdWlSYWRpb0J1dHRvblVuaXF1ZUlkU2VydmljZVxuXHQpIHt9XG5cblx0bmdPbkluaXQoKSB7XG5cdFx0Y29uc3QgdW5pcXVlSWQgPSB0aGlzLm5leHRVbmlxdWVJZC5nZXRSYWRpb0J1dHRvbkdyb3VwSWQoKTtcblxuXHRcdGlmICghdGhpcy5uYW1lKSB7XG5cdFx0XHR0aGlzLm5hbWUgPSBgaXVpLXJhZGlvLWdyb3VwLSR7dW5pcXVlSWR9YDtcblx0XHR9XG5cdH1cblxuXHRuZ0FmdGVyQ29udGVudEluaXQoKSB7XG5cdFx0dGhpcy51cGRhdGVSYWRpb0J1dHRvbk5hbWVzKCk7XG5cdFx0dGhpcy5fc3Vic2NyaWJlVG9SYWRpb0J1dHRvbkNoYW5nZXMoKTtcblx0fVxuXG5cdG5nT25EZXN0cm95KCkge1xuXHRcdHRoaXMucmFkaW9CdXR0b25DaGFuZ2VTdWJzY3JpcHRpb24/LnVuc3Vic2NyaWJlKCk7XG5cdH1cblxuXHR3cml0ZVZhbHVlKHZhbHVlOiBhbnkpOiB2b2lkIHtcblx0XHR0aGlzLnZhbHVlID0gdmFsdWU7XG5cdFx0dGhpcy51cGRhdGVTZWxlY3RlZFJhZGlvRnJvbVZhbHVlKCk7XG5cdFx0dGhpcy5fY2hhbmdlRGV0ZWN0b3JSZWYubWFya0ZvckNoZWNrKCk7XG5cdH1cblxuXHRyZWdpc3Rlck9uQ2hhbmdlKGZuOiBhbnkpOiB2b2lkIHtcblx0XHR0aGlzLl9vbkNoYW5nZSA9IGZuO1xuXHR9XG5cblx0cmVnaXN0ZXJPblRvdWNoZWQoZm46IGFueSk6IHZvaWQge1xuXHRcdHRoaXMuX29uVG91Y2hlZCA9IGZuO1xuXHR9XG5cblx0cHJpdmF0ZSBfb25DaGFuZ2U6ICh2YWx1ZTogYW55KSA9PiB2b2lkID0gKCkgPT4ge307XG5cdHByaXZhdGUgX29uVG91Y2hlZDogKHZhbHVlOiBhbnkpID0+IHZvaWQgPSAoKSA9PiB7fTtcblxuXHRwcml2YXRlIHVwZGF0ZVJhZGlvQnV0dG9uTmFtZXMoKTogdm9pZCB7XG5cdFx0dGhpcy5fcmFkaW9zLmZvckVhY2gocmFkaW9CdXR0b24gPT4ge1xuXHRcdFx0cmFkaW9CdXR0b24ubmFtZSA9IHRoaXMubmFtZTtcblx0XHRcdHJhZGlvQnV0dG9uLmRpc2FibGVkID0gdGhpcy5kaXNhYmxlZDtcblx0XHR9KTtcblx0fVxuXG5cdHByaXZhdGUgX3N1YnNjcmliZVRvUmFkaW9CdXR0b25DaGFuZ2VzKCk6IHZvaWQge1xuXHRcdHRoaXMucmFkaW9CdXR0b25DaGFuZ2VTdWJzY3JpcHRpb24gPSB0aGlzLl9yYWRpb3MuY2hhbmdlcy5zdWJzY3JpYmUoKCkgPT4ge1xuXHRcdFx0dGhpcy51cGRhdGVSYWRpb0J1dHRvbk5hbWVzKCk7XG5cdFx0fSk7XG5cblx0XHR0aGlzLl9yYWRpb3MuZm9yRWFjaChyYWRpb0J1dHRvbiA9PiB7XG5cdFx0XHRyYWRpb0J1dHRvbi5jaGFuZ2Uuc3Vic2NyaWJlKCgpID0+IHtcblx0XHRcdFx0dGhpcy5zZWxlY3RSYWRpbyhyYWRpb0J1dHRvbik7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxuXG5cdHNldERpc2FibGVkU3RhdGUoaXNEaXNhYmxlZDogYm9vbGVhbik6IHZvaWQge1xuXHRcdHRoaXMuZGlzYWJsZWQgPSBpc0Rpc2FibGVkO1xuXHRcdHRoaXMuX21hcmtSYWRpb3NGb3JDaGVjaygpO1xuXHR9XG5cblx0cHJpdmF0ZSB1cGRhdGVTZWxlY3RlZFJhZGlvRnJvbVZhbHVlKCk6IHZvaWQge1xuXHRcdGlmICh0aGlzLl9yYWRpb3MpIHtcblx0XHRcdHRoaXMuX3JhZGlvcy5mb3JFYWNoKHJhZGlvQnV0dG9uID0+IHtcblx0XHRcdFx0cmFkaW9CdXR0b24uY2hlY2tlZCA9IHRoaXMudmFsdWUgPT09IHJhZGlvQnV0dG9uLnZhbHVlO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG5cblx0c2VsZWN0UmFkaW8oc2VsZWN0ZWRSYWRpb0J1dHRvbjogSXVpUmFkaW9CdXR0b25Db21wb25lbnQpOiB2b2lkIHtcblx0XHR0aGlzLnZhbHVlID0gc2VsZWN0ZWRSYWRpb0J1dHRvbi52YWx1ZTtcblx0XHR0aGlzLl9zZWxlY3RlZCA9IHNlbGVjdGVkUmFkaW9CdXR0b247XG5cdFx0dGhpcy51cGRhdGVTZWxlY3RlZFJhZGlvRnJvbVZhbHVlKCk7XG5cdFx0dGhpcy5fb25DaGFuZ2UodGhpcy52YWx1ZSk7XG5cdFx0dGhpcy5fb25Ub3VjaGVkKHRoaXMudmFsdWUpO1xuXHRcdHRoaXMuX2NoYW5nZS5lbWl0KHRoaXMudmFsdWUpO1xuXHR9XG5cblx0cHJpdmF0ZSBfbWFya1JhZGlvc0ZvckNoZWNrKCk6IHZvaWQge1xuXHRcdGlmICh0aGlzLl9yYWRpb3MpIHtcblx0XHRcdHRoaXMuX3JhZGlvcy5mb3JFYWNoKHJhZGlvQnV0dG9uID0+IHJhZGlvQnV0dG9uLm1hcmtGb3JDaGVjaygpKTtcblx0XHR9XG5cdH1cblxuXHRjaGVja1NlbGVjdGVkUmFkaW9CdXR0b24oKSB7XG5cdFx0aWYgKHRoaXMuX3NlbGVjdGVkICYmICF0aGlzLl9zZWxlY3RlZC5jaGVja2VkKSB7XG5cdFx0XHR0aGlzLl9zZWxlY3RlZC5jaGVja2VkID0gdHJ1ZTtcblx0XHR9XG5cdH1cblxuXHRnZXRHcm91cE5hbWUoKTogc3RyaW5nIHwgbnVsbCB7XG5cdFx0cmV0dXJuIHRoaXMubmFtZSA/IHRoaXMubmFtZSA6IG51bGw7XG5cdH1cblxuXHRnZXRDaGVja2VkVmFsdWUoKSB7XG5cdFx0cmV0dXJuIHRoaXMudmFsdWUgIT09IG51bGwgJiYgdGhpcy52YWx1ZSAhPT0gdW5kZWZpbmVkID8gdGhpcy52YWx1ZSA6IG51bGw7XG5cdH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJpdWktcmFkaW8tZ3JvdXAtbGFiZWxcIiAqbmdJZj1cInNob3dMYWJlbCAmJiBsYWJlbFwiPlxuXHQ8c3BhbiBjbGFzcz1cIml1aS1yYWRpby1ncm91cC1sYWJlbC10ZXh0XCI+e3sgbGFiZWwgfX08L3NwYW4+XG5cdDxzcGFuIGNsYXNzPVwiaXVpLXJhZGlvLWdyb3VwLXJlcXVpcmVkXCIgKm5nSWY9XCJyZXF1aXJlZFwiPio8L3NwYW4+XG48L2Rpdj5cbjxkaXZcblx0Y2xhc3M9XCJpdWktcmFkaW8tZ3JvdXAtaXRlbXNcIlxuXHRbY2xhc3MuaXVpLXJhZGlvLWdyb3VwLWl0ZW1zLS1ob3Jpem9udGFsXT1cIm9yaWVudGF0aW9uID09PSAnaG9yaXpvbnRhbCdcIlxuPlxuXHQ8bmctY29udGVudD48L25nLWNvbnRlbnQ+XG48L2Rpdj5cbiJdfQ==