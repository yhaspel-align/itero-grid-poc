import { Directive, ElementRef, Input, ViewContainerRef } from '@angular/core';
import { Overlay } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';
import { IuiMenuComponent } from './iui-menu.component';
import * as i0 from "@angular/core";
import * as i1 from "@angular/cdk/overlay";
export class IuiMenuTriggerDirective {
    constructor(_el, _overlay, _viewContainerRef) {
        this._el = _el;
        this._overlay = _overlay;
        this._viewContainerRef = _viewContainerRef;
        /** Whether the panel opens above or below the trigger */
        this.menuPlacement = 'bottom';
        /** Whether the panel aligns to the start or end of the trigger */
        this.menuAlignment = 'start';
        /** Whether the menu overlay is currently open */
        this.isOpen = false;
        this._overlayRef = null;
        this._closeSub = Subscription.EMPTY;
        this._detachSub = Subscription.EMPTY;
        this._keydownSub = Subscription.EMPTY;
    }
    toggle() {
        this.isOpen ? this.close() : this.open();
    }
    open() {
        if (this.isOpen || !this.menuRef?.templateRef)
            return;
        const overlayRef = this._getOrCreateOverlay();
        const portal = new TemplatePortal(this.menuRef.templateRef, this._viewContainerRef);
        overlayRef.attach(portal);
        this.isOpen = true;
        this._closeSub = overlayRef.backdropClick().subscribe(() => this.close());
        this._detachSub = overlayRef.detachments().pipe(take(1)).subscribe(() => {
            if (this.isOpen) {
                this.isOpen = false;
            }
        });
        this._keydownSub = overlayRef.keydownEvents().subscribe(e => this._handleKeydown(e));
        // Focus first enabled item after overlay renders
        Promise.resolve().then(() => this._focusFirstItem());
    }
    close() {
        if (!this.isOpen)
            return;
        this._overlayRef?.detach();
        this._closeSub.unsubscribe();
        this._detachSub.unsubscribe();
        this._keydownSub.unsubscribe();
        this.isOpen = false;
        this._el.nativeElement.focus();
    }
    _getOrCreateOverlay() {
        if (!this._overlayRef) {
            const positionStrategy = this._overlay
                .position()
                .flexibleConnectedTo(this._el)
                .withPositions(this._buildPositions())
                .withFlexibleDimensions(false)
                .withPush(false);
            this._overlayRef = this._overlay.create({
                positionStrategy,
                scrollStrategy: this._overlay.scrollStrategies.reposition(),
                hasBackdrop: true,
                backdropClass: 'cdk-overlay-transparent-backdrop',
            });
        }
        return this._overlayRef;
    }
    _buildPositions() {
        const originYPrimary = this.menuPlacement === 'bottom' ? 'bottom' : 'top';
        const originYFallback = this.menuPlacement === 'bottom' ? 'top' : 'bottom';
        const overlayYPrimary = this.menuPlacement === 'bottom' ? 'top' : 'bottom';
        const overlayYFallback = this.menuPlacement === 'bottom' ? 'bottom' : 'top';
        const originX = this.menuAlignment === 'start' ? 'start' : 'end';
        const overlayX = this.menuAlignment === 'start' ? 'start' : 'end';
        const offsetY = 4;
        return [
            { originX, originY: originYPrimary, overlayX, overlayY: overlayYPrimary, offsetY },
            { originX, originY: originYFallback, overlayX, overlayY: overlayYFallback, offsetY: -offsetY },
        ];
    }
    _handleKeydown(event) {
        switch (event.key) {
            case 'Escape':
                event.preventDefault();
                this.close();
                break;
            case 'Tab':
                this.close();
                break;
            case 'ArrowDown':
                event.preventDefault();
                this._moveFocus(1);
                break;
            case 'ArrowUp':
                event.preventDefault();
                this._moveFocus(-1);
                break;
            case 'Home':
                event.preventDefault();
                this._focusFirstItem();
                break;
            case 'End':
                event.preventDefault();
                this._focusLastItem();
                break;
        }
    }
    _getMenuItems() {
        if (!this._overlayRef)
            return [];
        return Array.from(this._overlayRef.overlayElement.querySelectorAll('iui-menu-item:not(.iui-menu-item_disabled)'));
    }
    _focusFirstItem() {
        this._getMenuItems()[0]?.focus();
    }
    _focusLastItem() {
        const items = this._getMenuItems();
        items[items.length - 1]?.focus();
    }
    _moveFocus(direction) {
        const items = this._getMenuItems();
        if (!items.length)
            return;
        const focused = document.activeElement;
        const currentIndex = items.indexOf(focused);
        const nextIndex = currentIndex < 0
            ? direction === 1 ? 0 : items.length - 1
            : (currentIndex + direction + items.length) % items.length;
        items[nextIndex]?.focus();
    }
    ngOnDestroy() {
        this._overlayRef?.dispose();
        this._overlayRef = null;
        this._closeSub.unsubscribe();
        this._detachSub.unsubscribe();
        this._keydownSub.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiMenuTriggerDirective, deps: [{ token: i0.ElementRef }, { token: i1.Overlay }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: IuiMenuTriggerDirective, isStandalone: true, selector: "[iuiMenuTrigger]", inputs: { menuRef: ["iuiMenuTrigger", "menuRef"], menuPlacement: "menuPlacement", menuAlignment: "menuAlignment" }, host: { listeners: { "click": "toggle()" }, properties: { "attr.aria-expanded": "isOpen ? \"true\" : \"false\"", "attr.aria-haspopup": "\"menu\"" } }, exportAs: ["iuiMenuTrigger"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiMenuTriggerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[iuiMenuTrigger]',
                    standalone: true,
                    exportAs: 'iuiMenuTrigger',
                    host: {
                        '(click)': 'toggle()',
                        '[attr.aria-expanded]': 'isOpen ? "true" : "false"',
                        '[attr.aria-haspopup]': '"menu"',
                    },
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1.Overlay }, { type: i0.ViewContainerRef }], propDecorators: { menuRef: [{
                type: Input,
                args: ['iuiMenuTrigger']
            }], menuPlacement: [{
                type: Input
            }], menuAlignment: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLW1lbnUtdHJpZ2dlci5kaXJlY3RpdmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS9tZW51L3NyYy9pdWktbWVudS10cmlnZ2VyLmRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQWEsZ0JBQWdCLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDMUYsT0FBTyxFQUFxQixPQUFPLEVBQWMsTUFBTSxzQkFBc0IsQ0FBQztBQUM5RSxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFDckQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUNwQyxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDdEMsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sc0JBQXNCLENBQUM7OztBQWF4RCxNQUFNLE9BQU8sdUJBQXVCO0lBa0JuQyxZQUNTLEdBQTRCLEVBQzVCLFFBQWlCLEVBQ2pCLGlCQUFtQztRQUZuQyxRQUFHLEdBQUgsR0FBRyxDQUF5QjtRQUM1QixhQUFRLEdBQVIsUUFBUSxDQUFTO1FBQ2pCLHNCQUFpQixHQUFqQixpQkFBaUIsQ0FBa0I7UUFqQjVDLHlEQUF5RDtRQUNoRCxrQkFBYSxHQUFxQixRQUFRLENBQUM7UUFFcEQsa0VBQWtFO1FBQ3pELGtCQUFhLEdBQXFCLE9BQU8sQ0FBQztRQUVuRCxpREFBaUQ7UUFDakQsV0FBTSxHQUFHLEtBQUssQ0FBQztRQUVQLGdCQUFXLEdBQXNCLElBQUksQ0FBQztRQUN0QyxjQUFTLEdBQUcsWUFBWSxDQUFDLEtBQUssQ0FBQztRQUMvQixlQUFVLEdBQUcsWUFBWSxDQUFDLEtBQUssQ0FBQztRQUNoQyxnQkFBVyxHQUFHLFlBQVksQ0FBQyxLQUFLLENBQUM7SUFNdEMsQ0FBQztJQUVKLE1BQU07UUFDTCxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUMxQyxDQUFDO0lBRUQsSUFBSTtRQUNILElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsV0FBVztZQUFFLE9BQU87UUFFdEQsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFDOUMsTUFBTSxNQUFNLEdBQUcsSUFBSSxjQUFjLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDcEYsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMxQixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUVuQixJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUM7UUFDMUUsSUFBSSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7WUFDdkUsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2pCLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1lBQ3JCLENBQUM7UUFDRixDQUFDLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLGFBQWEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVyRixpREFBaUQ7UUFDakQsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRUQsS0FBSztRQUNKLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTTtZQUFFLE9BQU87UUFDekIsSUFBSSxDQUFDLFdBQVcsRUFBRSxNQUFNLEVBQUUsQ0FBQztRQUMzQixJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUMvQixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUNwQixJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUNoQyxDQUFDO0lBRU8sbUJBQW1CO1FBQzFCLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDdkIsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsUUFBUTtpQkFDcEMsUUFBUSxFQUFFO2lCQUNWLG1CQUFtQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7aUJBQzdCLGFBQWEsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7aUJBQ3JDLHNCQUFzQixDQUFDLEtBQUssQ0FBQztpQkFDN0IsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRWxCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7Z0JBQ3ZDLGdCQUFnQjtnQkFDaEIsY0FBYyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFO2dCQUMzRCxXQUFXLEVBQUUsSUFBSTtnQkFDakIsYUFBYSxFQUFFLGtDQUFrQzthQUNqRCxDQUFDLENBQUM7UUFDSixDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQ3pCLENBQUM7SUFFTyxlQUFlO1FBQ3RCLE1BQU0sY0FBYyxHQUFxQixJQUFJLENBQUMsYUFBYSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDNUYsTUFBTSxlQUFlLEdBQXFCLElBQUksQ0FBQyxhQUFhLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUM3RixNQUFNLGVBQWUsR0FBcUIsSUFBSSxDQUFDLGFBQWEsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO1FBQzdGLE1BQU0sZ0JBQWdCLEdBQXFCLElBQUksQ0FBQyxhQUFhLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUM5RixNQUFNLE9BQU8sR0FBb0IsSUFBSSxDQUFDLGFBQWEsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ2xGLE1BQU0sUUFBUSxHQUFvQixJQUFJLENBQUMsYUFBYSxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDbkYsTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBRWxCLE9BQU87WUFDTixFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsY0FBYyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsZUFBZSxFQUFFLE9BQU8sRUFBRTtZQUNsRixFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsZUFBZSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsT0FBTyxFQUFFLENBQUMsT0FBTyxFQUFFO1NBQzlGLENBQUM7SUFDSCxDQUFDO0lBRU8sY0FBYyxDQUFDLEtBQW9CO1FBQzFDLFFBQVEsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ25CLEtBQUssUUFBUTtnQkFDWixLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQ3ZCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztnQkFDYixNQUFNO1lBQ1AsS0FBSyxLQUFLO2dCQUNULElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztnQkFDYixNQUFNO1lBQ1AsS0FBSyxXQUFXO2dCQUNmLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQkFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbkIsTUFBTTtZQUNQLEtBQUssU0FBUztnQkFDYixLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDcEIsTUFBTTtZQUNQLEtBQUssTUFBTTtnQkFDVixLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQ3ZCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztnQkFDdkIsTUFBTTtZQUNQLEtBQUssS0FBSztnQkFDVCxLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQ3ZCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQkFDdEIsTUFBTTtRQUNSLENBQUM7SUFDRixDQUFDO0lBRU8sYUFBYTtRQUNwQixJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVc7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUNqQyxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQ2hCLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUMvQyw0Q0FBNEMsQ0FDNUMsQ0FDRCxDQUFDO0lBQ0gsQ0FBQztJQUVPLGVBQWU7UUFDdEIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDO0lBQ2xDLENBQUM7SUFFTyxjQUFjO1FBQ3JCLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNuQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRU8sVUFBVSxDQUFDLFNBQWlCO1FBQ25DLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNuQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU07WUFBRSxPQUFPO1FBQzFCLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxhQUE0QixDQUFDO1FBQ3RELE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDNUMsTUFBTSxTQUFTLEdBQ2QsWUFBWSxHQUFHLENBQUM7WUFDZixDQUFDLENBQUMsU0FBUyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUM7WUFDeEMsQ0FBQyxDQUFDLENBQUMsWUFBWSxHQUFHLFNBQVMsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUM3RCxLQUFLLENBQUMsU0FBUyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVELFdBQVc7UUFDVixJQUFJLENBQUMsV0FBVyxFQUFFLE9BQU8sRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ2hDLENBQUM7K0dBNUpXLHVCQUF1QjttR0FBdkIsdUJBQXVCOzs0RkFBdkIsdUJBQXVCO2tCQVZuQyxTQUFTO21CQUFDO29CQUNWLFFBQVEsRUFBRSxrQkFBa0I7b0JBQzVCLFVBQVUsRUFBRSxJQUFJO29CQUNoQixRQUFRLEVBQUUsZ0JBQWdCO29CQUMxQixJQUFJLEVBQUU7d0JBQ0wsU0FBUyxFQUFFLFVBQVU7d0JBQ3JCLHNCQUFzQixFQUFFLDJCQUEyQjt3QkFDbkQsc0JBQXNCLEVBQUUsUUFBUTtxQkFDaEM7aUJBQ0Q7b0lBR3lCLE9BQU87c0JBQS9CLEtBQUs7dUJBQUMsZ0JBQWdCO2dCQUdkLGFBQWE7c0JBQXJCLEtBQUs7Z0JBR0csYUFBYTtzQkFBckIsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpcmVjdGl2ZSwgRWxlbWVudFJlZiwgSW5wdXQsIE9uRGVzdHJveSwgVmlld0NvbnRhaW5lclJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBDb25uZWN0ZWRQb3NpdGlvbiwgT3ZlcmxheSwgT3ZlcmxheVJlZiB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9vdmVybGF5JztcclxuaW1wb3J0IHsgVGVtcGxhdGVQb3J0YWwgfSBmcm9tICdAYW5ndWxhci9jZGsvcG9ydGFsJztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IHRha2UgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IEl1aU1lbnVDb21wb25lbnQgfSBmcm9tICcuL2l1aS1tZW51LmNvbXBvbmVudCc7XHJcbmltcG9ydCB7IEl1aU1lbnVBbGlnbm1lbnQsIEl1aU1lbnVQbGFjZW1lbnQgfSBmcm9tICcuL21lbnUudHlwZXMnO1xyXG5cclxuQERpcmVjdGl2ZSh7XHJcblx0c2VsZWN0b3I6ICdbaXVpTWVudVRyaWdnZXJdJyxcclxuXHRzdGFuZGFsb25lOiB0cnVlLFxyXG5cdGV4cG9ydEFzOiAnaXVpTWVudVRyaWdnZXInLFxyXG5cdGhvc3Q6IHtcclxuXHRcdCcoY2xpY2spJzogJ3RvZ2dsZSgpJyxcclxuXHRcdCdbYXR0ci5hcmlhLWV4cGFuZGVkXSc6ICdpc09wZW4gPyBcInRydWVcIiA6IFwiZmFsc2VcIicsXHJcblx0XHQnW2F0dHIuYXJpYS1oYXNwb3B1cF0nOiAnXCJtZW51XCInLFxyXG5cdH0sXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBJdWlNZW51VHJpZ2dlckRpcmVjdGl2ZSBpbXBsZW1lbnRzIE9uRGVzdHJveSB7XHJcblx0LyoqIFJlZmVyZW5jZSB0byB0aGUgSXVpTWVudUNvbXBvbmVudCB0byBvcGVuICovXHJcblx0QElucHV0KCdpdWlNZW51VHJpZ2dlcicpIG1lbnVSZWYhOiBJdWlNZW51Q29tcG9uZW50O1xyXG5cclxuXHQvKiogV2hldGhlciB0aGUgcGFuZWwgb3BlbnMgYWJvdmUgb3IgYmVsb3cgdGhlIHRyaWdnZXIgKi9cclxuXHRASW5wdXQoKSBtZW51UGxhY2VtZW50OiBJdWlNZW51UGxhY2VtZW50ID0gJ2JvdHRvbSc7XHJcblxyXG5cdC8qKiBXaGV0aGVyIHRoZSBwYW5lbCBhbGlnbnMgdG8gdGhlIHN0YXJ0IG9yIGVuZCBvZiB0aGUgdHJpZ2dlciAqL1xyXG5cdEBJbnB1dCgpIG1lbnVBbGlnbm1lbnQ6IEl1aU1lbnVBbGlnbm1lbnQgPSAnc3RhcnQnO1xyXG5cclxuXHQvKiogV2hldGhlciB0aGUgbWVudSBvdmVybGF5IGlzIGN1cnJlbnRseSBvcGVuICovXHJcblx0aXNPcGVuID0gZmFsc2U7XHJcblxyXG5cdHByaXZhdGUgX292ZXJsYXlSZWY6IE92ZXJsYXlSZWYgfCBudWxsID0gbnVsbDtcclxuXHRwcml2YXRlIF9jbG9zZVN1YiA9IFN1YnNjcmlwdGlvbi5FTVBUWTtcclxuXHRwcml2YXRlIF9kZXRhY2hTdWIgPSBTdWJzY3JpcHRpb24uRU1QVFk7XHJcblx0cHJpdmF0ZSBfa2V5ZG93blN1YiA9IFN1YnNjcmlwdGlvbi5FTVBUWTtcclxuXHJcblx0Y29uc3RydWN0b3IoXHJcblx0XHRwcml2YXRlIF9lbDogRWxlbWVudFJlZjxIVE1MRWxlbWVudD4sXHJcblx0XHRwcml2YXRlIF9vdmVybGF5OiBPdmVybGF5LFxyXG5cdFx0cHJpdmF0ZSBfdmlld0NvbnRhaW5lclJlZjogVmlld0NvbnRhaW5lclJlZixcclxuXHQpIHt9XHJcblxyXG5cdHRvZ2dsZSgpOiB2b2lkIHtcclxuXHRcdHRoaXMuaXNPcGVuID8gdGhpcy5jbG9zZSgpIDogdGhpcy5vcGVuKCk7XHJcblx0fVxyXG5cclxuXHRvcGVuKCk6IHZvaWQge1xyXG5cdFx0aWYgKHRoaXMuaXNPcGVuIHx8ICF0aGlzLm1lbnVSZWY/LnRlbXBsYXRlUmVmKSByZXR1cm47XHJcblxyXG5cdFx0Y29uc3Qgb3ZlcmxheVJlZiA9IHRoaXMuX2dldE9yQ3JlYXRlT3ZlcmxheSgpO1xyXG5cdFx0Y29uc3QgcG9ydGFsID0gbmV3IFRlbXBsYXRlUG9ydGFsKHRoaXMubWVudVJlZi50ZW1wbGF0ZVJlZiwgdGhpcy5fdmlld0NvbnRhaW5lclJlZik7XHJcblx0XHRvdmVybGF5UmVmLmF0dGFjaChwb3J0YWwpO1xyXG5cdFx0dGhpcy5pc09wZW4gPSB0cnVlO1xyXG5cclxuXHRcdHRoaXMuX2Nsb3NlU3ViID0gb3ZlcmxheVJlZi5iYWNrZHJvcENsaWNrKCkuc3Vic2NyaWJlKCgpID0+IHRoaXMuY2xvc2UoKSk7XHJcblx0XHR0aGlzLl9kZXRhY2hTdWIgPSBvdmVybGF5UmVmLmRldGFjaG1lbnRzKCkucGlwZSh0YWtlKDEpKS5zdWJzY3JpYmUoKCkgPT4ge1xyXG5cdFx0XHRpZiAodGhpcy5pc09wZW4pIHtcclxuXHRcdFx0XHR0aGlzLmlzT3BlbiA9IGZhbHNlO1xyXG5cdFx0XHR9XHJcblx0XHR9KTtcclxuXHRcdHRoaXMuX2tleWRvd25TdWIgPSBvdmVybGF5UmVmLmtleWRvd25FdmVudHMoKS5zdWJzY3JpYmUoZSA9PiB0aGlzLl9oYW5kbGVLZXlkb3duKGUpKTtcclxuXHJcblx0XHQvLyBGb2N1cyBmaXJzdCBlbmFibGVkIGl0ZW0gYWZ0ZXIgb3ZlcmxheSByZW5kZXJzXHJcblx0XHRQcm9taXNlLnJlc29sdmUoKS50aGVuKCgpID0+IHRoaXMuX2ZvY3VzRmlyc3RJdGVtKCkpO1xyXG5cdH1cclxuXHJcblx0Y2xvc2UoKTogdm9pZCB7XHJcblx0XHRpZiAoIXRoaXMuaXNPcGVuKSByZXR1cm47XHJcblx0XHR0aGlzLl9vdmVybGF5UmVmPy5kZXRhY2goKTtcclxuXHRcdHRoaXMuX2Nsb3NlU3ViLnVuc3Vic2NyaWJlKCk7XHJcblx0XHR0aGlzLl9kZXRhY2hTdWIudW5zdWJzY3JpYmUoKTtcclxuXHRcdHRoaXMuX2tleWRvd25TdWIudW5zdWJzY3JpYmUoKTtcclxuXHRcdHRoaXMuaXNPcGVuID0gZmFsc2U7XHJcblx0XHR0aGlzLl9lbC5uYXRpdmVFbGVtZW50LmZvY3VzKCk7XHJcblx0fVxyXG5cclxuXHRwcml2YXRlIF9nZXRPckNyZWF0ZU92ZXJsYXkoKTogT3ZlcmxheVJlZiB7XHJcblx0XHRpZiAoIXRoaXMuX292ZXJsYXlSZWYpIHtcclxuXHRcdFx0Y29uc3QgcG9zaXRpb25TdHJhdGVneSA9IHRoaXMuX292ZXJsYXlcclxuXHRcdFx0XHQucG9zaXRpb24oKVxyXG5cdFx0XHRcdC5mbGV4aWJsZUNvbm5lY3RlZFRvKHRoaXMuX2VsKVxyXG5cdFx0XHRcdC53aXRoUG9zaXRpb25zKHRoaXMuX2J1aWxkUG9zaXRpb25zKCkpXHJcblx0XHRcdFx0LndpdGhGbGV4aWJsZURpbWVuc2lvbnMoZmFsc2UpXHJcblx0XHRcdFx0LndpdGhQdXNoKGZhbHNlKTtcclxuXHJcblx0XHRcdHRoaXMuX292ZXJsYXlSZWYgPSB0aGlzLl9vdmVybGF5LmNyZWF0ZSh7XHJcblx0XHRcdFx0cG9zaXRpb25TdHJhdGVneSxcclxuXHRcdFx0XHRzY3JvbGxTdHJhdGVneTogdGhpcy5fb3ZlcmxheS5zY3JvbGxTdHJhdGVnaWVzLnJlcG9zaXRpb24oKSxcclxuXHRcdFx0XHRoYXNCYWNrZHJvcDogdHJ1ZSxcclxuXHRcdFx0XHRiYWNrZHJvcENsYXNzOiAnY2RrLW92ZXJsYXktdHJhbnNwYXJlbnQtYmFja2Ryb3AnLFxyXG5cdFx0XHR9KTtcclxuXHRcdH1cclxuXHRcdHJldHVybiB0aGlzLl9vdmVybGF5UmVmO1xyXG5cdH1cclxuXHJcblx0cHJpdmF0ZSBfYnVpbGRQb3NpdGlvbnMoKTogQ29ubmVjdGVkUG9zaXRpb25bXSB7XHJcblx0XHRjb25zdCBvcmlnaW5ZUHJpbWFyeTogJ3RvcCcgfCAnYm90dG9tJyA9IHRoaXMubWVudVBsYWNlbWVudCA9PT0gJ2JvdHRvbScgPyAnYm90dG9tJyA6ICd0b3AnO1xyXG5cdFx0Y29uc3Qgb3JpZ2luWUZhbGxiYWNrOiAndG9wJyB8ICdib3R0b20nID0gdGhpcy5tZW51UGxhY2VtZW50ID09PSAnYm90dG9tJyA/ICd0b3AnIDogJ2JvdHRvbSc7XHJcblx0XHRjb25zdCBvdmVybGF5WVByaW1hcnk6ICd0b3AnIHwgJ2JvdHRvbScgPSB0aGlzLm1lbnVQbGFjZW1lbnQgPT09ICdib3R0b20nID8gJ3RvcCcgOiAnYm90dG9tJztcclxuXHRcdGNvbnN0IG92ZXJsYXlZRmFsbGJhY2s6ICd0b3AnIHwgJ2JvdHRvbScgPSB0aGlzLm1lbnVQbGFjZW1lbnQgPT09ICdib3R0b20nID8gJ2JvdHRvbScgOiAndG9wJztcclxuXHRcdGNvbnN0IG9yaWdpblg6ICdzdGFydCcgfCAnZW5kJyA9IHRoaXMubWVudUFsaWdubWVudCA9PT0gJ3N0YXJ0JyA/ICdzdGFydCcgOiAnZW5kJztcclxuXHRcdGNvbnN0IG92ZXJsYXlYOiAnc3RhcnQnIHwgJ2VuZCcgPSB0aGlzLm1lbnVBbGlnbm1lbnQgPT09ICdzdGFydCcgPyAnc3RhcnQnIDogJ2VuZCc7XHJcblx0XHRjb25zdCBvZmZzZXRZID0gNDtcclxuXHJcblx0XHRyZXR1cm4gW1xyXG5cdFx0XHR7IG9yaWdpblgsIG9yaWdpblk6IG9yaWdpbllQcmltYXJ5LCBvdmVybGF5WCwgb3ZlcmxheVk6IG92ZXJsYXlZUHJpbWFyeSwgb2Zmc2V0WSB9LFxyXG5cdFx0XHR7IG9yaWdpblgsIG9yaWdpblk6IG9yaWdpbllGYWxsYmFjaywgb3ZlcmxheVgsIG92ZXJsYXlZOiBvdmVybGF5WUZhbGxiYWNrLCBvZmZzZXRZOiAtb2Zmc2V0WSB9LFxyXG5cdFx0XTtcclxuXHR9XHJcblxyXG5cdHByaXZhdGUgX2hhbmRsZUtleWRvd24oZXZlbnQ6IEtleWJvYXJkRXZlbnQpOiB2b2lkIHtcclxuXHRcdHN3aXRjaCAoZXZlbnQua2V5KSB7XHJcblx0XHRcdGNhc2UgJ0VzY2FwZSc6XHJcblx0XHRcdFx0ZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuXHRcdFx0XHR0aGlzLmNsb3NlKCk7XHJcblx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdGNhc2UgJ1RhYic6XHJcblx0XHRcdFx0dGhpcy5jbG9zZSgpO1xyXG5cdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRjYXNlICdBcnJvd0Rvd24nOlxyXG5cdFx0XHRcdGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcblx0XHRcdFx0dGhpcy5fbW92ZUZvY3VzKDEpO1xyXG5cdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRjYXNlICdBcnJvd1VwJzpcclxuXHRcdFx0XHRldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cdFx0XHRcdHRoaXMuX21vdmVGb2N1cygtMSk7XHJcblx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdGNhc2UgJ0hvbWUnOlxyXG5cdFx0XHRcdGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcblx0XHRcdFx0dGhpcy5fZm9jdXNGaXJzdEl0ZW0oKTtcclxuXHRcdFx0XHRicmVhaztcclxuXHRcdFx0Y2FzZSAnRW5kJzpcclxuXHRcdFx0XHRldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cdFx0XHRcdHRoaXMuX2ZvY3VzTGFzdEl0ZW0oKTtcclxuXHRcdFx0XHRicmVhaztcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdHByaXZhdGUgX2dldE1lbnVJdGVtcygpOiBIVE1MRWxlbWVudFtdIHtcclxuXHRcdGlmICghdGhpcy5fb3ZlcmxheVJlZikgcmV0dXJuIFtdO1xyXG5cdFx0cmV0dXJuIEFycmF5LmZyb20oXHJcblx0XHRcdHRoaXMuX292ZXJsYXlSZWYub3ZlcmxheUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbDxIVE1MRWxlbWVudD4oXHJcblx0XHRcdFx0J2l1aS1tZW51LWl0ZW06bm90KC5pdWktbWVudS1pdGVtX2Rpc2FibGVkKScsXHJcblx0XHRcdCksXHJcblx0XHQpO1xyXG5cdH1cclxuXHJcblx0cHJpdmF0ZSBfZm9jdXNGaXJzdEl0ZW0oKTogdm9pZCB7XHJcblx0XHR0aGlzLl9nZXRNZW51SXRlbXMoKVswXT8uZm9jdXMoKTtcclxuXHR9XHJcblxyXG5cdHByaXZhdGUgX2ZvY3VzTGFzdEl0ZW0oKTogdm9pZCB7XHJcblx0XHRjb25zdCBpdGVtcyA9IHRoaXMuX2dldE1lbnVJdGVtcygpO1xyXG5cdFx0aXRlbXNbaXRlbXMubGVuZ3RoIC0gMV0/LmZvY3VzKCk7XHJcblx0fVxyXG5cclxuXHRwcml2YXRlIF9tb3ZlRm9jdXMoZGlyZWN0aW9uOiAxIHwgLTEpOiB2b2lkIHtcclxuXHRcdGNvbnN0IGl0ZW1zID0gdGhpcy5fZ2V0TWVudUl0ZW1zKCk7XHJcblx0XHRpZiAoIWl0ZW1zLmxlbmd0aCkgcmV0dXJuO1xyXG5cdFx0Y29uc3QgZm9jdXNlZCA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgYXMgSFRNTEVsZW1lbnQ7XHJcblx0XHRjb25zdCBjdXJyZW50SW5kZXggPSBpdGVtcy5pbmRleE9mKGZvY3VzZWQpO1xyXG5cdFx0Y29uc3QgbmV4dEluZGV4ID1cclxuXHRcdFx0Y3VycmVudEluZGV4IDwgMFxyXG5cdFx0XHRcdD8gZGlyZWN0aW9uID09PSAxID8gMCA6IGl0ZW1zLmxlbmd0aCAtIDFcclxuXHRcdFx0XHQ6IChjdXJyZW50SW5kZXggKyBkaXJlY3Rpb24gKyBpdGVtcy5sZW5ndGgpICUgaXRlbXMubGVuZ3RoO1xyXG5cdFx0aXRlbXNbbmV4dEluZGV4XT8uZm9jdXMoKTtcclxuXHR9XHJcblxyXG5cdG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG5cdFx0dGhpcy5fb3ZlcmxheVJlZj8uZGlzcG9zZSgpO1xyXG5cdFx0dGhpcy5fb3ZlcmxheVJlZiA9IG51bGw7XHJcblx0XHR0aGlzLl9jbG9zZVN1Yi51bnN1YnNjcmliZSgpO1xyXG5cdFx0dGhpcy5fZGV0YWNoU3ViLnVuc3Vic2NyaWJlKCk7XHJcblx0XHR0aGlzLl9rZXlkb3duU3ViLnVuc3Vic2NyaWJlKCk7XHJcblx0fVxyXG59XHJcbiJdfQ==