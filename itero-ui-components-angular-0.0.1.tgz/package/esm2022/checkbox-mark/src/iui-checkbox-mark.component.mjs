import { Component, ElementRef, EventEmitter, forwardRef, inject, Input, Output, ViewChild } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgControlDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
let nextUniqueId = 0;
export class IuiCheckboxMarkComponent {
    constructor() {
        /** The unique id of the element */
        this.id = `iui-checkbox-mark-${nextUniqueId++}`;
        this.skeleton = false;
        this.blurEvent = new EventEmitter();
        /**
         * @prop
         * @ignore
         */
        this._touched = false;
        /**
         * @prop
         * @ignore
         */
        this._checked = false;
        /**
         * @prop
         * @ignore
         */
        this._indeterminate = false;
        /**
         * @prop
         * @ignore
         */
        this.isDisabledDirective = inject(IuiIsDisabledDirective, { self: true });
        this.changeEvent = new EventEmitter();
        this.indeterminateChanged = new EventEmitter();
        /**
         * @prop
         * @ignore
         */
        this.propagateChange = () => undefined;
        /**
         * @prop
         * @ignore
         */
        this.propagateTouched = () => undefined;
    }
    /**
     * @prop
     * @ignore
     */
    get _inputId() {
        return this.id + '-input';
    }
    /**
     * input where you can pass desirable state of checkbox "true" or "false".
     * Can be helpful when you don't use formControl, otherwise you can patchValue of formControl
     * */
    set checked(value) {
        this._checked = value;
        this.indeterminate = false;
    }
    get checked() {
        return this._checked;
    }
    set indeterminate(value) {
        const updateCheckedState = (newIndeterminateState) => {
            if (newIndeterminateState) {
                this._checked = false;
            }
        };
        this.setIndeterminateInternal(value, updateCheckedState);
    }
    get indeterminate() {
        return this._indeterminate;
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled || this.skeleton;
    }
    /**
     * @method
     * @ignore
     */
    _blurHandler(event) {
        if (this.disabled) {
            return;
        }
        this.markAsTouched();
        this.blurEvent.emit(event);
    }
    /**
     * @method
     * @ignore
     */
    setIndeterminateInternal(value, cb) {
        const changed = value !== this._indeterminate;
        this._indeterminate = value;
        if (changed) {
            if (cb) {
                cb(this._indeterminate);
            }
            this.indeterminateChanged.emit(this._indeterminate);
        }
    }
    /**
     * @method
     * @ignore
     */
    markAsTouched() {
        if (!this._touched) {
            this.propagateTouched();
            this._touched = true;
        }
    }
    /**
     * @method
     * @ignore
     */
    _changeHandler(event) {
        if (this.disabled) {
            return;
        }
        this._checked = !this.checked;
        this.setIndeterminateInternal(false);
        this.markAsTouched();
        this.propagateChange(this._checked);
        this.changeEvent.emit({
            event,
            checked: this._checked
        });
    }
    writeValue(val) {
        this._checked = val;
        this.setIndeterminateInternal(false);
    }
    registerOnChange(fn) {
        this.propagateChange = fn;
    }
    registerOnTouched(fn) {
        this.propagateTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCheckboxMarkComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiCheckboxMarkComponent, isStandalone: true, selector: "iui-checkbox-mark", inputs: { id: "id", skeleton: "skeleton", checked: "checked", indeterminate: "indeterminate" }, outputs: { blurEvent: "blurEvent", changeEvent: "changeEvent", indeterminateChanged: "indeterminateChanged" }, host: { properties: { "class.iui-checkbox-mark_checked": "checked", "class.iui-checkbox-mark_indeterminate": "indeterminate", "class.iui-checkbox-mark_disabled": "disabled", "class.iui-checkbox-mark_skeleton": "skeleton", "attr.id": "id", "attr.data-testid": "id" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiCheckboxMarkComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "checkboxInput", first: true, predicate: ["checkboxInput"], descendants: true }], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<div\n\tclass=\"iui-checkbox-mark\"\n\t[attr.id]=\"id\"\n\t[attr.data-testid]=\"id\"\n\t[attr.aria-checked]=\"indeterminate ? 'mixed' : checked\"\n>\n\t<input\n\t\t#checkboxInput\n\t\t[attr.id]=\"_inputId\"\n\t\t[attr.data-testid]=\"_inputId\"\n\t\tclass=\"iui-checkbox-mark__input_native\"\n\t\t[disabled]=\"disabled\"\n\t\t(change)=\"_changeHandler($event)\"\n\t\t(blur)=\"_blurHandler($event)\"\n\t\t[checked]=\"checked\"\n\t\t[indeterminate]=\"indeterminate\"\n\t\ttype=\"checkbox\"\n\t/>\n\t<div class=\"iui-checkbox-mark__tickbox\"></div>\n\t<div class=\"iui-checkbox-mark__tick\"></div>\n</div>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:block;--checkbox-full-height: 20px}.iui-checkbox-mark__input_native{-webkit-appearance:none!important;-moz-appearance:none!important;appearance:none!important;border:0;overflow:hidden;outline:0;margin:0;padding:0;opacity:0;cursor:inherit;position:absolute;z-index:10;left:0;top:0;width:100%;height:100%}.iui-checkbox-mark{position:relative;padding:0;height:var(--checkbox-full-height);width:20px;display:flex;align-items:center;outline:none;border:none;background:transparent;cursor:pointer}:host.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark{cursor:default}.iui-checkbox-mark__tickbox{height:20px;width:20px;overflow:hidden;position:relative;flex-shrink:0;border-radius:var(--iui-main-unit);border:1px solid var(--iui-checkbox-border);background:var(--iui-checkbox-bg);transition:background-color .1s ease-in,border-color .1s ease-in}:host.iui-checkbox-mark_checked ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-checked-bg);border-color:var(--iui-checkbox-checked-bg)}:host.iui-checkbox-mark_indeterminate ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-checked-bg);border-color:var(--iui-checkbox-checked-bg)}:host.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-bg);border-color:var(--iui-checkbox-disabled-border)}:host.iui-checkbox-mark_checked.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-disabled-bg);border-color:var(--iui-checkbox-disabled-bg)}:host.iui-checkbox-mark_indeterminate.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-disabled-bg);border-color:var(--iui-checkbox-disabled-bg)}.iui-checkbox-mark__tickbox:before{content:\"\";position:absolute;inset:-4px;border:2px solid transparent;border-radius:calc(var(--iui-main-unit) * 2);transition:border-color .1s ease-in}.iui-checkbox-mark__input_native:focus-visible~.iui-checkbox-mark__tickbox:before{border-color:var(--iui-checkbox-focus-ring)}.iui-checkbox-mark__tick{position:absolute;z-index:1;display:inline-block;right:6.5px;top:calc((var(--checkbox-full-height) - 15px) * .5 - 2.4748737341px);transform:rotate(45deg);width:7px;height:15px;border-bottom:3px solid transparent;border-right:3px solid transparent}:host.iui-checkbox-mark_checked ::ng-deep .iui-checkbox-mark__tick{border-color:var(--iui-checkbox-checked-mark)}:host.iui-checkbox-mark_indeterminate ::ng-deep .iui-checkbox-mark__tick{transition:none;transform:none;border-right:none;border-bottom:4px solid var(--iui-checkbox-checked-mark);height:4px;width:8px;right:6px;top:calc((var(--checkbox-full-height) - 4px) * .5)}:host.iui-checkbox-mark_checked.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tick{border-color:var(--iui-checkbox-disabled-mark)}:host.iui-checkbox-mark_indeterminate.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tick{border-color:var(--iui-checkbox-disabled-mark)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiCheckboxMarkComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-checkbox-mark', standalone: true, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiCheckboxMarkComponent),
                            multi: true
                        }
                    ], imports: [CommonModule], hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiIsDisabledDirective,
                            // eslint-disable-next-line @angular-eslint/no-inputs-metadata-property
                            inputs: ['isDisabled'],
                            // eslint-disable-next-line @angular-eslint/no-outputs-metadata-property
                            outputs: ['disableChangeEvent']
                        }
                    ], host: {
                        '[class.iui-checkbox-mark_checked]': 'checked',
                        '[class.iui-checkbox-mark_indeterminate]': 'indeterminate',
                        '[class.iui-checkbox-mark_disabled]': 'disabled',
                        '[class.iui-checkbox-mark_skeleton]': 'skeleton',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "<div\n\tclass=\"iui-checkbox-mark\"\n\t[attr.id]=\"id\"\n\t[attr.data-testid]=\"id\"\n\t[attr.aria-checked]=\"indeterminate ? 'mixed' : checked\"\n>\n\t<input\n\t\t#checkboxInput\n\t\t[attr.id]=\"_inputId\"\n\t\t[attr.data-testid]=\"_inputId\"\n\t\tclass=\"iui-checkbox-mark__input_native\"\n\t\t[disabled]=\"disabled\"\n\t\t(change)=\"_changeHandler($event)\"\n\t\t(blur)=\"_blurHandler($event)\"\n\t\t[checked]=\"checked\"\n\t\t[indeterminate]=\"indeterminate\"\n\t\ttype=\"checkbox\"\n\t/>\n\t<div class=\"iui-checkbox-mark__tickbox\"></div>\n\t<div class=\"iui-checkbox-mark__tick\"></div>\n</div>\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:block;--checkbox-full-height: 20px}.iui-checkbox-mark__input_native{-webkit-appearance:none!important;-moz-appearance:none!important;appearance:none!important;border:0;overflow:hidden;outline:0;margin:0;padding:0;opacity:0;cursor:inherit;position:absolute;z-index:10;left:0;top:0;width:100%;height:100%}.iui-checkbox-mark{position:relative;padding:0;height:var(--checkbox-full-height);width:20px;display:flex;align-items:center;outline:none;border:none;background:transparent;cursor:pointer}:host.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark{cursor:default}.iui-checkbox-mark__tickbox{height:20px;width:20px;overflow:hidden;position:relative;flex-shrink:0;border-radius:var(--iui-main-unit);border:1px solid var(--iui-checkbox-border);background:var(--iui-checkbox-bg);transition:background-color .1s ease-in,border-color .1s ease-in}:host.iui-checkbox-mark_checked ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-checked-bg);border-color:var(--iui-checkbox-checked-bg)}:host.iui-checkbox-mark_indeterminate ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-checked-bg);border-color:var(--iui-checkbox-checked-bg)}:host.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-bg);border-color:var(--iui-checkbox-disabled-border)}:host.iui-checkbox-mark_checked.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-disabled-bg);border-color:var(--iui-checkbox-disabled-bg)}:host.iui-checkbox-mark_indeterminate.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tickbox{background-color:var(--iui-checkbox-disabled-bg);border-color:var(--iui-checkbox-disabled-bg)}.iui-checkbox-mark__tickbox:before{content:\"\";position:absolute;inset:-4px;border:2px solid transparent;border-radius:calc(var(--iui-main-unit) * 2);transition:border-color .1s ease-in}.iui-checkbox-mark__input_native:focus-visible~.iui-checkbox-mark__tickbox:before{border-color:var(--iui-checkbox-focus-ring)}.iui-checkbox-mark__tick{position:absolute;z-index:1;display:inline-block;right:6.5px;top:calc((var(--checkbox-full-height) - 15px) * .5 - 2.4748737341px);transform:rotate(45deg);width:7px;height:15px;border-bottom:3px solid transparent;border-right:3px solid transparent}:host.iui-checkbox-mark_checked ::ng-deep .iui-checkbox-mark__tick{border-color:var(--iui-checkbox-checked-mark)}:host.iui-checkbox-mark_indeterminate ::ng-deep .iui-checkbox-mark__tick{transition:none;transform:none;border-right:none;border-bottom:4px solid var(--iui-checkbox-checked-mark);height:4px;width:8px;right:6px;top:calc((var(--checkbox-full-height) - 4px) * .5)}:host.iui-checkbox-mark_checked.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tick{border-color:var(--iui-checkbox-disabled-mark)}:host.iui-checkbox-mark_indeterminate.iui-checkbox-mark_disabled ::ng-deep .iui-checkbox-mark__tick{border-color:var(--iui-checkbox-disabled-mark)}\n"] }]
        }], propDecorators: { checkboxInput: [{
                type: ViewChild,
                args: ['checkboxInput']
            }], id: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], blurEvent: [{
                type: Output
            }], checked: [{
                type: Input
            }], indeterminate: [{
                type: Input
            }], changeEvent: [{
                type: Output
            }], indeterminateChanged: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLWNoZWNrYm94LW1hcmsuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvY2hlY2tib3gtbWFyay9zcmMvaXVpLWNoZWNrYm94LW1hcmsuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvY2hlY2tib3gtbWFyay9zcmMvaXVpLWNoZWNrYm94LW1hcmsuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDbEgsT0FBTyxFQUF3QixpQkFBaUIsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3pFLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMvQyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQzs7O0FBVS9GLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztBQWtDckIsTUFBTSxPQUFPLHdCQUF3QjtJQWhDckM7UUFtQ0MsbUNBQW1DO1FBRW5DLE9BQUUsR0FBRyxxQkFBcUIsWUFBWSxFQUFFLEVBQUUsQ0FBQztRQUczQyxhQUFRLEdBQUcsS0FBSyxDQUFDO1FBR2pCLGNBQVMsR0FBRyxJQUFJLFlBQVksRUFBUyxDQUFDO1FBMkN0Qzs7O1dBR0c7UUFDSyxhQUFRLEdBQUcsS0FBSyxDQUFDO1FBRXpCOzs7V0FHRztRQUNLLGFBQVEsR0FBRyxLQUFLLENBQUM7UUFFekI7OztXQUdHO1FBQ0ssbUJBQWMsR0FBRyxLQUFLLENBQUM7UUFFL0I7OztXQUdHO1FBQ0ssd0JBQW1CLEdBQUcsTUFBTSxDQUFDLHNCQUFzQixFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7UUFHN0UsZ0JBQVcsR0FBRyxJQUFJLFlBQVksRUFBd0IsQ0FBQztRQUd2RCx5QkFBb0IsR0FBRyxJQUFJLFlBQVksRUFBVyxDQUFDO1FBNENuRDs7O1dBR0c7UUFDSyxvQkFBZSxHQUF1QyxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUM7UUFFOUU7OztXQUdHO1FBQ0sscUJBQWdCLEdBQXdDLEdBQUcsRUFBRSxDQUFDLFNBQVMsQ0FBQztLQXFDaEY7SUFoS0E7OztPQUdHO0lBQ0gsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsRUFBRSxHQUFHLFFBQVEsQ0FBQztJQUMzQixDQUFDO0lBRUQ7OztTQUdLO0lBQ0wsSUFDSSxPQUFPLENBQUMsS0FBYztRQUN6QixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztRQUN0QixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztJQUM1QixDQUFDO0lBRUQsSUFBSSxPQUFPO1FBQ1YsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3RCLENBQUM7SUFFRCxJQUNJLGFBQWEsQ0FBQyxLQUFjO1FBQy9CLE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxxQkFBOEIsRUFBRSxFQUFFO1lBQzdELElBQUkscUJBQXFCLEVBQUUsQ0FBQztnQkFDM0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7WUFDdkIsQ0FBQztRQUNGLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBRUQsSUFBSSxhQUFhO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUM1QixDQUFDO0lBRUQsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDN0QsQ0FBQztJQWdDRDs7O09BR0c7SUFDSCxZQUFZLENBQUMsS0FBWTtRQUN4QixJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNuQixPQUFPO1FBQ1IsQ0FBQztRQUVELElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUVyQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUM1QixDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssd0JBQXdCLENBQUMsS0FBYyxFQUFFLEVBQTZDO1FBQzdGLE1BQU0sT0FBTyxHQUFHLEtBQUssS0FBSyxJQUFJLENBQUMsY0FBYyxDQUFDO1FBRTlDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO1FBRTVCLElBQUksT0FBTyxFQUFFLENBQUM7WUFDYixJQUFJLEVBQUUsRUFBRSxDQUFDO2dCQUNSLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDekIsQ0FBQztZQUNELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ3JELENBQUM7SUFDRixDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssYUFBYTtRQUNwQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ3RCLENBQUM7SUFDRixDQUFDO0lBY0Q7OztPQUdHO0lBQ0gsY0FBYyxDQUFDLEtBQVk7UUFDMUIsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDbkIsT0FBTztRQUNSLENBQUM7UUFDRCxJQUFJLENBQUMsUUFBUSxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUU5QixJQUFJLENBQUMsd0JBQXdCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDO1lBQ3JCLEtBQUs7WUFDTCxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVE7U0FDdEIsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQUVELFVBQVUsQ0FBQyxHQUFZO1FBQ3RCLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDO1FBQ3BCLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRUQsZ0JBQWdCLENBQUMsRUFBc0M7UUFDdEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVELGlCQUFpQixDQUFDLEVBQXVDO1FBQ3hELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVELGdCQUFnQixDQUFDLFVBQW1CO1FBQ25DLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN2RCxDQUFDOytHQTVLVyx3QkFBd0I7bUdBQXhCLHdCQUF3Qiw0aEJBM0J6QjtZQUNWO2dCQUNDLE9BQU8sRUFBRSxpQkFBaUI7Z0JBQzFCLFdBQVcsRUFBRSxVQUFVLENBQUMsR0FBRyxFQUFFLENBQUMsd0JBQXdCLENBQUM7Z0JBQ3ZELEtBQUssRUFBRSxJQUFJO2FBQ1g7U0FDRCx5VUMxQkYsNmxCQXFCQSxraUdETVcsWUFBWTs7NEZBb0JWLHdCQUF3QjtrQkFoQ3BDLFNBQVM7K0JBQ0MsbUJBQW1CLGNBQ2pCLElBQUksYUFHTDt3QkFDVjs0QkFDQyxPQUFPLEVBQUUsaUJBQWlCOzRCQUMxQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSx5QkFBeUIsQ0FBQzs0QkFDdkQsS0FBSyxFQUFFLElBQUk7eUJBQ1g7cUJBQ0QsV0FDUSxDQUFDLFlBQVksQ0FBQyxrQkFDUDt3QkFDZixrQkFBa0I7d0JBQ2xCOzRCQUNDLFNBQVMsRUFBRSxzQkFBc0I7NEJBQ2pDLHVFQUF1RTs0QkFDdkUsTUFBTSxFQUFFLENBQUMsWUFBWSxDQUFDOzRCQUN0Qix3RUFBd0U7NEJBQ3hFLE9BQU8sRUFBRSxDQUFDLG9CQUFvQixDQUFDO3lCQUMvQjtxQkFDRCxRQUNLO3dCQUNMLG1DQUFtQyxFQUFFLFNBQVM7d0JBQzlDLHlDQUF5QyxFQUFFLGVBQWU7d0JBQzFELG9DQUFvQyxFQUFFLFVBQVU7d0JBQ2hELG9DQUFvQyxFQUFFLFVBQVU7d0JBQ2hELFdBQVcsRUFBRSxJQUFJO3dCQUNqQixvQkFBb0IsRUFBRSxJQUFJO3FCQUMxQjs4QkFHMkIsYUFBYTtzQkFBeEMsU0FBUzt1QkFBQyxlQUFlO2dCQUkxQixFQUFFO3NCQURELEtBQUs7Z0JBSU4sUUFBUTtzQkFEUCxLQUFLO2dCQUlOLFNBQVM7c0JBRFIsTUFBTTtnQkFnQkgsT0FBTztzQkFEVixLQUFLO2dCQVdGLGFBQWE7c0JBRGhCLEtBQUs7Z0JBNENOLFdBQVc7c0JBRFYsTUFBTTtnQkFJUCxvQkFBb0I7c0JBRG5CLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIEVsZW1lbnRSZWYsIEV2ZW50RW1pdHRlciwgZm9yd2FyZFJlZiwgaW5qZWN0LCBJbnB1dCwgT3V0cHV0LCBWaWV3Q2hpbGQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBOR19WQUxVRV9BQ0NFU1NPUiB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBOZ0NvbnRyb2xEaXJlY3RpdmUsIEl1aUlzRGlzYWJsZWREaXJlY3RpdmUgfSBmcm9tICdAaXRlcm8vdWktY29tcG9uZW50cy1hbmd1bGFyL2NvcmUnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEl1aUNoZWNrYm94TWFya0V2ZW50IHtcblx0ZXZlbnQ6IEV2ZW50O1xuXHRjaGVja2VkOiBib29sZWFuO1xufVxuXG5leHBvcnQgdHlwZSBJdWlDaGVja2JveE1hcmtQcm9wYWdhdGVDaGFuZ2VUeXBlID0gKF86IGJvb2xlYW4pID0+IHZvaWQ7XG5leHBvcnQgdHlwZSBJdWlDaGVja2JveE1hcmtQcm9wYWdhdGVUb3VjaGVkVHlwZSA9ICgpID0+IHZvaWQ7XG5cbmxldCBuZXh0VW5pcXVlSWQgPSAwO1xuXG5AQ29tcG9uZW50KHtcblx0c2VsZWN0b3I6ICdpdWktY2hlY2tib3gtbWFyaycsXG5cdHN0YW5kYWxvbmU6IHRydWUsXG5cdHRlbXBsYXRlVXJsOiAnLi9pdWktY2hlY2tib3gtbWFyay5jb21wb25lbnQuaHRtbCcsXG5cdHN0eWxlVXJsczogWycuL2l1aS1jaGVja2JveC1tYXJrLmNvbXBvbmVudC5zY3NzJ10sXG5cdHByb3ZpZGVyczogW1xuXHRcdHtcblx0XHRcdHByb3ZpZGU6IE5HX1ZBTFVFX0FDQ0VTU09SLFxuXHRcdFx0dXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gSXVpQ2hlY2tib3hNYXJrQ29tcG9uZW50KSxcblx0XHRcdG11bHRpOiB0cnVlXG5cdFx0fVxuXHRdLFxuXHRpbXBvcnRzOiBbQ29tbW9uTW9kdWxlXSxcblx0aG9zdERpcmVjdGl2ZXM6IFtcblx0XHROZ0NvbnRyb2xEaXJlY3RpdmUsXG5cdFx0e1xuXHRcdFx0ZGlyZWN0aXZlOiBJdWlJc0Rpc2FibGVkRGlyZWN0aXZlLFxuXHRcdFx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEBhbmd1bGFyLWVzbGludC9uby1pbnB1dHMtbWV0YWRhdGEtcHJvcGVydHlcblx0XHRcdGlucHV0czogWydpc0Rpc2FibGVkJ10sXG5cdFx0XHQvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQGFuZ3VsYXItZXNsaW50L25vLW91dHB1dHMtbWV0YWRhdGEtcHJvcGVydHlcblx0XHRcdG91dHB1dHM6IFsnZGlzYWJsZUNoYW5nZUV2ZW50J11cblx0XHR9XG5cdF0sXG5cdGhvc3Q6IHtcblx0XHQnW2NsYXNzLml1aS1jaGVja2JveC1tYXJrX2NoZWNrZWRdJzogJ2NoZWNrZWQnLFxuXHRcdCdbY2xhc3MuaXVpLWNoZWNrYm94LW1hcmtfaW5kZXRlcm1pbmF0ZV0nOiAnaW5kZXRlcm1pbmF0ZScsXG5cdFx0J1tjbGFzcy5pdWktY2hlY2tib3gtbWFya19kaXNhYmxlZF0nOiAnZGlzYWJsZWQnLFxuXHRcdCdbY2xhc3MuaXVpLWNoZWNrYm94LW1hcmtfc2tlbGV0b25dJzogJ3NrZWxldG9uJyxcblx0XHQnW2F0dHIuaWRdJzogJ2lkJyxcblx0XHQnW2F0dHIuZGF0YS10ZXN0aWRdJzogJ2lkJ1xuXHR9XG59KVxuZXhwb3J0IGNsYXNzIEl1aUNoZWNrYm94TWFya0NvbXBvbmVudCBpbXBsZW1lbnRzIENvbnRyb2xWYWx1ZUFjY2Vzc29yIHtcblx0QFZpZXdDaGlsZCgnY2hlY2tib3hJbnB1dCcpIGNoZWNrYm94SW5wdXQ/OiBFbGVtZW50UmVmPEhUTUxJbnB1dEVsZW1lbnQ+O1xuXG5cdC8qKiBUaGUgdW5pcXVlIGlkIG9mIHRoZSBlbGVtZW50ICovXG5cdEBJbnB1dCgpXG5cdGlkID0gYGl1aS1jaGVja2JveC1tYXJrLSR7bmV4dFVuaXF1ZUlkKyt9YDtcblxuXHRASW5wdXQoKVxuXHRza2VsZXRvbiA9IGZhbHNlO1xuXG5cdEBPdXRwdXQoKVxuXHRibHVyRXZlbnQgPSBuZXcgRXZlbnRFbWl0dGVyPEV2ZW50PigpO1xuXG5cdC8qKlxuXHQgKiBAcHJvcFxuXHQgKiBAaWdub3JlXG5cdCAqL1xuXHRnZXQgX2lucHV0SWQoKSB7XG5cdFx0cmV0dXJuIHRoaXMuaWQgKyAnLWlucHV0Jztcblx0fVxuXG5cdC8qKlxuXHQgKiBpbnB1dCB3aGVyZSB5b3UgY2FuIHBhc3MgZGVzaXJhYmxlIHN0YXRlIG9mIGNoZWNrYm94IFwidHJ1ZVwiIG9yIFwiZmFsc2VcIi5cblx0ICogQ2FuIGJlIGhlbHBmdWwgd2hlbiB5b3UgZG9uJ3QgdXNlIGZvcm1Db250cm9sLCBvdGhlcndpc2UgeW91IGNhbiBwYXRjaFZhbHVlIG9mIGZvcm1Db250cm9sXG5cdCAqICovXG5cdEBJbnB1dCgpXG5cdHNldCBjaGVja2VkKHZhbHVlOiBib29sZWFuKSB7XG5cdFx0dGhpcy5fY2hlY2tlZCA9IHZhbHVlO1xuXHRcdHRoaXMuaW5kZXRlcm1pbmF0ZSA9IGZhbHNlO1xuXHR9XG5cblx0Z2V0IGNoZWNrZWQoKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuX2NoZWNrZWQ7XG5cdH1cblxuXHRASW5wdXQoKVxuXHRzZXQgaW5kZXRlcm1pbmF0ZSh2YWx1ZTogYm9vbGVhbikge1xuXHRcdGNvbnN0IHVwZGF0ZUNoZWNrZWRTdGF0ZSA9IChuZXdJbmRldGVybWluYXRlU3RhdGU6IGJvb2xlYW4pID0+IHtcblx0XHRcdGlmIChuZXdJbmRldGVybWluYXRlU3RhdGUpIHtcblx0XHRcdFx0dGhpcy5fY2hlY2tlZCA9IGZhbHNlO1xuXHRcdFx0fVxuXHRcdH07XG5cblx0XHR0aGlzLnNldEluZGV0ZXJtaW5hdGVJbnRlcm5hbCh2YWx1ZSwgdXBkYXRlQ2hlY2tlZFN0YXRlKTtcblx0fVxuXG5cdGdldCBpbmRldGVybWluYXRlKCk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiB0aGlzLl9pbmRldGVybWluYXRlO1xuXHR9XG5cblx0Z2V0IGRpc2FibGVkKCkge1xuXHRcdHJldHVybiB0aGlzLmlzRGlzYWJsZWREaXJlY3RpdmUuaXNEaXNhYmxlZCB8fCB0aGlzLnNrZWxldG9uO1xuXHR9XG5cblx0LyoqXG5cdCAqIEBwcm9wXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdHByaXZhdGUgX3RvdWNoZWQgPSBmYWxzZTtcblxuXHQvKipcblx0ICogQHByb3Bcblx0ICogQGlnbm9yZVxuXHQgKi9cblx0cHJpdmF0ZSBfY2hlY2tlZCA9IGZhbHNlO1xuXG5cdC8qKlxuXHQgKiBAcHJvcFxuXHQgKiBAaWdub3JlXG5cdCAqL1xuXHRwcml2YXRlIF9pbmRldGVybWluYXRlID0gZmFsc2U7XG5cblx0LyoqXG5cdCAqIEBwcm9wXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdHByaXZhdGUgaXNEaXNhYmxlZERpcmVjdGl2ZSA9IGluamVjdChJdWlJc0Rpc2FibGVkRGlyZWN0aXZlLCB7IHNlbGY6IHRydWUgfSk7XG5cblx0QE91dHB1dCgpXG5cdGNoYW5nZUV2ZW50ID0gbmV3IEV2ZW50RW1pdHRlcjxJdWlDaGVja2JveE1hcmtFdmVudD4oKTtcblxuXHRAT3V0cHV0KClcblx0aW5kZXRlcm1pbmF0ZUNoYW5nZWQgPSBuZXcgRXZlbnRFbWl0dGVyPGJvb2xlYW4+KCk7XG5cblx0LyoqXG5cdCAqIEBtZXRob2Rcblx0ICogQGlnbm9yZVxuXHQgKi9cblx0X2JsdXJIYW5kbGVyKGV2ZW50OiBFdmVudCkge1xuXHRcdGlmICh0aGlzLmRpc2FibGVkKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0dGhpcy5tYXJrQXNUb3VjaGVkKCk7XG5cblx0XHR0aGlzLmJsdXJFdmVudC5lbWl0KGV2ZW50KTtcblx0fVxuXG5cdC8qKlxuXHQgKiBAbWV0aG9kXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdHByaXZhdGUgc2V0SW5kZXRlcm1pbmF0ZUludGVybmFsKHZhbHVlOiBib29sZWFuLCBjYj86IChuZXdJbmRldGVybWluYXRlU3RhdGU6IGJvb2xlYW4pID0+IHZvaWQpIHtcblx0XHRjb25zdCBjaGFuZ2VkID0gdmFsdWUgIT09IHRoaXMuX2luZGV0ZXJtaW5hdGU7XG5cblx0XHR0aGlzLl9pbmRldGVybWluYXRlID0gdmFsdWU7XG5cblx0XHRpZiAoY2hhbmdlZCkge1xuXHRcdFx0aWYgKGNiKSB7XG5cdFx0XHRcdGNiKHRoaXMuX2luZGV0ZXJtaW5hdGUpO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy5pbmRldGVybWluYXRlQ2hhbmdlZC5lbWl0KHRoaXMuX2luZGV0ZXJtaW5hdGUpO1xuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBAbWV0aG9kXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdHByaXZhdGUgbWFya0FzVG91Y2hlZCgpIHtcblx0XHRpZiAoIXRoaXMuX3RvdWNoZWQpIHtcblx0XHRcdHRoaXMucHJvcGFnYXRlVG91Y2hlZCgpO1xuXHRcdFx0dGhpcy5fdG91Y2hlZCA9IHRydWU7XG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIEBwcm9wXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdHByaXZhdGUgcHJvcGFnYXRlQ2hhbmdlOiBJdWlDaGVja2JveE1hcmtQcm9wYWdhdGVDaGFuZ2VUeXBlID0gKCkgPT4gdW5kZWZpbmVkO1xuXG5cdC8qKlxuXHQgKiBAcHJvcFxuXHQgKiBAaWdub3JlXG5cdCAqL1xuXHRwcml2YXRlIHByb3BhZ2F0ZVRvdWNoZWQ6IEl1aUNoZWNrYm94TWFya1Byb3BhZ2F0ZVRvdWNoZWRUeXBlID0gKCkgPT4gdW5kZWZpbmVkO1xuXG5cdC8qKlxuXHQgKiBAbWV0aG9kXG5cdCAqIEBpZ25vcmVcblx0ICovXG5cdF9jaGFuZ2VIYW5kbGVyKGV2ZW50OiBFdmVudCkge1xuXHRcdGlmICh0aGlzLmRpc2FibGVkKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdHRoaXMuX2NoZWNrZWQgPSAhdGhpcy5jaGVja2VkO1xuXG5cdFx0dGhpcy5zZXRJbmRldGVybWluYXRlSW50ZXJuYWwoZmFsc2UpO1xuXHRcdHRoaXMubWFya0FzVG91Y2hlZCgpO1xuXHRcdHRoaXMucHJvcGFnYXRlQ2hhbmdlKHRoaXMuX2NoZWNrZWQpO1xuXHRcdHRoaXMuY2hhbmdlRXZlbnQuZW1pdCh7XG5cdFx0XHRldmVudCxcblx0XHRcdGNoZWNrZWQ6IHRoaXMuX2NoZWNrZWRcblx0XHR9KTtcblx0fVxuXG5cdHdyaXRlVmFsdWUodmFsOiBib29sZWFuKSB7XG5cdFx0dGhpcy5fY2hlY2tlZCA9IHZhbDtcblx0XHR0aGlzLnNldEluZGV0ZXJtaW5hdGVJbnRlcm5hbChmYWxzZSk7XG5cdH1cblxuXHRyZWdpc3Rlck9uQ2hhbmdlKGZuOiBJdWlDaGVja2JveE1hcmtQcm9wYWdhdGVDaGFuZ2VUeXBlKSB7XG5cdFx0dGhpcy5wcm9wYWdhdGVDaGFuZ2UgPSBmbjtcblx0fVxuXG5cdHJlZ2lzdGVyT25Ub3VjaGVkKGZuOiBJdWlDaGVja2JveE1hcmtQcm9wYWdhdGVUb3VjaGVkVHlwZSkge1xuXHRcdHRoaXMucHJvcGFnYXRlVG91Y2hlZCA9IGZuO1xuXHR9XG5cblx0c2V0RGlzYWJsZWRTdGF0ZShpc0Rpc2FibGVkOiBib29sZWFuKSB7XG5cdFx0dGhpcy5pc0Rpc2FibGVkRGlyZWN0aXZlLnNldERpc2FibGVkU3RhdGUoaXNEaXNhYmxlZCk7XG5cdH1cbn1cbiIsIjxkaXZcblx0Y2xhc3M9XCJpdWktY2hlY2tib3gtbWFya1wiXG5cdFthdHRyLmlkXT1cImlkXCJcblx0W2F0dHIuZGF0YS10ZXN0aWRdPVwiaWRcIlxuXHRbYXR0ci5hcmlhLWNoZWNrZWRdPVwiaW5kZXRlcm1pbmF0ZSA/ICdtaXhlZCcgOiBjaGVja2VkXCJcbj5cblx0PGlucHV0XG5cdFx0I2NoZWNrYm94SW5wdXRcblx0XHRbYXR0ci5pZF09XCJfaW5wdXRJZFwiXG5cdFx0W2F0dHIuZGF0YS10ZXN0aWRdPVwiX2lucHV0SWRcIlxuXHRcdGNsYXNzPVwiaXVpLWNoZWNrYm94LW1hcmtfX2lucHV0X25hdGl2ZVwiXG5cdFx0W2Rpc2FibGVkXT1cImRpc2FibGVkXCJcblx0XHQoY2hhbmdlKT1cIl9jaGFuZ2VIYW5kbGVyKCRldmVudClcIlxuXHRcdChibHVyKT1cIl9ibHVySGFuZGxlcigkZXZlbnQpXCJcblx0XHRbY2hlY2tlZF09XCJjaGVja2VkXCJcblx0XHRbaW5kZXRlcm1pbmF0ZV09XCJpbmRldGVybWluYXRlXCJcblx0XHR0eXBlPVwiY2hlY2tib3hcIlxuXHQvPlxuXHQ8ZGl2IGNsYXNzPVwiaXVpLWNoZWNrYm94LW1hcmtfX3RpY2tib3hcIj48L2Rpdj5cblx0PGRpdiBjbGFzcz1cIml1aS1jaGVja2JveC1tYXJrX190aWNrXCI+PC9kaXY+XG48L2Rpdj5cbiJdfQ==