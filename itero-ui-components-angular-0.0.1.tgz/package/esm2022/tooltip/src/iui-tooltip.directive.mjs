import { ApplicationRef, createComponent, Directive, ElementRef, EnvironmentInjector, HostListener, Input } from '@angular/core';
import { IuiTooltipComponent } from './iui-tooltip.component';
import * as i0 from "@angular/core";
export class IuiTooltipDirective {
    constructor(_el, _appRef, _injector) {
        this._el = _el;
        this._appRef = _appRef;
        this._injector = _injector;
        this.tooltipText = '';
        this.iuiTooltipPlacement = 'top';
        this.iuiTooltipAlignment = 'middle';
        this.iuiTooltipShowCaret = true;
        this.iuiTooltipDelay = 300;
        this._tooltipRef = null;
        this._showTimeout = null;
        this._hideTimeout = null;
        this._tooltipId = `iui-tooltip-${_nextId++}`;
    }
    show() {
        this._clearHideTimeout();
        if (this._tooltipRef)
            return;
        if (!this.tooltipText)
            return;
        this._showTimeout = setTimeout(() => {
            this._createTooltip();
        }, this.iuiTooltipDelay);
    }
    hide() {
        this._clearShowTimeout();
        this._hideTimeout = setTimeout(() => {
            this._destroyTooltip();
        }, 100);
    }
    onEscape() {
        this._clearShowTimeout();
        this._destroyTooltip();
    }
    _createTooltip() {
        if (this._tooltipRef)
            return;
        const ref = createComponent(IuiTooltipComponent, {
            environmentInjector: this._injector
        });
        ref.setInput('text', this.tooltipText);
        ref.setInput('placement', this.iuiTooltipPlacement);
        ref.setInput('alignment', this.iuiTooltipAlignment);
        ref.setInput('showCaret', this.iuiTooltipShowCaret);
        const el = ref.location.nativeElement;
        el.style.cssText = 'position:fixed;z-index:9999;pointer-events:none;';
        el.id = this._tooltipId;
        this._el.nativeElement.setAttribute('aria-describedby', this._tooltipId);
        this._appRef.attachView(ref.hostView);
        document.body.appendChild(el);
        this._tooltipRef = ref;
        ref.changeDetectorRef.detectChanges();
        this._positionTooltip();
    }
    _positionTooltip() {
        if (!this._tooltipRef)
            return;
        const hostRect = this._el.nativeElement.getBoundingClientRect();
        const tooltipEl = this._tooltipRef.location.nativeElement;
        const tooltipRect = tooltipEl.getBoundingClientRect();
        const offset = 4;
        let x = 0;
        let y = 0;
        switch (this.iuiTooltipPlacement) {
            case 'bottom':
                y = hostRect.bottom + offset;
                break;
            case 'top':
                y = hostRect.top - offset - tooltipRect.height;
                break;
            case 'right':
                x = hostRect.right + offset;
                break;
            case 'left':
                x = hostRect.left - offset - tooltipRect.width;
                break;
        }
        const isHorizontal = this.iuiTooltipPlacement === 'top' || this.iuiTooltipPlacement === 'bottom';
        if (isHorizontal) {
            switch (this.iuiTooltipAlignment) {
                case 'start':
                    x = hostRect.left;
                    break;
                case 'middle':
                    x = hostRect.left + hostRect.width / 2 - tooltipRect.width / 2;
                    break;
                case 'end':
                    x = hostRect.right - tooltipRect.width;
                    break;
            }
        }
        else {
            switch (this.iuiTooltipAlignment) {
                case 'start':
                    y = hostRect.top;
                    break;
                case 'middle':
                    y = hostRect.top + hostRect.height / 2 - tooltipRect.height / 2;
                    break;
                case 'end':
                    y = hostRect.bottom - tooltipRect.height;
                    break;
            }
        }
        tooltipEl.style.left = `${x}px`;
        tooltipEl.style.top = `${y}px`;
    }
    _destroyTooltip() {
        if (!this._tooltipRef)
            return;
        this._el.nativeElement.removeAttribute('aria-describedby');
        this._appRef.detachView(this._tooltipRef.hostView);
        this._tooltipRef.location.nativeElement.remove();
        this._tooltipRef.destroy();
        this._tooltipRef = null;
    }
    _clearShowTimeout() {
        if (this._showTimeout !== null) {
            clearTimeout(this._showTimeout);
            this._showTimeout = null;
        }
    }
    _clearHideTimeout() {
        if (this._hideTimeout !== null) {
            clearTimeout(this._hideTimeout);
            this._hideTimeout = null;
        }
    }
    ngOnDestroy() {
        this._clearShowTimeout();
        this._clearHideTimeout();
        this._destroyTooltip();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTooltipDirective, deps: [{ token: i0.ElementRef }, { token: i0.ApplicationRef }, { token: i0.EnvironmentInjector }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: IuiTooltipDirective, isStandalone: true, selector: "[iuiTooltip]", inputs: { tooltipText: ["iuiTooltip", "tooltipText"], iuiTooltipPlacement: "iuiTooltipPlacement", iuiTooltipAlignment: "iuiTooltipAlignment", iuiTooltipShowCaret: "iuiTooltipShowCaret", iuiTooltipDelay: "iuiTooltipDelay" }, host: { listeners: { "mouseenter": "show()", "focusin": "show()", "mouseleave": "hide()", "focusout": "hide()", "keydown.escape": "onEscape()" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[iuiTooltip]',
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ApplicationRef }, { type: i0.EnvironmentInjector }], propDecorators: { tooltipText: [{
                type: Input,
                args: ['iuiTooltip']
            }], iuiTooltipPlacement: [{
                type: Input
            }], iuiTooltipAlignment: [{
                type: Input
            }], iuiTooltipShowCaret: [{
                type: Input
            }], iuiTooltipDelay: [{
                type: Input
            }], show: [{
                type: HostListener,
                args: ['mouseenter']
            }, {
                type: HostListener,
                args: ['focusin']
            }], hide: [{
                type: HostListener,
                args: ['mouseleave']
            }, {
                type: HostListener,
                args: ['focusout']
            }], onEscape: [{
                type: HostListener,
                args: ['keydown.escape']
            }] } });
let _nextId = 0;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLXRvb2x0aXAuZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvdG9vbHRpcC9zcmMvaXVpLXRvb2x0aXAuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxjQUFjLEVBQUUsZUFBZSxFQUFFLFNBQVMsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBYSxNQUFNLGVBQWUsQ0FBQztBQUU1SSxPQUFPLEVBQUUsbUJBQW1CLEVBQTRDLE1BQU0seUJBQXlCLENBQUM7O0FBTXhHLE1BQU0sT0FBTyxtQkFBbUI7SUFZL0IsWUFDUyxHQUE0QixFQUM1QixPQUF1QixFQUN2QixTQUE4QjtRQUY5QixRQUFHLEdBQUgsR0FBRyxDQUF5QjtRQUM1QixZQUFPLEdBQVAsT0FBTyxDQUFnQjtRQUN2QixjQUFTLEdBQVQsU0FBUyxDQUFxQjtRQWRsQixnQkFBVyxHQUFHLEVBQUUsQ0FBQztRQUM3Qix3QkFBbUIsR0FBd0IsS0FBSyxDQUFDO1FBQ2pELHdCQUFtQixHQUF3QixRQUFRLENBQUM7UUFDcEQsd0JBQW1CLEdBQUcsSUFBSSxDQUFDO1FBQzNCLG9CQUFlLEdBQUcsR0FBRyxDQUFDO1FBRXZCLGdCQUFXLEdBQTZDLElBQUksQ0FBQztRQUM3RCxpQkFBWSxHQUF5QyxJQUFJLENBQUM7UUFDMUQsaUJBQVksR0FBeUMsSUFBSSxDQUFDO1FBQzFELGVBQVUsR0FBRyxlQUFlLE9BQU8sRUFBRSxFQUFFLENBQUM7SUFNN0MsQ0FBQztJQUlKLElBQUk7UUFDSCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUN6QixJQUFJLElBQUksQ0FBQyxXQUFXO1lBQUUsT0FBTztRQUM3QixJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVc7WUFBRSxPQUFPO1FBRTlCLElBQUksQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNuQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdkIsQ0FBQyxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBSUQsSUFBSTtRQUNILElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNuQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDeEIsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ1QsQ0FBQztJQUdELFFBQVE7UUFDUCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVPLGNBQWM7UUFDckIsSUFBSSxJQUFJLENBQUMsV0FBVztZQUFFLE9BQU87UUFFN0IsTUFBTSxHQUFHLEdBQUcsZUFBZSxDQUFDLG1CQUFtQixFQUFFO1lBQ2hELG1CQUFtQixFQUFFLElBQUksQ0FBQyxTQUFTO1NBQ25DLENBQUMsQ0FBQztRQUVILEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUN2QyxHQUFHLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUNwRCxHQUFHLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUNwRCxHQUFHLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUVwRCxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLGFBQTRCLENBQUM7UUFDckQsRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsa0RBQWtELENBQUM7UUFDdEUsRUFBRSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFekUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3RDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzlCLElBQUksQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDO1FBRXZCLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN0QyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBRU8sZ0JBQWdCO1FBQ3ZCLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVztZQUFFLE9BQU87UUFFOUIsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUNoRSxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxhQUE0QixDQUFDO1FBQ3pFLE1BQU0sV0FBVyxHQUFHLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQ3RELE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQztRQUVqQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDVixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFVixRQUFRLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1lBQ2xDLEtBQUssUUFBUTtnQkFDWixDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7Z0JBQzdCLE1BQU07WUFDUCxLQUFLLEtBQUs7Z0JBQ1QsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxHQUFHLEdBQUcsTUFBTSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUM7Z0JBQy9DLE1BQU07WUFDUCxLQUFLLE9BQU87Z0JBQ1gsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDO2dCQUM1QixNQUFNO1lBQ1AsS0FBSyxNQUFNO2dCQUNWLENBQUMsR0FBRyxRQUFRLENBQUMsSUFBSSxHQUFHLE1BQU0sR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDO2dCQUMvQyxNQUFNO1FBQ1IsQ0FBQztRQUVELE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxtQkFBbUIsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLG1CQUFtQixLQUFLLFFBQVEsQ0FBQztRQUVqRyxJQUFJLFlBQVksRUFBRSxDQUFDO1lBQ2xCLFFBQVEsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7Z0JBQ2xDLEtBQUssT0FBTztvQkFDWCxDQUFDLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztvQkFDbEIsTUFBTTtnQkFDUCxLQUFLLFFBQVE7b0JBQ1osQ0FBQyxHQUFHLFFBQVEsQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsV0FBVyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQy9ELE1BQU07Z0JBQ1AsS0FBSyxLQUFLO29CQUNULENBQUMsR0FBRyxRQUFRLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUM7b0JBQ3ZDLE1BQU07WUFDUixDQUFDO1FBQ0YsQ0FBQzthQUFNLENBQUM7WUFDUCxRQUFRLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO2dCQUNsQyxLQUFLLE9BQU87b0JBQ1gsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUM7b0JBQ2pCLE1BQU07Z0JBQ1AsS0FBSyxRQUFRO29CQUNaLENBQUMsR0FBRyxRQUFRLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO29CQUNoRSxNQUFNO2dCQUNQLEtBQUssS0FBSztvQkFDVCxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDO29CQUN6QyxNQUFNO1lBQ1IsQ0FBQztRQUNGLENBQUM7UUFFRCxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ2hDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUM7SUFDaEMsQ0FBQztJQUVPLGVBQWU7UUFDdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXO1lBQUUsT0FBTztRQUU5QixJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ25ELElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNqRCxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO0lBQ3pCLENBQUM7SUFFTyxpQkFBaUI7UUFDeEIsSUFBSSxJQUFJLENBQUMsWUFBWSxLQUFLLElBQUksRUFBRSxDQUFDO1lBQ2hDLFlBQVksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDaEMsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7UUFDMUIsQ0FBQztJQUNGLENBQUM7SUFFTyxpQkFBaUI7UUFDeEIsSUFBSSxJQUFJLENBQUMsWUFBWSxLQUFLLElBQUksRUFBRSxDQUFDO1lBQ2hDLFlBQVksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDaEMsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7UUFDMUIsQ0FBQztJQUNGLENBQUM7SUFFRCxXQUFXO1FBQ1YsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDekIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDekIsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ3hCLENBQUM7K0dBNUpXLG1CQUFtQjttR0FBbkIsbUJBQW1COzs0RkFBbkIsbUJBQW1CO2tCQUovQixTQUFTO21CQUFDO29CQUNWLFFBQVEsRUFBRSxjQUFjO29CQUN4QixVQUFVLEVBQUUsSUFBSTtpQkFDaEI7OElBRXFCLFdBQVc7c0JBQS9CLEtBQUs7dUJBQUMsWUFBWTtnQkFDVixtQkFBbUI7c0JBQTNCLEtBQUs7Z0JBQ0csbUJBQW1CO3NCQUEzQixLQUFLO2dCQUNHLG1CQUFtQjtzQkFBM0IsS0FBSztnQkFDRyxlQUFlO3NCQUF2QixLQUFLO2dCQWVOLElBQUk7c0JBRkgsWUFBWTt1QkFBQyxZQUFZOztzQkFDekIsWUFBWTt1QkFBQyxTQUFTO2dCQWF2QixJQUFJO3NCQUZILFlBQVk7dUJBQUMsWUFBWTs7c0JBQ3pCLFlBQVk7dUJBQUMsVUFBVTtnQkFTeEIsUUFBUTtzQkFEUCxZQUFZO3VCQUFDLGdCQUFnQjs7QUF3SC9CLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcGxpY2F0aW9uUmVmLCBjcmVhdGVDb21wb25lbnQsIERpcmVjdGl2ZSwgRWxlbWVudFJlZiwgRW52aXJvbm1lbnRJbmplY3RvciwgSG9zdExpc3RlbmVyLCBJbnB1dCwgT25EZXN0cm95IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgdHlwZSB7IENvbXBvbmVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSXVpVG9vbHRpcENvbXBvbmVudCwgSXVpVG9vbHRpcEFsaWdubWVudCwgSXVpVG9vbHRpcFBsYWNlbWVudCB9IGZyb20gJy4vaXVpLXRvb2x0aXAuY29tcG9uZW50JztcblxuQERpcmVjdGl2ZSh7XG5cdHNlbGVjdG9yOiAnW2l1aVRvb2x0aXBdJyxcblx0c3RhbmRhbG9uZTogdHJ1ZVxufSlcbmV4cG9ydCBjbGFzcyBJdWlUb29sdGlwRGlyZWN0aXZlIGltcGxlbWVudHMgT25EZXN0cm95IHtcblx0QElucHV0KCdpdWlUb29sdGlwJykgdG9vbHRpcFRleHQgPSAnJztcblx0QElucHV0KCkgaXVpVG9vbHRpcFBsYWNlbWVudDogSXVpVG9vbHRpcFBsYWNlbWVudCA9ICd0b3AnO1xuXHRASW5wdXQoKSBpdWlUb29sdGlwQWxpZ25tZW50OiBJdWlUb29sdGlwQWxpZ25tZW50ID0gJ21pZGRsZSc7XG5cdEBJbnB1dCgpIGl1aVRvb2x0aXBTaG93Q2FyZXQgPSB0cnVlO1xuXHRASW5wdXQoKSBpdWlUb29sdGlwRGVsYXkgPSAzMDA7XG5cblx0cHJpdmF0ZSBfdG9vbHRpcFJlZjogQ29tcG9uZW50UmVmPEl1aVRvb2x0aXBDb21wb25lbnQ+IHwgbnVsbCA9IG51bGw7XG5cdHByaXZhdGUgX3Nob3dUaW1lb3V0OiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IG51bGwgPSBudWxsO1xuXHRwcml2YXRlIF9oaWRlVGltZW91dDogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCBudWxsID0gbnVsbDtcblx0cHJpdmF0ZSBfdG9vbHRpcElkID0gYGl1aS10b29sdGlwLSR7X25leHRJZCsrfWA7XG5cblx0Y29uc3RydWN0b3IoXG5cdFx0cHJpdmF0ZSBfZWw6IEVsZW1lbnRSZWY8SFRNTEVsZW1lbnQ+LFxuXHRcdHByaXZhdGUgX2FwcFJlZjogQXBwbGljYXRpb25SZWYsXG5cdFx0cHJpdmF0ZSBfaW5qZWN0b3I6IEVudmlyb25tZW50SW5qZWN0b3Jcblx0KSB7fVxuXG5cdEBIb3N0TGlzdGVuZXIoJ21vdXNlZW50ZXInKVxuXHRASG9zdExpc3RlbmVyKCdmb2N1c2luJylcblx0c2hvdygpOiB2b2lkIHtcblx0XHR0aGlzLl9jbGVhckhpZGVUaW1lb3V0KCk7XG5cdFx0aWYgKHRoaXMuX3Rvb2x0aXBSZWYpIHJldHVybjtcblx0XHRpZiAoIXRoaXMudG9vbHRpcFRleHQpIHJldHVybjtcblxuXHRcdHRoaXMuX3Nob3dUaW1lb3V0ID0gc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHR0aGlzLl9jcmVhdGVUb29sdGlwKCk7XG5cdFx0fSwgdGhpcy5pdWlUb29sdGlwRGVsYXkpO1xuXHR9XG5cblx0QEhvc3RMaXN0ZW5lcignbW91c2VsZWF2ZScpXG5cdEBIb3N0TGlzdGVuZXIoJ2ZvY3Vzb3V0Jylcblx0aGlkZSgpOiB2b2lkIHtcblx0XHR0aGlzLl9jbGVhclNob3dUaW1lb3V0KCk7XG5cdFx0dGhpcy5faGlkZVRpbWVvdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdHRoaXMuX2Rlc3Ryb3lUb29sdGlwKCk7XG5cdFx0fSwgMTAwKTtcblx0fVxuXG5cdEBIb3N0TGlzdGVuZXIoJ2tleWRvd24uZXNjYXBlJylcblx0b25Fc2NhcGUoKTogdm9pZCB7XG5cdFx0dGhpcy5fY2xlYXJTaG93VGltZW91dCgpO1xuXHRcdHRoaXMuX2Rlc3Ryb3lUb29sdGlwKCk7XG5cdH1cblxuXHRwcml2YXRlIF9jcmVhdGVUb29sdGlwKCk6IHZvaWQge1xuXHRcdGlmICh0aGlzLl90b29sdGlwUmVmKSByZXR1cm47XG5cblx0XHRjb25zdCByZWYgPSBjcmVhdGVDb21wb25lbnQoSXVpVG9vbHRpcENvbXBvbmVudCwge1xuXHRcdFx0ZW52aXJvbm1lbnRJbmplY3RvcjogdGhpcy5faW5qZWN0b3Jcblx0XHR9KTtcblxuXHRcdHJlZi5zZXRJbnB1dCgndGV4dCcsIHRoaXMudG9vbHRpcFRleHQpO1xuXHRcdHJlZi5zZXRJbnB1dCgncGxhY2VtZW50JywgdGhpcy5pdWlUb29sdGlwUGxhY2VtZW50KTtcblx0XHRyZWYuc2V0SW5wdXQoJ2FsaWdubWVudCcsIHRoaXMuaXVpVG9vbHRpcEFsaWdubWVudCk7XG5cdFx0cmVmLnNldElucHV0KCdzaG93Q2FyZXQnLCB0aGlzLml1aVRvb2x0aXBTaG93Q2FyZXQpO1xuXG5cdFx0Y29uc3QgZWwgPSByZWYubG9jYXRpb24ubmF0aXZlRWxlbWVudCBhcyBIVE1MRWxlbWVudDtcblx0XHRlbC5zdHlsZS5jc3NUZXh0ID0gJ3Bvc2l0aW9uOmZpeGVkO3otaW5kZXg6OTk5OTtwb2ludGVyLWV2ZW50czpub25lOyc7XG5cdFx0ZWwuaWQgPSB0aGlzLl90b29sdGlwSWQ7XG5cdFx0dGhpcy5fZWwubmF0aXZlRWxlbWVudC5zZXRBdHRyaWJ1dGUoJ2FyaWEtZGVzY3JpYmVkYnknLCB0aGlzLl90b29sdGlwSWQpO1xuXG5cdFx0dGhpcy5fYXBwUmVmLmF0dGFjaFZpZXcocmVmLmhvc3RWaWV3KTtcblx0XHRkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGVsKTtcblx0XHR0aGlzLl90b29sdGlwUmVmID0gcmVmO1xuXG5cdFx0cmVmLmNoYW5nZURldGVjdG9yUmVmLmRldGVjdENoYW5nZXMoKTtcblx0XHR0aGlzLl9wb3NpdGlvblRvb2x0aXAoKTtcblx0fVxuXG5cdHByaXZhdGUgX3Bvc2l0aW9uVG9vbHRpcCgpOiB2b2lkIHtcblx0XHRpZiAoIXRoaXMuX3Rvb2x0aXBSZWYpIHJldHVybjtcblxuXHRcdGNvbnN0IGhvc3RSZWN0ID0gdGhpcy5fZWwubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcblx0XHRjb25zdCB0b29sdGlwRWwgPSB0aGlzLl90b29sdGlwUmVmLmxvY2F0aW9uLm5hdGl2ZUVsZW1lbnQgYXMgSFRNTEVsZW1lbnQ7XG5cdFx0Y29uc3QgdG9vbHRpcFJlY3QgPSB0b29sdGlwRWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG5cdFx0Y29uc3Qgb2Zmc2V0ID0gNDtcblxuXHRcdGxldCB4ID0gMDtcblx0XHRsZXQgeSA9IDA7XG5cblx0XHRzd2l0Y2ggKHRoaXMuaXVpVG9vbHRpcFBsYWNlbWVudCkge1xuXHRcdFx0Y2FzZSAnYm90dG9tJzpcblx0XHRcdFx0eSA9IGhvc3RSZWN0LmJvdHRvbSArIG9mZnNldDtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRjYXNlICd0b3AnOlxuXHRcdFx0XHR5ID0gaG9zdFJlY3QudG9wIC0gb2Zmc2V0IC0gdG9vbHRpcFJlY3QuaGVpZ2h0O1xuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgJ3JpZ2h0Jzpcblx0XHRcdFx0eCA9IGhvc3RSZWN0LnJpZ2h0ICsgb2Zmc2V0O1xuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgJ2xlZnQnOlxuXHRcdFx0XHR4ID0gaG9zdFJlY3QubGVmdCAtIG9mZnNldCAtIHRvb2x0aXBSZWN0LndpZHRoO1xuXHRcdFx0XHRicmVhaztcblx0XHR9XG5cblx0XHRjb25zdCBpc0hvcml6b250YWwgPSB0aGlzLml1aVRvb2x0aXBQbGFjZW1lbnQgPT09ICd0b3AnIHx8IHRoaXMuaXVpVG9vbHRpcFBsYWNlbWVudCA9PT0gJ2JvdHRvbSc7XG5cblx0XHRpZiAoaXNIb3Jpem9udGFsKSB7XG5cdFx0XHRzd2l0Y2ggKHRoaXMuaXVpVG9vbHRpcEFsaWdubWVudCkge1xuXHRcdFx0XHRjYXNlICdzdGFydCc6XG5cdFx0XHRcdFx0eCA9IGhvc3RSZWN0LmxlZnQ7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdGNhc2UgJ21pZGRsZSc6XG5cdFx0XHRcdFx0eCA9IGhvc3RSZWN0LmxlZnQgKyBob3N0UmVjdC53aWR0aCAvIDIgLSB0b29sdGlwUmVjdC53aWR0aCAvIDI7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdGNhc2UgJ2VuZCc6XG5cdFx0XHRcdFx0eCA9IGhvc3RSZWN0LnJpZ2h0IC0gdG9vbHRpcFJlY3Qud2lkdGg7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIHtcblx0XHRcdHN3aXRjaCAodGhpcy5pdWlUb29sdGlwQWxpZ25tZW50KSB7XG5cdFx0XHRcdGNhc2UgJ3N0YXJ0Jzpcblx0XHRcdFx0XHR5ID0gaG9zdFJlY3QudG9wO1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRjYXNlICdtaWRkbGUnOlxuXHRcdFx0XHRcdHkgPSBob3N0UmVjdC50b3AgKyBob3N0UmVjdC5oZWlnaHQgLyAyIC0gdG9vbHRpcFJlY3QuaGVpZ2h0IC8gMjtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0Y2FzZSAnZW5kJzpcblx0XHRcdFx0XHR5ID0gaG9zdFJlY3QuYm90dG9tIC0gdG9vbHRpcFJlY3QuaGVpZ2h0O1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHRvb2x0aXBFbC5zdHlsZS5sZWZ0ID0gYCR7eH1weGA7XG5cdFx0dG9vbHRpcEVsLnN0eWxlLnRvcCA9IGAke3l9cHhgO1xuXHR9XG5cblx0cHJpdmF0ZSBfZGVzdHJveVRvb2x0aXAoKTogdm9pZCB7XG5cdFx0aWYgKCF0aGlzLl90b29sdGlwUmVmKSByZXR1cm47XG5cblx0XHR0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnJlbW92ZUF0dHJpYnV0ZSgnYXJpYS1kZXNjcmliZWRieScpO1xuXHRcdHRoaXMuX2FwcFJlZi5kZXRhY2hWaWV3KHRoaXMuX3Rvb2x0aXBSZWYuaG9zdFZpZXcpO1xuXHRcdHRoaXMuX3Rvb2x0aXBSZWYubG9jYXRpb24ubmF0aXZlRWxlbWVudC5yZW1vdmUoKTtcblx0XHR0aGlzLl90b29sdGlwUmVmLmRlc3Ryb3koKTtcblx0XHR0aGlzLl90b29sdGlwUmVmID0gbnVsbDtcblx0fVxuXG5cdHByaXZhdGUgX2NsZWFyU2hvd1RpbWVvdXQoKTogdm9pZCB7XG5cdFx0aWYgKHRoaXMuX3Nob3dUaW1lb3V0ICE9PSBudWxsKSB7XG5cdFx0XHRjbGVhclRpbWVvdXQodGhpcy5fc2hvd1RpbWVvdXQpO1xuXHRcdFx0dGhpcy5fc2hvd1RpbWVvdXQgPSBudWxsO1xuXHRcdH1cblx0fVxuXG5cdHByaXZhdGUgX2NsZWFySGlkZVRpbWVvdXQoKTogdm9pZCB7XG5cdFx0aWYgKHRoaXMuX2hpZGVUaW1lb3V0ICE9PSBudWxsKSB7XG5cdFx0XHRjbGVhclRpbWVvdXQodGhpcy5faGlkZVRpbWVvdXQpO1xuXHRcdFx0dGhpcy5faGlkZVRpbWVvdXQgPSBudWxsO1xuXHRcdH1cblx0fVxuXG5cdG5nT25EZXN0cm95KCk6IHZvaWQge1xuXHRcdHRoaXMuX2NsZWFyU2hvd1RpbWVvdXQoKTtcblx0XHR0aGlzLl9jbGVhckhpZGVUaW1lb3V0KCk7XG5cdFx0dGhpcy5fZGVzdHJveVRvb2x0aXAoKTtcblx0fVxufVxuXG5sZXQgX25leHRJZCA9IDA7XG4iXX0=