import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IuiTooltipComponent } from './iui-tooltip.component';
import { InformationIconComponent } from '@itero/ui-components-angular/icons';
import * as i0 from "@angular/core";
export class IuiTooltipIconTriggerComponent {
    constructor() {
        this.text = '';
        this.placement = 'bottom';
        this.alignment = 'middle';
        this._visible = false;
    }
    _show() {
        this._visible = true;
    }
    _hide() {
        this._visible = false;
    }
    get _tooltipStyle() {
        return _getTooltipStyle(this.placement, this.alignment);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTooltipIconTriggerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.12", type: IuiTooltipIconTriggerComponent, isStandalone: true, selector: "iui-tooltip-icon-trigger", inputs: { text: "text", placement: "placement", alignment: "alignment" }, ngImport: i0, template: "<span class=\"iui-tooltip-icon-trigger__icon\"\n      tabindex=\"0\"\n      (mouseenter)=\"_show()\"\n      (mouseleave)=\"_hide()\"\n      (focusin)=\"_show()\"\n      (focusout)=\"_hide()\"\n      (keydown.escape)=\"_hide()\">\n  <iui-information-icon style=\"width:16px;height:16px;\"></iui-information-icon>\n</span>\n@if (_visible && text) {\n  <iui-tooltip\n    [text]=\"text\"\n    [placement]=\"placement\"\n    [alignment]=\"alignment\"\n    [showCaret]=\"true\"\n    [style]=\"_tooltipStyle\">\n  </iui-tooltip>\n}\n", styles: [":host{display:inline-flex;position:relative}.iui-tooltip-icon-trigger__icon{display:inline-flex;align-items:center;justify-content:center;cursor:pointer;width:16px;height:16px;color:var(--iui-text-secondary)}.iui-tooltip-icon-trigger__icon:focus-visible{outline:2px solid var(--iui-border-focus);outline-offset:2px;border-radius:2px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: IuiTooltipComponent, selector: "iui-tooltip", inputs: ["placement", "alignment", "showCaret", "text"] }, { kind: "component", type: InformationIconComponent, selector: "iui-information-icon" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiTooltipIconTriggerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-tooltip-icon-trigger', standalone: true, imports: [CommonModule, IuiTooltipComponent, InformationIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<span class=\"iui-tooltip-icon-trigger__icon\"\n      tabindex=\"0\"\n      (mouseenter)=\"_show()\"\n      (mouseleave)=\"_hide()\"\n      (focusin)=\"_show()\"\n      (focusout)=\"_hide()\"\n      (keydown.escape)=\"_hide()\">\n  <iui-information-icon style=\"width:16px;height:16px;\"></iui-information-icon>\n</span>\n@if (_visible && text) {\n  <iui-tooltip\n    [text]=\"text\"\n    [placement]=\"placement\"\n    [alignment]=\"alignment\"\n    [showCaret]=\"true\"\n    [style]=\"_tooltipStyle\">\n  </iui-tooltip>\n}\n", styles: [":host{display:inline-flex;position:relative}.iui-tooltip-icon-trigger__icon{display:inline-flex;align-items:center;justify-content:center;cursor:pointer;width:16px;height:16px;color:var(--iui-text-secondary)}.iui-tooltip-icon-trigger__icon:focus-visible{outline:2px solid var(--iui-border-focus);outline-offset:2px;border-radius:2px}\n"] }]
        }], propDecorators: { text: [{
                type: Input
            }], placement: [{
                type: Input
            }], alignment: [{
                type: Input
            }] } });
export function _getTooltipStyle(placement, alignment) {
    const offset = 'var(--iui-tooltip-offset)';
    const style = { position: 'absolute' };
    const isHorizontal = placement === 'top' || placement === 'bottom';
    if (placement === 'bottom')
        style['top'] = `calc(100% + ${offset})`;
    else if (placement === 'top')
        style['bottom'] = `calc(100% + ${offset})`;
    else if (placement === 'right')
        style['left'] = `calc(100% + ${offset})`;
    else if (placement === 'left')
        style['right'] = `calc(100% + ${offset})`;
    if (isHorizontal) {
        if (alignment === 'start')
            style['left'] = '0';
        else if (alignment === 'middle') {
            style['left'] = '50%';
            style['transform'] = 'translateX(-50%)';
        }
        else if (alignment === 'end')
            style['right'] = '0';
    }
    else {
        if (alignment === 'start')
            style['top'] = '0';
        else if (alignment === 'middle') {
            style['top'] = '50%';
            style['transform'] = 'translateY(-50%)';
        }
        else if (alignment === 'end')
            style['bottom'] = '0';
    }
    return style;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLXRvb2x0aXAtaWNvbi10cmlnZ2VyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL2xpYnMvdWktY29tcG9uZW50cy1hbmd1bGFyLXB1Ymxpc2hhYmxlL3Rvb2x0aXAvc3JjL2l1aS10b29sdGlwLWljb24tdHJpZ2dlci5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS90b29sdGlwL3NyYy9pdWktdG9vbHRpcC1pY29uLXRyaWdnZXIuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLHVCQUF1QixFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDMUUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBRSxtQkFBbUIsRUFBNEMsTUFBTSx5QkFBeUIsQ0FBQztBQUN4RyxPQUFPLEVBQUUsd0JBQXdCLEVBQUUsTUFBTSxvQ0FBb0MsQ0FBQzs7QUFVOUUsTUFBTSxPQUFPLDhCQUE4QjtJQVIzQztRQVNVLFNBQUksR0FBRyxFQUFFLENBQUM7UUFDVixjQUFTLEdBQXdCLFFBQVEsQ0FBQztRQUMxQyxjQUFTLEdBQXdCLFFBQVEsQ0FBQztRQUV6QyxhQUFRLEdBQUcsS0FBSyxDQUFDO0tBYTNCO0lBWFUsS0FBSztRQUNkLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO0lBQ3RCLENBQUM7SUFFUyxLQUFLO1FBQ2QsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDdkIsQ0FBQztJQUVELElBQWMsYUFBYTtRQUMxQixPQUFPLGdCQUFnQixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3pELENBQUM7K0dBakJXLDhCQUE4QjttR0FBOUIsOEJBQThCLDhKQ2IzQyxnaEJBa0JBLHdZRFZXLFlBQVksK0JBQUUsbUJBQW1CLGlIQUFFLHdCQUF3Qjs7NEZBS3pELDhCQUE4QjtrQkFSMUMsU0FBUzsrQkFDQywwQkFBMEIsY0FDeEIsSUFBSSxXQUNQLENBQUMsWUFBWSxFQUFFLG1CQUFtQixFQUFFLHdCQUF3QixDQUFDLG1CQUdyRCx1QkFBdUIsQ0FBQyxNQUFNOzhCQUd0QyxJQUFJO3NCQUFaLEtBQUs7Z0JBQ0csU0FBUztzQkFBakIsS0FBSztnQkFDRyxTQUFTO3NCQUFqQixLQUFLOztBQWlCUCxNQUFNLFVBQVUsZ0JBQWdCLENBQUMsU0FBOEIsRUFBRSxTQUE4QjtJQUM5RixNQUFNLE1BQU0sR0FBRywyQkFBMkIsQ0FBQztJQUMzQyxNQUFNLEtBQUssR0FBMkIsRUFBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLENBQUM7SUFDL0QsTUFBTSxZQUFZLEdBQUcsU0FBUyxLQUFLLEtBQUssSUFBSSxTQUFTLEtBQUssUUFBUSxDQUFDO0lBRW5FLElBQUksU0FBUyxLQUFLLFFBQVE7UUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsZUFBZSxNQUFNLEdBQUcsQ0FBQztTQUMvRCxJQUFJLFNBQVMsS0FBSyxLQUFLO1FBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxHQUFHLGVBQWUsTUFBTSxHQUFHLENBQUM7U0FDcEUsSUFBSSxTQUFTLEtBQUssT0FBTztRQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxlQUFlLE1BQU0sR0FBRyxDQUFDO1NBQ3BFLElBQUksU0FBUyxLQUFLLE1BQU07UUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsZUFBZSxNQUFNLEdBQUcsQ0FBQztJQUV6RSxJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ2xCLElBQUksU0FBUyxLQUFLLE9BQU87WUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDO2FBQzFDLElBQUksU0FBUyxLQUFLLFFBQVEsRUFBRSxDQUFDO1lBQ2pDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxLQUFLLENBQUM7WUFDdEIsS0FBSyxDQUFDLFdBQVcsQ0FBQyxHQUFHLGtCQUFrQixDQUFDO1FBQ3pDLENBQUM7YUFBTSxJQUFJLFNBQVMsS0FBSyxLQUFLO1lBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUN0RCxDQUFDO1NBQU0sQ0FBQztRQUNQLElBQUksU0FBUyxLQUFLLE9BQU87WUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxDQUFDO2FBQ3pDLElBQUksU0FBUyxLQUFLLFFBQVEsRUFBRSxDQUFDO1lBQ2pDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUM7WUFDckIsS0FBSyxDQUFDLFdBQVcsQ0FBQyxHQUFHLGtCQUFrQixDQUFDO1FBQ3pDLENBQUM7YUFBTSxJQUFJLFNBQVMsS0FBSyxLQUFLO1lBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUN2RCxDQUFDO0lBRUQsT0FBTyxLQUFLLENBQUM7QUFDZCxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksIENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBJdWlUb29sdGlwQ29tcG9uZW50LCBJdWlUb29sdGlwQWxpZ25tZW50LCBJdWlUb29sdGlwUGxhY2VtZW50IH0gZnJvbSAnLi9pdWktdG9vbHRpcC5jb21wb25lbnQnO1xuaW1wb3J0IHsgSW5mb3JtYXRpb25JY29uQ29tcG9uZW50IH0gZnJvbSAnQGl0ZXJvL3VpLWNvbXBvbmVudHMtYW5ndWxhci9pY29ucyc7XG5cbkBDb21wb25lbnQoe1xuXHRzZWxlY3RvcjogJ2l1aS10b29sdGlwLWljb24tdHJpZ2dlcicsXG5cdHN0YW5kYWxvbmU6IHRydWUsXG5cdGltcG9ydHM6IFtDb21tb25Nb2R1bGUsIEl1aVRvb2x0aXBDb21wb25lbnQsIEluZm9ybWF0aW9uSWNvbkNvbXBvbmVudF0sXG5cdHRlbXBsYXRlVXJsOiAnLi9pdWktdG9vbHRpcC1pY29uLXRyaWdnZXIuY29tcG9uZW50Lmh0bWwnLFxuXHRzdHlsZVVybHM6IFsnLi9pdWktdG9vbHRpcC1pY29uLXRyaWdnZXIuY29tcG9uZW50LnNjc3MnXSxcblx0Y2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2hcbn0pXG5leHBvcnQgY2xhc3MgSXVpVG9vbHRpcEljb25UcmlnZ2VyQ29tcG9uZW50IHtcblx0QElucHV0KCkgdGV4dCA9ICcnO1xuXHRASW5wdXQoKSBwbGFjZW1lbnQ6IEl1aVRvb2x0aXBQbGFjZW1lbnQgPSAnYm90dG9tJztcblx0QElucHV0KCkgYWxpZ25tZW50OiBJdWlUb29sdGlwQWxpZ25tZW50ID0gJ21pZGRsZSc7XG5cblx0cHJvdGVjdGVkIF92aXNpYmxlID0gZmFsc2U7XG5cblx0cHJvdGVjdGVkIF9zaG93KCk6IHZvaWQge1xuXHRcdHRoaXMuX3Zpc2libGUgPSB0cnVlO1xuXHR9XG5cblx0cHJvdGVjdGVkIF9oaWRlKCk6IHZvaWQge1xuXHRcdHRoaXMuX3Zpc2libGUgPSBmYWxzZTtcblx0fVxuXG5cdHByb3RlY3RlZCBnZXQgX3Rvb2x0aXBTdHlsZSgpOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+IHtcblx0XHRyZXR1cm4gX2dldFRvb2x0aXBTdHlsZSh0aGlzLnBsYWNlbWVudCwgdGhpcy5hbGlnbm1lbnQpO1xuXHR9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfZ2V0VG9vbHRpcFN0eWxlKHBsYWNlbWVudDogSXVpVG9vbHRpcFBsYWNlbWVudCwgYWxpZ25tZW50OiBJdWlUb29sdGlwQWxpZ25tZW50KTogUmVjb3JkPHN0cmluZywgc3RyaW5nPiB7XG5cdGNvbnN0IG9mZnNldCA9ICd2YXIoLS1pdWktdG9vbHRpcC1vZmZzZXQpJztcblx0Y29uc3Qgc3R5bGU6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7IHBvc2l0aW9uOiAnYWJzb2x1dGUnIH07XG5cdGNvbnN0IGlzSG9yaXpvbnRhbCA9IHBsYWNlbWVudCA9PT0gJ3RvcCcgfHwgcGxhY2VtZW50ID09PSAnYm90dG9tJztcblxuXHRpZiAocGxhY2VtZW50ID09PSAnYm90dG9tJykgc3R5bGVbJ3RvcCddID0gYGNhbGMoMTAwJSArICR7b2Zmc2V0fSlgO1xuXHRlbHNlIGlmIChwbGFjZW1lbnQgPT09ICd0b3AnKSBzdHlsZVsnYm90dG9tJ10gPSBgY2FsYygxMDAlICsgJHtvZmZzZXR9KWA7XG5cdGVsc2UgaWYgKHBsYWNlbWVudCA9PT0gJ3JpZ2h0Jykgc3R5bGVbJ2xlZnQnXSA9IGBjYWxjKDEwMCUgKyAke29mZnNldH0pYDtcblx0ZWxzZSBpZiAocGxhY2VtZW50ID09PSAnbGVmdCcpIHN0eWxlWydyaWdodCddID0gYGNhbGMoMTAwJSArICR7b2Zmc2V0fSlgO1xuXG5cdGlmIChpc0hvcml6b250YWwpIHtcblx0XHRpZiAoYWxpZ25tZW50ID09PSAnc3RhcnQnKSBzdHlsZVsnbGVmdCddID0gJzAnO1xuXHRcdGVsc2UgaWYgKGFsaWdubWVudCA9PT0gJ21pZGRsZScpIHtcblx0XHRcdHN0eWxlWydsZWZ0J10gPSAnNTAlJztcblx0XHRcdHN0eWxlWyd0cmFuc2Zvcm0nXSA9ICd0cmFuc2xhdGVYKC01MCUpJztcblx0XHR9IGVsc2UgaWYgKGFsaWdubWVudCA9PT0gJ2VuZCcpIHN0eWxlWydyaWdodCddID0gJzAnO1xuXHR9IGVsc2Uge1xuXHRcdGlmIChhbGlnbm1lbnQgPT09ICdzdGFydCcpIHN0eWxlWyd0b3AnXSA9ICcwJztcblx0XHRlbHNlIGlmIChhbGlnbm1lbnQgPT09ICdtaWRkbGUnKSB7XG5cdFx0XHRzdHlsZVsndG9wJ10gPSAnNTAlJztcblx0XHRcdHN0eWxlWyd0cmFuc2Zvcm0nXSA9ICd0cmFuc2xhdGVZKC01MCUpJztcblx0XHR9IGVsc2UgaWYgKGFsaWdubWVudCA9PT0gJ2VuZCcpIHN0eWxlWydib3R0b20nXSA9ICcwJztcblx0fVxuXG5cdHJldHVybiBzdHlsZTtcbn1cbiIsIjxzcGFuIGNsYXNzPVwiaXVpLXRvb2x0aXAtaWNvbi10cmlnZ2VyX19pY29uXCJcbiAgICAgIHRhYmluZGV4PVwiMFwiXG4gICAgICAobW91c2VlbnRlcik9XCJfc2hvdygpXCJcbiAgICAgIChtb3VzZWxlYXZlKT1cIl9oaWRlKClcIlxuICAgICAgKGZvY3VzaW4pPVwiX3Nob3coKVwiXG4gICAgICAoZm9jdXNvdXQpPVwiX2hpZGUoKVwiXG4gICAgICAoa2V5ZG93bi5lc2NhcGUpPVwiX2hpZGUoKVwiPlxuICA8aXVpLWluZm9ybWF0aW9uLWljb24gc3R5bGU9XCJ3aWR0aDoxNnB4O2hlaWdodDoxNnB4O1wiPjwvaXVpLWluZm9ybWF0aW9uLWljb24+XG48L3NwYW4+XG5AaWYgKF92aXNpYmxlICYmIHRleHQpIHtcbiAgPGl1aS10b29sdGlwXG4gICAgW3RleHRdPVwidGV4dFwiXG4gICAgW3BsYWNlbWVudF09XCJwbGFjZW1lbnRcIlxuICAgIFthbGlnbm1lbnRdPVwiYWxpZ25tZW50XCJcbiAgICBbc2hvd0NhcmV0XT1cInRydWVcIlxuICAgIFtzdHlsZV09XCJfdG9vbHRpcFN0eWxlXCI+XG4gIDwvaXVpLXRvb2x0aXA+XG59XG4iXX0=