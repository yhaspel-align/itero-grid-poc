import { ChangeDetectionStrategy, ChangeDetectorRef, Component, forwardRef, Input, Self, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR, Validators } from '@angular/forms';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import { SubtractEmptyIconComponent, AddEmptyIconComponent } from '@itero/ui-components-angular/icons';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
import * as i2 from "@angular/common";
let nextUniqueId = 0;
export class IuiNumberInputComponent {
    set id(value) {
        this._id = value;
    }
    get id() {
        return this._id;
    }
    get required() {
        return this._required ?? this.ngControlDirective.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get _focused() {
        return this.__focused;
    }
    get _inputId() {
        return this.id + '-input';
    }
    get _isAtMin() {
        return this.__value != null && this.__value <= this.min;
    }
    get _isAtMax() {
        return this.__value != null && this.__value >= this.max;
    }
    get _ariaValueMin() {
        return isFinite(this.min) ? this.min : null;
    }
    get _ariaValueMax() {
        return isFinite(this.max) ? this.max : null;
    }
    get _displayValue() {
        if (this._rawInput != null) {
            return this._rawInput;
        }
        return this.__value != null ? String(this.__value) : '';
    }
    get _value() {
        return this.__value;
    }
    constructor(_changeDetectorRef, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._changeDetectorRef = _changeDetectorRef;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        this._id = `iui-number-input-${nextUniqueId++}`;
        this.label = '';
        this.helperText = '';
        this.name = '';
        this.size = 'l';
        this.layerSet = 'set-01';
        this.min = -Infinity;
        this.max = Infinity;
        this.step = 1;
        this.showControls = true;
        this.showLabel = true;
        this.showHelper = true;
        // showExplainer is deferred — no-op until tooltip integration is available
        this.showExplainer = false;
        this.skeleton = false;
        this.__value = null;
        this.__focused = false;
        this._rawInput = null;
        this._onChange = () => { };
        this._onTouched = () => { };
    }
    _increment() {
        const current = this.__value ?? 0;
        const newValue = Math.min(current + this.step, this.max);
        this._setValue(newValue);
    }
    _decrement() {
        const current = this.__value ?? 0;
        const newValue = Math.max(current - this.step, this.min);
        this._setValue(newValue);
    }
    _onKeydown(event) {
        if (event.key === 'ArrowUp') {
            event.preventDefault();
            this._increment();
        }
        else if (event.key === 'ArrowDown') {
            event.preventDefault();
            this._decrement();
        }
    }
    _onInputChange(event) {
        const raw = event.target.value;
        this._rawInput = raw;
        if (raw === '') {
            this._assignValue(null);
            return;
        }
        if (raw === '-') {
            return;
        }
        const parsed = Number(raw);
        if (!isNaN(parsed)) {
            this._setValue(this._clamp(parsed));
        }
    }
    _onFocus() {
        if (!this.disabled) {
            this.__focused = true;
            this._rawInput = this._displayValue;
        }
    }
    _onBlur() {
        this.__focused = false;
        this._rawInput = null;
        if (this.__value == null) {
            const resolved = isFinite(this.min) ? this.min : 0;
            this._setValue(resolved);
        }
        else {
            this._setValue(this._clamp(this.__value));
        }
        if (!this.disabled) {
            this._onTouched();
            this._changeDetectorRef.markForCheck();
        }
    }
    writeValue(value) {
        this._assignValue(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._changeDetectorRef.markForCheck();
    }
    _setValue(value) {
        const hasAssigned = this._assignValue(value);
        if (hasAssigned) {
            this._onChange(value);
        }
    }
    _assignValue(newValue) {
        if (newValue !== this.__value) {
            this.__value = newValue;
            this._changeDetectorRef.markForCheck();
            return true;
        }
        return false;
    }
    _clamp(value) {
        if (isFinite(this.min) && value < this.min) {
            return this.min;
        }
        if (isFinite(this.max) && value > this.max) {
            return this.max;
        }
        return value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiNumberInputComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.NgControlDirective, self: true }, { token: i1.IuiErrorStateMatcherDirective, self: true }, { token: i1.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IuiNumberInputComponent, isStandalone: true, selector: "iui-number-input", inputs: { id: "id", label: "label", helperText: "helperText", name: "name", size: "size", layerSet: "layerSet", min: "min", max: "max", step: "step", showControls: "showControls", showLabel: "showLabel", showHelper: "showHelper", showExplainer: "showExplainer", skeleton: "skeleton", required: "required" }, host: { properties: { "class.iui-number-input_size_l": "size === \"l\"", "class.iui-number-input_size_m": "size === \"m\"", "class.iui-number-input_size_s": "size === \"s\"", "class.iui-number-input_layer-set-02": "layerSet === \"set-02\"", "class.iui-number-input_focused": "_focused", "class.iui-number-input_disabled": "disabled", "class.iui-number-input_invalid": "_errorState", "class.iui-number-input_skeleton": "skeleton", "attr.id": "id" }, classAttribute: "iui-number-input" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiNumberInputComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true }], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\r\n\t<div class=\"iui-number-input__skeleton-label\" *ngIf=\"showLabel\"></div>\r\n\t<div class=\"iui-number-input__skeleton-field\"></div>\r\n\t<div class=\"iui-number-input__skeleton-helper\"></div>\r\n</ng-container>\r\n\r\n<ng-template #normalTemplate>\r\n\t<div class=\"iui-number-input__label-row\" *ngIf=\"showLabel && label\">\r\n\t\t<label class=\"iui-number-input__label\" [attr.for]=\"_inputId\">\r\n\t\t\t{{ label }}\r\n\t\t</label>\r\n\t</div>\r\n\r\n\t<div class=\"iui-number-input__field\">\r\n\t\t<input\r\n\t\t\t#inputElement\r\n\t\t\ttype=\"text\"\r\n\t\t\tinputmode=\"numeric\"\r\n\t\t\tclass=\"iui-number-input__input\"\r\n\t\t\trole=\"spinbutton\"\r\n\t\t\t[attr.id]=\"_inputId\"\r\n\t\t\t[attr.name]=\"name || null\"\r\n\t\t\t[attr.aria-label]=\"label || null\"\r\n\t\t\t[attr.aria-valuemin]=\"_ariaValueMin\"\r\n\t\t\t[attr.aria-valuemax]=\"_ariaValueMax\"\r\n\t\t\t[attr.aria-valuenow]=\"_value\"\r\n\t\t\t[disabled]=\"disabled\"\r\n\t\t\t[value]=\"_displayValue\"\r\n\t\t\t(input)=\"_onInputChange($event)\"\r\n\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t(keydown)=\"_onKeydown($event)\"\r\n\t\t/>\r\n\r\n\t\t<div class=\"iui-number-input__controls\" *ngIf=\"showControls\">\r\n\t\t\t<button\r\n\t\t\t\ttype=\"button\"\r\n\t\t\t\tclass=\"iui-number-input__control-btn\"\r\n\t\t\t\t[disabled]=\"disabled || _isAtMin\"\r\n\t\t\t\t(click)=\"_decrement()\"\r\n\t\t\t\ttabindex=\"-1\"\r\n\t\t\t\taria-label=\"Decrease value\"\r\n\t\t\t>\r\n\t\t\t\t<iui-subtract-empty-icon class=\"iui-icon iui-icon_size_s\"></iui-subtract-empty-icon>\r\n\t\t\t</button>\r\n\r\n\t\t\t<span class=\"iui-number-input__divider\" aria-hidden=\"true\"></span>\r\n\r\n\t\t\t<button\r\n\t\t\t\ttype=\"button\"\r\n\t\t\t\tclass=\"iui-number-input__control-btn\"\r\n\t\t\t\t[disabled]=\"disabled || _isAtMax\"\r\n\t\t\t\t(click)=\"_increment()\"\r\n\t\t\t\ttabindex=\"-1\"\r\n\t\t\t\taria-label=\"Increase value\"\r\n\t\t\t>\r\n\t\t\t\t<iui-add-empty-icon class=\"iui-icon iui-icon_size_s\"></iui-add-empty-icon>\r\n\t\t\t</button>\r\n\t\t</div>\r\n\t</div>\r\n\r\n\t<div class=\"iui-number-input__helper-row\" *ngIf=\"showHelper\">\r\n\t\t<span *ngIf=\"_errorState\" class=\"iui-number-input__error\">\r\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t</span>\r\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-number-input__helper\">\r\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t</span>\r\n\t</div>\r\n</ng-template>\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;width:100%}.iui-number-input__label-row{padding-bottom:var(--spacing-02, 8px)}.iui-number-input__label{font:var(--iui-tp-label-01-font);color:var(--iui-number-input-label-color);display:block}:host.iui-number-input_disabled .iui-number-input__label{color:var(--iui-number-input-disabled-color)}.iui-number-input__field{display:flex;align-items:center;gap:var(--spacing-02, 8px);overflow:hidden;background:var(--iui-number-input-bg);border:1px solid transparent;border-radius:var(--medium, 8px);transition:border-color .1s ease-out}:host.iui-number-input_size_l .iui-number-input__field{height:44px;padding:var(--spacing-02, 8px) var(--spacing-02, 8px) var(--spacing-02, 8px) var(--spacing-04, 16px)}:host.iui-number-input_size_m .iui-number-input__field{height:36px;padding:var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-03, 12px)}:host.iui-number-input_size_s .iui-number-input__field{height:28px;border-radius:var(--small, 4px);padding:var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-02, 8px)}:host.iui-number-input_layer-set-02 .iui-number-input__field{background:var(--iui-number-input-bg-layer-02)}:host.iui-number-input_focused .iui-number-input__field{border-color:var(--iui-number-input-focus-border)}:host.iui-number-input_invalid .iui-number-input__field{border-color:var(--iui-number-input-error-border)}.iui-number-input__input{flex:1 0 0;min-width:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border:none;outline:none;background:transparent;font:var(--iui-tp-body-01-font);color:var(--iui-number-input-color);padding:0}.iui-number-input__input:disabled{color:var(--iui-number-input-disabled-color)}.iui-number-input__controls{display:flex;align-items:center;gap:var(--spacing-01, 4px);flex-shrink:0}.iui-number-input__control-btn{display:flex;align-items:center;justify-content:center;padding:var(--spacing-01, 4px);background:transparent;border:none;border-radius:var(--small, 4px);cursor:pointer;color:var(--iui-number-input-color)}.iui-number-input__control-btn:hover:not(:disabled){background:var(--iui-background-interactive-hover)}.iui-number-input__control-btn:active:not(:disabled){background:var(--iui-background-interactive-active)}.iui-number-input__control-btn:focus-visible{outline:1px solid var(--iui-number-input-focus-border);outline-offset:-1px}.iui-number-input__control-btn:disabled{color:var(--iui-number-input-disabled-color);cursor:default}.iui-number-input__divider{display:block;width:1px;height:16px;background:var(--iui-number-input-divider-color);flex-shrink:0}.iui-number-input__helper-row{padding-top:var(--spacing-02, 8px)}.iui-number-input__helper{font:var(--iui-tp-label-01-font);color:var(--iui-number-input-helper-color)}:host.iui-number-input_disabled .iui-number-input__helper{color:var(--iui-number-input-disabled-color)}.iui-number-input__error{font:var(--iui-tp-label-01-font);color:var(--iui-number-input-error-color)}.iui-number-input__skeleton-label{width:40px;height:8px;background:var(--iui-number-input-skeleton-bg);border-radius:2px;margin-bottom:var(--spacing-02, 8px)}.iui-number-input__skeleton-field{width:100%;background:var(--iui-number-input-skeleton-bg)}:host.iui-number-input_size_l .iui-number-input__skeleton-field{height:44px;border-radius:var(--medium, 8px)}:host.iui-number-input_size_m .iui-number-input__skeleton-field{height:36px;border-radius:var(--medium, 8px)}:host.iui-number-input_size_s .iui-number-input__skeleton-field{height:28px;border-radius:var(--small, 4px)}:host:not(.iui-number-input_size_m):not(.iui-number-input_size_s) .iui-number-input__skeleton-field{height:44px;border-radius:var(--medium, 8px)}.iui-number-input__skeleton-helper{width:40px;height:8px;background:var(--iui-number-input-skeleton-bg);border-radius:2px;margin-top:var(--spacing-02, 8px)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SubtractEmptyIconComponent, selector: "iui-subtract-empty-icon" }, { kind: "component", type: AddEmptyIconComponent, selector: "iui-add-empty-icon" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiNumberInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-number-input', standalone: true, imports: [CommonModule, SubtractEmptyIconComponent, AddEmptyIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiNumberInputComponent),
                            multi: true
                        }
                    ], host: {
                        class: 'iui-number-input',
                        '[class.iui-number-input_size_l]': 'size === "l"',
                        '[class.iui-number-input_size_m]': 'size === "m"',
                        '[class.iui-number-input_size_s]': 'size === "s"',
                        '[class.iui-number-input_layer-set-02]': 'layerSet === "set-02"',
                        '[class.iui-number-input_focused]': '_focused',
                        '[class.iui-number-input_disabled]': 'disabled',
                        '[class.iui-number-input_invalid]': '_errorState',
                        '[class.iui-number-input_skeleton]': 'skeleton',
                        '[attr.id]': 'id'
                    }, template: "<ng-container *ngIf=\"skeleton; else normalTemplate\">\r\n\t<div class=\"iui-number-input__skeleton-label\" *ngIf=\"showLabel\"></div>\r\n\t<div class=\"iui-number-input__skeleton-field\"></div>\r\n\t<div class=\"iui-number-input__skeleton-helper\"></div>\r\n</ng-container>\r\n\r\n<ng-template #normalTemplate>\r\n\t<div class=\"iui-number-input__label-row\" *ngIf=\"showLabel && label\">\r\n\t\t<label class=\"iui-number-input__label\" [attr.for]=\"_inputId\">\r\n\t\t\t{{ label }}\r\n\t\t</label>\r\n\t</div>\r\n\r\n\t<div class=\"iui-number-input__field\">\r\n\t\t<input\r\n\t\t\t#inputElement\r\n\t\t\ttype=\"text\"\r\n\t\t\tinputmode=\"numeric\"\r\n\t\t\tclass=\"iui-number-input__input\"\r\n\t\t\trole=\"spinbutton\"\r\n\t\t\t[attr.id]=\"_inputId\"\r\n\t\t\t[attr.name]=\"name || null\"\r\n\t\t\t[attr.aria-label]=\"label || null\"\r\n\t\t\t[attr.aria-valuemin]=\"_ariaValueMin\"\r\n\t\t\t[attr.aria-valuemax]=\"_ariaValueMax\"\r\n\t\t\t[attr.aria-valuenow]=\"_value\"\r\n\t\t\t[disabled]=\"disabled\"\r\n\t\t\t[value]=\"_displayValue\"\r\n\t\t\t(input)=\"_onInputChange($event)\"\r\n\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t(keydown)=\"_onKeydown($event)\"\r\n\t\t/>\r\n\r\n\t\t<div class=\"iui-number-input__controls\" *ngIf=\"showControls\">\r\n\t\t\t<button\r\n\t\t\t\ttype=\"button\"\r\n\t\t\t\tclass=\"iui-number-input__control-btn\"\r\n\t\t\t\t[disabled]=\"disabled || _isAtMin\"\r\n\t\t\t\t(click)=\"_decrement()\"\r\n\t\t\t\ttabindex=\"-1\"\r\n\t\t\t\taria-label=\"Decrease value\"\r\n\t\t\t>\r\n\t\t\t\t<iui-subtract-empty-icon class=\"iui-icon iui-icon_size_s\"></iui-subtract-empty-icon>\r\n\t\t\t</button>\r\n\r\n\t\t\t<span class=\"iui-number-input__divider\" aria-hidden=\"true\"></span>\r\n\r\n\t\t\t<button\r\n\t\t\t\ttype=\"button\"\r\n\t\t\t\tclass=\"iui-number-input__control-btn\"\r\n\t\t\t\t[disabled]=\"disabled || _isAtMax\"\r\n\t\t\t\t(click)=\"_increment()\"\r\n\t\t\t\ttabindex=\"-1\"\r\n\t\t\t\taria-label=\"Increase value\"\r\n\t\t\t>\r\n\t\t\t\t<iui-add-empty-icon class=\"iui-icon iui-icon_size_s\"></iui-add-empty-icon>\r\n\t\t\t</button>\r\n\t\t</div>\r\n\t</div>\r\n\r\n\t<div class=\"iui-number-input__helper-row\" *ngIf=\"showHelper\">\r\n\t\t<span *ngIf=\"_errorState\" class=\"iui-number-input__error\">\r\n\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t</span>\r\n\t\t<span *ngIf=\"!_errorState\" class=\"iui-number-input__helper\">\r\n\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t</span>\r\n\t</div>\r\n</ng-template>\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{display:flex;flex-direction:column;width:100%}.iui-number-input__label-row{padding-bottom:var(--spacing-02, 8px)}.iui-number-input__label{font:var(--iui-tp-label-01-font);color:var(--iui-number-input-label-color);display:block}:host.iui-number-input_disabled .iui-number-input__label{color:var(--iui-number-input-disabled-color)}.iui-number-input__field{display:flex;align-items:center;gap:var(--spacing-02, 8px);overflow:hidden;background:var(--iui-number-input-bg);border:1px solid transparent;border-radius:var(--medium, 8px);transition:border-color .1s ease-out}:host.iui-number-input_size_l .iui-number-input__field{height:44px;padding:var(--spacing-02, 8px) var(--spacing-02, 8px) var(--spacing-02, 8px) var(--spacing-04, 16px)}:host.iui-number-input_size_m .iui-number-input__field{height:36px;padding:var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-03, 12px)}:host.iui-number-input_size_s .iui-number-input__field{height:28px;border-radius:var(--small, 4px);padding:var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-01, 4px) var(--spacing-02, 8px)}:host.iui-number-input_layer-set-02 .iui-number-input__field{background:var(--iui-number-input-bg-layer-02)}:host.iui-number-input_focused .iui-number-input__field{border-color:var(--iui-number-input-focus-border)}:host.iui-number-input_invalid .iui-number-input__field{border-color:var(--iui-number-input-error-border)}.iui-number-input__input{flex:1 0 0;min-width:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border:none;outline:none;background:transparent;font:var(--iui-tp-body-01-font);color:var(--iui-number-input-color);padding:0}.iui-number-input__input:disabled{color:var(--iui-number-input-disabled-color)}.iui-number-input__controls{display:flex;align-items:center;gap:var(--spacing-01, 4px);flex-shrink:0}.iui-number-input__control-btn{display:flex;align-items:center;justify-content:center;padding:var(--spacing-01, 4px);background:transparent;border:none;border-radius:var(--small, 4px);cursor:pointer;color:var(--iui-number-input-color)}.iui-number-input__control-btn:hover:not(:disabled){background:var(--iui-background-interactive-hover)}.iui-number-input__control-btn:active:not(:disabled){background:var(--iui-background-interactive-active)}.iui-number-input__control-btn:focus-visible{outline:1px solid var(--iui-number-input-focus-border);outline-offset:-1px}.iui-number-input__control-btn:disabled{color:var(--iui-number-input-disabled-color);cursor:default}.iui-number-input__divider{display:block;width:1px;height:16px;background:var(--iui-number-input-divider-color);flex-shrink:0}.iui-number-input__helper-row{padding-top:var(--spacing-02, 8px)}.iui-number-input__helper{font:var(--iui-tp-label-01-font);color:var(--iui-number-input-helper-color)}:host.iui-number-input_disabled .iui-number-input__helper{color:var(--iui-number-input-disabled-color)}.iui-number-input__error{font:var(--iui-tp-label-01-font);color:var(--iui-number-input-error-color)}.iui-number-input__skeleton-label{width:40px;height:8px;background:var(--iui-number-input-skeleton-bg);border-radius:2px;margin-bottom:var(--spacing-02, 8px)}.iui-number-input__skeleton-field{width:100%;background:var(--iui-number-input-skeleton-bg)}:host.iui-number-input_size_l .iui-number-input__skeleton-field{height:44px;border-radius:var(--medium, 8px)}:host.iui-number-input_size_m .iui-number-input__skeleton-field{height:36px;border-radius:var(--medium, 8px)}:host.iui-number-input_size_s .iui-number-input__skeleton-field{height:28px;border-radius:var(--small, 4px)}:host:not(.iui-number-input_size_m):not(.iui-number-input_size_s) .iui-number-input__skeleton-field{height:44px;border-radius:var(--medium, 8px)}.iui-number-input__skeleton-helper{width:40px;height:8px;background:var(--iui-number-input-skeleton-bg);border-radius:2px;margin-top:var(--spacing-02, 8px)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { inputElement: [{
                type: ViewChild,
                args: ['inputElement']
            }], id: [{
                type: Input
            }], label: [{
                type: Input
            }], helperText: [{
                type: Input
            }], name: [{
                type: Input
            }], size: [{
                type: Input
            }], layerSet: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], step: [{
                type: Input
            }], showControls: [{
                type: Input
            }], showLabel: [{
                type: Input
            }], showHelper: [{
                type: Input
            }], showExplainer: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], required: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLW51bWJlci1pbnB1dC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS9udW1iZXItaW5wdXQvc3JjL2l1aS1udW1iZXItaW5wdXQuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvbnVtYmVyLWlucHV0L3NyYy9pdWktbnVtYmVyLWlucHV0LmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDTix1QkFBdUIsRUFDdkIsaUJBQWlCLEVBQ2pCLFNBQVMsRUFFVCxVQUFVLEVBQ1YsS0FBSyxFQUNMLElBQUksRUFDSixTQUFTLEVBQ1QsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBd0IsaUJBQWlCLEVBQUUsVUFBVSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDckYsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDOUQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLDZCQUE2QixFQUFFLHNCQUFzQixFQUFFLE1BQU0sbUNBQW1DLENBQUM7QUFDOUgsT0FBTyxFQUFFLDBCQUEwQixFQUFFLHFCQUFxQixFQUFFLE1BQU0sb0NBQW9DLENBQUM7Ozs7QUFLdkcsSUFBSSxZQUFZLEdBQUcsQ0FBQyxDQUFDO0FBMkNyQixNQUFNLE9BQU8sdUJBQXVCO0lBR25DLElBQ0ksRUFBRSxDQUFDLEtBQWE7UUFDbkIsSUFBSSxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUM7SUFDbEIsQ0FBQztJQUVELElBQUksRUFBRTtRQUNMLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUNqQixDQUFDO0lBd0JELElBQ0ksUUFBUTtRQUNYLE9BQU8sSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLFlBQVksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksS0FBSyxDQUFDO0lBQ3RHLENBQUM7SUFFRCxJQUFJLFFBQVEsQ0FBQyxLQUEwQztRQUN0RCxJQUFJLENBQUMsU0FBUyxHQUFHLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRCxJQUFJLFFBQVE7UUFDWCxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVLENBQUM7SUFDNUMsQ0FBQztJQUVELElBQUksV0FBVztRQUNkLE9BQU8sSUFBSSxDQUFDLDBCQUEwQixDQUFDLFVBQVUsQ0FBQztJQUNuRCxDQUFDO0lBRUQsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQ3ZCLENBQUM7SUFFRCxJQUFJLFFBQVE7UUFDWCxPQUFPLElBQUksQ0FBQyxFQUFFLEdBQUcsUUFBUSxDQUFDO0lBQzNCLENBQUM7SUFFRCxJQUFJLFFBQVE7UUFDWCxPQUFPLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUN6RCxDQUFDO0lBRUQsSUFBSSxRQUFRO1FBQ1gsT0FBTyxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDekQsQ0FBQztJQUVELElBQUksYUFBYTtRQUNoQixPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUM3QyxDQUFDO0lBRUQsSUFBSSxhQUFhO1FBQ2hCLE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQzdDLENBQUM7SUFFRCxJQUFJLGFBQWE7UUFDaEIsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksRUFBRSxDQUFDO1lBQzVCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUN2QixDQUFDO1FBRUQsT0FBTyxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQ3pELENBQUM7SUFFRCxJQUFJLE1BQU07UUFDVCxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDckIsQ0FBQztJQUVELFlBQ1csa0JBQXFDLEVBQzdCLGtCQUFpRCxFQUNqRCwwQkFBeUQsRUFDekQsbUJBQTJDO1FBSG5ELHVCQUFrQixHQUFsQixrQkFBa0IsQ0FBbUI7UUFDN0IsdUJBQWtCLEdBQWxCLGtCQUFrQixDQUErQjtRQUNqRCwrQkFBMEIsR0FBMUIsMEJBQTBCLENBQStCO1FBQ3pELHdCQUFtQixHQUFuQixtQkFBbUIsQ0FBd0I7UUEvRTlELFFBQUcsR0FBRyxvQkFBb0IsWUFBWSxFQUFFLEVBQUUsQ0FBQztRQUVsQyxVQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ1gsZUFBVSxHQUFHLEVBQUUsQ0FBQztRQUNoQixTQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ1YsU0FBSSxHQUFvQixHQUFHLENBQUM7UUFDNUIsYUFBUSxHQUF3QixRQUFRLENBQUM7UUFDekMsUUFBRyxHQUFHLENBQUMsUUFBUSxDQUFDO1FBQ2hCLFFBQUcsR0FBRyxRQUFRLENBQUM7UUFDZixTQUFJLEdBQUcsQ0FBQyxDQUFDO1FBQ1QsaUJBQVksR0FBRyxJQUFJLENBQUM7UUFDcEIsY0FBUyxHQUFHLElBQUksQ0FBQztRQUNqQixlQUFVLEdBQUcsSUFBSSxDQUFDO1FBQzNCLDJFQUEyRTtRQUNsRSxrQkFBYSxHQUFHLEtBQUssQ0FBQztRQUN0QixhQUFRLEdBQUcsS0FBSyxDQUFDO1FBRWxCLFlBQU8sR0FBYyxJQUFJLENBQUM7UUFDMUIsY0FBUyxHQUFHLEtBQUssQ0FBQztRQUNsQixjQUFTLEdBQWtCLElBQUksQ0FBQztRQStEeEMsY0FBUyxHQUErQixHQUFHLEVBQUUsR0FBRSxDQUFDLENBQUM7UUFDakQsZUFBVSxHQUFHLEdBQUcsRUFBRSxHQUFFLENBQUMsQ0FBQztJQUhuQixDQUFDO0lBS0osVUFBVTtRQUNULE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxDQUFDO1FBQ2xDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXpELElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDMUIsQ0FBQztJQUVELFVBQVU7UUFDVCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQztRQUNsQyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUV6RCxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzFCLENBQUM7SUFFRCxVQUFVLENBQUMsS0FBb0I7UUFDOUIsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQzdCLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUN2QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbkIsQ0FBQzthQUFNLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxXQUFXLEVBQUUsQ0FBQztZQUN0QyxLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ25CLENBQUM7SUFDRixDQUFDO0lBRUQsY0FBYyxDQUFDLEtBQVk7UUFDMUIsTUFBTSxHQUFHLEdBQUksS0FBSyxDQUFDLE1BQTJCLENBQUMsS0FBSyxDQUFDO1FBRXJELElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO1FBRXJCLElBQUksR0FBRyxLQUFLLEVBQUUsRUFBRSxDQUFDO1lBQ2hCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFeEIsT0FBTztRQUNSLENBQUM7UUFFRCxJQUFJLEdBQUcsS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUNqQixPQUFPO1FBQ1IsQ0FBQztRQUVELE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUUzQixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7WUFDcEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDckMsQ0FBQztJQUNGLENBQUM7SUFFRCxRQUFRO1FBQ1AsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztZQUN0QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7UUFDckMsQ0FBQztJQUNGLENBQUM7SUFFRCxPQUFPO1FBQ04sSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFFdEIsSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksRUFBRSxDQUFDO1lBQzFCLE1BQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVuRCxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzFCLENBQUM7YUFBTSxDQUFDO1lBQ1AsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQzNDLENBQUM7UUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNsQixJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDeEMsQ0FBQztJQUNGLENBQUM7SUFFRCxVQUFVLENBQUMsS0FBZ0I7UUFDMUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsRUFBOEI7UUFDOUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7SUFDckIsQ0FBQztJQUVELGlCQUFpQixDQUFDLEVBQWM7UUFDL0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVELGdCQUFnQixDQUFDLFVBQW1CO1FBQ25DLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN0RCxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDeEMsQ0FBQztJQUVPLFNBQVMsQ0FBQyxLQUFhO1FBQzlCLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFN0MsSUFBSSxXQUFXLEVBQUUsQ0FBQztZQUNqQixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZCLENBQUM7SUFDRixDQUFDO0lBRU8sWUFBWSxDQUFDLFFBQW1CO1FBQ3ZDLElBQUksUUFBUSxLQUFLLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUMvQixJQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQztZQUN4QixJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFLENBQUM7WUFFdkMsT0FBTyxJQUFJLENBQUM7UUFDYixDQUFDO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZCxDQUFDO0lBRU8sTUFBTSxDQUFDLEtBQWE7UUFDM0IsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDNUMsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQ2pCLENBQUM7UUFFRCxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUM1QyxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUM7UUFDakIsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2QsQ0FBQzsrR0F0TlcsdUJBQXVCO21HQUF2Qix1QkFBdUIsMDFCQXBCeEI7WUFDVjtnQkFDQyxPQUFPLEVBQUUsaUJBQWlCO2dCQUMxQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLHVCQUF1QixDQUFDO2dCQUN0RCxLQUFLLEVBQUUsSUFBSTthQUNYO1NBQ0QsNGFDaERGLGcrRUFzRUEsKzVIRDVDVyxZQUFZLG1JQUFFLDBCQUEwQixvRUFBRSxxQkFBcUI7OzRGQW9DN0QsdUJBQXVCO2tCQXZDbkMsU0FBUzsrQkFDQyxrQkFBa0IsY0FDaEIsSUFBSSxXQUNQLENBQUMsWUFBWSxFQUFFLDBCQUEwQixFQUFFLHFCQUFxQixDQUFDLG1CQUd6RCx1QkFBdUIsQ0FBQyxNQUFNLGtCQUMvQjt3QkFDZixrQkFBa0I7d0JBQ2xCOzRCQUNDLFNBQVMsRUFBRSw2QkFBNkI7NEJBQ3hDLE1BQU0sRUFBRSxDQUFDLG1CQUFtQixDQUFDO3lCQUM3Qjt3QkFDRDs0QkFDQyxTQUFTLEVBQUUsc0JBQXNCOzRCQUNqQyxNQUFNLEVBQUUsQ0FBQyxZQUFZLENBQUM7NEJBQ3RCLE9BQU8sRUFBRSxDQUFDLG9CQUFvQixDQUFDO3lCQUMvQjtxQkFDRCxhQUNVO3dCQUNWOzRCQUNDLE9BQU8sRUFBRSxpQkFBaUI7NEJBQzFCLFdBQVcsRUFBRSxVQUFVLENBQUMsR0FBRyxFQUFFLHdCQUF3QixDQUFDOzRCQUN0RCxLQUFLLEVBQUUsSUFBSTt5QkFDWDtxQkFDRCxRQUNLO3dCQUNMLEtBQUssRUFBRSxrQkFBa0I7d0JBQ3pCLGlDQUFpQyxFQUFFLGNBQWM7d0JBQ2pELGlDQUFpQyxFQUFFLGNBQWM7d0JBQ2pELGlDQUFpQyxFQUFFLGNBQWM7d0JBQ2pELHVDQUF1QyxFQUFFLHVCQUF1Qjt3QkFDaEUsa0NBQWtDLEVBQUUsVUFBVTt3QkFDOUMsbUNBQW1DLEVBQUUsVUFBVTt3QkFDL0Msa0NBQWtDLEVBQUUsYUFBYTt3QkFDakQsbUNBQW1DLEVBQUUsVUFBVTt3QkFDL0MsV0FBVyxFQUFFLElBQUk7cUJBQ2pCOzswQkEyRkMsSUFBSTs7MEJBQ0osSUFBSTs7MEJBQ0osSUFBSTt5Q0ExRnFCLFlBQVk7c0JBQXRDLFNBQVM7dUJBQUMsY0FBYztnQkFHckIsRUFBRTtzQkFETCxLQUFLO2dCQVdHLEtBQUs7c0JBQWIsS0FBSztnQkFDRyxVQUFVO3NCQUFsQixLQUFLO2dCQUNHLElBQUk7c0JBQVosS0FBSztnQkFDRyxJQUFJO3NCQUFaLEtBQUs7Z0JBQ0csUUFBUTtzQkFBaEIsS0FBSztnQkFDRyxHQUFHO3NCQUFYLEtBQUs7Z0JBQ0csR0FBRztzQkFBWCxLQUFLO2dCQUNHLElBQUk7c0JBQVosS0FBSztnQkFDRyxZQUFZO3NCQUFwQixLQUFLO2dCQUNHLFNBQVM7c0JBQWpCLEtBQUs7Z0JBQ0csVUFBVTtzQkFBbEIsS0FBSztnQkFFRyxhQUFhO3NCQUFyQixLQUFLO2dCQUNHLFFBQVE7c0JBQWhCLEtBQUs7Z0JBUUYsUUFBUTtzQkFEWCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuXHRDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcclxuXHRDaGFuZ2VEZXRlY3RvclJlZixcclxuXHRDb21wb25lbnQsXHJcblx0RWxlbWVudFJlZixcclxuXHRmb3J3YXJkUmVmLFxyXG5cdElucHV0LFxyXG5cdFNlbGYsXHJcblx0Vmlld0NoaWxkXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBOR19WQUxVRV9BQ0NFU1NPUiwgVmFsaWRhdG9ycyB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgY29lcmNlQm9vbGVhblByb3BlcnR5IH0gZnJvbSAnQGFuZ3VsYXIvY2RrL2NvZXJjaW9uJztcclxuaW1wb3J0IHsgTmdDb250cm9sRGlyZWN0aXZlLCBJdWlFcnJvclN0YXRlTWF0Y2hlckRpcmVjdGl2ZSwgSXVpSXNEaXNhYmxlZERpcmVjdGl2ZSB9IGZyb20gJ0BpdGVyby91aS1jb21wb25lbnRzLWFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFN1YnRyYWN0RW1wdHlJY29uQ29tcG9uZW50LCBBZGRFbXB0eUljb25Db21wb25lbnQgfSBmcm9tICdAaXRlcm8vdWktY29tcG9uZW50cy1hbmd1bGFyL2ljb25zJztcclxuXHJcbmV4cG9ydCB0eXBlIE51bWJlcklucHV0U2l6ZSA9ICdsJyB8ICdtJyB8ICdzJztcclxuZXhwb3J0IHR5cGUgTnVtYmVySW5wdXRMYXllclNldCA9ICdzZXQtMDEnIHwgJ3NldC0wMic7XHJcblxyXG5sZXQgbmV4dFVuaXF1ZUlkID0gMDtcclxuXHJcbnR5cGUgVmFsdWVUeXBlID0gbnVtYmVyIHwgbnVsbDtcclxuXHJcbkBDb21wb25lbnQoe1xyXG5cdHNlbGVjdG9yOiAnaXVpLW51bWJlci1pbnB1dCcsXHJcblx0c3RhbmRhbG9uZTogdHJ1ZSxcclxuXHRpbXBvcnRzOiBbQ29tbW9uTW9kdWxlLCBTdWJ0cmFjdEVtcHR5SWNvbkNvbXBvbmVudCwgQWRkRW1wdHlJY29uQ29tcG9uZW50XSxcclxuXHR0ZW1wbGF0ZVVybDogJy4vaXVpLW51bWJlci1pbnB1dC5jb21wb25lbnQuaHRtbCcsXHJcblx0c3R5bGVVcmxzOiBbJy4vaXVpLW51bWJlci1pbnB1dC5jb21wb25lbnQuc2NzcyddLFxyXG5cdGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxyXG5cdGhvc3REaXJlY3RpdmVzOiBbXHJcblx0XHROZ0NvbnRyb2xEaXJlY3RpdmUsXHJcblx0XHR7XHJcblx0XHRcdGRpcmVjdGl2ZTogSXVpRXJyb3JTdGF0ZU1hdGNoZXJEaXJlY3RpdmUsXHJcblx0XHRcdGlucHV0czogWydlcnJvclN0YXRlTWF0Y2hlciddXHJcblx0XHR9LFxyXG5cdFx0e1xyXG5cdFx0XHRkaXJlY3RpdmU6IEl1aUlzRGlzYWJsZWREaXJlY3RpdmUsXHJcblx0XHRcdGlucHV0czogWydpc0Rpc2FibGVkJ10sXHJcblx0XHRcdG91dHB1dHM6IFsnZGlzYWJsZUNoYW5nZUV2ZW50J11cclxuXHRcdH1cclxuXHRdLFxyXG5cdHByb3ZpZGVyczogW1xyXG5cdFx0e1xyXG5cdFx0XHRwcm92aWRlOiBOR19WQUxVRV9BQ0NFU1NPUixcclxuXHRcdFx0dXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gSXVpTnVtYmVySW5wdXRDb21wb25lbnQpLFxyXG5cdFx0XHRtdWx0aTogdHJ1ZVxyXG5cdFx0fVxyXG5cdF0sXHJcblx0aG9zdDoge1xyXG5cdFx0Y2xhc3M6ICdpdWktbnVtYmVyLWlucHV0JyxcclxuXHRcdCdbY2xhc3MuaXVpLW51bWJlci1pbnB1dF9zaXplX2xdJzogJ3NpemUgPT09IFwibFwiJyxcclxuXHRcdCdbY2xhc3MuaXVpLW51bWJlci1pbnB1dF9zaXplX21dJzogJ3NpemUgPT09IFwibVwiJyxcclxuXHRcdCdbY2xhc3MuaXVpLW51bWJlci1pbnB1dF9zaXplX3NdJzogJ3NpemUgPT09IFwic1wiJyxcclxuXHRcdCdbY2xhc3MuaXVpLW51bWJlci1pbnB1dF9sYXllci1zZXQtMDJdJzogJ2xheWVyU2V0ID09PSBcInNldC0wMlwiJyxcclxuXHRcdCdbY2xhc3MuaXVpLW51bWJlci1pbnB1dF9mb2N1c2VkXSc6ICdfZm9jdXNlZCcsXHJcblx0XHQnW2NsYXNzLml1aS1udW1iZXItaW5wdXRfZGlzYWJsZWRdJzogJ2Rpc2FibGVkJyxcclxuXHRcdCdbY2xhc3MuaXVpLW51bWJlci1pbnB1dF9pbnZhbGlkXSc6ICdfZXJyb3JTdGF0ZScsXHJcblx0XHQnW2NsYXNzLml1aS1udW1iZXItaW5wdXRfc2tlbGV0b25dJzogJ3NrZWxldG9uJyxcclxuXHRcdCdbYXR0ci5pZF0nOiAnaWQnXHJcblx0fVxyXG59KVxyXG5leHBvcnQgY2xhc3MgSXVpTnVtYmVySW5wdXRDb21wb25lbnQgaW1wbGVtZW50cyBDb250cm9sVmFsdWVBY2Nlc3NvciB7XHJcblx0QFZpZXdDaGlsZCgnaW5wdXRFbGVtZW50JykgaW5wdXRFbGVtZW50OiBFbGVtZW50UmVmPEhUTUxJbnB1dEVsZW1lbnQ+IHwgdW5kZWZpbmVkO1xyXG5cclxuXHRASW5wdXQoKVxyXG5cdHNldCBpZCh2YWx1ZTogc3RyaW5nKSB7XHJcblx0XHR0aGlzLl9pZCA9IHZhbHVlO1xyXG5cdH1cclxuXHJcblx0Z2V0IGlkKCkge1xyXG5cdFx0cmV0dXJuIHRoaXMuX2lkO1xyXG5cdH1cclxuXHJcblx0X2lkID0gYGl1aS1udW1iZXItaW5wdXQtJHtuZXh0VW5pcXVlSWQrK31gO1xyXG5cclxuXHRASW5wdXQoKSBsYWJlbCA9ICcnO1xyXG5cdEBJbnB1dCgpIGhlbHBlclRleHQgPSAnJztcclxuXHRASW5wdXQoKSBuYW1lID0gJyc7XHJcblx0QElucHV0KCkgc2l6ZTogTnVtYmVySW5wdXRTaXplID0gJ2wnO1xyXG5cdEBJbnB1dCgpIGxheWVyU2V0OiBOdW1iZXJJbnB1dExheWVyU2V0ID0gJ3NldC0wMSc7XHJcblx0QElucHV0KCkgbWluID0gLUluZmluaXR5O1xyXG5cdEBJbnB1dCgpIG1heCA9IEluZmluaXR5O1xyXG5cdEBJbnB1dCgpIHN0ZXAgPSAxO1xyXG5cdEBJbnB1dCgpIHNob3dDb250cm9scyA9IHRydWU7XHJcblx0QElucHV0KCkgc2hvd0xhYmVsID0gdHJ1ZTtcclxuXHRASW5wdXQoKSBzaG93SGVscGVyID0gdHJ1ZTtcclxuXHQvLyBzaG93RXhwbGFpbmVyIGlzIGRlZmVycmVkIOKAlCBuby1vcCB1bnRpbCB0b29sdGlwIGludGVncmF0aW9uIGlzIGF2YWlsYWJsZVxyXG5cdEBJbnB1dCgpIHNob3dFeHBsYWluZXIgPSBmYWxzZTtcclxuXHRASW5wdXQoKSBza2VsZXRvbiA9IGZhbHNlO1xyXG5cclxuXHRwcml2YXRlIF9fdmFsdWU6IFZhbHVlVHlwZSA9IG51bGw7XHJcblx0cHJpdmF0ZSBfX2ZvY3VzZWQgPSBmYWxzZTtcclxuXHRwcml2YXRlIF9yYXdJbnB1dDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XHJcblx0cHJpdmF0ZSBfcmVxdWlyZWQ6IGJvb2xlYW4gfCB1bmRlZmluZWQ7XHJcblxyXG5cdEBJbnB1dCgpXHJcblx0Z2V0IHJlcXVpcmVkKCk6IGJvb2xlYW4ge1xyXG5cdFx0cmV0dXJuIHRoaXMuX3JlcXVpcmVkID8/IHRoaXMubmdDb250cm9sRGlyZWN0aXZlLmNvbnRyb2w/Lmhhc1ZhbGlkYXRvcihWYWxpZGF0b3JzLnJlcXVpcmVkKSA/PyBmYWxzZTtcclxuXHR9XHJcblxyXG5cdHNldCByZXF1aXJlZCh2YWx1ZTogc3RyaW5nIHwgYm9vbGVhbiB8IG51bGwgfCB1bmRlZmluZWQpIHtcclxuXHRcdHRoaXMuX3JlcXVpcmVkID0gY29lcmNlQm9vbGVhblByb3BlcnR5KHZhbHVlKTtcclxuXHR9XHJcblxyXG5cdGdldCBkaXNhYmxlZCgpOiBib29sZWFuIHtcclxuXHRcdHJldHVybiB0aGlzLmlzRGlzYWJsZWREaXJlY3RpdmUuaXNEaXNhYmxlZDtcclxuXHR9XHJcblxyXG5cdGdldCBfZXJyb3JTdGF0ZSgpOiBib29sZWFuIHtcclxuXHRcdHJldHVybiB0aGlzLmVycm9yU3RhdGVNYXRjaGVyRGlyZWN0aXZlLmVycm9yU3RhdGU7XHJcblx0fVxyXG5cclxuXHRnZXQgX2ZvY3VzZWQoKTogYm9vbGVhbiB7XHJcblx0XHRyZXR1cm4gdGhpcy5fX2ZvY3VzZWQ7XHJcblx0fVxyXG5cclxuXHRnZXQgX2lucHV0SWQoKTogc3RyaW5nIHtcclxuXHRcdHJldHVybiB0aGlzLmlkICsgJy1pbnB1dCc7XHJcblx0fVxyXG5cclxuXHRnZXQgX2lzQXRNaW4oKTogYm9vbGVhbiB7XHJcblx0XHRyZXR1cm4gdGhpcy5fX3ZhbHVlICE9IG51bGwgJiYgdGhpcy5fX3ZhbHVlIDw9IHRoaXMubWluO1xyXG5cdH1cclxuXHJcblx0Z2V0IF9pc0F0TWF4KCk6IGJvb2xlYW4ge1xyXG5cdFx0cmV0dXJuIHRoaXMuX192YWx1ZSAhPSBudWxsICYmIHRoaXMuX192YWx1ZSA+PSB0aGlzLm1heDtcclxuXHR9XHJcblxyXG5cdGdldCBfYXJpYVZhbHVlTWluKCk6IG51bWJlciB8IG51bGwge1xyXG5cdFx0cmV0dXJuIGlzRmluaXRlKHRoaXMubWluKSA/IHRoaXMubWluIDogbnVsbDtcclxuXHR9XHJcblxyXG5cdGdldCBfYXJpYVZhbHVlTWF4KCk6IG51bWJlciB8IG51bGwge1xyXG5cdFx0cmV0dXJuIGlzRmluaXRlKHRoaXMubWF4KSA/IHRoaXMubWF4IDogbnVsbDtcclxuXHR9XHJcblxyXG5cdGdldCBfZGlzcGxheVZhbHVlKCk6IHN0cmluZyB7XHJcblx0XHRpZiAodGhpcy5fcmF3SW5wdXQgIT0gbnVsbCkge1xyXG5cdFx0XHRyZXR1cm4gdGhpcy5fcmF3SW5wdXQ7XHJcblx0XHR9XHJcblxyXG5cdFx0cmV0dXJuIHRoaXMuX192YWx1ZSAhPSBudWxsID8gU3RyaW5nKHRoaXMuX192YWx1ZSkgOiAnJztcclxuXHR9XHJcblxyXG5cdGdldCBfdmFsdWUoKTogVmFsdWVUeXBlIHtcclxuXHRcdHJldHVybiB0aGlzLl9fdmFsdWU7XHJcblx0fVxyXG5cclxuXHRjb25zdHJ1Y3RvcihcclxuXHRcdHByb3RlY3RlZCBfY2hhbmdlRGV0ZWN0b3JSZWY6IENoYW5nZURldGVjdG9yUmVmLFxyXG5cdFx0QFNlbGYoKSBwcm90ZWN0ZWQgbmdDb250cm9sRGlyZWN0aXZlOiBOZ0NvbnRyb2xEaXJlY3RpdmU8VmFsdWVUeXBlPixcclxuXHRcdEBTZWxmKCkgcHJvdGVjdGVkIGVycm9yU3RhdGVNYXRjaGVyRGlyZWN0aXZlOiBJdWlFcnJvclN0YXRlTWF0Y2hlckRpcmVjdGl2ZSxcclxuXHRcdEBTZWxmKCkgcHJvdGVjdGVkIGlzRGlzYWJsZWREaXJlY3RpdmU6IEl1aUlzRGlzYWJsZWREaXJlY3RpdmVcclxuXHQpIHt9XHJcblxyXG5cdF9vbkNoYW5nZTogKHZhbHVlOiBWYWx1ZVR5cGUpID0+IHZvaWQgPSAoKSA9PiB7fTtcclxuXHRfb25Ub3VjaGVkID0gKCkgPT4ge307XHJcblxyXG5cdF9pbmNyZW1lbnQoKTogdm9pZCB7XHJcblx0XHRjb25zdCBjdXJyZW50ID0gdGhpcy5fX3ZhbHVlID8/IDA7XHJcblx0XHRjb25zdCBuZXdWYWx1ZSA9IE1hdGgubWluKGN1cnJlbnQgKyB0aGlzLnN0ZXAsIHRoaXMubWF4KTtcclxuXHJcblx0XHR0aGlzLl9zZXRWYWx1ZShuZXdWYWx1ZSk7XHJcblx0fVxyXG5cclxuXHRfZGVjcmVtZW50KCk6IHZvaWQge1xyXG5cdFx0Y29uc3QgY3VycmVudCA9IHRoaXMuX192YWx1ZSA/PyAwO1xyXG5cdFx0Y29uc3QgbmV3VmFsdWUgPSBNYXRoLm1heChjdXJyZW50IC0gdGhpcy5zdGVwLCB0aGlzLm1pbik7XHJcblxyXG5cdFx0dGhpcy5fc2V0VmFsdWUobmV3VmFsdWUpO1xyXG5cdH1cclxuXHJcblx0X29uS2V5ZG93bihldmVudDogS2V5Ym9hcmRFdmVudCk6IHZvaWQge1xyXG5cdFx0aWYgKGV2ZW50LmtleSA9PT0gJ0Fycm93VXAnKSB7XHJcblx0XHRcdGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcblx0XHRcdHRoaXMuX2luY3JlbWVudCgpO1xyXG5cdFx0fSBlbHNlIGlmIChldmVudC5rZXkgPT09ICdBcnJvd0Rvd24nKSB7XHJcblx0XHRcdGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcblx0XHRcdHRoaXMuX2RlY3JlbWVudCgpO1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0X29uSW5wdXRDaGFuZ2UoZXZlbnQ6IEV2ZW50KTogdm9pZCB7XHJcblx0XHRjb25zdCByYXcgPSAoZXZlbnQudGFyZ2V0IGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlO1xyXG5cclxuXHRcdHRoaXMuX3Jhd0lucHV0ID0gcmF3O1xyXG5cclxuXHRcdGlmIChyYXcgPT09ICcnKSB7XHJcblx0XHRcdHRoaXMuX2Fzc2lnblZhbHVlKG51bGwpO1xyXG5cclxuXHRcdFx0cmV0dXJuO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmIChyYXcgPT09ICctJykge1xyXG5cdFx0XHRyZXR1cm47XHJcblx0XHR9XHJcblxyXG5cdFx0Y29uc3QgcGFyc2VkID0gTnVtYmVyKHJhdyk7XHJcblxyXG5cdFx0aWYgKCFpc05hTihwYXJzZWQpKSB7XHJcblx0XHRcdHRoaXMuX3NldFZhbHVlKHRoaXMuX2NsYW1wKHBhcnNlZCkpO1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0X29uRm9jdXMoKTogdm9pZCB7XHJcblx0XHRpZiAoIXRoaXMuZGlzYWJsZWQpIHtcclxuXHRcdFx0dGhpcy5fX2ZvY3VzZWQgPSB0cnVlO1xyXG5cdFx0XHR0aGlzLl9yYXdJbnB1dCA9IHRoaXMuX2Rpc3BsYXlWYWx1ZTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdF9vbkJsdXIoKTogdm9pZCB7XHJcblx0XHR0aGlzLl9fZm9jdXNlZCA9IGZhbHNlO1xyXG5cdFx0dGhpcy5fcmF3SW5wdXQgPSBudWxsO1xyXG5cclxuXHRcdGlmICh0aGlzLl9fdmFsdWUgPT0gbnVsbCkge1xyXG5cdFx0XHRjb25zdCByZXNvbHZlZCA9IGlzRmluaXRlKHRoaXMubWluKSA/IHRoaXMubWluIDogMDtcclxuXHJcblx0XHRcdHRoaXMuX3NldFZhbHVlKHJlc29sdmVkKTtcclxuXHRcdH0gZWxzZSB7XHJcblx0XHRcdHRoaXMuX3NldFZhbHVlKHRoaXMuX2NsYW1wKHRoaXMuX192YWx1ZSkpO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmICghdGhpcy5kaXNhYmxlZCkge1xyXG5cdFx0XHR0aGlzLl9vblRvdWNoZWQoKTtcclxuXHRcdFx0dGhpcy5fY2hhbmdlRGV0ZWN0b3JSZWYubWFya0ZvckNoZWNrKCk7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHR3cml0ZVZhbHVlKHZhbHVlOiBWYWx1ZVR5cGUpOiB2b2lkIHtcclxuXHRcdHRoaXMuX2Fzc2lnblZhbHVlKHZhbHVlKTtcclxuXHR9XHJcblxyXG5cdHJlZ2lzdGVyT25DaGFuZ2UoZm46ICh2YWx1ZTogVmFsdWVUeXBlKSA9PiB2b2lkKTogdm9pZCB7XHJcblx0XHR0aGlzLl9vbkNoYW5nZSA9IGZuO1xyXG5cdH1cclxuXHJcblx0cmVnaXN0ZXJPblRvdWNoZWQoZm46ICgpID0+IHZvaWQpOiB2b2lkIHtcclxuXHRcdHRoaXMuX29uVG91Y2hlZCA9IGZuO1xyXG5cdH1cclxuXHJcblx0c2V0RGlzYWJsZWRTdGF0ZShpc0Rpc2FibGVkOiBib29sZWFuKTogdm9pZCB7XHJcblx0XHR0aGlzLmlzRGlzYWJsZWREaXJlY3RpdmUuc2V0RGlzYWJsZWRTdGF0ZShpc0Rpc2FibGVkKTtcclxuXHRcdHRoaXMuX2NoYW5nZURldGVjdG9yUmVmLm1hcmtGb3JDaGVjaygpO1xyXG5cdH1cclxuXHJcblx0cHJpdmF0ZSBfc2V0VmFsdWUodmFsdWU6IG51bWJlcik6IHZvaWQge1xyXG5cdFx0Y29uc3QgaGFzQXNzaWduZWQgPSB0aGlzLl9hc3NpZ25WYWx1ZSh2YWx1ZSk7XHJcblxyXG5cdFx0aWYgKGhhc0Fzc2lnbmVkKSB7XHJcblx0XHRcdHRoaXMuX29uQ2hhbmdlKHZhbHVlKTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdHByaXZhdGUgX2Fzc2lnblZhbHVlKG5ld1ZhbHVlOiBWYWx1ZVR5cGUpOiBib29sZWFuIHtcclxuXHRcdGlmIChuZXdWYWx1ZSAhPT0gdGhpcy5fX3ZhbHVlKSB7XHJcblx0XHRcdHRoaXMuX192YWx1ZSA9IG5ld1ZhbHVlO1xyXG5cdFx0XHR0aGlzLl9jaGFuZ2VEZXRlY3RvclJlZi5tYXJrRm9yQ2hlY2soKTtcclxuXHJcblx0XHRcdHJldHVybiB0cnVlO1xyXG5cdFx0fVxyXG5cclxuXHRcdHJldHVybiBmYWxzZTtcclxuXHR9XHJcblxyXG5cdHByaXZhdGUgX2NsYW1wKHZhbHVlOiBudW1iZXIpOiBudW1iZXIge1xyXG5cdFx0aWYgKGlzRmluaXRlKHRoaXMubWluKSAmJiB2YWx1ZSA8IHRoaXMubWluKSB7XHJcblx0XHRcdHJldHVybiB0aGlzLm1pbjtcclxuXHRcdH1cclxuXHJcblx0XHRpZiAoaXNGaW5pdGUodGhpcy5tYXgpICYmIHZhbHVlID4gdGhpcy5tYXgpIHtcclxuXHRcdFx0cmV0dXJuIHRoaXMubWF4O1xyXG5cdFx0fVxyXG5cclxuXHRcdHJldHVybiB2YWx1ZTtcclxuXHR9XHJcbn1cclxuIiwiPG5nLWNvbnRhaW5lciAqbmdJZj1cInNrZWxldG9uOyBlbHNlIG5vcm1hbFRlbXBsYXRlXCI+XHJcblx0PGRpdiBjbGFzcz1cIml1aS1udW1iZXItaW5wdXRfX3NrZWxldG9uLWxhYmVsXCIgKm5nSWY9XCJzaG93TGFiZWxcIj48L2Rpdj5cclxuXHQ8ZGl2IGNsYXNzPVwiaXVpLW51bWJlci1pbnB1dF9fc2tlbGV0b24tZmllbGRcIj48L2Rpdj5cclxuXHQ8ZGl2IGNsYXNzPVwiaXVpLW51bWJlci1pbnB1dF9fc2tlbGV0b24taGVscGVyXCI+PC9kaXY+XHJcbjwvbmctY29udGFpbmVyPlxyXG5cclxuPG5nLXRlbXBsYXRlICNub3JtYWxUZW1wbGF0ZT5cclxuXHQ8ZGl2IGNsYXNzPVwiaXVpLW51bWJlci1pbnB1dF9fbGFiZWwtcm93XCIgKm5nSWY9XCJzaG93TGFiZWwgJiYgbGFiZWxcIj5cclxuXHRcdDxsYWJlbCBjbGFzcz1cIml1aS1udW1iZXItaW5wdXRfX2xhYmVsXCIgW2F0dHIuZm9yXT1cIl9pbnB1dElkXCI+XHJcblx0XHRcdHt7IGxhYmVsIH19XHJcblx0XHQ8L2xhYmVsPlxyXG5cdDwvZGl2PlxyXG5cclxuXHQ8ZGl2IGNsYXNzPVwiaXVpLW51bWJlci1pbnB1dF9fZmllbGRcIj5cclxuXHRcdDxpbnB1dFxyXG5cdFx0XHQjaW5wdXRFbGVtZW50XHJcblx0XHRcdHR5cGU9XCJ0ZXh0XCJcclxuXHRcdFx0aW5wdXRtb2RlPVwibnVtZXJpY1wiXHJcblx0XHRcdGNsYXNzPVwiaXVpLW51bWJlci1pbnB1dF9faW5wdXRcIlxyXG5cdFx0XHRyb2xlPVwic3BpbmJ1dHRvblwiXHJcblx0XHRcdFthdHRyLmlkXT1cIl9pbnB1dElkXCJcclxuXHRcdFx0W2F0dHIubmFtZV09XCJuYW1lIHx8IG51bGxcIlxyXG5cdFx0XHRbYXR0ci5hcmlhLWxhYmVsXT1cImxhYmVsIHx8IG51bGxcIlxyXG5cdFx0XHRbYXR0ci5hcmlhLXZhbHVlbWluXT1cIl9hcmlhVmFsdWVNaW5cIlxyXG5cdFx0XHRbYXR0ci5hcmlhLXZhbHVlbWF4XT1cIl9hcmlhVmFsdWVNYXhcIlxyXG5cdFx0XHRbYXR0ci5hcmlhLXZhbHVlbm93XT1cIl92YWx1ZVwiXHJcblx0XHRcdFtkaXNhYmxlZF09XCJkaXNhYmxlZFwiXHJcblx0XHRcdFt2YWx1ZV09XCJfZGlzcGxheVZhbHVlXCJcclxuXHRcdFx0KGlucHV0KT1cIl9vbklucHV0Q2hhbmdlKCRldmVudClcIlxyXG5cdFx0XHQoZm9jdXMpPVwiX29uRm9jdXMoKVwiXHJcblx0XHRcdChibHVyKT1cIl9vbkJsdXIoKVwiXHJcblx0XHRcdChrZXlkb3duKT1cIl9vbktleWRvd24oJGV2ZW50KVwiXHJcblx0XHQvPlxyXG5cclxuXHRcdDxkaXYgY2xhc3M9XCJpdWktbnVtYmVyLWlucHV0X19jb250cm9sc1wiICpuZ0lmPVwic2hvd0NvbnRyb2xzXCI+XHJcblx0XHRcdDxidXR0b25cclxuXHRcdFx0XHR0eXBlPVwiYnV0dG9uXCJcclxuXHRcdFx0XHRjbGFzcz1cIml1aS1udW1iZXItaW5wdXRfX2NvbnRyb2wtYnRuXCJcclxuXHRcdFx0XHRbZGlzYWJsZWRdPVwiZGlzYWJsZWQgfHwgX2lzQXRNaW5cIlxyXG5cdFx0XHRcdChjbGljayk9XCJfZGVjcmVtZW50KClcIlxyXG5cdFx0XHRcdHRhYmluZGV4PVwiLTFcIlxyXG5cdFx0XHRcdGFyaWEtbGFiZWw9XCJEZWNyZWFzZSB2YWx1ZVwiXHJcblx0XHRcdD5cclxuXHRcdFx0XHQ8aXVpLXN1YnRyYWN0LWVtcHR5LWljb24gY2xhc3M9XCJpdWktaWNvbiBpdWktaWNvbl9zaXplX3NcIj48L2l1aS1zdWJ0cmFjdC1lbXB0eS1pY29uPlxyXG5cdFx0XHQ8L2J1dHRvbj5cclxuXHJcblx0XHRcdDxzcGFuIGNsYXNzPVwiaXVpLW51bWJlci1pbnB1dF9fZGl2aWRlclwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjwvc3Bhbj5cclxuXHJcblx0XHRcdDxidXR0b25cclxuXHRcdFx0XHR0eXBlPVwiYnV0dG9uXCJcclxuXHRcdFx0XHRjbGFzcz1cIml1aS1udW1iZXItaW5wdXRfX2NvbnRyb2wtYnRuXCJcclxuXHRcdFx0XHRbZGlzYWJsZWRdPVwiZGlzYWJsZWQgfHwgX2lzQXRNYXhcIlxyXG5cdFx0XHRcdChjbGljayk9XCJfaW5jcmVtZW50KClcIlxyXG5cdFx0XHRcdHRhYmluZGV4PVwiLTFcIlxyXG5cdFx0XHRcdGFyaWEtbGFiZWw9XCJJbmNyZWFzZSB2YWx1ZVwiXHJcblx0XHRcdD5cclxuXHRcdFx0XHQ8aXVpLWFkZC1lbXB0eS1pY29uIGNsYXNzPVwiaXVpLWljb24gaXVpLWljb25fc2l6ZV9zXCI+PC9pdWktYWRkLWVtcHR5LWljb24+XHJcblx0XHRcdDwvYnV0dG9uPlxyXG5cdFx0PC9kaXY+XHJcblx0PC9kaXY+XHJcblxyXG5cdDxkaXYgY2xhc3M9XCJpdWktbnVtYmVyLWlucHV0X19oZWxwZXItcm93XCIgKm5nSWY9XCJzaG93SGVscGVyXCI+XHJcblx0XHQ8c3BhbiAqbmdJZj1cIl9lcnJvclN0YXRlXCIgY2xhc3M9XCJpdWktbnVtYmVyLWlucHV0X19lcnJvclwiPlxyXG5cdFx0XHQ8bmctY29udGVudCBzZWxlY3Q9XCJbaXVpLWVycm9yXVwiPjwvbmctY29udGVudD5cclxuXHRcdDwvc3Bhbj5cclxuXHRcdDxzcGFuICpuZ0lmPVwiIV9lcnJvclN0YXRlXCIgY2xhc3M9XCJpdWktbnVtYmVyLWlucHV0X19oZWxwZXJcIj5cclxuXHRcdFx0PG5nLWNvbnRlbnQgc2VsZWN0PVwiW2l1aS1oaW50XVwiPjwvbmctY29udGVudD5cclxuXHRcdDwvc3Bhbj5cclxuXHQ8L2Rpdj5cclxuPC9uZy10ZW1wbGF0ZT5cclxuIl19