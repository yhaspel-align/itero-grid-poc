import { ChangeDetectorRef, Directive, inject, Injectable, Injector, Input } from '@angular/core';
import { FormGroupDirective, NgControl, NgForm } from '@angular/forms';
import * as i0 from "@angular/core";
/** Error state matcher that matches when a control is invalid and dirty. */
export class ShowOnDirtyErrorStateMatcher {
    isErrorState(control, form) {
        return !!(control && control.invalid && (control.dirty || (form && form.submitted)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShowOnDirtyErrorStateMatcher, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShowOnDirtyErrorStateMatcher }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ShowOnDirtyErrorStateMatcher, decorators: [{
            type: Injectable
        }] });
export class IuiInstantErrorStateMatcher {
    isErrorState(control, form) {
        return !!control && control.invalid;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiInstantErrorStateMatcher, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiInstantErrorStateMatcher }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiInstantErrorStateMatcher, decorators: [{
            type: Injectable
        }] });
/** Provider that defines how form controls behave with regards to displaying error messages. */
export class IuiErrorStateMatcher {
    isErrorState(control, form) {
        return !!(control && control.invalid && (control.touched || (form && form.submitted)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiErrorStateMatcher, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiErrorStateMatcher, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiErrorStateMatcher, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
export class IuiErrorStateMatcherDirective {
    constructor() {
        /** Whether the component is in an error state. */
        this.errorState = false;
        this.defaultErrorStateMatcher = inject(IuiErrorStateMatcher);
        this.cdr = inject(ChangeDetectorRef);
        this.injector = inject(Injector);
    }
    ngOnInit() {
        this._parentFormGroup = this.injector.get(FormGroupDirective, null, {
            optional: true
        });
        this._parentForm = this.injector.get(NgForm, null, { optional: true });
        this._ngControl = this.injector.get(NgControl, null, { optional: true });
    }
    /** returns true if errorState has changed */
    updateErrorState() {
        const oldState = this.errorState;
        const parent = this._parentFormGroup || this._parentForm;
        const matcher = this.errorStateMatcher ?? this.defaultErrorStateMatcher;
        const control = this._ngControl ? this._ngControl.control : null;
        const newState = matcher.isErrorState(control, parent ?? null);
        if (newState !== oldState) {
            this.errorState = newState;
            return true;
        }
        return false;
    }
    ngDoCheck() {
        if (this.updateErrorState()) {
            this.cdr.detectChanges();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiErrorStateMatcherDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: IuiErrorStateMatcherDirective, isStandalone: true, inputs: { errorStateMatcher: "errorStateMatcher" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiErrorStateMatcherDirective, decorators: [{
            type: Directive,
            args: [{ standalone: true }]
        }], propDecorators: { errorStateMatcher: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLWVycm9yLXN0YXRlLW1hdGNoZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS9jb3JlL3NyYy9kaXJlY3RpdmVzL2Vycm9yLXN0YXRlLW1hdGNoZXIvaXVpLWVycm9yLXN0YXRlLW1hdGNoZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLGlCQUFpQixFQUFFLFNBQVMsRUFBVyxNQUFNLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQVUsTUFBTSxlQUFlLENBQUM7QUFDbkgsT0FBTyxFQUFtQixrQkFBa0IsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7O0FBRXhGLDRFQUE0RTtBQUU1RSxNQUFNLE9BQU8sNEJBQTRCO0lBQ3hDLFlBQVksQ0FBQyxPQUErQixFQUFFLElBQXdDO1FBQ3JGLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdEYsQ0FBQzsrR0FIVyw0QkFBNEI7bUhBQTVCLDRCQUE0Qjs7NEZBQTVCLDRCQUE0QjtrQkFEeEMsVUFBVTs7QUFRWCxNQUFNLE9BQU8sMkJBQTJCO0lBQ3ZDLFlBQVksQ0FBQyxPQUErQixFQUFFLElBQXdDO1FBQ3JGLE9BQU8sQ0FBQyxDQUFDLE9BQU8sSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDO0lBQ3JDLENBQUM7K0dBSFcsMkJBQTJCO21IQUEzQiwyQkFBMkI7OzRGQUEzQiwyQkFBMkI7a0JBRHZDLFVBQVU7O0FBT1gsZ0dBQWdHO0FBRWhHLE1BQU0sT0FBTyxvQkFBb0I7SUFDaEMsWUFBWSxDQUFDLE9BQStCLEVBQUUsSUFBd0M7UUFDckYsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLElBQUksT0FBTyxDQUFDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN4RixDQUFDOytHQUhXLG9CQUFvQjttSEFBcEIsb0JBQW9CLGNBRFAsTUFBTTs7NEZBQ25CLG9CQUFvQjtrQkFEaEMsVUFBVTttQkFBQyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUU7O0FBUWxDLE1BQU0sT0FBTyw2QkFBNkI7SUFEMUM7UUFFQyxrREFBa0Q7UUFDbEQsZUFBVSxHQUFHLEtBQUssQ0FBQztRQUVuQiw2QkFBd0IsR0FBRyxNQUFNLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQU14RCxRQUFHLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFFdEIsYUFBUSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztLQW1DdEM7SUE3QkEsUUFBUTtRQUNQLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLEVBQUU7WUFDbkUsUUFBUSxFQUFFLElBQUk7U0FDZCxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUMxRSxDQUFDO0lBQ0QsNkNBQTZDO0lBQzdDLGdCQUFnQjtRQUNmLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7UUFDakMsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixJQUFJLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDekQsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixJQUFJLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztRQUN4RSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBRSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQTJCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUN0RixNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxNQUFNLElBQUksSUFBSSxDQUFDLENBQUM7UUFFL0QsSUFBSSxRQUFRLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDM0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUM7WUFFM0IsT0FBTyxJQUFJLENBQUM7UUFDYixDQUFDO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZCxDQUFDO0lBRUQsU0FBUztRQUNSLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFLEVBQUUsQ0FBQztZQUM3QixJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQzFCLENBQUM7SUFDRixDQUFDOytHQTlDVyw2QkFBNkI7bUdBQTdCLDZCQUE2Qjs7NEZBQTdCLDZCQUE2QjtrQkFEekMsU0FBUzttQkFBQyxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUU7OEJBUzlCLGlCQUFpQjtzQkFEaEIsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENoYW5nZURldGVjdG9yUmVmLCBEaXJlY3RpdmUsIERvQ2hlY2ssIGluamVjdCwgSW5qZWN0YWJsZSwgSW5qZWN0b3IsIElucHV0LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFic3RyYWN0Q29udHJvbCwgRm9ybUdyb3VwRGlyZWN0aXZlLCBOZ0NvbnRyb2wsIE5nRm9ybSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcblxuLyoqIEVycm9yIHN0YXRlIG1hdGNoZXIgdGhhdCBtYXRjaGVzIHdoZW4gYSBjb250cm9sIGlzIGludmFsaWQgYW5kIGRpcnR5LiAqL1xuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIFNob3dPbkRpcnR5RXJyb3JTdGF0ZU1hdGNoZXIgaW1wbGVtZW50cyBJdWlFcnJvclN0YXRlTWF0Y2hlciB7XG5cdGlzRXJyb3JTdGF0ZShjb250cm9sOiBBYnN0cmFjdENvbnRyb2wgfCBudWxsLCBmb3JtOiBGb3JtR3JvdXBEaXJlY3RpdmUgfCBOZ0Zvcm0gfCBudWxsKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuICEhKGNvbnRyb2wgJiYgY29udHJvbC5pbnZhbGlkICYmIChjb250cm9sLmRpcnR5IHx8IChmb3JtICYmIGZvcm0uc3VibWl0dGVkKSkpO1xuXHR9XG59XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBJdWlJbnN0YW50RXJyb3JTdGF0ZU1hdGNoZXIgaW1wbGVtZW50cyBJdWlFcnJvclN0YXRlTWF0Y2hlciB7XG5cdGlzRXJyb3JTdGF0ZShjb250cm9sOiBBYnN0cmFjdENvbnRyb2wgfCBudWxsLCBmb3JtOiBGb3JtR3JvdXBEaXJlY3RpdmUgfCBOZ0Zvcm0gfCBudWxsKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuICEhY29udHJvbCAmJiBjb250cm9sLmludmFsaWQ7XG5cdH1cbn1cblxuLyoqIFByb3ZpZGVyIHRoYXQgZGVmaW5lcyBob3cgZm9ybSBjb250cm9scyBiZWhhdmUgd2l0aCByZWdhcmRzIHRvIGRpc3BsYXlpbmcgZXJyb3IgbWVzc2FnZXMuICovXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIEl1aUVycm9yU3RhdGVNYXRjaGVyIHtcblx0aXNFcnJvclN0YXRlKGNvbnRyb2w6IEFic3RyYWN0Q29udHJvbCB8IG51bGwsIGZvcm06IEZvcm1Hcm91cERpcmVjdGl2ZSB8IE5nRm9ybSB8IG51bGwpOiBib29sZWFuIHtcblx0XHRyZXR1cm4gISEoY29udHJvbCAmJiBjb250cm9sLmludmFsaWQgJiYgKGNvbnRyb2wudG91Y2hlZCB8fCAoZm9ybSAmJiBmb3JtLnN1Ym1pdHRlZCkpKTtcblx0fVxufVxuXG5ARGlyZWN0aXZlKHsgc3RhbmRhbG9uZTogdHJ1ZSB9KVxuZXhwb3J0IGNsYXNzIEl1aUVycm9yU3RhdGVNYXRjaGVyRGlyZWN0aXZlIGltcGxlbWVudHMgT25Jbml0LCBEb0NoZWNrIHtcblx0LyoqIFdoZXRoZXIgdGhlIGNvbXBvbmVudCBpcyBpbiBhbiBlcnJvciBzdGF0ZS4gKi9cblx0ZXJyb3JTdGF0ZSA9IGZhbHNlO1xuXG5cdGRlZmF1bHRFcnJvclN0YXRlTWF0Y2hlciA9IGluamVjdChJdWlFcnJvclN0YXRlTWF0Y2hlcik7XG5cblx0LyoqIEFuIG9iamVjdCB1c2VkIHRvIGNvbnRyb2wgdGhlIGVycm9yIHN0YXRlIG9mIHRoZSBjb21wb25lbnQuICovXG5cdEBJbnB1dCgpXG5cdGVycm9yU3RhdGVNYXRjaGVyOiBJdWlFcnJvclN0YXRlTWF0Y2hlciB8IHVuZGVmaW5lZDtcblxuXHRjZHIgPSBpbmplY3QoQ2hhbmdlRGV0ZWN0b3JSZWYpO1xuXG5cdHByb3RlY3RlZCBpbmplY3RvciA9IGluamVjdChJbmplY3Rvcik7XG5cblx0cHJpdmF0ZSBfcGFyZW50Rm9ybUdyb3VwOiBGb3JtR3JvdXBEaXJlY3RpdmUgfCBudWxsIHwgdW5kZWZpbmVkO1xuXHRwcml2YXRlIF9wYXJlbnRGb3JtOiBOZ0Zvcm0gfCBudWxsIHwgdW5kZWZpbmVkO1xuXHRwcml2YXRlIF9uZ0NvbnRyb2w6IE5nQ29udHJvbCB8IG51bGwgfCB1bmRlZmluZWQ7XG5cblx0bmdPbkluaXQoKSB7XG5cdFx0dGhpcy5fcGFyZW50Rm9ybUdyb3VwID0gdGhpcy5pbmplY3Rvci5nZXQoRm9ybUdyb3VwRGlyZWN0aXZlLCBudWxsLCB7XG5cdFx0XHRvcHRpb25hbDogdHJ1ZVxuXHRcdH0pO1xuXHRcdHRoaXMuX3BhcmVudEZvcm0gPSB0aGlzLmluamVjdG9yLmdldChOZ0Zvcm0sIG51bGwsIHsgb3B0aW9uYWw6IHRydWUgfSk7XG5cdFx0dGhpcy5fbmdDb250cm9sID0gdGhpcy5pbmplY3Rvci5nZXQoTmdDb250cm9sLCBudWxsLCB7IG9wdGlvbmFsOiB0cnVlIH0pO1xuXHR9XG5cdC8qKiByZXR1cm5zIHRydWUgaWYgZXJyb3JTdGF0ZSBoYXMgY2hhbmdlZCAqL1xuXHR1cGRhdGVFcnJvclN0YXRlKCk6IGJvb2xlYW4ge1xuXHRcdGNvbnN0IG9sZFN0YXRlID0gdGhpcy5lcnJvclN0YXRlO1xuXHRcdGNvbnN0IHBhcmVudCA9IHRoaXMuX3BhcmVudEZvcm1Hcm91cCB8fCB0aGlzLl9wYXJlbnRGb3JtO1xuXHRcdGNvbnN0IG1hdGNoZXIgPSB0aGlzLmVycm9yU3RhdGVNYXRjaGVyID8/IHRoaXMuZGVmYXVsdEVycm9yU3RhdGVNYXRjaGVyO1xuXHRcdGNvbnN0IGNvbnRyb2wgPSB0aGlzLl9uZ0NvbnRyb2wgPyAodGhpcy5fbmdDb250cm9sLmNvbnRyb2wgYXMgQWJzdHJhY3RDb250cm9sKSA6IG51bGw7XG5cdFx0Y29uc3QgbmV3U3RhdGUgPSBtYXRjaGVyLmlzRXJyb3JTdGF0ZShjb250cm9sLCBwYXJlbnQgPz8gbnVsbCk7XG5cblx0XHRpZiAobmV3U3RhdGUgIT09IG9sZFN0YXRlKSB7XG5cdFx0XHR0aGlzLmVycm9yU3RhdGUgPSBuZXdTdGF0ZTtcblxuXHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG5cblx0bmdEb0NoZWNrKCkge1xuXHRcdGlmICh0aGlzLnVwZGF0ZUVycm9yU3RhdGUoKSkge1xuXHRcdFx0dGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xuXHRcdH1cblx0fVxufVxuIl19