import { ControlContainer, FormControlDirective, FormControlName, NgControl, NgModel } from '@angular/forms';
import { Directive, inject, Injector } from '@angular/core';
import * as i0 from "@angular/core";
export class NgControlDirective {
    constructor() {
        this.injector = inject(Injector);
    }
    ngOnInit() {
        const ngControl = this.injector.get(NgControl, null, {
            optional: true,
            self: true
        });
        if (ngControl instanceof NgModel) {
            this.control = ngControl.control;
        }
        else if (ngControl instanceof FormControlDirective) {
            this.control = ngControl.control;
        }
        else if (ngControl instanceof FormControlName) {
            const container = this.injector.get(ControlContainer).control;
            if (ngControl.name == null || container == null) {
                return;
            }
            const name = ngControl.name;
            this.control = container.get(typeof name === 'number' ? [name] : name);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NgControlDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: NgControlDirective, isStandalone: true, selector: "[iuiNgControl]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: NgControlDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[iuiNgControl]',
                    standalone: true
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmctY29udHJvbC5kaXJlY3RpdmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS9jb3JlL3NyYy9kaXJlY3RpdmVzL25nLWNvbnRyb2wvbmctY29udHJvbC5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNOLGdCQUFnQixFQUVoQixvQkFBb0IsRUFDcEIsZUFBZSxFQUNmLFNBQVMsRUFDVCxPQUFPLEVBQ1AsTUFBTSxnQkFBZ0IsQ0FBQztBQUN4QixPQUFPLEVBQ04sU0FBUyxFQUNULE1BQU0sRUFDTixRQUFRLEVBSVIsTUFBTSxlQUFlLENBQUM7O0FBT3ZCLE1BQU0sT0FBTyxrQkFBa0I7SUFKL0I7UUFNVyxhQUFRLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0tBMEJ0QztJQXhCQSxRQUFRO1FBQ1AsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRTtZQUNwRCxRQUFRLEVBQUUsSUFBSTtZQUNkLElBQUksRUFBRSxJQUFJO1NBQ1YsQ0FBQyxDQUFDO1FBRUgsSUFBSSxTQUFTLFlBQVksT0FBTyxFQUFFLENBQUM7WUFDbEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDO1FBQ2xDLENBQUM7YUFBTSxJQUFJLFNBQVMsWUFBWSxvQkFBb0IsRUFBRSxDQUFDO1lBQ3RELElBQUksQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQztRQUNsQyxDQUFDO2FBQU0sSUFBSSxTQUFTLFlBQVksZUFBZSxFQUFFLENBQUM7WUFDakQsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUM7WUFFOUQsSUFBSSxTQUFTLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxTQUFTLElBQUksSUFBSSxFQUFFLENBQUM7Z0JBQ2pELE9BQU87WUFDUixDQUFDO1lBRUQsTUFBTSxJQUFJLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQztZQUU1QixJQUFJLENBQUMsT0FBTyxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQzNCLE9BQU8sSUFBSSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUN6QixDQUFDO1FBQ2xCLENBQUM7SUFDRixDQUFDOytHQTNCVyxrQkFBa0I7bUdBQWxCLGtCQUFrQjs7NEZBQWxCLGtCQUFrQjtrQkFKOUIsU0FBUzttQkFBQztvQkFDVixRQUFRLEVBQUUsZ0JBQWdCO29CQUMxQixVQUFVLEVBQUUsSUFBSTtpQkFDaEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuXHRDb250cm9sQ29udGFpbmVyLFxuXHRGb3JtQ29udHJvbCxcblx0Rm9ybUNvbnRyb2xEaXJlY3RpdmUsXG5cdEZvcm1Db250cm9sTmFtZSxcblx0TmdDb250cm9sLFxuXHROZ01vZGVsXG59IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7XG5cdERpcmVjdGl2ZSxcblx0aW5qZWN0LFxuXHRJbmplY3Rvcixcblx0SW5wdXQsXG5cdE9uRGVzdHJveSxcblx0T25Jbml0XG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5cbkBEaXJlY3RpdmUoe1xuXHRzZWxlY3RvcjogJ1tpdWlOZ0NvbnRyb2xdJyxcblx0c3RhbmRhbG9uZTogdHJ1ZVxufSlcbmV4cG9ydCBjbGFzcyBOZ0NvbnRyb2xEaXJlY3RpdmU8VD4gaW1wbGVtZW50cyBPbkluaXQge1xuXHRjb250cm9sOiBGb3JtQ29udHJvbDxUPiB8IHVuZGVmaW5lZDtcblx0cHJvdGVjdGVkIGluamVjdG9yID0gaW5qZWN0KEluamVjdG9yKTtcblxuXHRuZ09uSW5pdCgpIHtcblx0XHRjb25zdCBuZ0NvbnRyb2wgPSB0aGlzLmluamVjdG9yLmdldChOZ0NvbnRyb2wsIG51bGwsIHtcblx0XHRcdG9wdGlvbmFsOiB0cnVlLFxuXHRcdFx0c2VsZjogdHJ1ZVxuXHRcdH0pO1xuXG5cdFx0aWYgKG5nQ29udHJvbCBpbnN0YW5jZW9mIE5nTW9kZWwpIHtcblx0XHRcdHRoaXMuY29udHJvbCA9IG5nQ29udHJvbC5jb250cm9sO1xuXHRcdH0gZWxzZSBpZiAobmdDb250cm9sIGluc3RhbmNlb2YgRm9ybUNvbnRyb2xEaXJlY3RpdmUpIHtcblx0XHRcdHRoaXMuY29udHJvbCA9IG5nQ29udHJvbC5jb250cm9sO1xuXHRcdH0gZWxzZSBpZiAobmdDb250cm9sIGluc3RhbmNlb2YgRm9ybUNvbnRyb2xOYW1lKSB7XG5cdFx0XHRjb25zdCBjb250YWluZXIgPSB0aGlzLmluamVjdG9yLmdldChDb250cm9sQ29udGFpbmVyKS5jb250cm9sO1xuXG5cdFx0XHRpZiAobmdDb250cm9sLm5hbWUgPT0gbnVsbCB8fCBjb250YWluZXIgPT0gbnVsbCkge1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IG5hbWUgPSBuZ0NvbnRyb2wubmFtZTtcblxuXHRcdFx0dGhpcy5jb250cm9sID0gY29udGFpbmVyLmdldChcblx0XHRcdFx0dHlwZW9mIG5hbWUgPT09ICdudW1iZXInID8gW25hbWVdIDogbmFtZVxuXHRcdFx0KSBhcyBGb3JtQ29udHJvbDtcblx0XHR9XG5cdH1cbn1cbiJdfQ==