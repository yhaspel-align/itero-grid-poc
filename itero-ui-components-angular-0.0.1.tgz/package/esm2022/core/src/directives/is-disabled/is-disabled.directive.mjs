import { Directive, Input, Output, EventEmitter, inject } from '@angular/core';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { NgControlDirective } from '../ng-control/ng-control.directive';
import * as i0 from "@angular/core";
export class IuiIsDisabledDirective {
    constructor() {
        this._isDisabled = false;
        this.ngControlDirective = inject((NgControlDirective), {
            self: true,
            optional: true
        });
        this.disableChangeEvent = new EventEmitter();
    }
    /**
     * whether the control is disabled.
     * [part of IuiIsDisabledDirective]
     * By assigning this input to truthy value, it makes associated formControl disabled.
     * The name "isDisabled" differs to traditional naming "disabled" because it clashes with attribute "disabled" of the formControl
     * */
    set isDisabled(value) {
        value = coerceBooleanProperty(value);
        if (this._isDisabled !== value) {
            this._isDisabled = value;
            this.handleDisabled(this._isDisabled);
        }
    }
    get isDisabled() {
        return this._isDisabled;
    }
    get control() {
        return this.ngControlDirective?.control;
    }
    ngOnInit() {
        this.handleDisabled(this.isDisabled);
    }
    /*
     *
     * @docs-private: returns true, when value was changed, otherwise - false
     * */
    handleDisabled(value) {
        if (this.control && this.control.disabled === value) {
            return false;
        }
        if (value) {
            this.control?.disable?.({ emitEvent: false });
            this.disableChangeEvent.emit(true);
        }
        else {
            this.control?.enable?.({ emitEvent: false });
            this.disableChangeEvent.emit(false);
        }
        return true;
    }
    // part of CVA handle when user disable control programmatically
    setDisabledState(isDisabled) {
        if (isDisabled !== this._isDisabled) {
            this._isDisabled = isDisabled;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiIsDisabledDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.12", type: IuiIsDisabledDirective, isStandalone: true, selector: "[isDisabled]", inputs: { isDisabled: "isDisabled" }, outputs: { disableChangeEvent: "disableChangeEvent" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiIsDisabledDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[isDisabled]',
                    standalone: true
                }]
        }], propDecorators: { isDisabled: [{
                type: Input
            }], disableChangeEvent: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXMtZGlzYWJsZWQuZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvY29yZS9zcmMvZGlyZWN0aXZlcy9pcy1kaXNhYmxlZC9pcy1kaXNhYmxlZC5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNOLFNBQVMsRUFDVCxLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFHWixNQUFNLEVBQ04sTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDOUQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sb0NBQW9DLENBQUM7O0FBVXhFLE1BQU0sT0FBTyxzQkFBc0I7SUFKbkM7UUF1QlMsZ0JBQVcsR0FBRyxLQUFLLENBQUM7UUFDbEIsdUJBQWtCLEdBQUcsTUFBTSxDQUFDLENBQUEsa0JBQTJCLENBQUEsRUFBRTtZQUNsRSxJQUFJLEVBQUUsSUFBSTtZQUNWLFFBQVEsRUFBRSxJQUFJO1NBQ2QsQ0FBQyxDQUFDO1FBR0gsdUJBQWtCLEdBQUcsSUFBSSxZQUFZLEVBQVcsQ0FBQztLQW9DakQ7SUE3REE7Ozs7O1NBS0s7SUFDTCxJQUNJLFVBQVUsQ0FBQyxLQUEwQztRQUN4RCxLQUFLLEdBQUcscUJBQXFCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDckMsSUFBSSxJQUFJLENBQUMsV0FBVyxLQUFLLEtBQUssRUFBRSxDQUFDO1lBQ2hDLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBQ3pCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3ZDLENBQUM7SUFDRixDQUFDO0lBRUQsSUFBSSxVQUFVO1FBQ2IsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQ3pCLENBQUM7SUFVRCxJQUFZLE9BQU87UUFDbEIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsT0FBTyxDQUFDO0lBQ3pDLENBQUM7SUFFRCxRQUFRO1FBQ1AsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVEOzs7U0FHSztJQUNHLGNBQWMsQ0FBQyxLQUFjO1FBQ3BDLElBQUksSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsS0FBSyxLQUFLLEVBQUUsQ0FBQztZQUNyRCxPQUFPLEtBQUssQ0FBQztRQUNkLENBQUM7UUFFRCxJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ1gsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1lBQzlDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDcEMsQ0FBQzthQUFNLENBQUM7WUFDUCxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxDQUFDLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7WUFDN0MsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyQyxDQUFDO1FBRUQsT0FBTyxJQUFJLENBQUM7SUFDYixDQUFDO0lBRUQsZ0VBQWdFO0lBQ2hFLGdCQUFnQixDQUFDLFVBQW1CO1FBQ25DLElBQUksVUFBVSxLQUFLLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNyQyxJQUFJLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQztRQUMvQixDQUFDO0lBQ0YsQ0FBQzsrR0E3RFcsc0JBQXNCO21HQUF0QixzQkFBc0I7OzRGQUF0QixzQkFBc0I7a0JBSmxDLFNBQVM7bUJBQUM7b0JBQ1YsUUFBUSxFQUFFLGNBQWM7b0JBQ3hCLFVBQVUsRUFBRSxJQUFJO2lCQUNoQjs4QkFTSSxVQUFVO3NCQURiLEtBQUs7Z0JBbUJOLGtCQUFrQjtzQkFEakIsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG5cdERpcmVjdGl2ZSxcblx0SW5wdXQsXG5cdE91dHB1dCxcblx0RXZlbnRFbWl0dGVyLFxuXHRTZWxmLFxuXHRPbkluaXQsXG5cdGluamVjdFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGNvZXJjZUJvb2xlYW5Qcm9wZXJ0eSB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9jb2VyY2lvbic7XG5pbXBvcnQgeyBOZ0NvbnRyb2xEaXJlY3RpdmUgfSBmcm9tICcuLi9uZy1jb250cm9sL25nLWNvbnRyb2wuZGlyZWN0aXZlJztcblxuaW50ZXJmYWNlIERpc2FibGVkQWNjZXNzb3Ige1xuXHRzZXREaXNhYmxlZFN0YXRlKGlzRGlzYWJsZWQ6IGJvb2xlYW4pOiB2b2lkO1xufVxuXG5ARGlyZWN0aXZlKHtcblx0c2VsZWN0b3I6ICdbaXNEaXNhYmxlZF0nLFxuXHRzdGFuZGFsb25lOiB0cnVlXG59KVxuZXhwb3J0IGNsYXNzIEl1aUlzRGlzYWJsZWREaXJlY3RpdmUgaW1wbGVtZW50cyBEaXNhYmxlZEFjY2Vzc29yLCBPbkluaXQge1xuXHQvKipcblx0ICogd2hldGhlciB0aGUgY29udHJvbCBpcyBkaXNhYmxlZC5cblx0ICogW3BhcnQgb2YgSXVpSXNEaXNhYmxlZERpcmVjdGl2ZV1cblx0ICogQnkgYXNzaWduaW5nIHRoaXMgaW5wdXQgdG8gdHJ1dGh5IHZhbHVlLCBpdCBtYWtlcyBhc3NvY2lhdGVkIGZvcm1Db250cm9sIGRpc2FibGVkLlxuXHQgKiBUaGUgbmFtZSBcImlzRGlzYWJsZWRcIiBkaWZmZXJzIHRvIHRyYWRpdGlvbmFsIG5hbWluZyBcImRpc2FibGVkXCIgYmVjYXVzZSBpdCBjbGFzaGVzIHdpdGggYXR0cmlidXRlIFwiZGlzYWJsZWRcIiBvZiB0aGUgZm9ybUNvbnRyb2xcblx0ICogKi9cblx0QElucHV0KClcblx0c2V0IGlzRGlzYWJsZWQodmFsdWU6IGJvb2xlYW4gfCBzdHJpbmcgfCB1bmRlZmluZWQgfCBudWxsKSB7XG5cdFx0dmFsdWUgPSBjb2VyY2VCb29sZWFuUHJvcGVydHkodmFsdWUpO1xuXHRcdGlmICh0aGlzLl9pc0Rpc2FibGVkICE9PSB2YWx1ZSkge1xuXHRcdFx0dGhpcy5faXNEaXNhYmxlZCA9IHZhbHVlO1xuXHRcdFx0dGhpcy5oYW5kbGVEaXNhYmxlZCh0aGlzLl9pc0Rpc2FibGVkKTtcblx0XHR9XG5cdH1cblxuXHRnZXQgaXNEaXNhYmxlZCgpOiBib29sZWFuIHtcblx0XHRyZXR1cm4gdGhpcy5faXNEaXNhYmxlZDtcblx0fVxuXHRwcml2YXRlIF9pc0Rpc2FibGVkID0gZmFsc2U7XG5cdHByb3RlY3RlZCBuZ0NvbnRyb2xEaXJlY3RpdmUgPSBpbmplY3QoTmdDb250cm9sRGlyZWN0aXZlPHVua25vd24+LCB7XG5cdFx0c2VsZjogdHJ1ZSxcblx0XHRvcHRpb25hbDogdHJ1ZVxuXHR9KTtcblxuXHRAT3V0cHV0KClcblx0ZGlzYWJsZUNoYW5nZUV2ZW50ID0gbmV3IEV2ZW50RW1pdHRlcjxib29sZWFuPigpO1xuXG5cdHByaXZhdGUgZ2V0IGNvbnRyb2woKSB7XG5cdFx0cmV0dXJuIHRoaXMubmdDb250cm9sRGlyZWN0aXZlPy5jb250cm9sO1xuXHR9XG5cblx0bmdPbkluaXQoKSB7XG5cdFx0dGhpcy5oYW5kbGVEaXNhYmxlZCh0aGlzLmlzRGlzYWJsZWQpO1xuXHR9XG5cblx0Lypcblx0ICpcblx0ICogQGRvY3MtcHJpdmF0ZTogcmV0dXJucyB0cnVlLCB3aGVuIHZhbHVlIHdhcyBjaGFuZ2VkLCBvdGhlcndpc2UgLSBmYWxzZVxuXHQgKiAqL1xuXHRwcml2YXRlIGhhbmRsZURpc2FibGVkKHZhbHVlOiBib29sZWFuKTogYm9vbGVhbiB7XG5cdFx0aWYgKHRoaXMuY29udHJvbCAmJiB0aGlzLmNvbnRyb2wuZGlzYWJsZWQgPT09IHZhbHVlKSB7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXG5cdFx0aWYgKHZhbHVlKSB7XG5cdFx0XHR0aGlzLmNvbnRyb2w/LmRpc2FibGU/Lih7IGVtaXRFdmVudDogZmFsc2UgfSk7XG5cdFx0XHR0aGlzLmRpc2FibGVDaGFuZ2VFdmVudC5lbWl0KHRydWUpO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHR0aGlzLmNvbnRyb2w/LmVuYWJsZT8uKHsgZW1pdEV2ZW50OiBmYWxzZSB9KTtcblx0XHRcdHRoaXMuZGlzYWJsZUNoYW5nZUV2ZW50LmVtaXQoZmFsc2UpO1xuXHRcdH1cblxuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cblx0Ly8gcGFydCBvZiBDVkEgaGFuZGxlIHdoZW4gdXNlciBkaXNhYmxlIGNvbnRyb2wgcHJvZ3JhbW1hdGljYWxseVxuXHRzZXREaXNhYmxlZFN0YXRlKGlzRGlzYWJsZWQ6IGJvb2xlYW4pOiB2b2lkIHtcblx0XHRpZiAoaXNEaXNhYmxlZCAhPT0gdGhpcy5faXNEaXNhYmxlZCkge1xuXHRcdFx0dGhpcy5faXNEaXNhYmxlZCA9IGlzRGlzYWJsZWQ7XG5cdFx0fVxuXHR9XG59XG4iXX0=