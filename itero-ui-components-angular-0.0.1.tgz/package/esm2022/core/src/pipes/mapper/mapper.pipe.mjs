import { Pipe } from '@angular/core';
import * as i0 from "@angular/core";
export class MapperPipe {
    transform(value, callBack, ...args) {
        return callBack(value, ...args);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MapperPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.12", ngImport: i0, type: MapperPipe, isStandalone: true, name: "mapper" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: MapperPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'mapper',
                    standalone: true
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFwcGVyLnBpcGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9saWJzL3VpLWNvbXBvbmVudHMtYW5ndWxhci1wdWJsaXNoYWJsZS9jb3JlL3NyYy9waXBlcy9tYXBwZXIvbWFwcGVyLnBpcGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLElBQUksRUFBaUIsTUFBTSxlQUFlLENBQUM7O0FBV3BELE1BQU0sT0FBTyxVQUFVO0lBQ3RCLFNBQVMsQ0FDUixLQUFRLEVBQ1IsUUFBNkIsRUFDN0IsR0FBRyxJQUFPO1FBRVYsT0FBTyxRQUFRLENBQUMsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUM7SUFDakMsQ0FBQzsrR0FQVyxVQUFVOzZHQUFWLFVBQVU7OzRGQUFWLFVBQVU7a0JBSnRCLElBQUk7bUJBQUM7b0JBQ0wsSUFBSSxFQUFFLFFBQVE7b0JBQ2QsVUFBVSxFQUFFLElBQUk7aUJBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGlwZSwgUGlwZVRyYW5zZm9ybSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG50eXBlIG1hcHBlckZ1bmM8ViA9IGFueSwgVCBleHRlbmRzIGFueVtdID0gYW55W10sIFUgPSBhbnk+ID0gKFxuXHR2YWx1ZTogVixcblx0Li4uYXJnczogVFxuKSA9PiBVO1xuXG5AUGlwZSh7XG5cdG5hbWU6ICdtYXBwZXInLFxuXHRzdGFuZGFsb25lOiB0cnVlXG59KVxuZXhwb3J0IGNsYXNzIE1hcHBlclBpcGUgaW1wbGVtZW50cyBQaXBlVHJhbnNmb3JtIHtcblx0dHJhbnNmb3JtPFYgPSBhbnksIFQgZXh0ZW5kcyBhbnlbXSA9IGFueVtdLCBVID0gYW55Pihcblx0XHR2YWx1ZTogVixcblx0XHRjYWxsQmFjazogbWFwcGVyRnVuYzxWLCBULCBVPixcblx0XHQuLi5hcmdzOiBUXG5cdCk6IFJldHVyblR5cGU8bWFwcGVyRnVuYzxWLCBULCBVPj4ge1xuXHRcdHJldHVybiBjYWxsQmFjayh2YWx1ZSwgLi4uYXJncyk7XG5cdH1cbn1cbiJdfQ==