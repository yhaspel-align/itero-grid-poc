import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, EventEmitter, forwardRef, inject, InjectionToken, Input, Output, Self, ViewChild } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule, NG_VALUE_ACCESSOR, Validators } from '@angular/forms';
import { CdkConnectedOverlay, Overlay, OverlayModule } from '@angular/cdk/overlay';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { Subject } from 'rxjs';
import { IuiErrorStateMatcherDirective, IuiIsDisabledDirective, NgControlDirective } from '@itero/ui-components-angular/core';
import { CalendarIconComponent } from '@itero/ui-components-angular/icons';
import { IuiDateInputComponent } from '@itero/ui-components-angular/date-input';
import { IuiCalendarComponent } from './iui-calendar.component';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "@angular/cdk/overlay";
let nextUniqueId = 0;
/** Scroll strategy token — block scrolling while calendar is open. */
export const IUI_DATE_PICKER_SCROLL_STRATEGY = new InjectionToken('iui-date-picker-scroll-strategy', {
    providedIn: 'root',
    factory: () => {
        const overlay = inject(Overlay);
        return () => overlay.scrollStrategies.block();
    }
});
const DATE_PICKER_POSITIONS = [
    { originX: 'end', originY: 'bottom', overlayX: 'end', overlayY: 'top', offsetY: 4 },
    { originX: 'end', originY: 'top', overlayX: 'end', overlayY: 'bottom', offsetY: -4 },
    { originX: 'start', originY: 'bottom', overlayX: 'start', overlayY: 'top', offsetY: 4 },
    { originX: 'start', originY: 'top', overlayX: 'start', overlayY: 'bottom', offsetY: -4 }
];
export class IuiDatePickerComponent {
    set id(value) { this._id = value; }
    get id() { return this._id; }
    get required() {
        return this._required ?? this.ngControlDirective.control?.hasValidator(Validators.required) ?? false;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
    }
    constructor(_cdr, _elementRef, ngControlDirective, errorStateMatcherDirective, isDisabledDirective) {
        this._cdr = _cdr;
        this._elementRef = _elementRef;
        this.ngControlDirective = ngControlDirective;
        this.errorStateMatcherDirective = errorStateMatcherDirective;
        this.isDisabledDirective = isDisabledDirective;
        this.type = 'single';
        this.layerSet = 'set-01';
        this.label = '';
        this.placeholder = 'mm.dd.yyyy';
        this.placeholderEnd = 'mm.dd.yyyy';
        this.dateFormat = 'MM/dd/yyyy';
        this.name = '';
        this.showLabel = true;
        this.showHelper = true;
        this.showExplainer = false; // reserved, no-op
        this.skeleton = false;
        this.minDate = null;
        this.maxDate = null;
        this.valueChange = new EventEmitter();
        this.calendarOpen = new EventEmitter();
        this.calendarClose = new EventEmitter();
        // Internal state
        this._panelOpen = false;
        this._focused = false;
        this._hovered = false;
        this._singleValue = null;
        this._rangeValue = null;
        this._selectingEnd = false; // ranged: true after start is set, waiting for end
        this._hoverDate = null;
        this._calendarView = 'day';
        this._displayMonth = new Date();
        this._displayValue = '';
        this._displayStartValue = '';
        this._displayEndValue = '';
        this._positions = DATE_PICKER_POSITIONS;
        this._id = `iui-date-picker-${nextUniqueId++}`;
        this._onChange = () => { };
        this._onTouched = () => { };
        this._destroy = new Subject();
        const factory = inject(IUI_DATE_PICKER_SCROLL_STRATEGY);
        this._scrollStrategy = factory();
        this._datePipe = new DatePipe('en-US');
    }
    get disabled() {
        return this.isDisabledDirective.isDisabled;
    }
    get _errorState() {
        return this.errorStateMatcherDirective.errorState;
    }
    get _empty() {
        if (this.type === 'single')
            return this._singleValue == null;
        return this._rangeValue == null || (this._rangeValue.start == null && this._rangeValue.end == null);
    }
    // ── Calendar open / close ────────────────────────────────────────────────
    open() {
        if (this.disabled || this._panelOpen)
            return;
        this._panelOpen = true;
        this._calendarView = 'day';
        // Set display month to currently selected date
        if (this.type === 'single' && this._singleValue) {
            this._displayMonth = new Date(this._singleValue);
        }
        else if (this.type === 'ranged' && this._rangeValue?.start) {
            this._displayMonth = new Date(this._rangeValue.start);
        }
        else {
            this._displayMonth = new Date();
        }
        this._displayMonth.setDate(1);
        this.calendarOpen.emit();
        this._cdr.markForCheck();
    }
    close() {
        if (!this._panelOpen)
            return;
        this._panelOpen = false;
        this._selectingEnd = false;
        this._hoverDate = null;
        this._onTouched();
        this.calendarClose.emit();
        this._cdr.markForCheck();
        // Return focus to host element
        this._elementRef.nativeElement.focus();
    }
    toggle() {
        if (this._panelOpen)
            this.close();
        else
            this.open();
    }
    // ── Calendar events ──────────────────────────────────────────────────────
    _onDateSelected(date) {
        if (this.type === 'single') {
            this._singleValue = date;
            this._displayValue = this._formatDate(date);
            this._onChange(date);
            this.valueChange.emit(date);
            this.close();
        }
        else {
            // Ranged mode
            if (!this._selectingEnd || this._rangeValue?.start == null) {
                // Setting start date
                const d = new Date(date);
                d.setHours(0, 0, 0, 0);
                this._rangeValue = { start: d, end: null };
                this._displayStartValue = this._formatDate(d);
                this._displayEndValue = '';
                this._selectingEnd = true;
                this._hoverDate = null;
            }
            else {
                // Setting end date
                const d = new Date(date);
                d.setHours(0, 0, 0, 0);
                const start = this._rangeValue.start;
                if (d < start) {
                    // New date is before start — swap
                    this._rangeValue = { start: d, end: start };
                    this._displayStartValue = this._formatDate(d);
                    this._displayEndValue = this._formatDate(start);
                }
                else {
                    this._rangeValue = { start, end: d };
                    this._displayStartValue = this._formatDate(start);
                    this._displayEndValue = this._formatDate(d);
                }
                this._onChange(this._rangeValue);
                this.valueChange.emit(this._rangeValue);
                this.close();
            }
        }
        this._cdr.markForCheck();
    }
    _onViewChange(view) {
        this._calendarView = view;
        this._cdr.markForCheck();
    }
    _onDisplayMonthChange(month) {
        this._displayMonth = month;
        this._cdr.markForCheck();
    }
    _onDateHover(date) {
        this._hoverDate = date;
        this._cdr.markForCheck();
    }
    // ── Trigger field events ─────────────────────────────────────────────────
    _onFocus() {
        this._focused = true;
        this._cdr.markForCheck();
    }
    _onBlur() {
        this._focused = false;
        this._cdr.markForCheck();
    }
    _onMouseEnter() {
        this._hovered = true;
        this._cdr.markForCheck();
    }
    _onMouseLeave() {
        this._hovered = false;
        this._cdr.markForCheck();
    }
    _onStartFocus() {
        this._focused = true;
        this._selectingEnd = false;
        this._cdr.markForCheck();
    }
    _onEndFocus() {
        this._focused = true;
        this._selectingEnd = true;
        this._cdr.markForCheck();
    }
    _onTextInput(value) {
        if (!value) {
            this._singleValue = null;
            this._onChange(null);
            this.valueChange.emit(null);
        }
        else {
            const parsed = this._parseDate(value);
            if (parsed) {
                this._singleValue = parsed;
                this._onChange(parsed);
                this.valueChange.emit(parsed);
            }
        }
        this._cdr.markForCheck();
    }
    _onStartTextInput(event) {
        const value = event.target.value;
        const parsed = value ? this._parseDate(value) : null;
        if (!this._rangeValue)
            this._rangeValue = { start: null, end: null };
        this._rangeValue = { ...this._rangeValue, start: parsed };
        this._emitRangeIfComplete();
        this._cdr.markForCheck();
    }
    _onEndTextInput(event) {
        const value = event.target.value;
        const parsed = value ? this._parseDate(value) : null;
        if (!this._rangeValue)
            this._rangeValue = { start: null, end: null };
        this._rangeValue = { ...this._rangeValue, end: parsed };
        this._emitRangeIfComplete();
        this._cdr.markForCheck();
    }
    _emitRangeIfComplete() {
        if (this._rangeValue?.start && this._rangeValue?.end) {
            this._onChange(this._rangeValue);
            this.valueChange.emit(this._rangeValue);
        }
        else if (!this._rangeValue?.start && !this._rangeValue?.end) {
            this._onChange(null);
            this.valueChange.emit(null);
        }
    }
    _handleKeydown(event) {
        if (event.key === 'Escape') {
            this.close();
        }
        else if (!this._panelOpen && (event.key === 'Enter' || event.key === ' ' || event.key === 'ArrowDown')) {
            this.open();
            event.preventDefault();
        }
    }
    // ── Date formatting / parsing ────────────────────────────────────────────
    _formatDate(date) {
        return this._datePipe.transform(date, this.dateFormat) ?? '';
    }
    _parseDate(text) {
        if (!text)
            return null;
        // Simple parser: supports MM/dd/yyyy and MM.dd.yyyy and yyyy-MM-dd
        const cleaned = text.replace(/\./g, '/').replace(/-/g, '/');
        const parts = cleaned.split('/');
        if (parts.length === 3) {
            const [a, b, c] = parts.map(Number);
            // Determine format based on dateFormat
            let month, day, year;
            if (this.dateFormat.startsWith('yyyy')) {
                year = a;
                month = b - 1;
                day = c;
            }
            else {
                month = a - 1;
                day = b;
                year = c;
            }
            if (!isNaN(month) && !isNaN(day) && !isNaN(year) && year > 1000) {
                const d = new Date(year, month, day);
                if (d.getFullYear() === year && d.getMonth() === month && d.getDate() === day) {
                    return d;
                }
            }
        }
        return null;
    }
    // ── ControlValueAccessor ─────────────────────────────────────────────────
    writeValue(value) {
        if (this.type === 'single') {
            if (value instanceof Date) {
                this._singleValue = value;
                this._displayValue = this._formatDate(value);
            }
            else if (typeof value === 'string') {
                const parsed = this._parseDate(value);
                this._singleValue = parsed;
                this._displayValue = parsed ? this._formatDate(parsed) : '';
            }
            else {
                this._singleValue = null;
                this._displayValue = '';
            }
        }
        else {
            const range = value;
            this._rangeValue = range ?? null;
            this._displayStartValue = range?.start ? this._formatDate(range.start) : '';
            this._displayEndValue = range?.end ? this._formatDate(range.end) : '';
        }
        this._cdr.markForCheck();
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabledDirective.setDisabledState(isDisabled);
        this._cdr.markForCheck();
    }
    ngOnDestroy() {
        this._destroy.next();
        this._destroy.complete();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiDatePickerComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i0.ElementRef }, { token: i1.NgControlDirective, self: true }, { token: i1.IuiErrorStateMatcherDirective, self: true }, { token: i1.IuiIsDisabledDirective, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.12", type: IuiDatePickerComponent, isStandalone: true, selector: "iui-date-picker", inputs: { id: "id", type: "type", layerSet: "layerSet", label: "label", placeholder: "placeholder", placeholderEnd: "placeholderEnd", dateFormat: "dateFormat", name: "name", showLabel: "showLabel", showHelper: "showHelper", showExplainer: "showExplainer", skeleton: "skeleton", minDate: "minDate", maxDate: "maxDate", required: "required" }, outputs: { valueChange: "valueChange", calendarOpen: "calendarOpen", calendarClose: "calendarClose" }, host: { properties: { "class.iui-date-picker_type_ranged": "type === \"ranged\"", "class.iui-date-picker_layer-set-02": "layerSet === \"set-02\"", "class.iui-date-picker_open": "_panelOpen", "class.iui-date-picker_focused": "_focused", "class.iui-date-picker_hovered": "_hovered", "class.iui-date-picker_selected": "!_empty", "class.iui-date-picker_disabled": "disabled", "class.iui-date-picker_invalid": "_errorState", "class.iui-date-picker_skeleton": "skeleton", "class.iui-date-picker_required": "required", "attr.id": "id", "attr.data-testid": "id" }, classAttribute: "iui-date-picker" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => IuiDatePickerComponent),
                multi: true
            }
        ], viewQueries: [{ propertyName: "_overlayDir", first: true, predicate: CdkConnectedOverlay, descendants: true }], hostDirectives: [{ directive: i1.NgControlDirective }, { directive: i1.IuiErrorStateMatcherDirective, inputs: ["errorStateMatcher", "errorStateMatcher"] }, { directive: i1.IuiIsDisabledDirective, inputs: ["isDisabled", "isDisabled"], outputs: ["disableChangeEvent", "disableChangeEvent"] }], ngImport: i0, template: "@if (skeleton) {\r\n\t<div class=\"iui-date-picker__skeleton-label\" *ngIf=\"showLabel\"></div>\r\n\t<div class=\"iui-date-picker__skeleton-field\"></div>\r\n\t<div class=\"iui-date-picker__skeleton-helper\" *ngIf=\"showHelper\"></div>\r\n} @else {\r\n\t<!-- Label row (optional) -->\r\n\t@if (showLabel && label) {\r\n\t\t<div class=\"iui-date-picker__label-row\">\r\n\t\t\t<label class=\"iui-date-picker__label\">\r\n\t\t\t\t{{ label }}<span class=\"iui-date-picker__required\" *ngIf=\"required\">*</span>\r\n\t\t\t</label>\r\n\t\t</div>\r\n\t}\r\n\r\n\t<!-- Trigger field wrapper (overlay origin) -->\r\n\t<div\r\n\t\tclass=\"iui-date-picker__field-wrap\"\r\n\t\tcdk-overlay-origin\r\n\t\t#overlayOrigin=\"cdkOverlayOrigin\"\r\n\t\t(click)=\"open()\"\r\n\t\t(mouseenter)=\"_onMouseEnter()\"\r\n\t\t(mouseleave)=\"_onMouseLeave()\"\r\n\t\t(keydown)=\"_handleKeydown($event)\"\r\n\t>\r\n\t\t@if (type === 'single') {\r\n\t\t\t<!-- Single mode: use iui-date-input with calendar icon suffix -->\r\n\t\t\t<iui-date-input\r\n\t\t\t\tclass=\"iui-date-picker__date-input\"\r\n\t\t\t\t[showLabel]=\"false\"\r\n\t\t\t\t[showHelper]=\"false\"\r\n\t\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t\t[isDisabled]=\"disabled\"\r\n\t\t\t\t[ngModel]=\"_displayValue\"\r\n\t\t\t\t(ngModelChange)=\"_onTextInput($event)\"\r\n\t\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t>\r\n\t\t\t\t<button\r\n\t\t\t\t\tiuiSuffix\r\n\t\t\t\t\tclass=\"iui-date-picker__calendar-btn\"\r\n\t\t\t\t\ttype=\"button\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\taria-label=\"Open calendar\"\r\n\t\t\t\t\t(click)=\"toggle(); $event.stopPropagation()\"\r\n\t\t\t\t>\r\n\t\t\t\t\t<iui-calendar-icon></iui-calendar-icon>\r\n\t\t\t\t</button>\r\n\t\t\t</iui-date-input>\r\n\t\t}\r\n\r\n\t\t@if (type === 'ranged') {\r\n\t\t\t<!-- Ranged mode: custom dual-input field -->\r\n\t\t\t<div class=\"iui-date-picker__range-field\">\r\n\t\t\t\t<input\r\n\t\t\t\t\tclass=\"iui-date-picker__range-input\"\r\n\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\t[value]=\"_displayStartValue\"\r\n\t\t\t\t\taria-label=\"Start date\"\r\n\t\t\t\t\t(input)=\"_onStartTextInput($event)\"\r\n\t\t\t\t\t(focus)=\"_onStartFocus()\"\r\n\t\t\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t\t\t(click)=\"open()\"\r\n\t\t\t\t/>\r\n\t\t\t\t<span class=\"iui-date-picker__range-divider\" aria-hidden=\"true\">\u2192</span>\r\n\t\t\t\t<input\r\n\t\t\t\t\tclass=\"iui-date-picker__range-input\"\r\n\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t[placeholder]=\"placeholderEnd\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\t[value]=\"_displayEndValue\"\r\n\t\t\t\t\taria-label=\"End date\"\r\n\t\t\t\t\t(input)=\"_onEndTextInput($event)\"\r\n\t\t\t\t\t(focus)=\"_onEndFocus()\"\r\n\t\t\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t\t\t(click)=\"open()\"\r\n\t\t\t\t/>\r\n\t\t\t\t<button\r\n\t\t\t\t\tclass=\"iui-date-picker__calendar-btn\"\r\n\t\t\t\t\ttype=\"button\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\taria-label=\"Open calendar\"\r\n\t\t\t\t\t(click)=\"toggle(); $event.stopPropagation()\"\r\n\t\t\t\t>\r\n\t\t\t\t\t<iui-calendar-icon></iui-calendar-icon>\r\n\t\t\t\t</button>\r\n\t\t\t</div>\r\n\t\t}\r\n\t</div>\r\n\r\n\t<!-- CDK overlay for calendar panel -->\r\n\t<ng-template\r\n\t\tcdk-connected-overlay\r\n\t\tcdkConnectedOverlayHasBackdrop\r\n\t\tcdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\r\n\t\t[cdkConnectedOverlayOrigin]=\"overlayOrigin\"\r\n\t\t[cdkConnectedOverlayOpen]=\"_panelOpen\"\r\n\t\t[cdkConnectedOverlayPositions]=\"_positions\"\r\n\t\t[cdkConnectedOverlayScrollStrategy]=\"_scrollStrategy\"\r\n\t\t[cdkConnectedOverlayWidth]=\"324\"\r\n\t\t(backdropClick)=\"close()\"\r\n\t\t(detach)=\"close()\"\r\n\t>\r\n\t\t<iui-calendar\r\n\t\t\t[type]=\"type\"\r\n\t\t\t[currentView]=\"_calendarView\"\r\n\t\t\t[displayMonth]=\"_displayMonth\"\r\n\t\t\t[selectedDate]=\"type === 'single' ? _singleValue : null\"\r\n\t\t\t[selectedRange]=\"type === 'ranged' ? _rangeValue : null\"\r\n\t\t\t[hoverDate]=\"_hoverDate\"\r\n\t\t\t[minDate]=\"minDate\"\r\n\t\t\t[maxDate]=\"maxDate\"\r\n\t\t\t(dateSelected)=\"_onDateSelected($event)\"\r\n\t\t\t(viewChange)=\"_onViewChange($event)\"\r\n\t\t\t(displayMonthChange)=\"_onDisplayMonthChange($event)\"\r\n\t\t\t(dateHover)=\"_onDateHover($event)\"\r\n\t\t></iui-calendar>\r\n\t</ng-template>\r\n\r\n\t<!-- Helper / Error row (optional) -->\r\n\t@if (showHelper) {\r\n\t\t<div class=\"iui-date-picker__helper-row\">\r\n\t\t\t@if (_errorState) {\r\n\t\t\t\t<span class=\"iui-date-picker__error\">\r\n\t\t\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t\t\t</span>\r\n\t\t\t} @else {\r\n\t\t\t\t<span class=\"iui-date-picker__helper\">\r\n\t\t\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t\t\t</span>\r\n\t\t\t}\r\n\t\t</div>\r\n\t}\r\n}\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{--iui-date-picker-field-bg: var(--iui-background-subtle-01);--iui-date-picker-field-bg-02: var(--iui-background-subtle-02);--iui-date-picker-field-hover-bg: var(--iui-background-subtle-hover);--iui-date-picker-label-color: var(--iui-text-secondary);--iui-date-picker-value-color: var(--iui-text-primary);--iui-date-picker-placeholder-color: var(--iui-text-tertiary);--iui-date-picker-helper-color: var(--iui-text-secondary);--iui-date-picker-error-color: var(--iui-text-error);--iui-date-picker-disabled-color: var(--iui-text-disabled);--iui-date-picker-focus-border: var(--iui-border-focus);--iui-date-picker-error-border: var(--iui-border-error);--iui-date-picker-divider-color: var(--iui-text-tertiary);--iui-date-picker-required-color: var(--iui-text-error);--iui-date-picker-skeleton-bg: var(--iui-background-highlight-gray);display:flex;flex-direction:column;min-width:200px;max-width:100%}:host.iui-date-picker_layer-set-02{--iui-date-picker-field-bg: var(--iui-date-picker-field-bg-02)}.iui-date-picker__label-row{display:flex;align-items:flex-start;padding-bottom:8px}.iui-date-picker__label{font:var(--iui-tp-label-01-font);color:var(--iui-date-picker-label-color);flex:1;min-width:0}.iui-date-picker__required{color:var(--iui-date-picker-required-color);margin-left:4px}:host.iui-date-picker_disabled .iui-date-picker__label{color:var(--iui-date-picker-disabled-color)}.iui-date-picker__field-wrap{position:relative;width:100%}:host:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input{width:100%}:host:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input ::ng-deep .iui-date-input__field{background:var(--iui-date-picker-field-bg);cursor:pointer}:host:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input:hover ::ng-deep .iui-date-input__field{background:linear-gradient(var(--iui-date-picker-field-hover-bg),var(--iui-date-picker-field-hover-bg)),var(--iui-date-picker-field-bg)}:host.iui-date-picker_open:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input ::ng-deep .iui-date-input__field{border-color:var(--iui-date-picker-focus-border)}:host.iui-date-picker_invalid:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input ::ng-deep .iui-date-input__field{border-color:var(--iui-date-picker-error-border)}:host.iui-date-picker_disabled .iui-date-picker__field-wrap{pointer-events:none}.iui-date-picker__range-field{display:flex;align-items:center;gap:8px;height:44px;padding:12px 16px;background:var(--iui-date-picker-field-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:pointer}:host.iui-date-picker_type_ranged:hover .iui-date-picker__range-field:not(.iui-date-picker_open .iui-date-picker__range-field){background:linear-gradient(var(--iui-date-picker-field-hover-bg),var(--iui-date-picker-field-hover-bg)),var(--iui-date-picker-field-bg)}:host.iui-date-picker_open.iui-date-picker_type_ranged .iui-date-picker__range-field,:host.iui-date-picker_focused.iui-date-picker_type_ranged .iui-date-picker__range-field{border-color:var(--iui-date-picker-focus-border)}:host.iui-date-picker_invalid.iui-date-picker_type_ranged .iui-date-picker__range-field{border-color:var(--iui-date-picker-error-border)}.iui-date-picker__range-input{font:var(--iui-tp-body-01-font);background:transparent;border:none;outline:none;color:var(--iui-date-picker-value-color);flex:1;min-width:0;padding:0;cursor:pointer}.iui-date-picker__range-input::placeholder{color:var(--iui-date-picker-placeholder-color)}.iui-date-picker__range-input:disabled{color:var(--iui-date-picker-disabled-color);cursor:default}.iui-date-picker__range-divider{font:var(--iui-tp-body-01-font);color:var(--iui-date-picker-divider-color);flex-shrink:0;-webkit-user-select:none;user-select:none}.iui-date-picker__calendar-btn{background:transparent;border:none;padding:0;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:var(--iui-date-picker-value-color);outline:none}.iui-date-picker__calendar-btn:disabled{cursor:default;color:var(--iui-date-picker-disabled-color)}.iui-date-picker__helper-row{padding-top:8px}.iui-date-picker__helper{font:var(--iui-tp-label-01-font);color:var(--iui-date-picker-helper-color)}.iui-date-picker__error{font:var(--iui-tp-label-01-font);color:var(--iui-date-picker-error-color)}:host.iui-date-picker_disabled .iui-date-picker__helper{color:var(--iui-date-picker-disabled-color)}.iui-date-picker__skeleton-label{width:80px;height:8px;background:var(--iui-date-picker-skeleton-bg);border-radius:2px;margin-bottom:8px}.iui-date-picker__skeleton-field{width:100%;height:44px;background:var(--iui-date-picker-skeleton-bg);border-radius:var(--iui-border-radius-medium)}.iui-date-picker__skeleton-helper{width:120px;height:8px;background:var(--iui-date-picker-skeleton-bg);border-radius:2px;margin-top:8px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i4.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: i4.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "component", type: IuiDateInputComponent, selector: "iui-date-input", inputs: ["id", "size", "layerSet", "label", "placeholder", "name", "showLabel", "showHelper", "showExplainer", "skeleton", "required"], outputs: ["valueChange"] }, { kind: "component", type: IuiCalendarComponent, selector: "iui-calendar", inputs: ["type", "currentView", "displayMonth", "selectedDate", "selectedRange", "hoverDate", "minDate", "maxDate"], outputs: ["dateSelected", "viewChange", "displayMonthChange", "dateHover"] }, { kind: "component", type: CalendarIconComponent, selector: "iui-calendar-icon" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IuiDatePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'iui-date-picker', standalone: true, imports: [
                        CommonModule,
                        FormsModule,
                        OverlayModule,
                        IuiDateInputComponent,
                        IuiCalendarComponent,
                        CalendarIconComponent,
                        DatePipe
                    ], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => IuiDatePickerComponent),
                            multi: true
                        }
                    ], hostDirectives: [
                        NgControlDirective,
                        {
                            directive: IuiErrorStateMatcherDirective,
                            inputs: ['errorStateMatcher']
                        },
                        {
                            directive: IuiIsDisabledDirective,
                            inputs: ['isDisabled'],
                            outputs: ['disableChangeEvent']
                        }
                    ], host: {
                        class: 'iui-date-picker',
                        '[class.iui-date-picker_type_ranged]': 'type === "ranged"',
                        '[class.iui-date-picker_layer-set-02]': 'layerSet === "set-02"',
                        '[class.iui-date-picker_open]': '_panelOpen',
                        '[class.iui-date-picker_focused]': '_focused',
                        '[class.iui-date-picker_hovered]': '_hovered',
                        '[class.iui-date-picker_selected]': '!_empty',
                        '[class.iui-date-picker_disabled]': 'disabled',
                        '[class.iui-date-picker_invalid]': '_errorState',
                        '[class.iui-date-picker_skeleton]': 'skeleton',
                        '[class.iui-date-picker_required]': 'required',
                        '[attr.id]': 'id',
                        '[attr.data-testid]': 'id'
                    }, template: "@if (skeleton) {\r\n\t<div class=\"iui-date-picker__skeleton-label\" *ngIf=\"showLabel\"></div>\r\n\t<div class=\"iui-date-picker__skeleton-field\"></div>\r\n\t<div class=\"iui-date-picker__skeleton-helper\" *ngIf=\"showHelper\"></div>\r\n} @else {\r\n\t<!-- Label row (optional) -->\r\n\t@if (showLabel && label) {\r\n\t\t<div class=\"iui-date-picker__label-row\">\r\n\t\t\t<label class=\"iui-date-picker__label\">\r\n\t\t\t\t{{ label }}<span class=\"iui-date-picker__required\" *ngIf=\"required\">*</span>\r\n\t\t\t</label>\r\n\t\t</div>\r\n\t}\r\n\r\n\t<!-- Trigger field wrapper (overlay origin) -->\r\n\t<div\r\n\t\tclass=\"iui-date-picker__field-wrap\"\r\n\t\tcdk-overlay-origin\r\n\t\t#overlayOrigin=\"cdkOverlayOrigin\"\r\n\t\t(click)=\"open()\"\r\n\t\t(mouseenter)=\"_onMouseEnter()\"\r\n\t\t(mouseleave)=\"_onMouseLeave()\"\r\n\t\t(keydown)=\"_handleKeydown($event)\"\r\n\t>\r\n\t\t@if (type === 'single') {\r\n\t\t\t<!-- Single mode: use iui-date-input with calendar icon suffix -->\r\n\t\t\t<iui-date-input\r\n\t\t\t\tclass=\"iui-date-picker__date-input\"\r\n\t\t\t\t[showLabel]=\"false\"\r\n\t\t\t\t[showHelper]=\"false\"\r\n\t\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t\t[isDisabled]=\"disabled\"\r\n\t\t\t\t[ngModel]=\"_displayValue\"\r\n\t\t\t\t(ngModelChange)=\"_onTextInput($event)\"\r\n\t\t\t\t(focus)=\"_onFocus()\"\r\n\t\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t>\r\n\t\t\t\t<button\r\n\t\t\t\t\tiuiSuffix\r\n\t\t\t\t\tclass=\"iui-date-picker__calendar-btn\"\r\n\t\t\t\t\ttype=\"button\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\taria-label=\"Open calendar\"\r\n\t\t\t\t\t(click)=\"toggle(); $event.stopPropagation()\"\r\n\t\t\t\t>\r\n\t\t\t\t\t<iui-calendar-icon></iui-calendar-icon>\r\n\t\t\t\t</button>\r\n\t\t\t</iui-date-input>\r\n\t\t}\r\n\r\n\t\t@if (type === 'ranged') {\r\n\t\t\t<!-- Ranged mode: custom dual-input field -->\r\n\t\t\t<div class=\"iui-date-picker__range-field\">\r\n\t\t\t\t<input\r\n\t\t\t\t\tclass=\"iui-date-picker__range-input\"\r\n\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t[placeholder]=\"placeholder\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\t[value]=\"_displayStartValue\"\r\n\t\t\t\t\taria-label=\"Start date\"\r\n\t\t\t\t\t(input)=\"_onStartTextInput($event)\"\r\n\t\t\t\t\t(focus)=\"_onStartFocus()\"\r\n\t\t\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t\t\t(click)=\"open()\"\r\n\t\t\t\t/>\r\n\t\t\t\t<span class=\"iui-date-picker__range-divider\" aria-hidden=\"true\">\u2192</span>\r\n\t\t\t\t<input\r\n\t\t\t\t\tclass=\"iui-date-picker__range-input\"\r\n\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t[placeholder]=\"placeholderEnd\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\t[value]=\"_displayEndValue\"\r\n\t\t\t\t\taria-label=\"End date\"\r\n\t\t\t\t\t(input)=\"_onEndTextInput($event)\"\r\n\t\t\t\t\t(focus)=\"_onEndFocus()\"\r\n\t\t\t\t\t(blur)=\"_onBlur()\"\r\n\t\t\t\t\t(click)=\"open()\"\r\n\t\t\t\t/>\r\n\t\t\t\t<button\r\n\t\t\t\t\tclass=\"iui-date-picker__calendar-btn\"\r\n\t\t\t\t\ttype=\"button\"\r\n\t\t\t\t\t[disabled]=\"disabled\"\r\n\t\t\t\t\taria-label=\"Open calendar\"\r\n\t\t\t\t\t(click)=\"toggle(); $event.stopPropagation()\"\r\n\t\t\t\t>\r\n\t\t\t\t\t<iui-calendar-icon></iui-calendar-icon>\r\n\t\t\t\t</button>\r\n\t\t\t</div>\r\n\t\t}\r\n\t</div>\r\n\r\n\t<!-- CDK overlay for calendar panel -->\r\n\t<ng-template\r\n\t\tcdk-connected-overlay\r\n\t\tcdkConnectedOverlayHasBackdrop\r\n\t\tcdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\r\n\t\t[cdkConnectedOverlayOrigin]=\"overlayOrigin\"\r\n\t\t[cdkConnectedOverlayOpen]=\"_panelOpen\"\r\n\t\t[cdkConnectedOverlayPositions]=\"_positions\"\r\n\t\t[cdkConnectedOverlayScrollStrategy]=\"_scrollStrategy\"\r\n\t\t[cdkConnectedOverlayWidth]=\"324\"\r\n\t\t(backdropClick)=\"close()\"\r\n\t\t(detach)=\"close()\"\r\n\t>\r\n\t\t<iui-calendar\r\n\t\t\t[type]=\"type\"\r\n\t\t\t[currentView]=\"_calendarView\"\r\n\t\t\t[displayMonth]=\"_displayMonth\"\r\n\t\t\t[selectedDate]=\"type === 'single' ? _singleValue : null\"\r\n\t\t\t[selectedRange]=\"type === 'ranged' ? _rangeValue : null\"\r\n\t\t\t[hoverDate]=\"_hoverDate\"\r\n\t\t\t[minDate]=\"minDate\"\r\n\t\t\t[maxDate]=\"maxDate\"\r\n\t\t\t(dateSelected)=\"_onDateSelected($event)\"\r\n\t\t\t(viewChange)=\"_onViewChange($event)\"\r\n\t\t\t(displayMonthChange)=\"_onDisplayMonthChange($event)\"\r\n\t\t\t(dateHover)=\"_onDateHover($event)\"\r\n\t\t></iui-calendar>\r\n\t</ng-template>\r\n\r\n\t<!-- Helper / Error row (optional) -->\r\n\t@if (showHelper) {\r\n\t\t<div class=\"iui-date-picker__helper-row\">\r\n\t\t\t@if (_errorState) {\r\n\t\t\t\t<span class=\"iui-date-picker__error\">\r\n\t\t\t\t\t<ng-content select=\"[iui-error]\"></ng-content>\r\n\t\t\t\t</span>\r\n\t\t\t} @else {\r\n\t\t\t\t<span class=\"iui-date-picker__helper\">\r\n\t\t\t\t\t<ng-content select=\"[iui-hint]\"></ng-content>\r\n\t\t\t\t</span>\r\n\t\t\t}\r\n\t\t</div>\r\n\t}\r\n}\r\n", styles: [":host,:host *,:host :before,:host :after{box-sizing:border-box}:host{--iui-date-picker-field-bg: var(--iui-background-subtle-01);--iui-date-picker-field-bg-02: var(--iui-background-subtle-02);--iui-date-picker-field-hover-bg: var(--iui-background-subtle-hover);--iui-date-picker-label-color: var(--iui-text-secondary);--iui-date-picker-value-color: var(--iui-text-primary);--iui-date-picker-placeholder-color: var(--iui-text-tertiary);--iui-date-picker-helper-color: var(--iui-text-secondary);--iui-date-picker-error-color: var(--iui-text-error);--iui-date-picker-disabled-color: var(--iui-text-disabled);--iui-date-picker-focus-border: var(--iui-border-focus);--iui-date-picker-error-border: var(--iui-border-error);--iui-date-picker-divider-color: var(--iui-text-tertiary);--iui-date-picker-required-color: var(--iui-text-error);--iui-date-picker-skeleton-bg: var(--iui-background-highlight-gray);display:flex;flex-direction:column;min-width:200px;max-width:100%}:host.iui-date-picker_layer-set-02{--iui-date-picker-field-bg: var(--iui-date-picker-field-bg-02)}.iui-date-picker__label-row{display:flex;align-items:flex-start;padding-bottom:8px}.iui-date-picker__label{font:var(--iui-tp-label-01-font);color:var(--iui-date-picker-label-color);flex:1;min-width:0}.iui-date-picker__required{color:var(--iui-date-picker-required-color);margin-left:4px}:host.iui-date-picker_disabled .iui-date-picker__label{color:var(--iui-date-picker-disabled-color)}.iui-date-picker__field-wrap{position:relative;width:100%}:host:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input{width:100%}:host:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input ::ng-deep .iui-date-input__field{background:var(--iui-date-picker-field-bg);cursor:pointer}:host:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input:hover ::ng-deep .iui-date-input__field{background:linear-gradient(var(--iui-date-picker-field-hover-bg),var(--iui-date-picker-field-hover-bg)),var(--iui-date-picker-field-bg)}:host.iui-date-picker_open:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input ::ng-deep .iui-date-input__field{border-color:var(--iui-date-picker-focus-border)}:host.iui-date-picker_invalid:not(.iui-date-picker_type_ranged) .iui-date-picker__date-input ::ng-deep .iui-date-input__field{border-color:var(--iui-date-picker-error-border)}:host.iui-date-picker_disabled .iui-date-picker__field-wrap{pointer-events:none}.iui-date-picker__range-field{display:flex;align-items:center;gap:8px;height:44px;padding:12px 16px;background:var(--iui-date-picker-field-bg);border:1px solid transparent;border-radius:var(--iui-border-radius-medium);transition:border-color .2s ease-out;cursor:pointer}:host.iui-date-picker_type_ranged:hover .iui-date-picker__range-field:not(.iui-date-picker_open .iui-date-picker__range-field){background:linear-gradient(var(--iui-date-picker-field-hover-bg),var(--iui-date-picker-field-hover-bg)),var(--iui-date-picker-field-bg)}:host.iui-date-picker_open.iui-date-picker_type_ranged .iui-date-picker__range-field,:host.iui-date-picker_focused.iui-date-picker_type_ranged .iui-date-picker__range-field{border-color:var(--iui-date-picker-focus-border)}:host.iui-date-picker_invalid.iui-date-picker_type_ranged .iui-date-picker__range-field{border-color:var(--iui-date-picker-error-border)}.iui-date-picker__range-input{font:var(--iui-tp-body-01-font);background:transparent;border:none;outline:none;color:var(--iui-date-picker-value-color);flex:1;min-width:0;padding:0;cursor:pointer}.iui-date-picker__range-input::placeholder{color:var(--iui-date-picker-placeholder-color)}.iui-date-picker__range-input:disabled{color:var(--iui-date-picker-disabled-color);cursor:default}.iui-date-picker__range-divider{font:var(--iui-tp-body-01-font);color:var(--iui-date-picker-divider-color);flex-shrink:0;-webkit-user-select:none;user-select:none}.iui-date-picker__calendar-btn{background:transparent;border:none;padding:0;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;color:var(--iui-date-picker-value-color);outline:none}.iui-date-picker__calendar-btn:disabled{cursor:default;color:var(--iui-date-picker-disabled-color)}.iui-date-picker__helper-row{padding-top:8px}.iui-date-picker__helper{font:var(--iui-tp-label-01-font);color:var(--iui-date-picker-helper-color)}.iui-date-picker__error{font:var(--iui-tp-label-01-font);color:var(--iui-date-picker-error-color)}:host.iui-date-picker_disabled .iui-date-picker__helper{color:var(--iui-date-picker-disabled-color)}.iui-date-picker__skeleton-label{width:80px;height:8px;background:var(--iui-date-picker-skeleton-bg);border-radius:2px;margin-bottom:8px}.iui-date-picker__skeleton-field{width:100%;height:44px;background:var(--iui-date-picker-skeleton-bg);border-radius:var(--iui-border-radius-medium)}.iui-date-picker__skeleton-helper{width:120px;height:8px;background:var(--iui-date-picker-skeleton-bg);border-radius:2px;margin-top:8px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i0.ElementRef }, { type: i1.NgControlDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiErrorStateMatcherDirective, decorators: [{
                    type: Self
                }] }, { type: i1.IuiIsDisabledDirective, decorators: [{
                    type: Self
                }] }], propDecorators: { _overlayDir: [{
                type: ViewChild,
                args: [CdkConnectedOverlay]
            }], id: [{
                type: Input
            }], type: [{
                type: Input
            }], layerSet: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], placeholderEnd: [{
                type: Input
            }], dateFormat: [{
                type: Input
            }], name: [{
                type: Input
            }], showLabel: [{
                type: Input
            }], showHelper: [{
                type: Input
            }], showExplainer: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], minDate: [{
                type: Input
            }], maxDate: [{
                type: Input
            }], required: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], calendarOpen: [{
                type: Output
            }], calendarClose: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXVpLWRhdGUtcGlja2VyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL2xpYnMvdWktY29tcG9uZW50cy1hbmd1bGFyLXB1Ymxpc2hhYmxlL2RhdGUtcGlja2VyL3NyYy9pdWktZGF0ZS1waWNrZXIuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvZGF0ZS1waWNrZXIvc3JjL2l1aS1kYXRlLXBpY2tlci5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ04sdUJBQXVCLEVBQ3ZCLGlCQUFpQixFQUNqQixTQUFTLEVBQ1QsVUFBVSxFQUNWLFlBQVksRUFDWixVQUFVLEVBQ1YsTUFBTSxFQUNOLGNBQWMsRUFDZCxLQUFLLEVBRUwsTUFBTSxFQUNOLElBQUksRUFDSixTQUFTLEVBQ1QsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFlBQVksRUFBRSxRQUFRLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUN6RCxPQUFPLEVBQUUsV0FBVyxFQUFFLGlCQUFpQixFQUF3QixVQUFVLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUNsRyxPQUFPLEVBQUUsbUJBQW1CLEVBQXFCLE9BQU8sRUFBRSxhQUFhLEVBQWtCLE1BQU0sc0JBQXNCLENBQUM7QUFDdEgsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDOUQsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUMvQixPQUFPLEVBQ04sNkJBQTZCLEVBQzdCLHNCQUFzQixFQUN0QixrQkFBa0IsRUFDbEIsTUFBTSxtQ0FBbUMsQ0FBQztBQUMzQyxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxvQ0FBb0MsQ0FBQztBQUMzRSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSx5Q0FBeUMsQ0FBQztBQUNoRixPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQzs7Ozs7O0FBR2hFLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztBQUVyQixzRUFBc0U7QUFDdEUsTUFBTSxDQUFDLE1BQU0sK0JBQStCLEdBQUcsSUFBSSxjQUFjLENBQ2hFLGlDQUFpQyxFQUNqQztJQUNDLFVBQVUsRUFBRSxNQUFNO0lBQ2xCLE9BQU8sRUFBRSxHQUFHLEVBQUU7UUFDYixNQUFNLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDaEMsT0FBTyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxFQUFFLENBQUM7SUFDL0MsQ0FBQztDQUNELENBQ0QsQ0FBQztBQUVGLE1BQU0scUJBQXFCLEdBQXdCO0lBQ2xELEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFO0lBQ25GLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUU7SUFDcEYsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7SUFDdkYsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRTtDQUN4RixDQUFDO0FBb0RGLE1BQU0sT0FBTyxzQkFBc0I7SUFHbEMsSUFDSSxFQUFFLENBQUMsS0FBYSxJQUFJLElBQUksQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUMzQyxJQUFJLEVBQUUsS0FBYSxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBZ0JyQyxJQUNJLFFBQVE7UUFDWCxPQUFPLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEtBQUssQ0FBQztJQUN0RyxDQUFDO0lBQ0QsSUFBSSxRQUFRLENBQUMsS0FBMEM7UUFDdEQsSUFBSSxDQUFDLFNBQVMsR0FBRyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBOEJELFlBQ1MsSUFBdUIsRUFDdkIsV0FBdUIsRUFDYixrQkFBK0QsRUFDL0QsMEJBQXlELEVBQ3pELG1CQUEyQztRQUpyRCxTQUFJLEdBQUosSUFBSSxDQUFtQjtRQUN2QixnQkFBVyxHQUFYLFdBQVcsQ0FBWTtRQUNiLHVCQUFrQixHQUFsQixrQkFBa0IsQ0FBNkM7UUFDL0QsK0JBQTBCLEdBQTFCLDBCQUEwQixDQUErQjtRQUN6RCx3QkFBbUIsR0FBbkIsbUJBQW1CLENBQXdCO1FBdkRyRCxTQUFJLEdBQW1CLFFBQVEsQ0FBQztRQUNoQyxhQUFRLEdBQXVCLFFBQVEsQ0FBQztRQUN4QyxVQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ1gsZ0JBQVcsR0FBRyxZQUFZLENBQUM7UUFDM0IsbUJBQWMsR0FBRyxZQUFZLENBQUM7UUFDOUIsZUFBVSxHQUFHLFlBQVksQ0FBQztRQUMxQixTQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ1YsY0FBUyxHQUFHLElBQUksQ0FBQztRQUNqQixlQUFVLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLGtCQUFhLEdBQUcsS0FBSyxDQUFDLENBQUMsa0JBQWtCO1FBQ3pDLGFBQVEsR0FBRyxLQUFLLENBQUM7UUFDakIsWUFBTyxHQUFnQixJQUFJLENBQUM7UUFDNUIsWUFBTyxHQUFnQixJQUFJLENBQUM7UUFVM0IsZ0JBQVcsR0FBRyxJQUFJLFlBQVksRUFBMkIsQ0FBQztRQUMxRCxpQkFBWSxHQUFHLElBQUksWUFBWSxFQUFRLENBQUM7UUFDeEMsa0JBQWEsR0FBRyxJQUFJLFlBQVksRUFBUSxDQUFDO1FBRW5ELGlCQUFpQjtRQUNqQixlQUFVLEdBQUcsS0FBSyxDQUFDO1FBQ25CLGFBQVEsR0FBRyxLQUFLLENBQUM7UUFDakIsYUFBUSxHQUFHLEtBQUssQ0FBQztRQUNqQixpQkFBWSxHQUFnQixJQUFJLENBQUM7UUFDakMsZ0JBQVcsR0FBcUIsSUFBSSxDQUFDO1FBQ3JDLGtCQUFhLEdBQUcsS0FBSyxDQUFDLENBQUMsbURBQW1EO1FBQzFFLGVBQVUsR0FBZ0IsSUFBSSxDQUFDO1FBQy9CLGtCQUFhLEdBQWlCLEtBQUssQ0FBQztRQUNwQyxrQkFBYSxHQUFTLElBQUksSUFBSSxFQUFFLENBQUM7UUFDakMsa0JBQWEsR0FBRyxFQUFFLENBQUM7UUFDbkIsdUJBQWtCLEdBQUcsRUFBRSxDQUFDO1FBQ3hCLHFCQUFnQixHQUFHLEVBQUUsQ0FBQztRQUViLGVBQVUsR0FBRyxxQkFBcUIsQ0FBQztRQUVwQyxRQUFHLEdBQUcsbUJBQW1CLFlBQVksRUFBRSxFQUFFLENBQUM7UUFFMUMsY0FBUyxHQUE2QyxHQUFHLEVBQUUsR0FBRSxDQUFDLENBQUM7UUFDL0QsZUFBVSxHQUFlLEdBQUcsRUFBRSxHQUFFLENBQUMsQ0FBQztRQUd2QixhQUFRLEdBQUcsSUFBSSxPQUFPLEVBQVEsQ0FBQztRQVNqRCxNQUFNLE9BQU8sR0FBRyxNQUFNLENBQUMsK0JBQStCLENBQUMsQ0FBQztRQUN4RCxJQUFJLENBQUMsZUFBZSxHQUFHLE9BQU8sRUFBRSxDQUFDO1FBQ2pDLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUVELElBQUksUUFBUTtRQUNYLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFVBQVUsQ0FBQztJQUM1QyxDQUFDO0lBRUQsSUFBSSxXQUFXO1FBQ2QsT0FBTyxJQUFJLENBQUMsMEJBQTBCLENBQUMsVUFBVSxDQUFDO0lBQ25ELENBQUM7SUFFRCxJQUFJLE1BQU07UUFDVCxJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssUUFBUTtZQUFFLE9BQU8sSUFBSSxDQUFDLFlBQVksSUFBSSxJQUFJLENBQUM7UUFDN0QsT0FBTyxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQztJQUNyRyxDQUFDO0lBRUQsNEVBQTRFO0lBRTVFLElBQUk7UUFDSCxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLFVBQVU7WUFBRSxPQUFPO1FBQzdDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBQzNCLCtDQUErQztRQUMvQyxJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUNqRCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNsRCxDQUFDO2FBQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFLEtBQUssRUFBRSxDQUFDO1lBQzlELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN2RCxDQUFDO2FBQU0sQ0FBQztZQUNQLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUNqQyxDQUFDO1FBQ0QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDOUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxLQUFLO1FBQ0osSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVO1lBQUUsT0FBTztRQUM3QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUN4QixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztRQUMzQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztRQUN2QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3pCLCtCQUErQjtRQUMvQixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUN4QyxDQUFDO0lBRUQsTUFBTTtRQUNMLElBQUksSUFBSSxDQUFDLFVBQVU7WUFBRSxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7O1lBQzdCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNsQixDQUFDO0lBRUQsNEVBQTRFO0lBRTVFLGVBQWUsQ0FBQyxJQUFVO1FBQ3pCLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxRQUFRLEVBQUUsQ0FBQztZQUM1QixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztZQUN6QixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDNUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNyQixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM1QixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNQLGNBQWM7WUFDZCxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFLEtBQUssSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDNUQscUJBQXFCO2dCQUNyQixNQUFNLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDekIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDdkIsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxDQUFDO2dCQUMzQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDOUMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztnQkFDM0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQzFCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1lBQ3hCLENBQUM7aUJBQU0sQ0FBQztnQkFDUCxtQkFBbUI7Z0JBQ25CLE1BQU0sQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN6QixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUN2QixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBWSxDQUFDLEtBQU0sQ0FBQztnQkFDdkMsSUFBSSxDQUFDLEdBQUcsS0FBSyxFQUFFLENBQUM7b0JBQ2Ysa0NBQWtDO29CQUNsQyxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQUM7b0JBQzVDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUM5QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDakQsQ0FBQztxQkFBTSxDQUFDO29CQUNQLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDO29CQUNyQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDbEQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzdDLENBQUM7Z0JBQ0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDeEMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2QsQ0FBQztRQUNGLENBQUM7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxhQUFhLENBQUMsSUFBa0I7UUFDL0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7UUFDMUIsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQscUJBQXFCLENBQUMsS0FBVztRQUNoQyxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztRQUMzQixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxZQUFZLENBQUMsSUFBaUI7UUFDN0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7UUFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsNEVBQTRFO0lBRTVFLFFBQVE7UUFDUCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztRQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxPQUFPO1FBQ04sSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsYUFBYTtRQUNaLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELGFBQWE7UUFDWixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztRQUN0QixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxhQUFhO1FBQ1osSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFDckIsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7UUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsV0FBVztRQUNWLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQzFCLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELFlBQVksQ0FBQyxLQUFhO1FBQ3pCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNaLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDckIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDN0IsQ0FBQzthQUFNLENBQUM7WUFDUCxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3RDLElBQUksTUFBTSxFQUFFLENBQUM7Z0JBQ1osSUFBSSxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3ZCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQy9CLENBQUM7UUFDRixDQUFDO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsaUJBQWlCLENBQUMsS0FBWTtRQUM3QixNQUFNLEtBQUssR0FBSSxLQUFLLENBQUMsTUFBMkIsQ0FBQyxLQUFLLENBQUM7UUFDdkQsTUFBTSxNQUFNLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDckQsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXO1lBQUUsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxDQUFDO1FBQ3JFLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxDQUFDO1FBQzFELElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELGVBQWUsQ0FBQyxLQUFZO1FBQzNCLE1BQU0sS0FBSyxHQUFJLEtBQUssQ0FBQyxNQUEyQixDQUFDLEtBQUssQ0FBQztRQUN2RCxNQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUNyRCxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVc7WUFBRSxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLENBQUM7UUFDckUsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLENBQUM7UUFDeEQsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRU8sb0JBQW9CO1FBQzNCLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxLQUFLLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxHQUFHLEVBQUUsQ0FBQztZQUN0RCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUNqQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDekMsQ0FBQzthQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsR0FBRyxFQUFFLENBQUM7WUFDL0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNyQixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM3QixDQUFDO0lBQ0YsQ0FBQztJQUVELGNBQWMsQ0FBQyxLQUFvQjtRQUNsQyxJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDNUIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2QsQ0FBQzthQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsS0FBSyxPQUFPLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxHQUFHLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxXQUFXLENBQUMsRUFBRSxDQUFDO1lBQzFHLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNaLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN4QixDQUFDO0lBQ0YsQ0FBQztJQUVELDRFQUE0RTtJQUU1RSxXQUFXLENBQUMsSUFBVTtRQUNyQixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQzlELENBQUM7SUFFRCxVQUFVLENBQUMsSUFBWTtRQUN0QixJQUFJLENBQUMsSUFBSTtZQUFFLE9BQU8sSUFBSSxDQUFDO1FBQ3ZCLG1FQUFtRTtRQUNuRSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzVELE1BQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDakMsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3hCLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDcEMsdUNBQXVDO1lBQ3ZDLElBQUksS0FBYSxFQUFFLEdBQVcsRUFBRSxJQUFZLENBQUM7WUFDN0MsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO2dCQUN4QyxJQUFJLEdBQUcsQ0FBQyxDQUFDO2dCQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7WUFDbEMsQ0FBQztpQkFBTSxDQUFDO2dCQUNQLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7Z0JBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQztZQUNsQyxDQUFDO1lBQ0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLENBQUM7Z0JBQ2pFLE1BQU0sQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ3JDLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxLQUFLLElBQUksSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUUsS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDL0UsT0FBTyxDQUFDLENBQUM7Z0JBQ1YsQ0FBQztZQUNGLENBQUM7UUFDRixDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDYixDQUFDO0lBRUQsNEVBQTRFO0lBRTVFLFVBQVUsQ0FBQyxLQUE4QjtRQUN4QyxJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDNUIsSUFBSSxLQUFLLFlBQVksSUFBSSxFQUFFLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO2dCQUMxQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDOUMsQ0FBQztpQkFBTSxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRSxDQUFDO2dCQUN0QyxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN0QyxJQUFJLENBQUMsWUFBWSxHQUFHLE1BQU0sQ0FBQztnQkFDM0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztZQUM3RCxDQUFDO2lCQUFNLENBQUM7Z0JBQ1AsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7Z0JBQ3pCLElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO1lBQ3pCLENBQUM7UUFDRixDQUFDO2FBQU0sQ0FBQztZQUNQLE1BQU0sS0FBSyxHQUFHLEtBQXlCLENBQUM7WUFDeEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLElBQUksSUFBSSxDQUFDO1lBQ2pDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQzVFLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQ3ZFLENBQUM7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxFQUE0QztRQUM1RCxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztJQUNyQixDQUFDO0lBRUQsaUJBQWlCLENBQUMsRUFBYztRQUMvQixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsVUFBbUI7UUFDbkMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3RELElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELFdBQVc7UUFDVixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDMUIsQ0FBQzsrR0E3VVcsc0JBQXNCO21HQUF0QixzQkFBc0IsNmtDQW5DdkI7WUFDVjtnQkFDQyxPQUFPLEVBQUUsaUJBQWlCO2dCQUMxQixXQUFXLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLHNCQUFzQixDQUFDO2dCQUNyRCxLQUFLLEVBQUUsSUFBSTthQUNYO1NBQ0QsdUVBOEJVLG1CQUFtQixvVkN0Ry9CLCt2SkF1SUEsdTVKRGhGRSxZQUFZLGtJQUNaLFdBQVcsOFZBQ1gsYUFBYSwyckNBQ2IscUJBQXFCLDZOQUNyQixvQkFBb0IsMFBBQ3BCLHFCQUFxQjs7NEZBeUNWLHNCQUFzQjtrQkFsRGxDLFNBQVM7K0JBQ0MsaUJBQWlCLGNBQ2YsSUFBSSxXQUNQO3dCQUNSLFlBQVk7d0JBQ1osV0FBVzt3QkFDWCxhQUFhO3dCQUNiLHFCQUFxQjt3QkFDckIsb0JBQW9CO3dCQUNwQixxQkFBcUI7d0JBQ3JCLFFBQVE7cUJBQ1IsbUJBR2dCLHVCQUF1QixDQUFDLE1BQU0sYUFDcEM7d0JBQ1Y7NEJBQ0MsT0FBTyxFQUFFLGlCQUFpQjs0QkFDMUIsV0FBVyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsdUJBQXVCLENBQUM7NEJBQ3JELEtBQUssRUFBRSxJQUFJO3lCQUNYO3FCQUNELGtCQUNlO3dCQUNmLGtCQUFrQjt3QkFDbEI7NEJBQ0MsU0FBUyxFQUFFLDZCQUE2Qjs0QkFDeEMsTUFBTSxFQUFFLENBQUMsbUJBQW1CLENBQUM7eUJBQzdCO3dCQUNEOzRCQUNDLFNBQVMsRUFBRSxzQkFBc0I7NEJBQ2pDLE1BQU0sRUFBRSxDQUFDLFlBQVksQ0FBQzs0QkFDdEIsT0FBTyxFQUFFLENBQUMsb0JBQW9CLENBQUM7eUJBQy9CO3FCQUNELFFBQ0s7d0JBQ0wsS0FBSyxFQUFFLGlCQUFpQjt3QkFDeEIscUNBQXFDLEVBQUUsbUJBQW1CO3dCQUMxRCxzQ0FBc0MsRUFBRSx1QkFBdUI7d0JBQy9ELDhCQUE4QixFQUFFLFlBQVk7d0JBQzVDLGlDQUFpQyxFQUFFLFVBQVU7d0JBQzdDLGlDQUFpQyxFQUFFLFVBQVU7d0JBQzdDLGtDQUFrQyxFQUFFLFNBQVM7d0JBQzdDLGtDQUFrQyxFQUFFLFVBQVU7d0JBQzlDLGlDQUFpQyxFQUFFLGFBQWE7d0JBQ2hELGtDQUFrQyxFQUFFLFVBQVU7d0JBQzlDLGtDQUFrQyxFQUFFLFVBQVU7d0JBQzlDLFdBQVcsRUFBRSxJQUFJO3dCQUNqQixvQkFBb0IsRUFBRSxJQUFJO3FCQUMxQjs7MEJBOERDLElBQUk7OzBCQUNKLElBQUk7OzBCQUNKLElBQUk7eUNBN0RvQyxXQUFXO3NCQUFwRCxTQUFTO3VCQUFDLG1CQUFtQjtnQkFHMUIsRUFBRTtzQkFETCxLQUFLO2dCQUlHLElBQUk7c0JBQVosS0FBSztnQkFDRyxRQUFRO3NCQUFoQixLQUFLO2dCQUNHLEtBQUs7c0JBQWIsS0FBSztnQkFDRyxXQUFXO3NCQUFuQixLQUFLO2dCQUNHLGNBQWM7c0JBQXRCLEtBQUs7Z0JBQ0csVUFBVTtzQkFBbEIsS0FBSztnQkFDRyxJQUFJO3NCQUFaLEtBQUs7Z0JBQ0csU0FBUztzQkFBakIsS0FBSztnQkFDRyxVQUFVO3NCQUFsQixLQUFLO2dCQUNHLGFBQWE7c0JBQXJCLEtBQUs7Z0JBQ0csUUFBUTtzQkFBaEIsS0FBSztnQkFDRyxPQUFPO3NCQUFmLEtBQUs7Z0JBQ0csT0FBTztzQkFBZixLQUFLO2dCQUdGLFFBQVE7c0JBRFgsS0FBSztnQkFRSSxXQUFXO3NCQUFwQixNQUFNO2dCQUNHLFlBQVk7c0JBQXJCLE1BQU07Z0JBQ0csYUFBYTtzQkFBdEIsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcblx0Q2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXHJcblx0Q2hhbmdlRGV0ZWN0b3JSZWYsXHJcblx0Q29tcG9uZW50LFxyXG5cdEVsZW1lbnRSZWYsXHJcblx0RXZlbnRFbWl0dGVyLFxyXG5cdGZvcndhcmRSZWYsXHJcblx0aW5qZWN0LFxyXG5cdEluamVjdGlvblRva2VuLFxyXG5cdElucHV0LFxyXG5cdE9uRGVzdHJveSxcclxuXHRPdXRwdXQsXHJcblx0U2VsZixcclxuXHRWaWV3Q2hpbGRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ29tbW9uTW9kdWxlLCBEYXRlUGlwZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IEZvcm1zTW9kdWxlLCBOR19WQUxVRV9BQ0NFU1NPUiwgQ29udHJvbFZhbHVlQWNjZXNzb3IsIFZhbGlkYXRvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7IENka0Nvbm5lY3RlZE92ZXJsYXksIENvbm5lY3RlZFBvc2l0aW9uLCBPdmVybGF5LCBPdmVybGF5TW9kdWxlLCBTY3JvbGxTdHJhdGVneSB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9vdmVybGF5JztcclxuaW1wb3J0IHsgY29lcmNlQm9vbGVhblByb3BlcnR5IH0gZnJvbSAnQGFuZ3VsYXIvY2RrL2NvZXJjaW9uJztcclxuaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQge1xyXG5cdEl1aUVycm9yU3RhdGVNYXRjaGVyRGlyZWN0aXZlLFxyXG5cdEl1aUlzRGlzYWJsZWREaXJlY3RpdmUsXHJcblx0TmdDb250cm9sRGlyZWN0aXZlXHJcbn0gZnJvbSAnQGl0ZXJvL3VpLWNvbXBvbmVudHMtYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ2FsZW5kYXJJY29uQ29tcG9uZW50IH0gZnJvbSAnQGl0ZXJvL3VpLWNvbXBvbmVudHMtYW5ndWxhci9pY29ucyc7XHJcbmltcG9ydCB7IEl1aURhdGVJbnB1dENvbXBvbmVudCB9IGZyb20gJ0BpdGVyby91aS1jb21wb25lbnRzLWFuZ3VsYXIvZGF0ZS1pbnB1dCc7XHJcbmltcG9ydCB7IEl1aUNhbGVuZGFyQ29tcG9uZW50IH0gZnJvbSAnLi9pdWktY2FsZW5kYXIuY29tcG9uZW50JztcclxuaW1wb3J0IHsgQ2FsZW5kYXJWaWV3LCBEYXRlUGlja2VyTGF5ZXJTZXQsIERhdGVQaWNrZXJUeXBlLCBEYXRlUmFuZ2UgfSBmcm9tICcuL3R5cGVzJztcclxuXHJcbmxldCBuZXh0VW5pcXVlSWQgPSAwO1xyXG5cclxuLyoqIFNjcm9sbCBzdHJhdGVneSB0b2tlbiDigJQgYmxvY2sgc2Nyb2xsaW5nIHdoaWxlIGNhbGVuZGFyIGlzIG9wZW4uICovXHJcbmV4cG9ydCBjb25zdCBJVUlfREFURV9QSUNLRVJfU0NST0xMX1NUUkFURUdZID0gbmV3IEluamVjdGlvblRva2VuPCgpID0+IFNjcm9sbFN0cmF0ZWd5PihcclxuXHQnaXVpLWRhdGUtcGlja2VyLXNjcm9sbC1zdHJhdGVneScsXHJcblx0e1xyXG5cdFx0cHJvdmlkZWRJbjogJ3Jvb3QnLFxyXG5cdFx0ZmFjdG9yeTogKCkgPT4ge1xyXG5cdFx0XHRjb25zdCBvdmVybGF5ID0gaW5qZWN0KE92ZXJsYXkpO1xyXG5cdFx0XHRyZXR1cm4gKCkgPT4gb3ZlcmxheS5zY3JvbGxTdHJhdGVnaWVzLmJsb2NrKCk7XHJcblx0XHR9XHJcblx0fVxyXG4pO1xyXG5cclxuY29uc3QgREFURV9QSUNLRVJfUE9TSVRJT05TOiBDb25uZWN0ZWRQb3NpdGlvbltdID0gW1xyXG5cdHsgb3JpZ2luWDogJ2VuZCcsIG9yaWdpblk6ICdib3R0b20nLCBvdmVybGF5WDogJ2VuZCcsIG92ZXJsYXlZOiAndG9wJywgb2Zmc2V0WTogNCB9LFxyXG5cdHsgb3JpZ2luWDogJ2VuZCcsIG9yaWdpblk6ICd0b3AnLCBvdmVybGF5WDogJ2VuZCcsIG92ZXJsYXlZOiAnYm90dG9tJywgb2Zmc2V0WTogLTQgfSxcclxuXHR7IG9yaWdpblg6ICdzdGFydCcsIG9yaWdpblk6ICdib3R0b20nLCBvdmVybGF5WDogJ3N0YXJ0Jywgb3ZlcmxheVk6ICd0b3AnLCBvZmZzZXRZOiA0IH0sXHJcblx0eyBvcmlnaW5YOiAnc3RhcnQnLCBvcmlnaW5ZOiAndG9wJywgb3ZlcmxheVg6ICdzdGFydCcsIG92ZXJsYXlZOiAnYm90dG9tJywgb2Zmc2V0WTogLTQgfVxyXG5dO1xyXG5cclxuQENvbXBvbmVudCh7XHJcblx0c2VsZWN0b3I6ICdpdWktZGF0ZS1waWNrZXInLFxyXG5cdHN0YW5kYWxvbmU6IHRydWUsXHJcblx0aW1wb3J0czogW1xyXG5cdFx0Q29tbW9uTW9kdWxlLFxyXG5cdFx0Rm9ybXNNb2R1bGUsXHJcblx0XHRPdmVybGF5TW9kdWxlLFxyXG5cdFx0SXVpRGF0ZUlucHV0Q29tcG9uZW50LFxyXG5cdFx0SXVpQ2FsZW5kYXJDb21wb25lbnQsXHJcblx0XHRDYWxlbmRhckljb25Db21wb25lbnQsXHJcblx0XHREYXRlUGlwZVxyXG5cdF0sXHJcblx0dGVtcGxhdGVVcmw6ICcuL2l1aS1kYXRlLXBpY2tlci5jb21wb25lbnQuaHRtbCcsXHJcblx0c3R5bGVVcmxzOiBbJy4vaXVpLWRhdGUtcGlja2VyLmNvbXBvbmVudC5zY3NzJ10sXHJcblx0Y2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXHJcblx0cHJvdmlkZXJzOiBbXHJcblx0XHR7XHJcblx0XHRcdHByb3ZpZGU6IE5HX1ZBTFVFX0FDQ0VTU09SLFxyXG5cdFx0XHR1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBJdWlEYXRlUGlja2VyQ29tcG9uZW50KSxcclxuXHRcdFx0bXVsdGk6IHRydWVcclxuXHRcdH1cclxuXHRdLFxyXG5cdGhvc3REaXJlY3RpdmVzOiBbXHJcblx0XHROZ0NvbnRyb2xEaXJlY3RpdmUsXHJcblx0XHR7XHJcblx0XHRcdGRpcmVjdGl2ZTogSXVpRXJyb3JTdGF0ZU1hdGNoZXJEaXJlY3RpdmUsXHJcblx0XHRcdGlucHV0czogWydlcnJvclN0YXRlTWF0Y2hlciddXHJcblx0XHR9LFxyXG5cdFx0e1xyXG5cdFx0XHRkaXJlY3RpdmU6IEl1aUlzRGlzYWJsZWREaXJlY3RpdmUsXHJcblx0XHRcdGlucHV0czogWydpc0Rpc2FibGVkJ10sXHJcblx0XHRcdG91dHB1dHM6IFsnZGlzYWJsZUNoYW5nZUV2ZW50J11cclxuXHRcdH1cclxuXHRdLFxyXG5cdGhvc3Q6IHtcclxuXHRcdGNsYXNzOiAnaXVpLWRhdGUtcGlja2VyJyxcclxuXHRcdCdbY2xhc3MuaXVpLWRhdGUtcGlja2VyX3R5cGVfcmFuZ2VkXSc6ICd0eXBlID09PSBcInJhbmdlZFwiJyxcclxuXHRcdCdbY2xhc3MuaXVpLWRhdGUtcGlja2VyX2xheWVyLXNldC0wMl0nOiAnbGF5ZXJTZXQgPT09IFwic2V0LTAyXCInLFxyXG5cdFx0J1tjbGFzcy5pdWktZGF0ZS1waWNrZXJfb3Blbl0nOiAnX3BhbmVsT3BlbicsXHJcblx0XHQnW2NsYXNzLml1aS1kYXRlLXBpY2tlcl9mb2N1c2VkXSc6ICdfZm9jdXNlZCcsXHJcblx0XHQnW2NsYXNzLml1aS1kYXRlLXBpY2tlcl9ob3ZlcmVkXSc6ICdfaG92ZXJlZCcsXHJcblx0XHQnW2NsYXNzLml1aS1kYXRlLXBpY2tlcl9zZWxlY3RlZF0nOiAnIV9lbXB0eScsXHJcblx0XHQnW2NsYXNzLml1aS1kYXRlLXBpY2tlcl9kaXNhYmxlZF0nOiAnZGlzYWJsZWQnLFxyXG5cdFx0J1tjbGFzcy5pdWktZGF0ZS1waWNrZXJfaW52YWxpZF0nOiAnX2Vycm9yU3RhdGUnLFxyXG5cdFx0J1tjbGFzcy5pdWktZGF0ZS1waWNrZXJfc2tlbGV0b25dJzogJ3NrZWxldG9uJyxcclxuXHRcdCdbY2xhc3MuaXVpLWRhdGUtcGlja2VyX3JlcXVpcmVkXSc6ICdyZXF1aXJlZCcsXHJcblx0XHQnW2F0dHIuaWRdJzogJ2lkJyxcclxuXHRcdCdbYXR0ci5kYXRhLXRlc3RpZF0nOiAnaWQnXHJcblx0fVxyXG59KVxyXG5leHBvcnQgY2xhc3MgSXVpRGF0ZVBpY2tlckNvbXBvbmVudCBpbXBsZW1lbnRzIENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBPbkRlc3Ryb3kge1xyXG5cdEBWaWV3Q2hpbGQoQ2RrQ29ubmVjdGVkT3ZlcmxheSkgcHJvdGVjdGVkIF9vdmVybGF5RGlyITogQ2RrQ29ubmVjdGVkT3ZlcmxheTtcclxuXHJcblx0QElucHV0KClcclxuXHRzZXQgaWQodmFsdWU6IHN0cmluZykgeyB0aGlzLl9pZCA9IHZhbHVlOyB9XHJcblx0Z2V0IGlkKCk6IHN0cmluZyB7IHJldHVybiB0aGlzLl9pZDsgfVxyXG5cclxuXHRASW5wdXQoKSB0eXBlOiBEYXRlUGlja2VyVHlwZSA9ICdzaW5nbGUnO1xyXG5cdEBJbnB1dCgpIGxheWVyU2V0OiBEYXRlUGlja2VyTGF5ZXJTZXQgPSAnc2V0LTAxJztcclxuXHRASW5wdXQoKSBsYWJlbCA9ICcnO1xyXG5cdEBJbnB1dCgpIHBsYWNlaG9sZGVyID0gJ21tLmRkLnl5eXknO1xyXG5cdEBJbnB1dCgpIHBsYWNlaG9sZGVyRW5kID0gJ21tLmRkLnl5eXknO1xyXG5cdEBJbnB1dCgpIGRhdGVGb3JtYXQgPSAnTU0vZGQveXl5eSc7XHJcblx0QElucHV0KCkgbmFtZSA9ICcnO1xyXG5cdEBJbnB1dCgpIHNob3dMYWJlbCA9IHRydWU7XHJcblx0QElucHV0KCkgc2hvd0hlbHBlciA9IHRydWU7XHJcblx0QElucHV0KCkgc2hvd0V4cGxhaW5lciA9IGZhbHNlOyAvLyByZXNlcnZlZCwgbm8tb3BcclxuXHRASW5wdXQoKSBza2VsZXRvbiA9IGZhbHNlO1xyXG5cdEBJbnB1dCgpIG1pbkRhdGU6IERhdGUgfCBudWxsID0gbnVsbDtcclxuXHRASW5wdXQoKSBtYXhEYXRlOiBEYXRlIHwgbnVsbCA9IG51bGw7XHJcblxyXG5cdEBJbnB1dCgpXHJcblx0Z2V0IHJlcXVpcmVkKCk6IGJvb2xlYW4ge1xyXG5cdFx0cmV0dXJuIHRoaXMuX3JlcXVpcmVkID8/IHRoaXMubmdDb250cm9sRGlyZWN0aXZlLmNvbnRyb2w/Lmhhc1ZhbGlkYXRvcihWYWxpZGF0b3JzLnJlcXVpcmVkKSA/PyBmYWxzZTtcclxuXHR9XHJcblx0c2V0IHJlcXVpcmVkKHZhbHVlOiBzdHJpbmcgfCBib29sZWFuIHwgbnVsbCB8IHVuZGVmaW5lZCkge1xyXG5cdFx0dGhpcy5fcmVxdWlyZWQgPSBjb2VyY2VCb29sZWFuUHJvcGVydHkodmFsdWUpO1xyXG5cdH1cclxuXHJcblx0QE91dHB1dCgpIHZhbHVlQ2hhbmdlID0gbmV3IEV2ZW50RW1pdHRlcjxEYXRlIHwgRGF0ZVJhbmdlIHwgbnVsbD4oKTtcclxuXHRAT3V0cHV0KCkgY2FsZW5kYXJPcGVuID0gbmV3IEV2ZW50RW1pdHRlcjx2b2lkPigpO1xyXG5cdEBPdXRwdXQoKSBjYWxlbmRhckNsb3NlID0gbmV3IEV2ZW50RW1pdHRlcjx2b2lkPigpO1xyXG5cclxuXHQvLyBJbnRlcm5hbCBzdGF0ZVxyXG5cdF9wYW5lbE9wZW4gPSBmYWxzZTtcclxuXHRfZm9jdXNlZCA9IGZhbHNlO1xyXG5cdF9ob3ZlcmVkID0gZmFsc2U7XHJcblx0X3NpbmdsZVZhbHVlOiBEYXRlIHwgbnVsbCA9IG51bGw7XHJcblx0X3JhbmdlVmFsdWU6IERhdGVSYW5nZSB8IG51bGwgPSBudWxsO1xyXG5cdF9zZWxlY3RpbmdFbmQgPSBmYWxzZTsgLy8gcmFuZ2VkOiB0cnVlIGFmdGVyIHN0YXJ0IGlzIHNldCwgd2FpdGluZyBmb3IgZW5kXHJcblx0X2hvdmVyRGF0ZTogRGF0ZSB8IG51bGwgPSBudWxsO1xyXG5cdF9jYWxlbmRhclZpZXc6IENhbGVuZGFyVmlldyA9ICdkYXknO1xyXG5cdF9kaXNwbGF5TW9udGg6IERhdGUgPSBuZXcgRGF0ZSgpO1xyXG5cdF9kaXNwbGF5VmFsdWUgPSAnJztcclxuXHRfZGlzcGxheVN0YXJ0VmFsdWUgPSAnJztcclxuXHRfZGlzcGxheUVuZFZhbHVlID0gJyc7XHJcblxyXG5cdHJlYWRvbmx5IF9wb3NpdGlvbnMgPSBEQVRFX1BJQ0tFUl9QT1NJVElPTlM7XHJcblx0cmVhZG9ubHkgX3Njcm9sbFN0cmF0ZWd5OiBTY3JvbGxTdHJhdGVneTtcclxuXHRwcml2YXRlIF9pZCA9IGBpdWktZGF0ZS1waWNrZXItJHtuZXh0VW5pcXVlSWQrK31gO1xyXG5cdHByaXZhdGUgX3JlcXVpcmVkOiBib29sZWFuIHwgdW5kZWZpbmVkO1xyXG5cdHByaXZhdGUgX29uQ2hhbmdlOiAodmFsdWU6IERhdGUgfCBEYXRlUmFuZ2UgfCBudWxsKSA9PiB2b2lkID0gKCkgPT4ge307XHJcblx0cHJpdmF0ZSBfb25Ub3VjaGVkOiAoKSA9PiB2b2lkID0gKCkgPT4ge307XHJcblx0cHJpdmF0ZSBfZGF0ZVBpcGU6IERhdGVQaXBlO1xyXG5cclxuXHRwcm90ZWN0ZWQgcmVhZG9ubHkgX2Rlc3Ryb3kgPSBuZXcgU3ViamVjdDx2b2lkPigpO1xyXG5cclxuXHRjb25zdHJ1Y3RvcihcclxuXHRcdHByaXZhdGUgX2NkcjogQ2hhbmdlRGV0ZWN0b3JSZWYsXHJcblx0XHRwcml2YXRlIF9lbGVtZW50UmVmOiBFbGVtZW50UmVmLFxyXG5cdFx0QFNlbGYoKSBwcm90ZWN0ZWQgbmdDb250cm9sRGlyZWN0aXZlOiBOZ0NvbnRyb2xEaXJlY3RpdmU8RGF0ZSB8IERhdGVSYW5nZSB8IG51bGw+LFxyXG5cdFx0QFNlbGYoKSBwcm90ZWN0ZWQgZXJyb3JTdGF0ZU1hdGNoZXJEaXJlY3RpdmU6IEl1aUVycm9yU3RhdGVNYXRjaGVyRGlyZWN0aXZlLFxyXG5cdFx0QFNlbGYoKSBwcm90ZWN0ZWQgaXNEaXNhYmxlZERpcmVjdGl2ZTogSXVpSXNEaXNhYmxlZERpcmVjdGl2ZVxyXG5cdCkge1xyXG5cdFx0Y29uc3QgZmFjdG9yeSA9IGluamVjdChJVUlfREFURV9QSUNLRVJfU0NST0xMX1NUUkFURUdZKTtcclxuXHRcdHRoaXMuX3Njcm9sbFN0cmF0ZWd5ID0gZmFjdG9yeSgpO1xyXG5cdFx0dGhpcy5fZGF0ZVBpcGUgPSBuZXcgRGF0ZVBpcGUoJ2VuLVVTJyk7XHJcblx0fVxyXG5cclxuXHRnZXQgZGlzYWJsZWQoKTogYm9vbGVhbiB7XHJcblx0XHRyZXR1cm4gdGhpcy5pc0Rpc2FibGVkRGlyZWN0aXZlLmlzRGlzYWJsZWQ7XHJcblx0fVxyXG5cclxuXHRnZXQgX2Vycm9yU3RhdGUoKTogYm9vbGVhbiB7XHJcblx0XHRyZXR1cm4gdGhpcy5lcnJvclN0YXRlTWF0Y2hlckRpcmVjdGl2ZS5lcnJvclN0YXRlO1xyXG5cdH1cclxuXHJcblx0Z2V0IF9lbXB0eSgpOiBib29sZWFuIHtcclxuXHRcdGlmICh0aGlzLnR5cGUgPT09ICdzaW5nbGUnKSByZXR1cm4gdGhpcy5fc2luZ2xlVmFsdWUgPT0gbnVsbDtcclxuXHRcdHJldHVybiB0aGlzLl9yYW5nZVZhbHVlID09IG51bGwgfHwgKHRoaXMuX3JhbmdlVmFsdWUuc3RhcnQgPT0gbnVsbCAmJiB0aGlzLl9yYW5nZVZhbHVlLmVuZCA9PSBudWxsKTtcclxuXHR9XHJcblxyXG5cdC8vIOKUgOKUgCBDYWxlbmRhciBvcGVuIC8gY2xvc2Ug4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXHJcblxyXG5cdG9wZW4oKTogdm9pZCB7XHJcblx0XHRpZiAodGhpcy5kaXNhYmxlZCB8fCB0aGlzLl9wYW5lbE9wZW4pIHJldHVybjtcclxuXHRcdHRoaXMuX3BhbmVsT3BlbiA9IHRydWU7XHJcblx0XHR0aGlzLl9jYWxlbmRhclZpZXcgPSAnZGF5JztcclxuXHRcdC8vIFNldCBkaXNwbGF5IG1vbnRoIHRvIGN1cnJlbnRseSBzZWxlY3RlZCBkYXRlXHJcblx0XHRpZiAodGhpcy50eXBlID09PSAnc2luZ2xlJyAmJiB0aGlzLl9zaW5nbGVWYWx1ZSkge1xyXG5cdFx0XHR0aGlzLl9kaXNwbGF5TW9udGggPSBuZXcgRGF0ZSh0aGlzLl9zaW5nbGVWYWx1ZSk7XHJcblx0XHR9IGVsc2UgaWYgKHRoaXMudHlwZSA9PT0gJ3JhbmdlZCcgJiYgdGhpcy5fcmFuZ2VWYWx1ZT8uc3RhcnQpIHtcclxuXHRcdFx0dGhpcy5fZGlzcGxheU1vbnRoID0gbmV3IERhdGUodGhpcy5fcmFuZ2VWYWx1ZS5zdGFydCk7XHJcblx0XHR9IGVsc2Uge1xyXG5cdFx0XHR0aGlzLl9kaXNwbGF5TW9udGggPSBuZXcgRGF0ZSgpO1xyXG5cdFx0fVxyXG5cdFx0dGhpcy5fZGlzcGxheU1vbnRoLnNldERhdGUoMSk7XHJcblx0XHR0aGlzLmNhbGVuZGFyT3Blbi5lbWl0KCk7XHJcblx0XHR0aGlzLl9jZHIubWFya0ZvckNoZWNrKCk7XHJcblx0fVxyXG5cclxuXHRjbG9zZSgpOiB2b2lkIHtcclxuXHRcdGlmICghdGhpcy5fcGFuZWxPcGVuKSByZXR1cm47XHJcblx0XHR0aGlzLl9wYW5lbE9wZW4gPSBmYWxzZTtcclxuXHRcdHRoaXMuX3NlbGVjdGluZ0VuZCA9IGZhbHNlO1xyXG5cdFx0dGhpcy5faG92ZXJEYXRlID0gbnVsbDtcclxuXHRcdHRoaXMuX29uVG91Y2hlZCgpO1xyXG5cdFx0dGhpcy5jYWxlbmRhckNsb3NlLmVtaXQoKTtcclxuXHRcdHRoaXMuX2Nkci5tYXJrRm9yQ2hlY2soKTtcclxuXHRcdC8vIFJldHVybiBmb2N1cyB0byBob3N0IGVsZW1lbnRcclxuXHRcdHRoaXMuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5mb2N1cygpO1xyXG5cdH1cclxuXHJcblx0dG9nZ2xlKCk6IHZvaWQge1xyXG5cdFx0aWYgKHRoaXMuX3BhbmVsT3BlbikgdGhpcy5jbG9zZSgpO1xyXG5cdFx0ZWxzZSB0aGlzLm9wZW4oKTtcclxuXHR9XHJcblxyXG5cdC8vIOKUgOKUgCBDYWxlbmRhciBldmVudHMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXHJcblxyXG5cdF9vbkRhdGVTZWxlY3RlZChkYXRlOiBEYXRlKTogdm9pZCB7XHJcblx0XHRpZiAodGhpcy50eXBlID09PSAnc2luZ2xlJykge1xyXG5cdFx0XHR0aGlzLl9zaW5nbGVWYWx1ZSA9IGRhdGU7XHJcblx0XHRcdHRoaXMuX2Rpc3BsYXlWYWx1ZSA9IHRoaXMuX2Zvcm1hdERhdGUoZGF0ZSk7XHJcblx0XHRcdHRoaXMuX29uQ2hhbmdlKGRhdGUpO1xyXG5cdFx0XHR0aGlzLnZhbHVlQ2hhbmdlLmVtaXQoZGF0ZSk7XHJcblx0XHRcdHRoaXMuY2xvc2UoKTtcclxuXHRcdH0gZWxzZSB7XHJcblx0XHRcdC8vIFJhbmdlZCBtb2RlXHJcblx0XHRcdGlmICghdGhpcy5fc2VsZWN0aW5nRW5kIHx8IHRoaXMuX3JhbmdlVmFsdWU/LnN0YXJ0ID09IG51bGwpIHtcclxuXHRcdFx0XHQvLyBTZXR0aW5nIHN0YXJ0IGRhdGVcclxuXHRcdFx0XHRjb25zdCBkID0gbmV3IERhdGUoZGF0ZSk7XHJcblx0XHRcdFx0ZC5zZXRIb3VycygwLCAwLCAwLCAwKTtcclxuXHRcdFx0XHR0aGlzLl9yYW5nZVZhbHVlID0geyBzdGFydDogZCwgZW5kOiBudWxsIH07XHJcblx0XHRcdFx0dGhpcy5fZGlzcGxheVN0YXJ0VmFsdWUgPSB0aGlzLl9mb3JtYXREYXRlKGQpO1xyXG5cdFx0XHRcdHRoaXMuX2Rpc3BsYXlFbmRWYWx1ZSA9ICcnO1xyXG5cdFx0XHRcdHRoaXMuX3NlbGVjdGluZ0VuZCA9IHRydWU7XHJcblx0XHRcdFx0dGhpcy5faG92ZXJEYXRlID0gbnVsbDtcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHQvLyBTZXR0aW5nIGVuZCBkYXRlXHJcblx0XHRcdFx0Y29uc3QgZCA9IG5ldyBEYXRlKGRhdGUpO1xyXG5cdFx0XHRcdGQuc2V0SG91cnMoMCwgMCwgMCwgMCk7XHJcblx0XHRcdFx0Y29uc3Qgc3RhcnQgPSB0aGlzLl9yYW5nZVZhbHVlIS5zdGFydCE7XHJcblx0XHRcdFx0aWYgKGQgPCBzdGFydCkge1xyXG5cdFx0XHRcdFx0Ly8gTmV3IGRhdGUgaXMgYmVmb3JlIHN0YXJ0IOKAlCBzd2FwXHJcblx0XHRcdFx0XHR0aGlzLl9yYW5nZVZhbHVlID0geyBzdGFydDogZCwgZW5kOiBzdGFydCB9O1xyXG5cdFx0XHRcdFx0dGhpcy5fZGlzcGxheVN0YXJ0VmFsdWUgPSB0aGlzLl9mb3JtYXREYXRlKGQpO1xyXG5cdFx0XHRcdFx0dGhpcy5fZGlzcGxheUVuZFZhbHVlID0gdGhpcy5fZm9ybWF0RGF0ZShzdGFydCk7XHJcblx0XHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRcdHRoaXMuX3JhbmdlVmFsdWUgPSB7IHN0YXJ0LCBlbmQ6IGQgfTtcclxuXHRcdFx0XHRcdHRoaXMuX2Rpc3BsYXlTdGFydFZhbHVlID0gdGhpcy5fZm9ybWF0RGF0ZShzdGFydCk7XHJcblx0XHRcdFx0XHR0aGlzLl9kaXNwbGF5RW5kVmFsdWUgPSB0aGlzLl9mb3JtYXREYXRlKGQpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHR0aGlzLl9vbkNoYW5nZSh0aGlzLl9yYW5nZVZhbHVlKTtcclxuXHRcdFx0XHR0aGlzLnZhbHVlQ2hhbmdlLmVtaXQodGhpcy5fcmFuZ2VWYWx1ZSk7XHJcblx0XHRcdFx0dGhpcy5jbG9zZSgpO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0XHR0aGlzLl9jZHIubWFya0ZvckNoZWNrKCk7XHJcblx0fVxyXG5cclxuXHRfb25WaWV3Q2hhbmdlKHZpZXc6IENhbGVuZGFyVmlldyk6IHZvaWQge1xyXG5cdFx0dGhpcy5fY2FsZW5kYXJWaWV3ID0gdmlldztcclxuXHRcdHRoaXMuX2Nkci5tYXJrRm9yQ2hlY2soKTtcclxuXHR9XHJcblxyXG5cdF9vbkRpc3BsYXlNb250aENoYW5nZShtb250aDogRGF0ZSk6IHZvaWQge1xyXG5cdFx0dGhpcy5fZGlzcGxheU1vbnRoID0gbW9udGg7XHJcblx0XHR0aGlzLl9jZHIubWFya0ZvckNoZWNrKCk7XHJcblx0fVxyXG5cclxuXHRfb25EYXRlSG92ZXIoZGF0ZTogRGF0ZSB8IG51bGwpOiB2b2lkIHtcclxuXHRcdHRoaXMuX2hvdmVyRGF0ZSA9IGRhdGU7XHJcblx0XHR0aGlzLl9jZHIubWFya0ZvckNoZWNrKCk7XHJcblx0fVxyXG5cclxuXHQvLyDilIDilIAgVHJpZ2dlciBmaWVsZCBldmVudHMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXHJcblxyXG5cdF9vbkZvY3VzKCk6IHZvaWQge1xyXG5cdFx0dGhpcy5fZm9jdXNlZCA9IHRydWU7XHJcblx0XHR0aGlzLl9jZHIubWFya0ZvckNoZWNrKCk7XHJcblx0fVxyXG5cclxuXHRfb25CbHVyKCk6IHZvaWQge1xyXG5cdFx0dGhpcy5fZm9jdXNlZCA9IGZhbHNlO1xyXG5cdFx0dGhpcy5fY2RyLm1hcmtGb3JDaGVjaygpO1xyXG5cdH1cclxuXHJcblx0X29uTW91c2VFbnRlcigpOiB2b2lkIHtcclxuXHRcdHRoaXMuX2hvdmVyZWQgPSB0cnVlO1xyXG5cdFx0dGhpcy5fY2RyLm1hcmtGb3JDaGVjaygpO1xyXG5cdH1cclxuXHJcblx0X29uTW91c2VMZWF2ZSgpOiB2b2lkIHtcclxuXHRcdHRoaXMuX2hvdmVyZWQgPSBmYWxzZTtcclxuXHRcdHRoaXMuX2Nkci5tYXJrRm9yQ2hlY2soKTtcclxuXHR9XHJcblxyXG5cdF9vblN0YXJ0Rm9jdXMoKTogdm9pZCB7XHJcblx0XHR0aGlzLl9mb2N1c2VkID0gdHJ1ZTtcclxuXHRcdHRoaXMuX3NlbGVjdGluZ0VuZCA9IGZhbHNlO1xyXG5cdFx0dGhpcy5fY2RyLm1hcmtGb3JDaGVjaygpO1xyXG5cdH1cclxuXHJcblx0X29uRW5kRm9jdXMoKTogdm9pZCB7XHJcblx0XHR0aGlzLl9mb2N1c2VkID0gdHJ1ZTtcclxuXHRcdHRoaXMuX3NlbGVjdGluZ0VuZCA9IHRydWU7XHJcblx0XHR0aGlzLl9jZHIubWFya0ZvckNoZWNrKCk7XHJcblx0fVxyXG5cclxuXHRfb25UZXh0SW5wdXQodmFsdWU6IHN0cmluZyk6IHZvaWQge1xyXG5cdFx0aWYgKCF2YWx1ZSkge1xyXG5cdFx0XHR0aGlzLl9zaW5nbGVWYWx1ZSA9IG51bGw7XHJcblx0XHRcdHRoaXMuX29uQ2hhbmdlKG51bGwpO1xyXG5cdFx0XHR0aGlzLnZhbHVlQ2hhbmdlLmVtaXQobnVsbCk7XHJcblx0XHR9IGVsc2Uge1xyXG5cdFx0XHRjb25zdCBwYXJzZWQgPSB0aGlzLl9wYXJzZURhdGUodmFsdWUpO1xyXG5cdFx0XHRpZiAocGFyc2VkKSB7XHJcblx0XHRcdFx0dGhpcy5fc2luZ2xlVmFsdWUgPSBwYXJzZWQ7XHJcblx0XHRcdFx0dGhpcy5fb25DaGFuZ2UocGFyc2VkKTtcclxuXHRcdFx0XHR0aGlzLnZhbHVlQ2hhbmdlLmVtaXQocGFyc2VkKTtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdFx0dGhpcy5fY2RyLm1hcmtGb3JDaGVjaygpO1xyXG5cdH1cclxuXHJcblx0X29uU3RhcnRUZXh0SW5wdXQoZXZlbnQ6IEV2ZW50KTogdm9pZCB7XHJcblx0XHRjb25zdCB2YWx1ZSA9IChldmVudC50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWU7XHJcblx0XHRjb25zdCBwYXJzZWQgPSB2YWx1ZSA/IHRoaXMuX3BhcnNlRGF0ZSh2YWx1ZSkgOiBudWxsO1xyXG5cdFx0aWYgKCF0aGlzLl9yYW5nZVZhbHVlKSB0aGlzLl9yYW5nZVZhbHVlID0geyBzdGFydDogbnVsbCwgZW5kOiBudWxsIH07XHJcblx0XHR0aGlzLl9yYW5nZVZhbHVlID0geyAuLi50aGlzLl9yYW5nZVZhbHVlLCBzdGFydDogcGFyc2VkIH07XHJcblx0XHR0aGlzLl9lbWl0UmFuZ2VJZkNvbXBsZXRlKCk7XHJcblx0XHR0aGlzLl9jZHIubWFya0ZvckNoZWNrKCk7XHJcblx0fVxyXG5cclxuXHRfb25FbmRUZXh0SW5wdXQoZXZlbnQ6IEV2ZW50KTogdm9pZCB7XHJcblx0XHRjb25zdCB2YWx1ZSA9IChldmVudC50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWU7XHJcblx0XHRjb25zdCBwYXJzZWQgPSB2YWx1ZSA/IHRoaXMuX3BhcnNlRGF0ZSh2YWx1ZSkgOiBudWxsO1xyXG5cdFx0aWYgKCF0aGlzLl9yYW5nZVZhbHVlKSB0aGlzLl9yYW5nZVZhbHVlID0geyBzdGFydDogbnVsbCwgZW5kOiBudWxsIH07XHJcblx0XHR0aGlzLl9yYW5nZVZhbHVlID0geyAuLi50aGlzLl9yYW5nZVZhbHVlLCBlbmQ6IHBhcnNlZCB9O1xyXG5cdFx0dGhpcy5fZW1pdFJhbmdlSWZDb21wbGV0ZSgpO1xyXG5cdFx0dGhpcy5fY2RyLm1hcmtGb3JDaGVjaygpO1xyXG5cdH1cclxuXHJcblx0cHJpdmF0ZSBfZW1pdFJhbmdlSWZDb21wbGV0ZSgpOiB2b2lkIHtcclxuXHRcdGlmICh0aGlzLl9yYW5nZVZhbHVlPy5zdGFydCAmJiB0aGlzLl9yYW5nZVZhbHVlPy5lbmQpIHtcclxuXHRcdFx0dGhpcy5fb25DaGFuZ2UodGhpcy5fcmFuZ2VWYWx1ZSk7XHJcblx0XHRcdHRoaXMudmFsdWVDaGFuZ2UuZW1pdCh0aGlzLl9yYW5nZVZhbHVlKTtcclxuXHRcdH0gZWxzZSBpZiAoIXRoaXMuX3JhbmdlVmFsdWU/LnN0YXJ0ICYmICF0aGlzLl9yYW5nZVZhbHVlPy5lbmQpIHtcclxuXHRcdFx0dGhpcy5fb25DaGFuZ2UobnVsbCk7XHJcblx0XHRcdHRoaXMudmFsdWVDaGFuZ2UuZW1pdChudWxsKTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdF9oYW5kbGVLZXlkb3duKGV2ZW50OiBLZXlib2FyZEV2ZW50KTogdm9pZCB7XHJcblx0XHRpZiAoZXZlbnQua2V5ID09PSAnRXNjYXBlJykge1xyXG5cdFx0XHR0aGlzLmNsb3NlKCk7XHJcblx0XHR9IGVsc2UgaWYgKCF0aGlzLl9wYW5lbE9wZW4gJiYgKGV2ZW50LmtleSA9PT0gJ0VudGVyJyB8fCBldmVudC5rZXkgPT09ICcgJyB8fCBldmVudC5rZXkgPT09ICdBcnJvd0Rvd24nKSkge1xyXG5cdFx0XHR0aGlzLm9wZW4oKTtcclxuXHRcdFx0ZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdC8vIOKUgOKUgCBEYXRlIGZvcm1hdHRpbmcgLyBwYXJzaW5nIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxyXG5cclxuXHRfZm9ybWF0RGF0ZShkYXRlOiBEYXRlKTogc3RyaW5nIHtcclxuXHRcdHJldHVybiB0aGlzLl9kYXRlUGlwZS50cmFuc2Zvcm0oZGF0ZSwgdGhpcy5kYXRlRm9ybWF0KSA/PyAnJztcclxuXHR9XHJcblxyXG5cdF9wYXJzZURhdGUodGV4dDogc3RyaW5nKTogRGF0ZSB8IG51bGwge1xyXG5cdFx0aWYgKCF0ZXh0KSByZXR1cm4gbnVsbDtcclxuXHRcdC8vIFNpbXBsZSBwYXJzZXI6IHN1cHBvcnRzIE1NL2RkL3l5eXkgYW5kIE1NLmRkLnl5eXkgYW5kIHl5eXktTU0tZGRcclxuXHRcdGNvbnN0IGNsZWFuZWQgPSB0ZXh0LnJlcGxhY2UoL1xcLi9nLCAnLycpLnJlcGxhY2UoLy0vZywgJy8nKTtcclxuXHRcdGNvbnN0IHBhcnRzID0gY2xlYW5lZC5zcGxpdCgnLycpO1xyXG5cdFx0aWYgKHBhcnRzLmxlbmd0aCA9PT0gMykge1xyXG5cdFx0XHRjb25zdCBbYSwgYiwgY10gPSBwYXJ0cy5tYXAoTnVtYmVyKTtcclxuXHRcdFx0Ly8gRGV0ZXJtaW5lIGZvcm1hdCBiYXNlZCBvbiBkYXRlRm9ybWF0XHJcblx0XHRcdGxldCBtb250aDogbnVtYmVyLCBkYXk6IG51bWJlciwgeWVhcjogbnVtYmVyO1xyXG5cdFx0XHRpZiAodGhpcy5kYXRlRm9ybWF0LnN0YXJ0c1dpdGgoJ3l5eXknKSkge1xyXG5cdFx0XHRcdHllYXIgPSBhOyBtb250aCA9IGIgLSAxOyBkYXkgPSBjO1xyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdG1vbnRoID0gYSAtIDE7IGRheSA9IGI7IHllYXIgPSBjO1xyXG5cdFx0XHR9XHJcblx0XHRcdGlmICghaXNOYU4obW9udGgpICYmICFpc05hTihkYXkpICYmICFpc05hTih5ZWFyKSAmJiB5ZWFyID4gMTAwMCkge1xyXG5cdFx0XHRcdGNvbnN0IGQgPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCwgZGF5KTtcclxuXHRcdFx0XHRpZiAoZC5nZXRGdWxsWWVhcigpID09PSB5ZWFyICYmIGQuZ2V0TW9udGgoKSA9PT0gbW9udGggJiYgZC5nZXREYXRlKCkgPT09IGRheSkge1xyXG5cdFx0XHRcdFx0cmV0dXJuIGQ7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0XHRyZXR1cm4gbnVsbDtcclxuXHR9XHJcblxyXG5cdC8vIOKUgOKUgCBDb250cm9sVmFsdWVBY2Nlc3NvciDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcclxuXHJcblx0d3JpdGVWYWx1ZSh2YWx1ZTogRGF0ZSB8IERhdGVSYW5nZSB8IG51bGwpOiB2b2lkIHtcclxuXHRcdGlmICh0aGlzLnR5cGUgPT09ICdzaW5nbGUnKSB7XHJcblx0XHRcdGlmICh2YWx1ZSBpbnN0YW5jZW9mIERhdGUpIHtcclxuXHRcdFx0XHR0aGlzLl9zaW5nbGVWYWx1ZSA9IHZhbHVlO1xyXG5cdFx0XHRcdHRoaXMuX2Rpc3BsYXlWYWx1ZSA9IHRoaXMuX2Zvcm1hdERhdGUodmFsdWUpO1xyXG5cdFx0XHR9IGVsc2UgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcclxuXHRcdFx0XHRjb25zdCBwYXJzZWQgPSB0aGlzLl9wYXJzZURhdGUodmFsdWUpO1xyXG5cdFx0XHRcdHRoaXMuX3NpbmdsZVZhbHVlID0gcGFyc2VkO1xyXG5cdFx0XHRcdHRoaXMuX2Rpc3BsYXlWYWx1ZSA9IHBhcnNlZCA/IHRoaXMuX2Zvcm1hdERhdGUocGFyc2VkKSA6ICcnO1xyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdHRoaXMuX3NpbmdsZVZhbHVlID0gbnVsbDtcclxuXHRcdFx0XHR0aGlzLl9kaXNwbGF5VmFsdWUgPSAnJztcclxuXHRcdFx0fVxyXG5cdFx0fSBlbHNlIHtcclxuXHRcdFx0Y29uc3QgcmFuZ2UgPSB2YWx1ZSBhcyBEYXRlUmFuZ2UgfCBudWxsO1xyXG5cdFx0XHR0aGlzLl9yYW5nZVZhbHVlID0gcmFuZ2UgPz8gbnVsbDtcclxuXHRcdFx0dGhpcy5fZGlzcGxheVN0YXJ0VmFsdWUgPSByYW5nZT8uc3RhcnQgPyB0aGlzLl9mb3JtYXREYXRlKHJhbmdlLnN0YXJ0KSA6ICcnO1xyXG5cdFx0XHR0aGlzLl9kaXNwbGF5RW5kVmFsdWUgPSByYW5nZT8uZW5kID8gdGhpcy5fZm9ybWF0RGF0ZShyYW5nZS5lbmQpIDogJyc7XHJcblx0XHR9XHJcblx0XHR0aGlzLl9jZHIubWFya0ZvckNoZWNrKCk7XHJcblx0fVxyXG5cclxuXHRyZWdpc3Rlck9uQ2hhbmdlKGZuOiAodmFsdWU6IERhdGUgfCBEYXRlUmFuZ2UgfCBudWxsKSA9PiB2b2lkKTogdm9pZCB7XHJcblx0XHR0aGlzLl9vbkNoYW5nZSA9IGZuO1xyXG5cdH1cclxuXHJcblx0cmVnaXN0ZXJPblRvdWNoZWQoZm46ICgpID0+IHZvaWQpOiB2b2lkIHtcclxuXHRcdHRoaXMuX29uVG91Y2hlZCA9IGZuO1xyXG5cdH1cclxuXHJcblx0c2V0RGlzYWJsZWRTdGF0ZShpc0Rpc2FibGVkOiBib29sZWFuKTogdm9pZCB7XHJcblx0XHR0aGlzLmlzRGlzYWJsZWREaXJlY3RpdmUuc2V0RGlzYWJsZWRTdGF0ZShpc0Rpc2FibGVkKTtcclxuXHRcdHRoaXMuX2Nkci5tYXJrRm9yQ2hlY2soKTtcclxuXHR9XHJcblxyXG5cdG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG5cdFx0dGhpcy5fZGVzdHJveS5uZXh0KCk7XHJcblx0XHR0aGlzLl9kZXN0cm95LmNvbXBsZXRlKCk7XHJcblx0fVxyXG59XHJcbiIsIkBpZiAoc2tlbGV0b24pIHtcclxuXHQ8ZGl2IGNsYXNzPVwiaXVpLWRhdGUtcGlja2VyX19za2VsZXRvbi1sYWJlbFwiICpuZ0lmPVwic2hvd0xhYmVsXCI+PC9kaXY+XHJcblx0PGRpdiBjbGFzcz1cIml1aS1kYXRlLXBpY2tlcl9fc2tlbGV0b24tZmllbGRcIj48L2Rpdj5cclxuXHQ8ZGl2IGNsYXNzPVwiaXVpLWRhdGUtcGlja2VyX19za2VsZXRvbi1oZWxwZXJcIiAqbmdJZj1cInNob3dIZWxwZXJcIj48L2Rpdj5cclxufSBAZWxzZSB7XHJcblx0PCEtLSBMYWJlbCByb3cgKG9wdGlvbmFsKSAtLT5cclxuXHRAaWYgKHNob3dMYWJlbCAmJiBsYWJlbCkge1xyXG5cdFx0PGRpdiBjbGFzcz1cIml1aS1kYXRlLXBpY2tlcl9fbGFiZWwtcm93XCI+XHJcblx0XHRcdDxsYWJlbCBjbGFzcz1cIml1aS1kYXRlLXBpY2tlcl9fbGFiZWxcIj5cclxuXHRcdFx0XHR7eyBsYWJlbCB9fTxzcGFuIGNsYXNzPVwiaXVpLWRhdGUtcGlja2VyX19yZXF1aXJlZFwiICpuZ0lmPVwicmVxdWlyZWRcIj4qPC9zcGFuPlxyXG5cdFx0XHQ8L2xhYmVsPlxyXG5cdFx0PC9kaXY+XHJcblx0fVxyXG5cclxuXHQ8IS0tIFRyaWdnZXIgZmllbGQgd3JhcHBlciAob3ZlcmxheSBvcmlnaW4pIC0tPlxyXG5cdDxkaXZcclxuXHRcdGNsYXNzPVwiaXVpLWRhdGUtcGlja2VyX19maWVsZC13cmFwXCJcclxuXHRcdGNkay1vdmVybGF5LW9yaWdpblxyXG5cdFx0I292ZXJsYXlPcmlnaW49XCJjZGtPdmVybGF5T3JpZ2luXCJcclxuXHRcdChjbGljayk9XCJvcGVuKClcIlxyXG5cdFx0KG1vdXNlZW50ZXIpPVwiX29uTW91c2VFbnRlcigpXCJcclxuXHRcdChtb3VzZWxlYXZlKT1cIl9vbk1vdXNlTGVhdmUoKVwiXHJcblx0XHQoa2V5ZG93bik9XCJfaGFuZGxlS2V5ZG93bigkZXZlbnQpXCJcclxuXHQ+XHJcblx0XHRAaWYgKHR5cGUgPT09ICdzaW5nbGUnKSB7XHJcblx0XHRcdDwhLS0gU2luZ2xlIG1vZGU6IHVzZSBpdWktZGF0ZS1pbnB1dCB3aXRoIGNhbGVuZGFyIGljb24gc3VmZml4IC0tPlxyXG5cdFx0XHQ8aXVpLWRhdGUtaW5wdXRcclxuXHRcdFx0XHRjbGFzcz1cIml1aS1kYXRlLXBpY2tlcl9fZGF0ZS1pbnB1dFwiXHJcblx0XHRcdFx0W3Nob3dMYWJlbF09XCJmYWxzZVwiXHJcblx0XHRcdFx0W3Nob3dIZWxwZXJdPVwiZmFsc2VcIlxyXG5cdFx0XHRcdFtwbGFjZWhvbGRlcl09XCJwbGFjZWhvbGRlclwiXHJcblx0XHRcdFx0W2lzRGlzYWJsZWRdPVwiZGlzYWJsZWRcIlxyXG5cdFx0XHRcdFtuZ01vZGVsXT1cIl9kaXNwbGF5VmFsdWVcIlxyXG5cdFx0XHRcdChuZ01vZGVsQ2hhbmdlKT1cIl9vblRleHRJbnB1dCgkZXZlbnQpXCJcclxuXHRcdFx0XHQoZm9jdXMpPVwiX29uRm9jdXMoKVwiXHJcblx0XHRcdFx0KGJsdXIpPVwiX29uQmx1cigpXCJcclxuXHRcdFx0PlxyXG5cdFx0XHRcdDxidXR0b25cclxuXHRcdFx0XHRcdGl1aVN1ZmZpeFxyXG5cdFx0XHRcdFx0Y2xhc3M9XCJpdWktZGF0ZS1waWNrZXJfX2NhbGVuZGFyLWJ0blwiXHJcblx0XHRcdFx0XHR0eXBlPVwiYnV0dG9uXCJcclxuXHRcdFx0XHRcdFtkaXNhYmxlZF09XCJkaXNhYmxlZFwiXHJcblx0XHRcdFx0XHRhcmlhLWxhYmVsPVwiT3BlbiBjYWxlbmRhclwiXHJcblx0XHRcdFx0XHQoY2xpY2spPVwidG9nZ2xlKCk7ICRldmVudC5zdG9wUHJvcGFnYXRpb24oKVwiXHJcblx0XHRcdFx0PlxyXG5cdFx0XHRcdFx0PGl1aS1jYWxlbmRhci1pY29uPjwvaXVpLWNhbGVuZGFyLWljb24+XHJcblx0XHRcdFx0PC9idXR0b24+XHJcblx0XHRcdDwvaXVpLWRhdGUtaW5wdXQ+XHJcblx0XHR9XHJcblxyXG5cdFx0QGlmICh0eXBlID09PSAncmFuZ2VkJykge1xyXG5cdFx0XHQ8IS0tIFJhbmdlZCBtb2RlOiBjdXN0b20gZHVhbC1pbnB1dCBmaWVsZCAtLT5cclxuXHRcdFx0PGRpdiBjbGFzcz1cIml1aS1kYXRlLXBpY2tlcl9fcmFuZ2UtZmllbGRcIj5cclxuXHRcdFx0XHQ8aW5wdXRcclxuXHRcdFx0XHRcdGNsYXNzPVwiaXVpLWRhdGUtcGlja2VyX19yYW5nZS1pbnB1dFwiXHJcblx0XHRcdFx0XHR0eXBlPVwidGV4dFwiXHJcblx0XHRcdFx0XHRbcGxhY2Vob2xkZXJdPVwicGxhY2Vob2xkZXJcIlxyXG5cdFx0XHRcdFx0W2Rpc2FibGVkXT1cImRpc2FibGVkXCJcclxuXHRcdFx0XHRcdFt2YWx1ZV09XCJfZGlzcGxheVN0YXJ0VmFsdWVcIlxyXG5cdFx0XHRcdFx0YXJpYS1sYWJlbD1cIlN0YXJ0IGRhdGVcIlxyXG5cdFx0XHRcdFx0KGlucHV0KT1cIl9vblN0YXJ0VGV4dElucHV0KCRldmVudClcIlxyXG5cdFx0XHRcdFx0KGZvY3VzKT1cIl9vblN0YXJ0Rm9jdXMoKVwiXHJcblx0XHRcdFx0XHQoYmx1cik9XCJfb25CbHVyKClcIlxyXG5cdFx0XHRcdFx0KGNsaWNrKT1cIm9wZW4oKVwiXHJcblx0XHRcdFx0Lz5cclxuXHRcdFx0XHQ8c3BhbiBjbGFzcz1cIml1aS1kYXRlLXBpY2tlcl9fcmFuZ2UtZGl2aWRlclwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPuKGkjwvc3Bhbj5cclxuXHRcdFx0XHQ8aW5wdXRcclxuXHRcdFx0XHRcdGNsYXNzPVwiaXVpLWRhdGUtcGlja2VyX19yYW5nZS1pbnB1dFwiXHJcblx0XHRcdFx0XHR0eXBlPVwidGV4dFwiXHJcblx0XHRcdFx0XHRbcGxhY2Vob2xkZXJdPVwicGxhY2Vob2xkZXJFbmRcIlxyXG5cdFx0XHRcdFx0W2Rpc2FibGVkXT1cImRpc2FibGVkXCJcclxuXHRcdFx0XHRcdFt2YWx1ZV09XCJfZGlzcGxheUVuZFZhbHVlXCJcclxuXHRcdFx0XHRcdGFyaWEtbGFiZWw9XCJFbmQgZGF0ZVwiXHJcblx0XHRcdFx0XHQoaW5wdXQpPVwiX29uRW5kVGV4dElucHV0KCRldmVudClcIlxyXG5cdFx0XHRcdFx0KGZvY3VzKT1cIl9vbkVuZEZvY3VzKClcIlxyXG5cdFx0XHRcdFx0KGJsdXIpPVwiX29uQmx1cigpXCJcclxuXHRcdFx0XHRcdChjbGljayk9XCJvcGVuKClcIlxyXG5cdFx0XHRcdC8+XHJcblx0XHRcdFx0PGJ1dHRvblxyXG5cdFx0XHRcdFx0Y2xhc3M9XCJpdWktZGF0ZS1waWNrZXJfX2NhbGVuZGFyLWJ0blwiXHJcblx0XHRcdFx0XHR0eXBlPVwiYnV0dG9uXCJcclxuXHRcdFx0XHRcdFtkaXNhYmxlZF09XCJkaXNhYmxlZFwiXHJcblx0XHRcdFx0XHRhcmlhLWxhYmVsPVwiT3BlbiBjYWxlbmRhclwiXHJcblx0XHRcdFx0XHQoY2xpY2spPVwidG9nZ2xlKCk7ICRldmVudC5zdG9wUHJvcGFnYXRpb24oKVwiXHJcblx0XHRcdFx0PlxyXG5cdFx0XHRcdFx0PGl1aS1jYWxlbmRhci1pY29uPjwvaXVpLWNhbGVuZGFyLWljb24+XHJcblx0XHRcdFx0PC9idXR0b24+XHJcblx0XHRcdDwvZGl2PlxyXG5cdFx0fVxyXG5cdDwvZGl2PlxyXG5cclxuXHQ8IS0tIENESyBvdmVybGF5IGZvciBjYWxlbmRhciBwYW5lbCAtLT5cclxuXHQ8bmctdGVtcGxhdGVcclxuXHRcdGNkay1jb25uZWN0ZWQtb3ZlcmxheVxyXG5cdFx0Y2RrQ29ubmVjdGVkT3ZlcmxheUhhc0JhY2tkcm9wXHJcblx0XHRjZGtDb25uZWN0ZWRPdmVybGF5QmFja2Ryb3BDbGFzcz1cImNkay1vdmVybGF5LXRyYW5zcGFyZW50LWJhY2tkcm9wXCJcclxuXHRcdFtjZGtDb25uZWN0ZWRPdmVybGF5T3JpZ2luXT1cIm92ZXJsYXlPcmlnaW5cIlxyXG5cdFx0W2Nka0Nvbm5lY3RlZE92ZXJsYXlPcGVuXT1cIl9wYW5lbE9wZW5cIlxyXG5cdFx0W2Nka0Nvbm5lY3RlZE92ZXJsYXlQb3NpdGlvbnNdPVwiX3Bvc2l0aW9uc1wiXHJcblx0XHRbY2RrQ29ubmVjdGVkT3ZlcmxheVNjcm9sbFN0cmF0ZWd5XT1cIl9zY3JvbGxTdHJhdGVneVwiXHJcblx0XHRbY2RrQ29ubmVjdGVkT3ZlcmxheVdpZHRoXT1cIjMyNFwiXHJcblx0XHQoYmFja2Ryb3BDbGljayk9XCJjbG9zZSgpXCJcclxuXHRcdChkZXRhY2gpPVwiY2xvc2UoKVwiXHJcblx0PlxyXG5cdFx0PGl1aS1jYWxlbmRhclxyXG5cdFx0XHRbdHlwZV09XCJ0eXBlXCJcclxuXHRcdFx0W2N1cnJlbnRWaWV3XT1cIl9jYWxlbmRhclZpZXdcIlxyXG5cdFx0XHRbZGlzcGxheU1vbnRoXT1cIl9kaXNwbGF5TW9udGhcIlxyXG5cdFx0XHRbc2VsZWN0ZWREYXRlXT1cInR5cGUgPT09ICdzaW5nbGUnID8gX3NpbmdsZVZhbHVlIDogbnVsbFwiXHJcblx0XHRcdFtzZWxlY3RlZFJhbmdlXT1cInR5cGUgPT09ICdyYW5nZWQnID8gX3JhbmdlVmFsdWUgOiBudWxsXCJcclxuXHRcdFx0W2hvdmVyRGF0ZV09XCJfaG92ZXJEYXRlXCJcclxuXHRcdFx0W21pbkRhdGVdPVwibWluRGF0ZVwiXHJcblx0XHRcdFttYXhEYXRlXT1cIm1heERhdGVcIlxyXG5cdFx0XHQoZGF0ZVNlbGVjdGVkKT1cIl9vbkRhdGVTZWxlY3RlZCgkZXZlbnQpXCJcclxuXHRcdFx0KHZpZXdDaGFuZ2UpPVwiX29uVmlld0NoYW5nZSgkZXZlbnQpXCJcclxuXHRcdFx0KGRpc3BsYXlNb250aENoYW5nZSk9XCJfb25EaXNwbGF5TW9udGhDaGFuZ2UoJGV2ZW50KVwiXHJcblx0XHRcdChkYXRlSG92ZXIpPVwiX29uRGF0ZUhvdmVyKCRldmVudClcIlxyXG5cdFx0PjwvaXVpLWNhbGVuZGFyPlxyXG5cdDwvbmctdGVtcGxhdGU+XHJcblxyXG5cdDwhLS0gSGVscGVyIC8gRXJyb3Igcm93IChvcHRpb25hbCkgLS0+XHJcblx0QGlmIChzaG93SGVscGVyKSB7XHJcblx0XHQ8ZGl2IGNsYXNzPVwiaXVpLWRhdGUtcGlja2VyX19oZWxwZXItcm93XCI+XHJcblx0XHRcdEBpZiAoX2Vycm9yU3RhdGUpIHtcclxuXHRcdFx0XHQ8c3BhbiBjbGFzcz1cIml1aS1kYXRlLXBpY2tlcl9fZXJyb3JcIj5cclxuXHRcdFx0XHRcdDxuZy1jb250ZW50IHNlbGVjdD1cIltpdWktZXJyb3JdXCI+PC9uZy1jb250ZW50PlxyXG5cdFx0XHRcdDwvc3Bhbj5cclxuXHRcdFx0fSBAZWxzZSB7XHJcblx0XHRcdFx0PHNwYW4gY2xhc3M9XCJpdWktZGF0ZS1waWNrZXJfX2hlbHBlclwiPlxyXG5cdFx0XHRcdFx0PG5nLWNvbnRlbnQgc2VsZWN0PVwiW2l1aS1oaW50XVwiPjwvbmctY29udGVudD5cclxuXHRcdFx0XHQ8L3NwYW4+XHJcblx0XHRcdH1cclxuXHRcdDwvZGl2PlxyXG5cdH1cclxufVxyXG4iXX0=