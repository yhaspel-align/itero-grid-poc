/**
 * loads fonts from the static server. Extremely helpful for microfrontends, because they know their baseUrl only in runtime.
 * Invoke this function at the start of your application.
 * */
export function loadFonts(baseUrl = '.', options = {}) {
    if (document.head.querySelector('.iui-fonts')) {
        return Promise.resolve();
    }
    const { iuiFontsFolder = 'iui-fonts' } = options;
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = `${baseUrl}/${iuiFontsFolder}/fonts.css`;
    link.crossOrigin = 'anonymous';
    link.classList.add('iui-fonts');
    link.type = 'text/css';
    document.head.appendChild(link);
    return new Promise((resolve, reject) => {
        const listeners = [
            (e) => {
                resolve(e);
                link.removeEventListener('load', listeners[0]);
                link.removeEventListener('error', listeners[1]);
            },
            (err) => {
                reject(err);
                document.head.removeChild(link);
                link.removeEventListener('load', listeners[0]);
                link.removeEventListener('error', listeners[1]);
            }
        ];
        link.addEventListener('load', listeners[0]);
        link.addEventListener('error', listeners[1]);
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9hZEZvbnRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vbGlicy91aS1jb21wb25lbnRzLWFuZ3VsYXItcHVibGlzaGFibGUvc3JjL2hlbHBlcnMvbG9hZEZvbnRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUlBOzs7S0FHSztBQUNMLE1BQU0sVUFBVSxTQUFTLENBQUMsVUFBa0IsR0FBRyxFQUFFLFVBQStCLEVBQUU7SUFDakYsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1FBQy9DLE9BQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxNQUFNLEVBQUUsY0FBYyxHQUFHLFdBQVcsRUFBRSxHQUFHLE9BQU8sQ0FBQztJQUVqRCxNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBRTVDLElBQUksQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDO0lBQ3hCLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxPQUFPLElBQUksY0FBYyxZQUFZLENBQUM7SUFDckQsSUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7SUFDL0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDaEMsSUFBSSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUM7SUFFdkIsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7SUFFaEMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtRQUN0QyxNQUFNLFNBQVMsR0FBRztZQUNqQixDQUFDLENBQVEsRUFBRSxFQUFFO2dCQUNaLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDWCxJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMvQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2pELENBQUM7WUFDRCxDQUFDLEdBQVUsRUFBRSxFQUFFO2dCQUNkLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDWixRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDaEMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDL0MsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNqRCxDQUFDO1NBQ0QsQ0FBQztRQUVGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDNUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM5QyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgaW50ZXJmYWNlIEl1aUxvYWRGb250c09wdGlvbnMge1xuXHRpdWlGb250c0ZvbGRlcj86IHN0cmluZztcbn1cblxuLyoqXG4gKiBsb2FkcyBmb250cyBmcm9tIHRoZSBzdGF0aWMgc2VydmVyLiBFeHRyZW1lbHkgaGVscGZ1bCBmb3IgbWljcm9mcm9udGVuZHMsIGJlY2F1c2UgdGhleSBrbm93IHRoZWlyIGJhc2VVcmwgb25seSBpbiBydW50aW1lLlxuICogSW52b2tlIHRoaXMgZnVuY3Rpb24gYXQgdGhlIHN0YXJ0IG9mIHlvdXIgYXBwbGljYXRpb24uXG4gKiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxvYWRGb250cyhiYXNlVXJsOiBzdHJpbmcgPSAnLicsIG9wdGlvbnM6IEl1aUxvYWRGb250c09wdGlvbnMgPSB7fSk6IFByb21pc2U8dW5rbm93bj4ge1xuXHRpZiAoZG9jdW1lbnQuaGVhZC5xdWVyeVNlbGVjdG9yKCcuaXVpLWZvbnRzJykpIHtcblx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdH1cblxuXHRjb25zdCB7IGl1aUZvbnRzRm9sZGVyID0gJ2l1aS1mb250cycgfSA9IG9wdGlvbnM7XG5cblx0Y29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpbmsnKTtcblxuXHRsaW5rLnJlbCA9ICdzdHlsZXNoZWV0Jztcblx0bGluay5ocmVmID0gYCR7YmFzZVVybH0vJHtpdWlGb250c0ZvbGRlcn0vZm9udHMuY3NzYDtcblx0bGluay5jcm9zc09yaWdpbiA9ICdhbm9ueW1vdXMnO1xuXHRsaW5rLmNsYXNzTGlzdC5hZGQoJ2l1aS1mb250cycpO1xuXHRsaW5rLnR5cGUgPSAndGV4dC9jc3MnO1xuXG5cdGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQobGluayk7XG5cblx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRjb25zdCBsaXN0ZW5lcnMgPSBbXG5cdFx0XHQoZTogRXZlbnQpID0+IHtcblx0XHRcdFx0cmVzb2x2ZShlKTtcblx0XHRcdFx0bGluay5yZW1vdmVFdmVudExpc3RlbmVyKCdsb2FkJywgbGlzdGVuZXJzWzBdKTtcblx0XHRcdFx0bGluay5yZW1vdmVFdmVudExpc3RlbmVyKCdlcnJvcicsIGxpc3RlbmVyc1sxXSk7XG5cdFx0XHR9LFxuXHRcdFx0KGVycjogRXZlbnQpID0+IHtcblx0XHRcdFx0cmVqZWN0KGVycik7XG5cdFx0XHRcdGRvY3VtZW50LmhlYWQucmVtb3ZlQ2hpbGQobGluayk7XG5cdFx0XHRcdGxpbmsucmVtb3ZlRXZlbnRMaXN0ZW5lcignbG9hZCcsIGxpc3RlbmVyc1swXSk7XG5cdFx0XHRcdGxpbmsucmVtb3ZlRXZlbnRMaXN0ZW5lcignZXJyb3InLCBsaXN0ZW5lcnNbMV0pO1xuXHRcdFx0fVxuXHRcdF07XG5cblx0XHRsaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCBsaXN0ZW5lcnNbMF0pO1xuXHRcdGxpbmsuYWRkRXZlbnRMaXN0ZW5lcignZXJyb3InLCBsaXN0ZW5lcnNbMV0pO1xuXHR9KTtcbn1cbiJdfQ==