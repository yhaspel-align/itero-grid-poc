# @itero/ui-components-angular/text-input

Secondary entry point of `@itero/ui-components-angular`. It can be used by importing from `@itero/ui-components-angular/text-input`.
