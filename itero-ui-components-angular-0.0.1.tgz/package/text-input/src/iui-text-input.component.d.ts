import { ChangeDetectorRef, ElementRef } from '@angular/core';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
export type TextInputSize = 'l' | 'm' | 's';
export type TextInputLayerSet = 'set-01' | 'set-02';
type ValueType = string | null;
type InputType = 'text' | 'password' | 'email';
export declare class IuiTextInputComponent implements ControlValueAccessor {
    protected _changeDetectorRef: ChangeDetectorRef;
    protected ngControlDirective: NgControlDirective<ValueType>;
    protected errorStateMatcherDirective: IuiErrorStateMatcherDirective;
    protected isDisabledDirective: IuiIsDisabledDirective;
    /** The ref to native input element. You can use it and pass attributes or events to native input */
    inputElement: ElementRef | undefined;
    /** Unique id of the element */
    set id(value: string);
    get id(): string;
    /** Label of component, default is '', strongly recommended to be filled */
    label: string;
    /** Placeholder of component, rendered in the place of the value when no selections/input */
    placeholder: string;
    /** Whether the input contains "X" icon to clear the field */
    cancelable: boolean;
    /** Name assigned to input element inside */
    name: string;
    autocomplete: string | null;
    /** Type of input element, supported: text, password, email */
    type: InputType;
    /** Size of the input field: large (default), medium, small */
    size: TextInputSize;
    /** Layer set: set-01 (white bg, default) or set-02 (gray bg) */
    layerSet: TextInputLayerSet;
    /** Whether to show character counter in the label row */
    showCounter: boolean;
    /** Max character length; displayed in counter as current/max */
    maxLength: number | null;
    /** Whether to show the skeleton loading state */
    skeleton: boolean;
    /** Whether the component is required. */
    get required(): boolean;
    set required(value: string | boolean | null | undefined);
    get _labelId(): string;
    get _inputId(): string;
    get disabled(): boolean;
    get _errorState(): boolean;
    get empty(): boolean;
    get _counterText(): string;
    constructor(_changeDetectorRef: ChangeDetectorRef, ngControlDirective: NgControlDirective<ValueType>, errorStateMatcherDirective: IuiErrorStateMatcherDirective, isDisabledDirective: IuiIsDisabledDirective);
    private __value;
    /** Value of the select control. */
    get _value(): ValueType;
    set _value(newValue: ValueType);
    private _required;
    private __focused;
    _id: string;
    /** `View -> model callback called when value changes` */
    _onChange: (value: ValueType) => void;
    /** `View -> model callback called when select has been touched` */
    _onTouched: () => void;
    /** Whether the select is focused. */
    get _focused(): boolean;
    _onFocus(): void;
    _onBlur(): void;
    _focusInput(input: HTMLInputElement): void;
    _cancelSelection(event: MouseEvent): void;
    writeValue(value: ValueType): void;
    registerOnChange(fn: (value: ValueType) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    modelChangeHandler(value: ValueType): void;
    private _assignValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiTextInputComponent, [null, { self: true; }, { self: true; }, { self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiTextInputComponent, "iui-text-input", never, { "id": { "alias": "id"; "required": false; }; "label": { "alias": "label"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "cancelable": { "alias": "cancelable"; "required": false; }; "name": { "alias": "name"; "required": false; }; "autocomplete": { "alias": "autocomplete"; "required": false; }; "type": { "alias": "type"; "required": false; }; "size": { "alias": "size"; "required": false; }; "layerSet": { "alias": "layerSet"; "required": false; }; "showCounter": { "alias": "showCounter"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "skeleton": { "alias": "skeleton"; "required": false; }; "required": { "alias": "required"; "required": false; }; }, {}, never, ["[iui-prefix]", "[iui-suffix]", "[iui-error]", "[iui-hint]"], true, [{ directive: typeof i1.NgControlDirective; inputs: {}; outputs: {}; }, { directive: typeof i1.IuiErrorStateMatcherDirective; inputs: { "errorStateMatcher": "errorStateMatcher"; }; outputs: {}; }, { directive: typeof i1.IuiIsDisabledDirective; inputs: { "isDisabled": "isDisabled"; }; outputs: { "disableChangeEvent": "disableChangeEvent"; }; }]>;
}
export {};
