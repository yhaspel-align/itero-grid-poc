export * from './src/iui-slider.component';
