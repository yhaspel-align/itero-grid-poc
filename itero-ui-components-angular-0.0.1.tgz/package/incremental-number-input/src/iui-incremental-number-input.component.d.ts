import { ChangeDetectorRef, ElementRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
type ValueType = number | null;
/**
 * @deprecated Use `IuiNumberInputComponent` from `@itero/ui-components-angular/number-input` instead.
 * This component will be removed in the next major version.
 */
export declare class IuiIncrementalNumberInputComponent implements ControlValueAccessor {
    protected _changeDetectorRef: ChangeDetectorRef;
    protected ngControlDirective: NgControlDirective<ValueType>;
    protected errorStateMatcherDirective: IuiErrorStateMatcherDirective;
    protected isDisabledDirective: IuiIsDisabledDirective;
    inputElement: ElementRef<HTMLInputElement> | undefined;
    set id(value: string);
    get id(): string;
    _id: string;
    label: string;
    helperText: string;
    name: string;
    min: number;
    max: number;
    step: number;
    private __value;
    private __focused;
    private _rawInput;
    private _required;
    get required(): boolean;
    set required(value: string | boolean | null | undefined);
    get disabled(): boolean;
    get _errorState(): boolean;
    get _focused(): boolean;
    get _inputId(): string;
    get _isAtMin(): boolean;
    get _isAtMax(): boolean;
    get _inputSize(): number;
    get _ariaValueMin(): number | null;
    get _ariaValueMax(): number | null;
    get _displayValue(): string;
    get _value(): ValueType;
    constructor(_changeDetectorRef: ChangeDetectorRef, ngControlDirective: NgControlDirective<ValueType>, errorStateMatcherDirective: IuiErrorStateMatcherDirective, isDisabledDirective: IuiIsDisabledDirective);
    _onChange: (value: ValueType) => void;
    _onTouched: () => void;
    _increment(): void;
    _decrement(): void;
    _onKeydown(event: KeyboardEvent): void;
    _onInputChange(event: Event): void;
    _onFocus(): void;
    _onBlur(): void;
    writeValue(value: ValueType): void;
    registerOnChange(fn: (value: ValueType) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    private _setValue;
    private _assignValue;
    private _clamp;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiIncrementalNumberInputComponent, [null, { self: true; }, { self: true; }, { self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiIncrementalNumberInputComponent, "iui-incremental-number-input", never, { "id": { "alias": "id"; "required": false; }; "label": { "alias": "label"; "required": false; }; "helperText": { "alias": "helperText"; "required": false; }; "name": { "alias": "name"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "step": { "alias": "step"; "required": false; }; "required": { "alias": "required"; "required": false; }; }, {}, never, never, true, [{ directive: typeof i1.NgControlDirective; inputs: {}; outputs: {}; }, { directive: typeof i1.IuiErrorStateMatcherDirective; inputs: { "errorStateMatcher": "errorStateMatcher"; }; outputs: {}; }, { directive: typeof i1.IuiIsDisabledDirective; inputs: { "isDisabled": "isDisabled"; }; outputs: { "disableChangeEvent": "disableChangeEvent"; }; }]>;
}
export {};
