/** @deprecated Use IuiNumberInputComponent from @itero/ui-components-angular/number-input instead. Will be removed in the next major version. */
export * from './src/iui-incremental-number-input.component';
