import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type NotificationType = 'inline' | 'toast';
export type NotificationStatus = 'information' | 'success' | 'warning' | 'error';
export declare class IuiNotificationComponent {
    /** Notification display type: inline (flat, in-flow) or toast (elevated, floating) */
    type: NotificationType;
    /** Semantic status determining colors and icon */
    status: NotificationStatus;
    /** Optional title text (visible when showTitle is true) */
    title: string;
    /** Optional subtitle text (shown between title and message) */
    subtitle: string;
    /** Main message text */
    message: string;
    /** Whether to display the title area */
    showTitle: boolean;
    /** Whether to display the close button */
    closable: boolean;
    /** Whether to display the action slot */
    showAction: boolean;
    /** Emits when the close button is clicked */
    closed: EventEmitter<void>;
    onClose(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiNotificationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiNotificationComponent, "iui-notification", never, { "type": { "alias": "type"; "required": false; }; "status": { "alias": "status"; "required": false; }; "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "message": { "alias": "message"; "required": false; }; "showTitle": { "alias": "showTitle"; "required": false; }; "closable": { "alias": "closable"; "required": false; }; "showAction": { "alias": "showAction"; "required": false; }; }, { "closed": "closed"; }, never, ["[iuiNotificationAction]"], true, never>;
}
