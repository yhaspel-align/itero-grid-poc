# Notification (iui-notification)

A notification component for displaying contextual messages with semantic status. Supports two display modes: embedded (`inline`) and floating (`toast`).

## Import

```typescript
import { IuiNotificationComponent } from '@itero/ui-components-angular/notification';
```

## Usage

```html
<!-- Simple notification -->
<iui-notification
  status="information"
  message="Your data has been saved successfully."
  [showTitle]="false"
></iui-notification>

<!-- With title and subtitle -->
<iui-notification
  status="warning"
  title="Attention"
  subtitle="Version 3.2.1"
  message="A new application version has been detected. Restart to update."
></iui-notification>

<!-- With close button -->
<iui-notification
  status="error"
  title="Connection Error"
  message="Could not connect to the server."
  [closable]="true"
  (closed)="onNotificationClosed()"
></iui-notification>

<!-- With action -->
<iui-notification
  status="information"
  message="Storage is almost full."
  [showAction]="true"
>
  <a iuiLink iuiNotificationAction>Manage storage</a>
</iui-notification>

<!-- Toast notification -->
<iui-notification
  type="toast"
  status="success"
  message="Settings saved."
  [showTitle]="false"
></iui-notification>
```

## Parameters

| Parameter    | Type                                                   | Default         | Description                                        |
|--------------|--------------------------------------------------------|-----------------|----------------------------------------------------|
| `type`       | `'inline' \| 'toast'`                                  | `'inline'`      | Display mode: embedded or floating                 |
| `status`     | `'information' \| 'success' \| 'warning' \| 'error'`  | `'information'` | Semantic status (color, icon)                      |
| `title`      | `string`                                               | `''`            | Title text                                         |
| `subtitle`   | `string`                                               | `''`            | Secondary text below the title                     |
| `message`    | `string`                                               | `''`            | Main message text                                  |
| `showTitle`  | `boolean`                                              | `true`          | Whether to display the title                       |
| `closable`   | `boolean`                                              | `false`         | Whether to show the close button                   |
| `showAction` | `boolean`                                              | `false`         | Whether to show the action area                    |

## Events

| Event    | Type   | Description                               |
|----------|--------|-------------------------------------------|
| `closed` | `void` | Emitted when the close button is clicked  |

## Slots

| Attribute                | Description                                                     |
|--------------------------|-----------------------------------------------------------------|
| `iuiNotificationAction`  | Action element (link or button), displayed when `[showAction]="true"` |

## Statuses

| Status        | Color  | Purpose                                  |
|---------------|--------|------------------------------------------|
| `information` | Blue   | Neutral and informational messages       |
| `success`     | Green  | Successful operations                    |
| `warning`     | Orange | Warnings and cautions                    |
| `error`       | Red    | Errors and critical problems             |

## Types (`type`)

- **`inline`** — Embedded notification: flat appearance with a 4px left accent border and background fill. Used for contextual messages within the page flow.
- **`toast`** — Floating notification: card with shadow, rounded corners, and a full border. Used for system-level and transient messages displayed above content.
