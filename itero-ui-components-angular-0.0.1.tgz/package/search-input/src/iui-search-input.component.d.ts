import { ChangeDetectorRef, ElementRef, EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
export type SearchInputSize = 'l' | 'm' | 's';
export type SearchInputLayerSet = 'set-01' | 'set-02';
type ValueType = string | null;
export declare class IuiSearchInputComponent implements ControlValueAccessor {
    protected _changeDetectorRef: ChangeDetectorRef;
    protected ngControlDirective: NgControlDirective<ValueType>;
    protected errorStateMatcherDirective: IuiErrorStateMatcherDirective;
    protected isDisabledDirective: IuiIsDisabledDirective;
    /** Reference to the native input element */
    inputElement?: ElementRef<HTMLInputElement>;
    /** Unique id of the component */
    set id(value: string);
    get id(): string;
    /** Size of the search field: large (default), medium, small */
    size: SearchInputSize;
    /** Layer set: set-01 (white bg, default) or set-02 (gray bg) */
    layerSet: SearchInputLayerSet;
    /** Placeholder text shown when the field is empty */
    placeholder: string;
    /** Name attribute for the native input */
    name: string;
    /** When true, the suggestions dropdown panel (ng-content) is shown */
    showMenu: boolean;
    /** Whether to show the skeleton loading state */
    skeleton: boolean;
    /** Emitted when the input value changes */
    valueChange: EventEmitter<ValueType>;
    /** Emitted when the clear (×) button is clicked */
    clearClick: EventEmitter<void>;
    /** Emitted when the user presses Enter */
    searchSubmit: EventEmitter<string>;
    _id: string;
    get _inputId(): string;
    get empty(): boolean;
    get disabled(): boolean;
    get _errorState(): boolean;
    get _focused(): boolean;
    get _value(): ValueType;
    set _value(newValue: ValueType);
    private __value;
    private __focused;
    _onChange: (value: ValueType) => void;
    _onTouched: () => void;
    constructor(_changeDetectorRef: ChangeDetectorRef, ngControlDirective: NgControlDirective<ValueType>, errorStateMatcherDirective: IuiErrorStateMatcherDirective, isDisabledDirective: IuiIsDisabledDirective);
    _onModelChange(value: ValueType): void;
    _onFocus(): void;
    _onBlur(): void;
    _onEnter(): void;
    _onClear(event: MouseEvent): void;
    _focusInput(): void;
    writeValue(value: ValueType): void;
    registerOnChange(fn: (value: ValueType) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiSearchInputComponent, [null, { self: true; }, { self: true; }, { self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiSearchInputComponent, "iui-search-input", never, { "id": { "alias": "id"; "required": false; }; "size": { "alias": "size"; "required": false; }; "layerSet": { "alias": "layerSet"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "name": { "alias": "name"; "required": false; }; "showMenu": { "alias": "showMenu"; "required": false; }; "skeleton": { "alias": "skeleton"; "required": false; }; }, { "valueChange": "valueChange"; "clearClick": "clearClick"; "searchSubmit": "searchSubmit"; }, never, ["*"], true, [{ directive: typeof i1.NgControlDirective; inputs: {}; outputs: {}; }, { directive: typeof i1.IuiErrorStateMatcherDirective; inputs: { "errorStateMatcher": "errorStateMatcher"; }; outputs: {}; }, { directive: typeof i1.IuiIsDisabledDirective; inputs: { "isDisabled": "isDisabled"; }; outputs: { "disableChangeEvent": "disableChangeEvent"; }; }]>;
}
export {};
