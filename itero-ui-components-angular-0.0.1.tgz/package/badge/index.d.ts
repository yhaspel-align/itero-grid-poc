export * from './src/iui-badge.component';
