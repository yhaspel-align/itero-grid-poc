import * as i0 from "@angular/core";
export type BadgeStatus = 'netral' | 'info' | 'success' | 'warning' | 'destructive';
export type BadgeLayout = 'default' | 'on-image';
export declare class IuiBadgeComponent {
    /** Semantic status determining badge colors */
    status: BadgeStatus;
    /** Layout context — 'default' for standard use, 'on-image' for overlaying photos */
    layout: BadgeLayout;
    /** Show loading skeleton state */
    loading: boolean;
    /** Show leading icon */
    showIcon: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiBadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiBadgeComponent, "span[iui-badge]", never, { "status": { "alias": "status"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "showIcon": { "alias": "showIcon"; "required": false; }; }, {}, never, ["*"], true, never>;
}
