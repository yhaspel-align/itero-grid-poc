import { AfterContentInit, ChangeDetectorRef, EventEmitter, InjectionToken, OnDestroy, TemplateRef } from '@angular/core';
import { Subject } from 'rxjs';
import { TemplatePortal } from '@angular/cdk/portal';
import { CdkAccordion, CdkAccordionItem } from '@angular/cdk/accordion';
import { UniqueSelectionDispatcher } from '@angular/cdk/collections';
import { AnimationEvent } from '@angular/animations';
import * as i0 from "@angular/core";
export type IuiAccordionStyle = 'background-01' | 'background-02' | 'border' | 'line';
export type IuiAccordionState = 'expanded' | 'collapsed';
export interface IuiAccordionContent {
    templateRef: TemplateRef<unknown>;
    _accordion: CdkAccordionItem;
}
export declare const IUI_ACCORDION_CONTENT: InjectionToken<IuiAccordionContent>;
export declare const IUI_ACCORDION_ITEM: InjectionToken<CdkAccordionItem>;
export declare const IUI_ACCORDION: InjectionToken<CdkAccordion>;
export declare class IuiAccordionContentDirective implements IuiAccordionContent {
    templateRef: TemplateRef<any>;
    _accordion: CdkAccordionItem;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiAccordionContentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IuiAccordionContentDirective, "[iuiAccordionContent]", never, {}, {}, never, never, true, never>;
}
export declare class IuiAccordionComponent extends CdkAccordionItem implements OnDestroy, AfterContentInit {
    private vcr;
    _portal: TemplatePortal | undefined;
    style: IuiAccordionStyle;
    title: string;
    set skeleton(value: string | boolean | null | undefined);
    get skeleton(): boolean;
    private _skeleton;
    id: string;
    set removeWhenCollapsed(value: string | boolean | null | undefined);
    get removeWhenCollapsed(): boolean;
    private _removeWhenCollapsed;
    protected readonly _destroy: Subject<void>;
    _content: IuiAccordionContent | undefined;
    readonly afterExpand: EventEmitter<void>;
    readonly afterCollapse: EventEmitter<void>;
    readonly _bodyAnimationDone: Subject<AnimationEvent>;
    constructor(accordion: CdkAccordion, _changeDetectorRef: ChangeDetectorRef, _uniqueSelectionDispatcher: UniqueSelectionDispatcher);
    _getExpandedState(): IuiAccordionState;
    _toggle(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiAccordionComponent, [{ optional: true; skipSelf: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiAccordionComponent, "iui-accordion", never, { "style": { "alias": "style"; "required": false; }; "title": { "alias": "title"; "required": false; }; "skeleton": { "alias": "skeleton"; "required": false; }; "id": { "alias": "id"; "required": false; }; "removeWhenCollapsed": { "alias": "removeWhenCollapsed"; "required": false; }; }, { "afterExpand": "afterExpand"; "afterCollapse": "afterCollapse"; }, ["_content"], never, true, never>;
}
