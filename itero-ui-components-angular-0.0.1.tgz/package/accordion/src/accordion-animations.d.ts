import { AnimationTriggerMetadata } from '@angular/animations';
export declare const ACCORDION_ANIMATION_TIMING = "225ms cubic-bezier(0.4,0.0,0.2,1)";
export declare const iuiAccordionAnimations: {
    readonly indicatorRotate: AnimationTriggerMetadata;
    readonly bodyExpansion: AnimationTriggerMetadata;
};
