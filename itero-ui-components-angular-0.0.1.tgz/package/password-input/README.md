# @itero/ui-components-angular/password-input

Secondary entry point of `@itero/ui-components-angular`.

## Import

```typescript
import { IuiPasswordInputComponent } from '@itero/ui-components-angular/password-input';
```

## Basic usage

```html
<iui-password-input label="Password" [formControl]="ctrl">
  <span iui-hint>Must be at least 8 characters</span>
  <span iui-link><a href="/forgot">Forgot password?</a></span>
</iui-password-input>
```

## Inputs

| Input | Type | Default | Description |
|---|---|---|---|
| `id` | `string` | auto-generated | Host element id and `data-testid` |
| `label` | `string` | `''` | Label text. Non-empty value shows the label row. |
| `placeholder` | `string` | `''` | Placeholder for the native input |
| `name` | `string` | `''` | `name` attribute on native input |
| `autocomplete` | `string \| null` | `null` | `autocomplete` attribute (e.g. `'current-password'`) |
| `layerSet` | `'set-01' \| 'set-02'` | `'set-01'` | Background layer variant |
| `required` | `boolean \| string` | auto from validators | Shows asterisk; also sets `required` on native input |
| `skeleton` | `boolean` | `false` | Renders loading skeleton |
| `isDisabled` | `boolean` | `false` | From `IuiIsDisabledDirective` (alternative to `formControl.disable()`) |
| `errorStateMatcher` | `IuiErrorStateMatcher` | default | From `IuiErrorStateMatcherDirective` |

## Content projection slots

| Selector | Description |
|---|---|
| `[iui-hint]` | Helper text shown below field when no error |
| `[iui-error]` | Error text shown below field when error state |
| `[iui-link]` | Link shown in label row right side (e.g. "Forgot password?") |
| `[iui-explainer]` | Optional icon in label row after label text (tooltip trigger) |
