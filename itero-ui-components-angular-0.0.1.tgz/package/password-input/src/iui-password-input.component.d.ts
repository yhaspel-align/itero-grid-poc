import { ChangeDetectorRef, ElementRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import * as i0 from "@angular/core";
import * as i1 from "@itero/ui-components-angular/core";
export type PasswordInputLayerSet = 'set-01' | 'set-02';
type ValueType = string | null;
export declare class IuiPasswordInputComponent implements ControlValueAccessor {
    protected _changeDetectorRef: ChangeDetectorRef;
    protected ngControlDirective: NgControlDirective<ValueType>;
    protected errorStateMatcherDirective: IuiErrorStateMatcherDirective;
    protected isDisabledDirective: IuiIsDisabledDirective;
    /** The ref to the native input element */
    inputElement: ElementRef<HTMLInputElement> | undefined;
    /** Unique id of the element */
    set id(value: string);
    get id(): string;
    /** Label text. Non-empty value shows the label row. */
    label: string;
    /** Placeholder for the native input */
    placeholder: string;
    /** Name attribute on native input */
    name: string;
    /** autocomplete attribute (e.g. 'current-password') */
    autocomplete: string | null;
    /** Background layer variant: 'set-01' (white) or 'set-02' (gray) */
    layerSet: PasswordInputLayerSet;
    /** Whether to show the skeleton loading state */
    skeleton: boolean;
    /** Whether the component is required. */
    get required(): boolean;
    set required(value: string | boolean | null | undefined);
    get _labelId(): string;
    get _inputId(): string;
    get disabled(): boolean;
    get _errorState(): boolean;
    get empty(): boolean;
    /** Current input type: 'password' when hidden, 'text' when visible */
    get _inputType(): 'password' | 'text';
    constructor(_changeDetectorRef: ChangeDetectorRef, ngControlDirective: NgControlDirective<ValueType>, errorStateMatcherDirective: IuiErrorStateMatcherDirective, isDisabledDirective: IuiIsDisabledDirective);
    private __value;
    get _value(): ValueType;
    set _value(newValue: ValueType);
    private _required;
    private __focused;
    _id: string;
    /** Whether the password is shown as plain text */
    _passwordVisible: boolean;
    /** View -> model callback called when value changes */
    _onChange: (value: ValueType) => void;
    /** View -> model callback called when touched */
    _onTouched: () => void;
    get _focused(): boolean;
    _onFocus(): void;
    _onBlur(): void;
    _focusInput(): void;
    _toggleVisibility(event: MouseEvent): void;
    writeValue(value: ValueType): void;
    registerOnChange(fn: (value: ValueType) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    modelChangeHandler(value: ValueType): void;
    private _assignValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiPasswordInputComponent, [null, { self: true; }, { self: true; }, { self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiPasswordInputComponent, "iui-password-input", never, { "id": { "alias": "id"; "required": false; }; "label": { "alias": "label"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "name": { "alias": "name"; "required": false; }; "autocomplete": { "alias": "autocomplete"; "required": false; }; "layerSet": { "alias": "layerSet"; "required": false; }; "skeleton": { "alias": "skeleton"; "required": false; }; "required": { "alias": "required"; "required": false; }; }, {}, never, ["[iui-explainer]", "[iui-link]", "[iui-error]", "[iui-hint]"], true, [{ directive: typeof i1.NgControlDirective; inputs: {}; outputs: {}; }, { directive: typeof i1.IuiErrorStateMatcherDirective; inputs: { "errorStateMatcher": "errorStateMatcher"; }; outputs: {}; }, { directive: typeof i1.IuiIsDisabledDirective; inputs: { "isDisabled": "isDisabled"; }; outputs: { "disableChangeEvent": "disableChangeEvent"; }; }]>;
}
export {};
