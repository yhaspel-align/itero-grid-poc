/**
 * Interface for the grid header component theme.
 * Pass an object implementing this interface to the `[theme]` input of `iui-grid-header`.
 */
export interface GridHeaderTheme {
    /** Panel background color */
    backgroundColor: string;
    /** Primary text and label color */
    textColor: string;
    /** Panel and divider border color */
    borderColor: string;
    /** Font stack for all header text */
    fontFamily: string;
    /** Search / filter input background */
    inputBackground: string;
    /** Input text color */
    inputTextColor: string;
    /** Input default border color */
    inputBorderColor: string;
    /** Input focused border color */
    inputBorderFocusColor: string;
    /** Input focus box-shadow (rgba) */
    inputFocusShadow: string;
    /** Input placeholder text color */
    placeholderColor: string;
    /** Action button background */
    buttonBackground: string;
    /** Action button label color */
    buttonTextColor: string;
    /** Action button border color */
    buttonBorderColor: string;
    /** Action button hover background */
    buttonHoverBackground: string;
    /** Action button hover border color */
    buttonHoverBorderColor: string;
    /** Highlight / active accent color */
    accentColor: string;
}
