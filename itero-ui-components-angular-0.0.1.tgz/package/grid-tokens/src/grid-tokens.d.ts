import { GridHeaderTheme } from './grid-header-theme.model';
/**
 * AG Grid `themeQuartz` params for light mode.
 *
 * @example
 * ```typescript
 * import { themeQuartz, iconSetQuartzLight } from 'ag-grid-community';
 * import { GRID_LIGHT_THEME } from '@itero/ui-components-angular/grid-tokens';
 *
 * export const lightTheme = themeQuartz
 *   .withPart(iconSetQuartzLight)
 *   .withParams(GRID_LIGHT_THEME);
 * ```
 */
export declare const GRID_LIGHT_THEME: {
    backgroundColor: string;
    browserColorScheme: string;
    columnBorder: boolean;
    fontFamily: {
        googleFont: string;
    };
    foregroundColor: string;
    headerBackgroundColor: string;
    headerFontWeight: number;
    headerTextColor: string;
    oddRowBackgroundColor: string;
    rowBorder: boolean;
    sidePanelBorder: boolean;
    spacing: number;
    wrapperBorder: boolean;
    wrapperBorderRadius: number;
};
/**
 * AG Grid `themeQuartz` params for dark mode.
 *
 * @example
 * ```typescript
 * import { themeQuartz } from 'ag-grid-community';
 * import { GRID_DARK_THEME } from '@itero/ui-components-angular/grid-tokens';
 *
 * export const darkTheme = themeQuartz
 *   .withParams(GRID_DARK_THEME);
 * ```
 */
export declare const GRID_DARK_THEME: {
    accentColor: string;
    backgroundColor: string;
    borderColor: string;
    borderRadius: number;
    browserColorScheme: string;
    cellHorizontalPaddingScale: number;
    cellTextColor: string;
    columnBorder: boolean;
    fontFamily: {
        googleFont: string;
    };
    fontSize: number;
    foregroundColor: string;
    headerBackgroundColor: string;
    headerFontWeight: number;
    headerTextColor: string;
    headerVerticalPaddingScale: number;
    oddRowBackgroundColor: string;
    rangeSelectionBackgroundColor: string;
    rangeSelectionBorderColor: string;
    rangeSelectionBorderStyle: string;
    rowBorder: boolean;
    rowVerticalPaddingScale: number;
    sidePanelBorder: boolean;
    spacing: number;
    wrapperBorder: boolean;
    wrapperBorderRadius: number;
};
/**
 * `GridHeaderTheme` values for light mode.
 *
 * @example
 * ```typescript
 * import { GRID_HEADER_LIGHT_THEME } from '@itero/ui-components-angular/grid-tokens';
 *
 * @Component({ template: `<iui-grid-header [theme]="theme">` })
 * export class MyComponent {
 *   readonly theme = GRID_HEADER_LIGHT_THEME;
 * }
 * ```
 */
export declare const GRID_HEADER_LIGHT_THEME: GridHeaderTheme;
/**
 * `GridHeaderTheme` values for dark mode.
 *
 * @example
 * ```typescript
 * import { GRID_HEADER_DARK_THEME } from '@itero/ui-components-angular/grid-tokens';
 *
 * @Component({ template: `<iui-grid-header [theme]="theme">` })
 * export class MyComponent {
 *   readonly theme = GRID_HEADER_DARK_THEME;
 * }
 * ```
 */
export declare const GRID_HEADER_DARK_THEME: GridHeaderTheme;
