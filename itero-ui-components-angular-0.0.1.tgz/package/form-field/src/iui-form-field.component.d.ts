import { AfterViewInit, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { AnimationEvent } from '@angular/animations';
import { NgControlDirective, IuiErrorStateMatcherDirective, IuiIsDisabledDirective } from '@itero/ui-components-angular/core';
import * as i0 from "@angular/core";
export declare class IuiFormFieldComponent implements OnDestroy, AfterViewInit {
    protected ngControlDirective: NgControlDirective<unknown> | null;
    protected errorStateMatcherDirective: IuiErrorStateMatcherDirective | null;
    protected isDisabledDirective: IuiIsDisabledDirective | null;
    /** Id for label inside */
    set labelId(value: string);
    get labelId(): string;
    /** Unique id of the element */
    set id(value: string);
    get id(): string;
    _id: string;
    /** Label of select component, default is '', strongly recommended to be filled */
    label: string;
    private _labelId;
    /** "for" Attribute assigned to label, as a value you should provide Id of your input/combobox component */
    labelFor: string;
    _underlineAnimationState: string;
    _hovered: boolean;
    /** Emits whenever the component is destroyed. */
    protected readonly _destroy: Subject<void>;
    constructor(ngControlDirective: NgControlDirective<unknown> | null, errorStateMatcherDirective: IuiErrorStateMatcherDirective | null, isDisabledDirective: IuiIsDisabledDirective | null);
    /** flag that controls moving label up, when it is clicked, focused, etc. */
    labelAbove: boolean;
    focused: boolean;
    /** Whether the select is disabled. */
    get disabled(): boolean;
    private _required;
    /** Whether the component is required. */
    get required(): boolean;
    set required(value: string | boolean | null | undefined);
    get _labelAbove(): boolean;
    get _errorState(): boolean;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    _handleTransitionMessagesStart(event: AnimationEvent): void;
    _handleTransitionMessagesDone(event: AnimationEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiFormFieldComponent, [{ optional: true; skipSelf: true; }, { optional: true; skipSelf: true; }, { optional: true; skipSelf: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiFormFieldComponent, "iui-form-field", never, { "labelId": { "alias": "labelId"; "required": false; }; "id": { "alias": "id"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelFor": { "alias": "labelFor"; "required": false; }; "labelAbove": { "alias": "labelAbove"; "required": false; }; "focused": { "alias": "focused"; "required": false; }; "required": { "alias": "required"; "required": false; }; }, {}, never, ["*", "[iui-error]", "[iui-hint]"], true, never>;
}
