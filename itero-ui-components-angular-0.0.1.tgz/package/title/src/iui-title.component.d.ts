import * as i0 from "@angular/core";
export type TitleNavigation = 'none' | 'breadcrumbs' | 'stepper';
export interface BreadcrumbItem {
    label: string;
    /**
     * Optional route for Angular Router navigation.
     * When omitted the item renders as plain text (suitable for the current page).
     */
    routerLink?: string | string[];
}
export interface StepItem {
    label: string;
    /** Controls which step indicator icon is displayed. */
    state: 'active' | 'pending' | 'completed';
}
export declare class IuiTitleComponent {
    /** Which navigation sub-section to render above the title row. */
    navigation: TitleNavigation;
    /** Main page heading text. */
    title: string;
    /** Supporting description shown below the title. */
    subtitle: string;
    /** Show the subtitle line. */
    showSubtitle: boolean;
    /** Show the actions area — project content using [iuiTitleActions]. */
    showActions: boolean;
    /** Show the tab strip at the bottom — project content using [iuiTitleTabs]. */
    showTabs: boolean;
    /** Breadcrumb trail — used when navigation is 'breadcrumbs'. */
    breadcrumbs: BreadcrumbItem[];
    /** Step list — used when navigation is 'stepper'. */
    steps: StepItem[];
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiTitleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiTitleComponent, "iui-title", never, { "navigation": { "alias": "navigation"; "required": false; }; "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "showSubtitle": { "alias": "showSubtitle"; "required": false; }; "showActions": { "alias": "showActions"; "required": false; }; "showTabs": { "alias": "showTabs"; "required": false; }; "breadcrumbs": { "alias": "breadcrumbs"; "required": false; }; "steps": { "alias": "steps"; "required": false; }; }, {}, never, ["[iuiTitleActions]", "[iuiTitleTabs]"], true, never>;
}
