import { ElementRef, OnDestroy, ViewContainerRef } from '@angular/core';
import { Overlay } from '@angular/cdk/overlay';
import { IuiMenuComponent } from './iui-menu.component';
import { IuiMenuAlignment, IuiMenuPlacement } from './menu.types';
import * as i0 from "@angular/core";
export declare class IuiMenuTriggerDirective implements OnDestroy {
    private _el;
    private _overlay;
    private _viewContainerRef;
    /** Reference to the IuiMenuComponent to open */
    menuRef: IuiMenuComponent;
    /** Whether the panel opens above or below the trigger */
    menuPlacement: IuiMenuPlacement;
    /** Whether the panel aligns to the start or end of the trigger */
    menuAlignment: IuiMenuAlignment;
    /** Whether the menu overlay is currently open */
    isOpen: boolean;
    private _overlayRef;
    private _closeSub;
    private _detachSub;
    private _keydownSub;
    constructor(_el: ElementRef<HTMLElement>, _overlay: Overlay, _viewContainerRef: ViewContainerRef);
    toggle(): void;
    open(): void;
    close(): void;
    private _getOrCreateOverlay;
    private _buildPositions;
    private _handleKeydown;
    private _getMenuItems;
    private _focusFirstItem;
    private _focusLastItem;
    private _moveFocus;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiMenuTriggerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IuiMenuTriggerDirective, "[iuiMenuTrigger]", ["iuiMenuTrigger"], { "menuRef": { "alias": "iuiMenuTrigger"; "required": false; }; "menuPlacement": { "alias": "menuPlacement"; "required": false; }; "menuAlignment": { "alias": "menuAlignment"; "required": false; }; }, {}, never, never, true, never>;
}
