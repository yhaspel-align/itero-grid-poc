import * as i0 from "@angular/core";
export declare class IuiMenuDividerComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiMenuDividerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiMenuDividerComponent, "iui-menu-divider", never, {}, {}, never, never, true, never>;
}
