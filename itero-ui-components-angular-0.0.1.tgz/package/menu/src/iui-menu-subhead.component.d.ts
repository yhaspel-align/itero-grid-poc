import * as i0 from "@angular/core";
export declare class IuiMenuSubheadComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiMenuSubheadComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiMenuSubheadComponent, "iui-menu-subhead", never, {}, {}, never, ["*"], true, never>;
}
