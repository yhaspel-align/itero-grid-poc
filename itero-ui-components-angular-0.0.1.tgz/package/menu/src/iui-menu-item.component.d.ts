import { EventEmitter } from '@angular/core';
import { IuiSlideToggleEvent } from '@itero/ui-components-angular/slide-toggle';
import { IuiMenuItemType, IuiMenuTrailingType } from './menu.types';
import * as i0 from "@angular/core";
export declare class IuiMenuItemComponent {
    /** Visual type: neutral (default) or destructive (red) */
    type: IuiMenuItemType;
    /** Whether the item is disabled — removes pointer-events and dims text */
    disabled: boolean;
    /** Whether the item shows a checkmark selection indicator */
    selected: boolean;
    /** Optional trailing element type */
    trailing?: IuiMenuTrailingType;
    /** Text label shown when trailing === 'keyboard-shortcut' */
    shortcutLabel: string;
    /** Checked state for the toggle when trailing === 'toggle' */
    toggleValue: boolean;
    /** Emits the new boolean value when the trailing toggle changes */
    toggleChange: EventEmitter<boolean>;
    _onToggleChange(event: IuiSlideToggleEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiMenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiMenuItemComponent, "iui-menu-item", never, { "type": { "alias": "type"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "trailing": { "alias": "trailing"; "required": false; }; "shortcutLabel": { "alias": "shortcutLabel"; "required": false; }; "toggleValue": { "alias": "toggleValue"; "required": false; }; }, { "toggleChange": "toggleChange"; }, never, ["[iuiMenuItemIcon]", "*"], true, never>;
}
