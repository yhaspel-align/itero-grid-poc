import { TemplateRef } from '@angular/core';
import { IuiMenuSize } from './menu.types';
import * as i0 from "@angular/core";
export declare class IuiMenuComponent {
    /** Size of the menu items inside this panel — drives CSS custom property for item height */
    size: IuiMenuSize;
    /** Exposed to IuiMenuTriggerDirective for TemplatePortal rendering */
    templateRef: TemplateRef<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiMenuComponent, "iui-menu", never, { "size": { "alias": "size"; "required": false; }; }, {}, never, ["*"], true, never>;
}
