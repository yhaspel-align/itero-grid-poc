export type IuiMenuItemType = 'neutral' | 'destructive';
export type IuiMenuSize = 'l' | 'm' | 's';
export type IuiMenuPlacement = 'top' | 'bottom';
export type IuiMenuAlignment = 'start' | 'end';
export type IuiMenuTrailingType = 'keyboard-shortcut' | 'toggle' | 'submenu';
