export interface IuiLoadFontsOptions {
    iuiFontsFolder?: string;
}
/**
 * loads fonts from the static server. Extremely helpful for microfrontends, because they know their baseUrl only in runtime.
 * Invoke this function at the start of your application.
 * */
export declare function loadFonts(baseUrl?: string, options?: IuiLoadFontsOptions): Promise<unknown>;
