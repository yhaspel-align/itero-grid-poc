import { ChangeDetectorRef, ElementRef, EventEmitter, NgZone } from '@angular/core';
import { CdkDialogContainer, DialogConfig } from '@angular/cdk/dialog';
import { FocusMonitor, FocusTrapFactory, InteractivityChecker } from '@angular/cdk/a11y';
import { OverlayRef } from '@angular/cdk/overlay';
import { AnimationEvent } from '@angular/animations';
import * as i0 from "@angular/core";
export interface IuiModalWindowAnimationEvent {
    state: 'opened' | 'opening' | 'closing' | 'closed';
    totalTime: number;
}
export declare class IuiModalContainerComponent extends CdkDialogContainer {
    protected readonly _changeDetectorRef: ChangeDetectorRef;
    constructor(elementRef: ElementRef, focusTrapFactory: FocusTrapFactory, _document: any, dialogConfig: DialogConfig, interactivityChecker: InteractivityChecker, ngZone: NgZone, _changeDetectorRef: ChangeDetectorRef, overlayRef: OverlayRef, focusMonitor?: FocusMonitor);
    /** Emits when an animation state changes. */
    _animationStateChanged: EventEmitter<IuiModalWindowAnimationEvent>;
    /** State of the dialog animation. */
    _state: 'void' | 'enter' | 'exit';
    _getAnimationState(): {
        value: "enter" | "void" | "exit";
        params: {
            enterAnimationDuration: string;
            exitAnimationDuration: string;
        };
    };
    /** Callback, invoked when an animation on the host starts. */
    _onAnimationStart({ toState, totalTime }: AnimationEvent): void;
    /** Callback, invoked whenever an animation on the host completes. */
    _onAnimationDone({ toState, totalTime }: AnimationEvent): void;
    protected _openAnimationDone(totalTime: number): void;
    /** Starts the dialog exit animation. */
    _startExitAnimation(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiModalContainerComponent, [null, null, { optional: true; }, null, null, null, null, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiModalContainerComponent, "iui-modal-container", never, {}, {}, never, never, false, never>;
}
