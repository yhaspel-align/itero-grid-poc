import { AnimationTriggerMetadata } from '@angular/animations';
/**
 * Default parameters for the animation for backwards compatibility.
 * @docs-private
 */
export declare const _defaultParams: {
    params: {
        enterAnimationDuration: string;
        exitAnimationDuration: string;
    };
};
export declare const iuiDialogAnimations: {
    readonly dialogContainer: AnimationTriggerMetadata;
};
