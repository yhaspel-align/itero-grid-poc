import * as i0 from "@angular/core";
export declare class IuiModalFooterComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiModalFooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiModalFooterComponent, "iui-modal-footer", never, {}, {}, never, ["[left-buttons]", "[right-buttons]", "*"], false, never>;
}
