import * as i0 from "@angular/core";
export declare class IuiModalContentComponent {
    set padding(value: number);
    _padding: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiModalContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiModalContentComponent, "iui-modal-content", never, { "padding": { "alias": "padding"; "required": false; }; }, {}, never, ["*"], false, never>;
}
