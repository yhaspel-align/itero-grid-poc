import { ElementRef, OnInit } from '@angular/core';
import { IuiModalWindowService } from '../iui-modal-window.service';
import { DialogRef } from '@angular/cdk/dialog';
import * as i0 from "@angular/core";
export declare class IuiModalHeaderComponent implements OnInit {
    private _dialogRef;
    private _elementRef;
    private _dialog;
    id: string;
    /** Optional description text displayed below the title. */
    description: string | undefined;
    /** Whether to show the built-in close button. Default: true */
    showCloseButton: boolean;
    constructor(_dialogRef: DialogRef<any> | undefined | null, _elementRef: ElementRef<HTMLElement>, _dialog: IuiModalWindowService);
    ngOnInit(): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiModalHeaderComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IuiModalHeaderComponent, "iui-modal-header", never, { "id": { "alias": "id"; "required": false; }; "description": { "alias": "description"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; }, {}, never, ["[left-icon]", "*", "[right-icon]"], false, never>;
}
