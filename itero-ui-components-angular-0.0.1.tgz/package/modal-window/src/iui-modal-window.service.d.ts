import { InjectionToken, OnDestroy, TemplateRef } from '@angular/core';
import { Dialog, DialogConfig, DialogRef } from '@angular/cdk/dialog';
import { ComponentType, Overlay, OverlayRef } from '@angular/cdk/overlay';
import { BasePortalOutlet } from '@angular/cdk/portal';
import * as i0 from "@angular/core";
export declare const IUI_MODAL_WINDOW_DATA: InjectionToken<unknown>;
export type IuiModalSize = 'sm' | 'md' | 'lg' | 'xl';
export interface IuiModalWindowConfig<D = unknown> extends DialogConfig<D> {
    /** Modal width preset. Default: 'md' (656px). */
    size?: IuiModalSize;
}
export declare class IuiModalWindowRef<R = unknown, C = unknown> extends DialogRef<R, C> {
    constructor(overlayRef: OverlayRef, config: DialogConfig<any, IuiModalWindowRef<R, C>, BasePortalOutlet>);
}
export declare class IuiModalWindowService implements OnDestroy {
    private dialog;
    private _overlay;
    constructor(dialog: Dialog, _overlay: Overlay);
    readonly afterAllClosed: import("rxjs").Observable<void>;
    private _defaultOptions;
    protected _idPrefix: string;
    private _sizePanelClassMap;
    /**
     * Opens a modal dialog containing the given component.
     * @param component Type of the component to load into the dialog.
     * @param config Extra configuration options.
     * @returns Reference to the newly-opened dialog.
     */
    open<R = unknown, D = unknown, C = unknown>(component: ComponentType<C>, config?: IuiModalWindowConfig<D>): DialogRef<R, C>;
    /**
     * Opens a modal dialog containing the given template.
     * @param template TemplateRef to instantiate as the dialog content.
     * @param config Extra configuration options.
     * @returns Reference to the newly-opened dialog.
     */
    open<R = unknown, D = unknown, C = unknown>(template: TemplateRef<C>, config?: IuiModalWindowConfig<D>): DialogRef<R, C>;
    open<R = unknown, D = unknown, C = unknown>(componentOrTemplateRef: ComponentType<C> | TemplateRef<C>, config?: IuiModalWindowConfig<D>): DialogRef<R, C>;
    /**
     * Closes all the currently-open dialogs.
     */
    closeAll(): void;
    /**
     * Finds an open dialog by its id.
     * @param id ID to use when looking up the dialog.
     */
    getDialogById<R, C>(id: string): DialogRef<R, C> | undefined;
    get openDialogs(): readonly DialogRef<any, any>[];
    get afterOpened(): import("rxjs").Subject<DialogRef<any, any>>;
    /**
     * Call onDestroy method in yours microfrontend's app.component to remove pendiing subscriptions and opened dialogs
     * Otherwise it wont be destroyed because of microfrontend architecture
     * */
    ngOnDestroy(): void;
    /**
     * Returns the size panel class if applicable.
     * If an explicit width is set, no size class is applied (backwards compat).
     * If no size and no explicit width, defaults to 'md'.
     */
    private _resolveSizePanelClass;
    private _definePanelClasses;
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiModalWindowService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IuiModalWindowService>;
}
