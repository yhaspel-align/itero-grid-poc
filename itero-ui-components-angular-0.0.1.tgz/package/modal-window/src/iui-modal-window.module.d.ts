import * as i0 from "@angular/core";
import * as i1 from "./modal-container/iui-modal-container.component";
import * as i2 from "./modal-header/iui-modal-header.component";
import * as i3 from "./modal-footer/iui-modal-footer.component";
import * as i4 from "./modal-content/iui-modal-content.component";
import * as i5 from "@angular/cdk/dialog";
import * as i6 from "@angular/cdk/overlay";
import * as i7 from "@angular/cdk/portal";
import * as i8 from "@angular/common";
export declare class IuiModalWindowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<IuiModalWindowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<IuiModalWindowModule, [typeof i1.IuiModalContainerComponent, typeof i2.IuiModalHeaderComponent, typeof i3.IuiModalFooterComponent, typeof i4.IuiModalContentComponent], [typeof i5.DialogModule, typeof i6.OverlayModule, typeof i7.PortalModule, typeof i8.CommonModule], [typeof i1.IuiModalContainerComponent, typeof i2.IuiModalHeaderComponent, typeof i3.IuiModalFooterComponent, typeof i4.IuiModalContentComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<IuiModalWindowModule>;
}
